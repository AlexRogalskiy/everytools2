package com.iluwatar.testdomain;

public class PhoneNumber {
    private String number;
}
