/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Apply defaults for IPv6 TCP over IPv4 (6to4) for traceroute.
int
sixto4_tcp6_tr_default (SPSData *data)
{
  int status, *ip4_flags;

  // IPv4 header fragmentation flags and offset
  ip4_flags = allocate_intmem (4);

  // Number of ethernet frames
  data->nframes[15] = 1;

  // Ethernet header
  
  // Set flag for user to specify ethernet header.
  data->specify_ether[15] = 1;

  // Default interface MTU
  data->ifmtu[15] = 1280;

  // Destination link-layer (MAC) address (48 bits): N/A
  // Address from IPv6 TCP traceroute page will be used.

  // Source Interface Name: N/A
  // Interface name from IPv6 TCP traceroute page will be used.

  // Source link-layer (MAC) address (48 bits): N/A
  // Address from IPv6 TCP traceroute page will be used.

  // Ethernet type code (16 bits): IPv4
  // http://www.iana.org/assignments/ethernet-numbers
  data->ethhdr[15].type_code = htons (ETH_P_IP);

  // IPv4 header for tunnelling IPv6 over IPv4 (6to4) (Section 3.5 of RFC 4213)

  // IPv4 header length (4 bits): Number of 32-bit words in header = 5
  data->ip4hdr[15].ip_hl = IP4_HDRLEN / sizeof (uint32_t);

  // Internet Protocol version (4 bits): IPv4
  data->ip4hdr[15].ip_v = 4u;

  // Type of service (8 bits)
  data->ip4hdr[15].ip_tos = 0;

  // Total length of datagram (16 bits): IPv4 header + IPv6 header + IPv6 payload length
  // Assumes neither IPv4 header options nor TCP options.
  data->ip4hdr[15].ip_len = htons (IP4_HDRLEN + IP6_HDRLEN + TCP_HDRLEN + data->payloadlen[12]);

  // ID sequence number (16 bits): unused, since single datagram
  data->ip4hdr[15].ip_id = htons (31415);

  // Flags, and Fragmentation offset (3, 13 bits): 0 since single datagram
  ip4_flags[0] = 0;  // Zero (1 bit)
  ip4_flags[1] = 0;  // Do not fragment flag (1 bit): 0 (see Section 3.2.1 of RFC 4213)
  ip4_flags[2] = 0;  // More fragments following flag (1 bit)
  ip4_flags[3] = 0;  // Fragmentation offset (13 bits)
  data->ip4hdr[15].ip_off = htons ((ip4_flags[0] << 15) + (ip4_flags[1] << 14) +
    (ip4_flags[2] << 13) + ip4_flags[3]);

  // Time-to-Live (8 bits): use maximum value
  data->ip4hdr[15].ip_ttl = 255u;

  // Transport layer protocol (8 bits): 41 for IPv6 (Section 3.5 of RFC 4213)
  data->ip4hdr[15].ip_p = IPPROTO_IPV6;

  // Source IPv4 address (32 bits): default to loopback
  if ((status = inet_pton (AF_INET, "127.0.0.1", &(data->ip4hdr[15].ip_src))) != 1) {
    sprintf (data->error_text, "sixto4_tcp6_tr_default(): inet_pton() failed for source IPv4 address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    return (EXIT_FAILURE);
  }

  // Destination IPv4 address (32 bits): 6to4 anycast address
  if ((status = inet_pton (AF_INET, "192.88.99.1", &(data->ip4hdr[15].ip_dst))) != 1) {
    sprintf (data->error_text, "sixto4_tcp6_tr_default(): inet_pton() failed for destination IPv4 address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    return (EXIT_FAILURE);
  }

  // IPv4 header checksum (16 bits): set to 0 when calculating checksum
  data->ip4hdr[15].ip_sum = 0;
  data->ip4hdr[15].ip_sum = checksum ((uint16_t *) &data->ip4hdr[15], IP4_HDRLEN);

  // Free allocated memory.
  free (ip4_flags);

  // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
  memcpy (&data->ip6hdr[15], &data->ip6hdr[12], IP6_HDRLEN * sizeof (uint8_t));

  // Update ethernet frame.
  create_6to4_frame (15, data);

  return (EXIT_SUCCESS);
}

// Apply defaults for IPv6 ICMP over IPv4 (6to4) for traceroute.
int
sixto4_icmp6_tr_default (SPSData *data)
{
  int status, *ip4_flags;

  // IPv4 header fragmentation flags and offset
  ip4_flags = allocate_intmem (4);

  // Number of ethernet frames
  data->nframes[16] = 1;

  // Ethernet header
  
  // Set flag for user to specify ethernet header.
  data->specify_ether[16] = 1;

  // Default interface MTU
  data->ifmtu[16] = 1280;

  // Destination link-layer (MAC) address (48 bits): N/A
  // Address from IPv6 ICMP traceroute page will be used.

  // Source Interface Name: N/A
  // Interface name from IPv6 ICMP traceroute page will be used.

  // Source link-layer (MAC) address (48 bits): N/A
  // Address from IPv6 ICMP traceroute page will be used.

  // Ethernet type code (16 bits): IPv4
  // http://www.iana.org/assignments/ethernet-numbers
  data->ethhdr[16].type_code = htons (ETH_P_IP);

  // IPv4 header for tunnelling IPv6 over IPv4 (6to4) (Section 3.5 of RFC 4213)

  // IPv4 header length (4 bits): Number of 32-bit words in header = 5
  data->ip4hdr[16].ip_hl = IP4_HDRLEN / sizeof (uint32_t);

  // Internet Protocol version (4 bits): IPv4
  data->ip4hdr[16].ip_v = 4u;

  // Type of service (8 bits)
  data->ip4hdr[16].ip_tos = 0;

  // Total length of datagram (16 bits): IPv4 header + IPv6 header + IPv6 payload length
  // Assumes no IPv4 header options.
  data->ip4hdr[16].ip_len = htons (IP4_HDRLEN + IP6_HDRLEN + ICMP_HDRLEN + data->payloadlen[13]);

  // ID sequence number (16 bits): unused, since single datagram
  data->ip4hdr[16].ip_id = htons (31415);

  // Flags, and Fragmentation offset (3, 13 bits): 0 since single datagram
  ip4_flags[0] = 0;  // Zero (1 bit)
  ip4_flags[1] = 0;  // Do not fragment flag (1 bit): 0 (see Section 3.2.1 of RFC 4213)
  ip4_flags[2] = 0;  // More fragments following flag (1 bit)
  ip4_flags[3] = 0;  // Fragmentation offset (13 bits)
  data->ip4hdr[16].ip_off = htons ((ip4_flags[0] << 15) + (ip4_flags[1] << 14) +
    (ip4_flags[2] << 13) + ip4_flags[3]);

  // Time-to-Live (8 bits): use maximum value
  data->ip4hdr[16].ip_ttl = 255u;

  // Transport layer protocol (8 bits): 41 for IPv6 (Section 3.5 of RFC 4213)
  data->ip4hdr[16].ip_p = IPPROTO_IPV6;

  // Source IPv4 address (32 bits): default to loopback
  if ((status = inet_pton (AF_INET, "127.0.0.1", &(data->ip4hdr[16].ip_src))) != 1) {
    sprintf (data->error_text, "sixto4_icmp6_tr_default(): inet_pton() failed for source IPv4 address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    return (EXIT_FAILURE);
  }

  // Destination IPv4 address (32 bits): 6to4 anycast address
  if ((status = inet_pton (AF_INET, "192.88.99.1", &(data->ip4hdr[16].ip_dst))) != 1) {
    sprintf (data->error_text, "sixto4_icmp6_tr_default(): inet_pton() failed for destination IPv4 address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    return (EXIT_FAILURE);
  }

  // IPv4 header checksum (16 bits): set to 0 when calculating checksum
  data->ip4hdr[16].ip_sum = 0;
  data->ip4hdr[16].ip_sum = checksum ((uint16_t *) &data->ip4hdr[16], IP4_HDRLEN);

  // Free allocated memory.
  free (ip4_flags);

  // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
  memcpy (&data->ip6hdr[16], &data->ip6hdr[13], IP6_HDRLEN * sizeof (uint8_t));

  // Update ethernet frame.
  create_6to4_frame (16, data);

  return (EXIT_SUCCESS);
}

// Apply defaults for IPv6 UDP over IPv4 (6to4) for traceroute.
int
sixto4_udp6_tr_default (SPSData *data)
{
  int status, *ip4_flags;

  // IPv4 header fragmentation flags and offset
  ip4_flags = allocate_intmem (4);

  // Number of ethernet frames
  data->nframes[17] = 1;

  // Ethernet header
  
  // Set flag for user to specify ethernet header.
  data->specify_ether[17] = 1;

  // Default interface MTU
  data->ifmtu[17] = 1280;

  // Destination link-layer (MAC) address (48 bits): N/A
  // Address from IPv6 UDP traceroute page will be used.

  // Source Interface Name: N/A
  // Interface name from IPv6 UDP traceroute page will be used.

  // Source link-layer (MAC) address (48 bits): N/A
  // Address from IPv6 UDP traceroute page will be used.

  // Ethernet type code (16 bits): IPv4
  // http://www.iana.org/assignments/ethernet-numbers
  data->ethhdr[17].type_code = htons (ETH_P_IP);

  // IPv4 header for tunnelling IPv6 over IPv4 (6to4) (Section 3.5 of RFC 4213)

  // IPv4 header length (4 bits): Number of 32-bit words in header = 5
  data->ip4hdr[17].ip_hl = IP4_HDRLEN / sizeof (uint32_t);

  // Internet Protocol version (4 bits): IPv4
  data->ip4hdr[17].ip_v = 4u;

  // Type of service (8 bits)
  data->ip4hdr[17].ip_tos = 0;

  // Total length of datagram (16 bits): IPv4 header + IPv6 header + IPv6 payload length
  // Assumes no IPv4 header options.
  data->ip4hdr[17].ip_len = htons (IP4_HDRLEN + IP6_HDRLEN + UDP_HDRLEN + data->payloadlen[14]);

  // ID sequence number (16 bits): unused, since single datagram
  data->ip4hdr[17].ip_id = htons (31415);

  // Flags, and Fragmentation offset (3, 13 bits): 0 since single datagram
  ip4_flags[0] = 0;  // Zero (1 bit)
  ip4_flags[1] = 0;  // Do not fragment flag (1 bit): 0 (see Section 3.2.1 of RFC 4213)
  ip4_flags[2] = 0;  // More fragments following flag (1 bit)
  ip4_flags[3] = 0;  // Fragmentation offset (13 bits)
  data->ip4hdr[17].ip_off = htons ((ip4_flags[0] << 15) + (ip4_flags[1] << 14) +
    (ip4_flags[2] << 13) + ip4_flags[3]);

  // Time-to-Live (8 bits): use maximum value
  data->ip4hdr[17].ip_ttl = 255u;

  // Transport layer protocol (8 bits): 41 for IPv6 (Section 3.5 of RFC 4213)
  data->ip4hdr[17].ip_p = IPPROTO_IPV6;

  // Source IPv4 address (32 bits): default to loopback
  if ((status = inet_pton (AF_INET, "127.0.0.1", &(data->ip4hdr[17].ip_src))) != 1) {
    sprintf (data->error_text, "sixto4_udp6_tr_default(): inet_pton() failed for source IPv4 address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    return (EXIT_FAILURE);
  }

  // Destination IPv4 address (32 bits): 6to4 anycast address
  if ((status = inet_pton (AF_INET, "192.88.99.1", &(data->ip4hdr[17].ip_dst))) != 1) {
    sprintf (data->error_text, "sixto4_udp6_tr_default(): inet_pton() failed for destination IPv4 address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    return (EXIT_FAILURE);
  }

  // IPv4 header checksum (16 bits): set to 0 when calculating checksum
  data->ip4hdr[17].ip_sum = 0;
  data->ip4hdr[17].ip_sum = checksum ((uint16_t *) &data->ip4hdr[17], IP4_HDRLEN);

  // Free allocated memory.
  free (ip4_flags);

  // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
  memcpy (&data->ip6hdr[17], &data->ip6hdr[14], IP6_HDRLEN * sizeof (uint8_t));

  // Update ethernet frame.
  create_6to4_frame (17, data);

  return (EXIT_SUCCESS);
}
