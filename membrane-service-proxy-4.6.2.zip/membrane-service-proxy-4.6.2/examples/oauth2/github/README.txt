This example shows OAuth2 authorization with help of Github as authorization server.

Please follow https://www.membrane-soa.org/service-proxy-doc/4.4/oauth2-github.htm