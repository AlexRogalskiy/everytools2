# Apache Tika Examples

Some examples on content extraction on different file formats using Apache Tika.

Please feel free to visit [my blog] for the full tutorial.

---

**2012 Micha Kops / hasCode.com**

   [my blog]:http://www.hascode.com
