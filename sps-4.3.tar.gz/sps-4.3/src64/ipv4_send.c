/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

extern int flood_mode;  // Flood flag
extern int sending;  // Sending flag for sending finite number of packets

G_LOCK_EXTERN (sending);  // MUTEX for flag indicating packets are being sent

// Send IPv4 packet(s)
// This function will be executed as a separate thread spawned by on_button1_clicked().
int
ipv4_send (SPSData *data)
{
  int status;
  uint64_t i;  // unsigned 64-bit integer for number of packets to send
  int j, frame, sd_tcp, sd_icmp, sd_udp;
  char *ipaddress, *message;
  const int on = 1;
  struct sockaddr_in tcp_sin, icmp_sin, udp_sin;
  struct sockaddr_ll tcp_device, icmp_device, udp_device;
  Msgdata *msgdata;

  // This state can be changed by on_button5_clicked()
  // as will flood_mode.
  G_LOCK (sending);
  sending = 1;
  G_UNLOCK (sending);

  // Allocate memory for message local character string.
  message = allocate_strmem (TEXT_STRINGLEN);

  // Grab system date and time.
  message = date_and_time (message, TEXT_STRINGLEN);

  // Display packet activity in Activity Log.
  if (flood_mode) {
    sprintf (message, "%s Flooding ", message);
  } else {
    sprintf (message, "%s Sending ", message);
  }
  if (data->packet_type == 0) {
    sprintf (message, "%sIPv4 TCP ethernet frames.\n", message);
  } else if (data->packet_type == 1) {
    sprintf (message, "%sIPv4 ICMP ethernet frames.\n", message);
  } else if (data->packet_type == 2) {
    sprintf (message, "%sIPv4 UDP ethernet frames.\n", message);
  } else if (data->packet_type == 100) {
    sprintf (message, "%sIPv4 TCP+ICMP+UDP ethernet frames.\n", message);
  } else {
    fprintf (stderr, "ERROR: Invalid upper layer protocol type %i in ipv4_send().\n", data->packet_type);
    free (message);
    exit (EXIT_FAILURE);
  }

  // Have idle function post message to UI.
  // strdup() allocates memory for message on the heap using malloc().
  msgdata = allocate_msgdata (1);
  msgdata->textview = data->textview1;
  g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));

  // Array to hold an IPv4 or IPv6 address + '\0'
  ipaddress = allocate_strmem (INET6_ADDRSTRLEN);

  // Make sure all interfaces were specified
  if ((((data->packet_type == 0) || (data->packet_type == 100)) && (data->specify_ether[0] &&
       (strnlen (data->ifname[0], TMP_STRINGLEN) < 2))) ||
      (((data->packet_type == 1) || (data->packet_type == 100)) && (data->specify_ether[1] &&
       (strnlen (data->ifname[1], TMP_STRINGLEN) < 2))) ||
      (((data->packet_type == 2) || (data->packet_type == 100)) && (data->specify_ether[2] &&
       (strnlen (data->ifname[2], TMP_STRINGLEN) < 2)))) {
    sprintf (data->error_text, "ipv4_send(): Appears to be an invalid interface name.");
    data->parent = data->main_window;
    send_error ();
    free (message);
    free (ipaddress);
    return (EXIT_FAILURE);
  }

  // Resolve interface index.
  memset (&tcp_device, 0, sizeof (tcp_device));
  memset (&icmp_device, 0, sizeof (icmp_device));
  memset (&udp_device, 0, sizeof (udp_device));

  // TCP
  if (data->specify_ether[0] && ((data->packet_type == 0) || (data->packet_type == 100))) {
    if ((tcp_device.sll_ifindex = if_nametoindex (data->ifname[0])) == 0) {
      status = errno;
      sprintf (data->error_text, "ipv4_send(): if_nametoindex() failed to obtain interface index for TCP.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      send_error ();
      free (message);
      free (ipaddress);
      return (EXIT_FAILURE);
    }
  }

  // ICMP
  if (data->specify_ether[1] && ((data->packet_type == 1) || (data->packet_type == 100))) {
    if ((icmp_device.sll_ifindex = if_nametoindex (data->ifname[1])) == 0) {
      status = errno;
      sprintf (data->error_text, "ipv4_send(): if_nametoindex() failed to obtain interface index for ICMP.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      send_error ();
      free (message);
      free (ipaddress);
      return (EXIT_FAILURE);
    }
  }

  // UDP
  if (data->specify_ether[2] && ((data->packet_type == 2) || (data->packet_type == 100))) {
    if ((udp_device.sll_ifindex = if_nametoindex (data->ifname[2])) == 0) {
      status = errno;
      sprintf (data->error_text, "ipv4_send(): if_nametoindex() failed to obtain interface index for UDP.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      send_error ();
      free (message);
      free (ipaddress);
      return (EXIT_FAILURE);
    }
  }

  // Fill out sockaddr_ll.
  tcp_device.sll_family = AF_PACKET;
  memcpy (tcp_device.sll_addr, data->ethhdr[0].src_mac, 6 * sizeof (uint8_t));
  tcp_device.sll_halen = 6u;

  icmp_device.sll_family = AF_PACKET;
  memcpy (icmp_device.sll_addr, data->ethhdr[1].src_mac, 6 * sizeof (uint8_t));
  icmp_device.sll_halen = 6u;

  udp_device.sll_family = AF_PACKET;
  memcpy (udp_device.sll_addr, data->ethhdr[2].src_mac, 6 * sizeof (uint8_t));
  udp_device.sll_halen = 6u;

  // For packets (no ethernet header):
  // The kernel will provide Layer 2 (data link layer) information (MAC addresses).
  // To do that, we need to specify a destination for the kernel in order for it
  // to decide where to send the raw datagram. We fill in a struct in_addr with
  // the desired destination IP address, and pass this structure to the sendto() function.
  memset (&tcp_sin, 0, sizeof (tcp_sin));
  tcp_sin.sin_family = AF_INET;
  tcp_sin.sin_addr.s_addr = data->ip4hdr[0].ip_dst.s_addr;

  memset (&icmp_sin, 0, sizeof (icmp_sin));
  icmp_sin.sin_family = AF_INET;
  icmp_sin.sin_addr.s_addr = data->ip4hdr[1].ip_dst.s_addr;

  memset (&udp_sin, 0, sizeof (udp_sin));
  udp_sin.sin_family = AF_INET;
  udp_sin.sin_addr.s_addr = data->ip4hdr[2].ip_dst.s_addr;

  i = data->npackets;  // Number of packets to send
  j = 0;               // Number of packets sent

  // Submit requests for raw socket descriptors.
  // Separate descriptors for TCP, ICMP, and UDP since we may use difference ethernet headers and interfaces.
  sd_tcp = -1;  // Initially set to invalid socket descriptor.
  sd_icmp = -1;  // Initially set to invalid socket descriptor.
  sd_udp = -1;  // Initially set to invalid socket descriptor.

  // TCP
  if ((data->packet_type == 0) || (data->packet_type == 100)) {
    if (data->specify_ether[0]) {
      if ((sd_tcp = socket (PF_PACKET, SOCK_RAW, htons (ETH_P_ALL))) < 0) {
        status = errno;
        sprintf (data->error_text, "ipv4_send(): socket() failed to get a socket descriptor for TCP.\nError message: %s", strerror (status));
        data->parent = data->main_window;
        send_error ();
        free (message);
        free (ipaddress);
        return (EXIT_FAILURE);
      }
    } else {
      if ((sd_tcp = socket (AF_INET, SOCK_RAW, IPPROTO_RAW)) < 0) {
        status = errno;
        sprintf (data->error_text, "ipv4_send(): socket() failed to get a socket descriptor for TCP.\nError message: %s", strerror (status));
        data->parent = data->main_window;
        send_error ();
        free (message);
        free (ipaddress);
        return (EXIT_FAILURE);

      } else {
        // Set flag so socket expects us to provide IPv4 header.
        if (setsockopt (sd_tcp, IPPROTO_IP, IP_HDRINCL, &on, sizeof (on)) < 0) {
          status = errno;
          sprintf (data->error_text, "ipv4_send(): setsockopt() failed to set IP_HDRINCL for TCP socket.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }
    }
  }

  // ICMP
  if ((data->packet_type == 1) || (data->packet_type == 100)) {

    if (data->specify_ether[1]) {

      if ((sd_icmp = socket (PF_PACKET, SOCK_RAW, htons (ETH_P_ALL))) < 0) {
        status = errno;
        sprintf (data->error_text, "ipv4_send(): socket() failed to get a socket descriptor for ICMP.\nError message: %s", strerror (status));
        data->parent = data->main_window;
        send_error ();
        free (message);
        free (ipaddress);
        return (EXIT_FAILURE);
      }
    } else {
      if ((sd_icmp = socket (AF_INET, SOCK_RAW, IPPROTO_RAW)) < 0) {
        status = errno;
        sprintf (data->error_text, "ipv4_send(): socket() failed to get a socket descriptor for ICMP.\nError message: %s", strerror (status));
        data->parent = data->main_window;
        send_error ();
        free (message);
        free (ipaddress);
        return (EXIT_FAILURE);

      } else {
        // Set flag so socket expects us to provide IPv4 header.
        if (setsockopt (sd_icmp, IPPROTO_IP, IP_HDRINCL, &on, sizeof (on)) < 0) {
          status = errno;
          sprintf (data->error_text, "ipv4_send(): setsockopt() failed to set IP_HDRINCL for ICMP socket.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }
    }
  }

  // UDP
  if ((data->packet_type == 2) || (data->packet_type == 100)) {
    if (data->specify_ether[2]) {
      if ((sd_udp = socket (PF_PACKET, SOCK_RAW, htons (ETH_P_ALL))) < 0) {
        status = errno;
        sprintf (data->error_text, "ipv4_send: socket() failed to get a socket descriptor for UDP.\nError message: %s", strerror (status));
        data->parent = data->main_window;
        send_error ();
        free (message);
        free (ipaddress);
        return (EXIT_FAILURE);
      }
    } else {
      if ((sd_udp = socket (AF_INET, SOCK_RAW, IPPROTO_RAW)) < 0) {
        status = errno;
        sprintf (data->error_text, "ipv4_send(): socket() failed to get a socket descriptor for UDP.\nError message: %s", strerror (status));
        data->parent = data->main_window;
        send_error ();
        free (message);
        free (ipaddress);
        return (EXIT_FAILURE);

      } else {
        // Set flag so socket expects us to provide IPv4 header.
        if (setsockopt (sd_udp, IPPROTO_IP, IP_HDRINCL, &on, sizeof (on)) < 0) {
          status = errno;
          sprintf (data->error_text, "ipv4_send(): setsockopt() failed to set IP_HDRINCL for UDP socket.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }
    }
  }

  // Send TCP packet(s)
  if (data->packet_type == 0) {

    while ((i > 0ull) && sending) {

      for (frame=0; frame<data->nframes[0]; frame++) {

        if (data->specify_ether[0]) {

          if ((sendto (sd_tcp, data->ether_frame[0][frame], data->frame_length[0][frame], 0, (struct sockaddr *) &tcp_device, sizeof (tcp_device))) <= 0) {
            status = errno;
            sprintf (data->error_text, "ipv4_send(): sendto() failed for TCP.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            send_error ();
            free (message);
            free (ipaddress);
            return (EXIT_FAILURE);
          }
        } else {
          if (sendto (sd_tcp, data->ether_frame[0][frame] + ETH_HDRLEN, data->frame_length[0][frame] - ETH_HDRLEN, 0, (struct sockaddr *) &tcp_sin, sizeof (struct sockaddr)) < 0)  {
            status = errno;
            sprintf (data->error_text, "ipv4_send(): sendto() failed for TCP.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            send_error ();
            free (message);
            free (ipaddress);
            return (EXIT_FAILURE);
          }
        }
      }

      if (!flood_mode) i--;
      j++;

      // Randomize source IPv4 address if requested.
      if (data->ran_tcp4_sourceip) {
        if ((status = inet_pton (AF_INET, ran4_addr (ipaddress, data), &data->ip4hdr[0].ip_src)) != 1) {
          sprintf (data->error_text, "ipv4_send(): inet_pton() failed for randomized TCP source IP address.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }

      // Randomize source port if requested.
      if (data->ran_tcp4_sourceport) {
        data->tcphdr[0].th_sport = htons (ran16_0to65535 (data));
      }

      // Re-calculate IPv4 and upper layer protocol checksum
      // regardless of whether source IP and/or port was changed.

      // TCP header checksum (16 bits)
      data->tcphdr[0].th_sum = tcp4_checksum (data->ip4hdr[0], data->tcphdr[0], data->tcp_nopt[0], data->tcp_opt_totlen[0], data->tcp_optlen[0], data->tcp_options[0], data->tcp_optpadlen[0], data->payload[0], data->payloadlen[0]);

      // IPv4 header checksum (16 bits): set to 0 when calculating checksum
      data->ip4hdr[0].ip_sum = 0;
      data->ip4hdr[0].ip_sum = ip4_checksum (data->ip4hdr[0], data->ip_nopt[0], data->ip_optlen[0], data->ip_options[0], data->ip_optpadlen[0]);

      // Update ethernet frame.
      create_ip4_frame (0, data);
    }
    close (sd_tcp);

  // Send ICMP packet(s)
  } else if (data->packet_type == 1) {

    while ((i > 0ull) && sending) {

      for (frame=0; frame<data->nframes[1]; frame++) {

        if (data->specify_ether[1]) {

          if ((sendto (sd_icmp, data->ether_frame[1][frame], data->frame_length[1][frame], 0, (struct sockaddr *) &icmp_device, sizeof (icmp_device))) <= 0) {
            status = errno;
            sprintf (data->error_text, "ipv4_send(): sendto() failed for ICMP.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            send_error ();
            free (message);
            free (ipaddress);
            return (EXIT_FAILURE);
          }
        } else {
          if (sendto (sd_icmp, data->ether_frame[1][frame] + ETH_HDRLEN, data->frame_length[1][frame] - ETH_HDRLEN, 0, (struct sockaddr *) &icmp_sin, sizeof (struct sockaddr)) < 0)  {
            status = errno;
            sprintf (data->error_text, "ipv4_send(): sendto() failed for ICMP.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            send_error ();
            free (message);
            free (ipaddress);
            return (EXIT_FAILURE);
          }
        }
      }

      if (!flood_mode) i--;
      j++;

      // Randomize source IPv4 address if requested.
      if (data->ran_icmp4_sourceip) {
        if ((status = inet_pton (AF_INET, ran4_addr (ipaddress, data), &data->ip4hdr[1].ip_src)) != 1) {
          sprintf (data->error_text, "ipv4_send(): inet_pton() failed for randomized ICMP source IP address.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }

        // IPv4 header checksum (16 bits): set to 0 when calculating checksum
        data->ip4hdr[1].ip_sum = 0;
        data->ip4hdr[1].ip_sum = ip4_checksum (data->ip4hdr[1], data->ip_nopt[1], data->ip_optlen[1], data->ip_options[1], data->ip_optpadlen[1]);

        // Update ethernet frame.
        create_ip4_frame (1, data);
      }
    }
    close (sd_icmp);

  // Send UDP packet(s)
  } else if (data->packet_type == 2) {

    while ((i > 0ull) && sending) {

      for (frame=0; frame<data->nframes[2]; frame++) {

        if (data->specify_ether[2]) {

          if ((sendto (sd_udp, data->ether_frame[2][frame], data->frame_length[2][frame], 0, (struct sockaddr *) &udp_device, sizeof (udp_device))) <= 0) {
            status = errno;
            sprintf (data->error_text, "ipv4_send(): sendto() failed for UDP.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            send_error ();
            free (message);
            free (ipaddress);
            return (EXIT_FAILURE);
          }
        } else {
          if (sendto (sd_udp, data->ether_frame[2][frame] + ETH_HDRLEN, data->frame_length[2][frame] - ETH_HDRLEN, 0, (struct sockaddr *) &udp_sin, sizeof (struct sockaddr)) < 0)  {
            status = errno;
            sprintf (data->error_text, "ipv4_send(): sendto() failed for UDP.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            send_error ();
            free (message);
            free (ipaddress);
            return (EXIT_FAILURE);
          }
        }
      }

      if (!flood_mode) i--;
      j++;

      // Randomize source IPv4 address if requested.
      if (data->ran_udp4_sourceip) {
        if ((status = inet_pton (AF_INET, ran4_addr (ipaddress, data), &data->ip4hdr[2].ip_src)) != 1) {
          sprintf (data->error_text, "ipv4_send(): inet_pton() failed for randomized UDP source IP address.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }

      // Randomize source port if requested.
      if (data->ran_udp4_sourceport) {
        data->udphdr[2].uh_sport = htons (ran16_0to65535 (data));
      }

      // Re-calculate IPv4 and upper layer protocol checksum
      // regardless of whether source IP and/or port was changed.

      // UDP header checksum (16 bits)
      data->udphdr[2].uh_sum = udp4_checksum (data->ip4hdr[2], data->udphdr[2], data->payload[2], data->payloadlen[2]);

      // IPv4 header checksum (16 bits): set to 0 when calculating checksum
      data->ip4hdr[2].ip_sum = 0;
      data->ip4hdr[2].ip_sum = ip4_checksum (data->ip4hdr[2], data->ip_nopt[2], data->ip_optlen[2], data->ip_options[2], data->ip_optpadlen[2]);

      // Update ethernet frame.
      create_ip4_frame (2, data);
    }
    close (sd_udp);

  // Send all types of packets.
  } else if (data->packet_type == 100) {

    // Send TCP packet.
    while ((i > 0ull) && sending) {

      for (frame=0; frame<data->nframes[0]; frame++) {

        if (data->specify_ether[0]) {

          if ((sendto (sd_tcp, data->ether_frame[0][frame], data->frame_length[0][frame], 0, (struct sockaddr *) &tcp_device, sizeof (tcp_device))) <= 0) {
            status = errno;
            sprintf (data->error_text, "ipv4_send(): sendto() failed for TCP.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            send_error ();
            free (message);
            free (ipaddress);
            return (EXIT_FAILURE);
          }
        } else {
          if (sendto (sd_tcp, data->ether_frame[0][frame] + ETH_HDRLEN, data->frame_length[0][frame] - ETH_HDRLEN, 0, (struct sockaddr *) &tcp_sin, sizeof (struct sockaddr)) < 0)  {
            status = errno;
            sprintf (data->error_text, "ipv4_send(): sendto() failed for TCP.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            send_error ();
            free (message);
            free (ipaddress);
            return (EXIT_FAILURE);
          }
        }
      }

      // Send ICMP packet.
      for (frame=0; frame<data->nframes[1]; frame++) {

        if (data->specify_ether[1]) {

          if ((sendto (sd_icmp, data->ether_frame[1][frame], data->frame_length[1][frame], 0, (struct sockaddr *) &icmp_device, sizeof (icmp_device))) <= 0) {
            status = errno;
            sprintf (data->error_text, "ipv4_send(): sendto() failed for ICMP.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            send_error ();
            free (message);
            free (ipaddress);
            return (EXIT_FAILURE);
          }
        } else {
          if (sendto (sd_icmp, data->ether_frame[1][frame] + ETH_HDRLEN, data->frame_length[1][frame] - ETH_HDRLEN, 0, (struct sockaddr *) &icmp_sin, sizeof (struct sockaddr)) < 0)  {
            status = errno;
            sprintf (data->error_text, "ipv4_send(): sendto() failed for ICMP.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            send_error ();
            free (message);
            free (ipaddress);
            return (EXIT_FAILURE);
          }
        }
      }

      // Send UDP packet.
      for (frame=0; frame<data->nframes[2]; frame++) {

        if (data->specify_ether[2]) {

          if ((sendto (sd_udp, data->ether_frame[2][frame], data->frame_length[2][frame], 0, (struct sockaddr *) &udp_device, sizeof (udp_device))) <= 0) {
            status = errno;
            sprintf (data->error_text, "ipv4_send(): sendto() failed for UDP.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            send_error ();
            free (message);
            free (ipaddress);
            return (EXIT_FAILURE);
          }
        } else {
          if (sendto (sd_udp, data->ether_frame[2][frame] + ETH_HDRLEN, data->frame_length[2][frame] - ETH_HDRLEN, 0, (struct sockaddr *) &udp_sin, sizeof (struct sockaddr)) < 0)  {
            status = errno;
            sprintf (data->error_text, "ipv4_send(): sendto() failed for UDP.\nError message: %s", strerror (status));
            data->parent = data->main_window;
            send_error ();
            free (message);
            free (ipaddress);
            return (EXIT_FAILURE);
          }
        }
      }

      if (!flood_mode) i--;
      j++;

      // Randomize source IPv4 address if requested.
      if (data->ran_tcp4_sourceip) {
        if ((status = inet_pton (AF_INET, ran4_addr (ipaddress, data), &data->ip4hdr[0].ip_src)) != 1) {
          sprintf (data->error_text, "ipv4_send(): inet_pton() failed for randomized TCP source IP address.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }
      if (data->ran_icmp4_sourceip) {
        if ((status = inet_pton (AF_INET, ran4_addr (ipaddress, data), &data->ip4hdr[1].ip_src)) != 1) {
          sprintf (data->error_text, "ipv4_send(): inet_pton() failed for randomized ICMP source IP address.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }
      if (data->ran_udp4_sourceip) {
        if ((status = inet_pton (AF_INET, ran4_addr (ipaddress, data), &data->ip4hdr[2].ip_src)) != 1) {
          sprintf (data->error_text, "ipv4_send(): inet_pton() failed for randomized UDP source IP address.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }

      // Randomize source port if requested.
      if (data->ran_tcp4_sourceport) {
        data->tcphdr[0].th_sport = htons (ran16_0to65535 (data));
      }
      if (data->ran_udp4_sourceport) {
        data->udphdr[2].uh_sport = htons (ran16_0to65535 (data));
      }

      // Re-calculate IPv4 and upper layer protocol checksum
      // regardless of whether source IP and/or port was changed.

      // Upper layer protocol header checksum (16 bits)
      // ICMP does not protect source and destination addresses in IPv4,
      // so don't re-calculate ICMP checksum.
      data->tcphdr[0].th_sum = tcp4_checksum (data->ip4hdr[0], data->tcphdr[0], data->tcp_nopt[0], data->tcp_opt_totlen[0], data->tcp_optlen[0], data->tcp_options[0], data->tcp_optpadlen[0], data->payload[0], data->payloadlen[0]);
      data->udphdr[2].uh_sum = udp4_checksum (data->ip4hdr[2], data->udphdr[2], data->payload[2], data->payloadlen[2]);

      // IPv4 header checksum (16 bits): set to 0 when calculating checksum
      data->ip4hdr[0].ip_sum = 0;
      data->ip4hdr[0].ip_sum = ip4_checksum (data->ip4hdr[0], data->ip_nopt[0], data->ip_optlen[0], data->ip_options[0], data->ip_optpadlen[0]);
      data->ip4hdr[1].ip_sum = 0;
      data->ip4hdr[1].ip_sum = ip4_checksum (data->ip4hdr[1], data->ip_nopt[1], data->ip_optlen[1], data->ip_options[1], data->ip_optpadlen[1]);
      data->ip4hdr[2].ip_sum = 0;
      data->ip4hdr[2].ip_sum = ip4_checksum (data->ip4hdr[2], data->ip_nopt[2], data->ip_optlen[2], data->ip_options[2], data->ip_optpadlen[2]);

      // Update ethernet frames.
      create_ip4_frame (0, data);
      create_ip4_frame (1, data);
      create_ip4_frame (2, data);
    }

    // Close appropriate socket descriptors.
    if ((data->packet_type == 0) || (data->packet_type == 100)) {
      close (sd_tcp);
    } else if ((data->packet_type == 1) || (data->packet_type == 100)) {
      close (sd_icmp);
    } else if ((data->packet_type == 2) || (data->packet_type == 100)) {
      close (sd_udp);
    }
  }

  // Display packet activity in Activity Log.
  memset (message, 0, TEXT_STRINGLEN * sizeof (char));
  if (data->packet_type == 0) {
    sprintf (message, "%i IPv4 TCP ethernet frames (%i packets) sent.\n", j * data->nframes[0], j);
  } else if (data->packet_type == 1) {
    sprintf (message, "%i IPv4 ICMP ethernet frames (%i packets) sent.\n", j * data->nframes[1], j);
  } else if (data->packet_type == 2) {
    sprintf (message, "%i IPv4 UDP ethernet frames (%i packets) sent.\n", j * data->nframes[2], j);
  } else if (data->packet_type == 100) {
    sprintf (message, "%i IPv4 TCP+ICMP+UDP packets sent.\n", j);
  }

  // Have idle function post message to UI.
  // strdup() allocates memory for message on the heap using malloc().
  msgdata = allocate_msgdata (1);
  msgdata->textview = data->textview1;
  g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));

  // Have idle function update source IPv4 addresses and source ports, which may have changed if randomized during send.
  g_idle_add ((GSourceFunc) update_ip4_sources, data);

  // Free allocated memory.
  free (ipaddress);
  free (message);

  return (EXIT_SUCCESS);
}

// Idle function to update source IPv4 addresses and source ports, which may have changed if randomized during send.
// This idle function returns 0 in order to stop.
int
update_ip4_sources (SPSData *data)
{
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // TCP source IPv4 address
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  if (inet_ntop (AF_INET, &(data->ip4hdr[0].ip_src), value, INET_ADDRSTRLEN) == NULL) {
    fprintf (stderr, "ERROR: inet_ntop() failed for TCP source IPv4 address in update_ip4_sources().\n");
    fprintf (stderr, "       This should not happen unless invalid addresses are being generated.\n");
    exit (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry35), value);

  // ICMP source IPv4 address
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  if (inet_ntop (AF_INET, &(data->ip4hdr[1].ip_src), value, INET_ADDRSTRLEN) == NULL) {
    fprintf (stderr, "ERROR: inet_ntop() failed for ICMP source IPv4 address in update_ip4_sources().\n");
    fprintf (stderr, "       This should not happen unless invalid addresses are being generated.\n");
    exit (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry63), value);

  // UDP source IPv4 address
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  if (inet_ntop (AF_INET, &(data->ip4hdr[2].ip_src), value, INET_ADDRSTRLEN) == NULL) {
    fprintf (stderr, "ERROR: inet_ntop() failed for UDP source IPv4 address in update_ip4_sources().\n");
    fprintf (stderr, "       This should not happen unless invalid addresses are being generated.\n");
    exit (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry7), value);

  // TCP (IPv4) source port
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[0].th_sport));
  gtk_entry_set_text (GTK_ENTRY (data->entry41), value);

  // UDP (IPv4) source port
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->udphdr[2].uh_sport));
  gtk_entry_set_text (GTK_ENTRY (data->entry13), value);

  // Free allocated memory.
  free (value);

  return (0);  // This idle function stops when it returns a value of zero.
}
