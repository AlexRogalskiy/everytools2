package com.iluwatar.testdomain.person;

public class DoubleReferer {
    private Manager myBoss;
    private Manager myTeamManager;
}
