/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Apply IPv4 TCP default settings
int
tcp4_default (SPSData *data)
{
  int status, i, *ip4_flags, *tcp4_flags;
  char *ipaddress, *value;
  GtkTextBuffer *textbuffer24, *textbuffer30;

  // IPv4 header fragmentation flags and offset
  ip4_flags = allocate_intmem (4);

  // TCP flags
  tcp4_flags = allocate_intmem (8);

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Array to hold an IPv4 or IPv6 address + '\0'
  ipaddress = allocate_strmem (INET6_ADDRSTRLEN);

  // Number of ethernet frames
  data->nframes[0] = 1;

  // Ethernet header

  // Default to have the user specify the ethernet header
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton18), TRUE);
  data->specify_ether[0] = 1;  // The toggling done above will trigger the callback, but we set it here to be sure.

  // Destination link-layer (MAC) address (48 bits): default to zero; user needs to fill out
  memset (data->ethhdr[0].dst_mac, 0, 6 * sizeof (uint8_t));
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  mac_bin2string (data->ethhdr[0].dst_mac, value);
  gtk_entry_set_text (GTK_ENTRY (data->entry144), value);

  // Source Interface Name: defaults to blank
  memset (data->ifname[0], 0, TMP_STRINGLEN * sizeof (char));
  gtk_entry_set_text (GTK_ENTRY (data->entry150), "");

  // Default interface MTU
  data->ifmtu[0] = 1500;

  // Set spinbutton value to interface MTU.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton5), data->ifmtu[0]);

  // Source link-layer (MAC) address (48 bits): default to zero; user needs to fill out
  memset (data->ethhdr[0].src_mac, 0, 6 * sizeof (uint8_t));
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  mac_bin2string (data->ethhdr[0].src_mac, value);
  gtk_entry_set_text (GTK_ENTRY (data->entry145), value);

  // Ethernet type code (16 bits): default to IPv4
  // http://www.iana.org/assignments/ethernet-numbers
  data->ethhdr[0].type_code = htons (ETH_P_IP);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ethhdr[0].type_code));
  gtk_entry_set_text (GTK_ENTRY (data->entry146), value);

  // Deal with IP header options, TCP header options, and TCP data first
  // so that lengths and offsets are correct for updating IP and TCP headers.

  // IP header options

  // IP option data entry format: default to hexadecimal input
  data->dec_hex_ipopt_tcp4 = 1;

  // IP option entry format
  if (data->dec_hex_ipopt_tcp4 == 1) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton25), TRUE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton25), FALSE);
  }

  // No IP options
  data->ip_nopt[0] = 0;
  textbuffer30 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview30));
  sprintf (value, "%i", data->ip_nopt[0]);
  gtk_text_buffer_set_text (textbuffer30, value, -1);

  // Clear IP options buffer entry.
  gtk_entry_set_text (GTK_ENTRY (data->entry400), "");

  // Set all option data to zero.
  for (i=0; i<MAX_IP4OPTIONS; i++) {
    data->ip_optlen[0][i] = 0;
    memset (data->ip_options[0][i], 0, MAX_IP4OPTLEN * sizeof (uint8_t));
  }
  memset (data->ip_optionsbuf[0], 0, MAX_IP4OPTLEN * sizeof (uint8_t));

  // Length of option in buffer is zero.
  data->ip_optlenbuf[0] = 0;

  // Default option number after which to insert a new option
  data->ipopt_tcp4_after = 0;
  gtk_entry_set_text (GTK_ENTRY (data->entry401), "");

  // Number of IP option to remove (0 = none)
  data->ipopt_tcp4_remove = 0;
  gtk_entry_set_text (GTK_ENTRY (data->entry403), "");

  // TCP header options

  // TCP option data entry format: default to hexadecimal input
  data->dec_hex_tcpopt_tcp4 = 1;

  // TCP option entry format
  if (data->dec_hex_tcpopt_tcp4 == 1) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton42), TRUE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton42), FALSE);
  }

  // No TCP options
  data->tcp_nopt[0] = 0;
  textbuffer24 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview24));
  sprintf (value, "%i", data->tcp_nopt[0]);
  gtk_text_buffer_set_text (textbuffer24, value, -1);

  // Clear TCP option buffer entry.
  gtk_entry_set_text (GTK_ENTRY (data->entry404), "");

  // Set all option data to zero.
  for (i=0; i<MAX_TCPOPTIONS; i++) {
    data->tcp_optlen[0][i] = 0;
    memset (data->tcp_options[0][i], 0, MAX_TCPOPTLEN * sizeof (uint8_t));
  }
  memset (data->tcp_optionsbuf[0], 0, MAX_TCPOPTLEN * sizeof (uint8_t));

  // Set total length of options to zero.
  data->tcp_opt_totlen[0] = 0;

  // Length of option in buffer is zero.
  data->tcp_optlenbuf[0] = 0;

  // Default option number after which to insert a new option
  data->tcpopt_tcp4_after = 0;
  gtk_entry_set_text (GTK_ENTRY (data->entry405), "");

  // Number of TCP option to remove (0 = none)
  data->tcpopt_tcp4_remove = 0;
  gtk_entry_set_text (GTK_ENTRY (data->entry406), "");

  // TCP data

  // Clear TCP data buffer.
  memset (data->payload[0], 0, IP_MAXPACKET * sizeof (uint8_t));
  data->payloadlen[0] = 0;
  gtk_entry_set_text (GTK_ENTRY (data->entry162), "");

  // TCP data entry format: default to hexadecimal input
  data->ascii_hex_tcp4 = 1;
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton18), TRUE);

  // IPv4 header

  // IPv4 header length (4 bits): Number of 32-bit words in header = 5
  // Assume no IP options by default.
  data->ip4hdr[0].ip_hl = IP4_HDRLEN / sizeof (uint32_t);
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[0].ip_hl);
  gtk_entry_set_text (GTK_ENTRY (data->entry29), value);

  // Internet Protocol version (4 bits): IPv4
  data->ip4hdr[0].ip_v = 4u;
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[0].ip_v);
  gtk_entry_set_text (GTK_ENTRY (data->entry30), value);

  // Type of service (8 bits): default is 0
  data->ip4hdr[0].ip_tos = 0;
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[0].ip_tos);
  gtk_entry_set_text (GTK_ENTRY (data->entry31), value);

  // Total length of datagram (16 bits): IP header + TCP header + TCP data
  // Assume no IP options and no TCP options by default.
  data->ip4hdr[0].ip_len = htons (IP4_HDRLEN + TCP_HDRLEN + data->payloadlen[0]);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[0].ip_len));
  gtk_entry_set_text (GTK_ENTRY (data->entry32), value);

  // ID sequence number (16 bits): unused, since single datagram
  data->ip4hdr[0].ip_id = htons (0);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[0].ip_id));
  gtk_entry_set_text (GTK_ENTRY (data->entry33), value);

  // Zero (1 bit)
  ip4_flags[0] = 0;
  sprintf (value, "%i", ip4_flags[0]);
  gtk_entry_set_text (GTK_ENTRY (data->entry122), value);

  // Do not fragment flag (1 bit)
  ip4_flags[1] = 0;
  sprintf (value, "%i", ip4_flags[1]);
  gtk_entry_set_text (GTK_ENTRY (data->entry37), value);

  // More fragments following flag (1 bit)
  ip4_flags[2] = 0;
  sprintf (value, "%i", ip4_flags[2]);
  gtk_entry_set_text (GTK_ENTRY (data->entry38), value);

  // Fragmentation offset (13 bits)
  ip4_flags[3] = 0;
  sprintf (value, "%i", ip4_flags[3]);
  gtk_entry_set_text (GTK_ENTRY (data->entry39), value);

  // Flags, and Fragmentation offset (3, 13 bits): 0 since single datagram
  data->ip4hdr[0].ip_off = htons ((ip4_flags[0] << 15) +
   (ip4_flags[1] << 14) + (ip4_flags[2] << 13) + ip4_flags[3]);

  // Time-to-Live (8 bits): default to maximum value
  data->ip4hdr[0].ip_ttl = 255u;
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[0].ip_ttl);
  gtk_entry_set_text (GTK_ENTRY (data->entry40), value);

  // Transport layer protocol (8 bits): 6 for TCP
  data->ip4hdr[0].ip_p = IPPROTO_TCP;
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[0].ip_p);
  gtk_entry_set_text (GTK_ENTRY (data->entry74), value);

  // Source IPv4 address (32 bits): default to random
  data->ran_tcp4_sourceip = 1;
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton5), TRUE);
  if ((status = inet_pton (AF_INET, ran4_addr (ipaddress, data), &(data->ip4hdr[0].ip_src))) != 1) {
    sprintf (data->error_text, "tcp4_default(): inet_ntop() failed.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    free (tcp4_flags);
    free (value);
    free (ipaddress);
    return (EXIT_FAILURE);
  }
  if (inet_ntop (AF_INET, &(data->ip4hdr[0].ip_src), value, INET_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "tcp4_default(): inet_ntop() failed.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    free (tcp4_flags);
    free (value);
    free (ipaddress);
    return (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry35), value);

  // Destination IPv4 address (32 bits): default to loopback IP address to be safe
  memset (ipaddress, 0, INET6_ADDRSTRLEN * sizeof (char));
  strncpy (ipaddress, "127.0.0.1", INET6_ADDRSTRLEN - 1);  // Minus 1 for string termination.
  if ((status = inet_pton (AF_INET, ipaddress, &(data->ip4hdr[0].ip_dst))) != 1) {
    sprintf (data->error_text, "tcp4_default: inet_pton() failed.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    free (tcp4_flags);
    free (value);
    free (ipaddress);
    return (EXIT_FAILURE);
  }
  if (inet_ntop (AF_INET, &(data->ip4hdr[0].ip_dst), value, INET_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "tcp4_default(): inet_ntop() failed.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    free (tcp4_flags);
    free (value);
    free (ipaddress);
    return (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry36), value);

  // IPv4 header checksum (16 bits): set to 0 when calculating checksum
  data->ip4hdr[0].ip_sum = 0;
  data->ip4hdr[0].ip_sum = ip4_checksum (data->ip4hdr[0], data->ip_nopt[0], data->ip_optlen[0], data->ip_options[0], data->ip_optpadlen[0]);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[0].ip_sum));
  gtk_entry_set_text (GTK_ENTRY (data->entry34), value);

  // Length of option in buffer is zero.
  data->ip_optlenbuf[0] = 0;

  // Default option number after which to insert a new option
  data->ipopt_tcp4_after = 0;
  gtk_entry_set_text (GTK_ENTRY (data->entry401), "");

  // Number of IP option to remove (0 = none)
  data->ipopt_tcp4_remove = 0;
  gtk_entry_set_text (GTK_ENTRY (data->entry403), "");

  // TCP header (IPv4)

  // Source port number (16 bits): default to random
  data->ran_tcp4_sourceport = 1;
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton7), TRUE);
  data->tcphdr[0].th_sport = htons (ran16_0to65535 (data));
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[0].th_sport));
  gtk_entry_set_text (GTK_ENTRY (data->entry41), value);

  // Destination port number (16 bits)
  data->tcphdr[0].th_dport = htons (80u);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[0].th_dport));
  gtk_entry_set_text (GTK_ENTRY (data->entry42), value);

  // Sequence number (32 bits)
  data->tcphdr[0].th_seq = htonl (0);
  sprintf (value, "%" PRIu32, (uint32_t) ntohl (data->tcphdr[0].th_seq));
  gtk_entry_set_text (GTK_ENTRY (data->entry43), value);

  // Acknowledgement number (32 bits): 0 in first packet
  data->tcphdr[0].th_ack = htonl (0);
  sprintf (value, "%" PRIu32, (uint32_t) ntohl (data->tcphdr[0].th_ack));
  gtk_entry_set_text (GTK_ENTRY (data->entry44), value);

  // Reserved (4 bits): should be 0
  data->tcphdr[0].th_x2 = 0;
  sprintf (value, "%" PRIu8, (uint8_t) data->tcphdr[0].th_x2);
  gtk_entry_set_text (GTK_ENTRY (data->entry45), value);

  // Data offset (4 bits): size of TCP header + length of TCP options, in 32-bit words
  // Default is no TCP options.
  data->tcphdr[0].th_off = TCP_HDRLEN / sizeof (uint32_t);
  sprintf (value, "%" PRIu8, (uint8_t) data->tcphdr[0].th_off);
  gtk_entry_set_text (GTK_ENTRY (data->entry46), value);

  // FIN flag (1 bit)
  tcp4_flags[0] = 0;
  sprintf (value, "%i", tcp4_flags[0]);
  gtk_entry_set_text (GTK_ENTRY (data->entry47), value);

  // SYN flag (1 bit): set to 1
  tcp4_flags[1] = 1;
  sprintf (value, "%i", tcp4_flags[1]);
  gtk_entry_set_text (GTK_ENTRY (data->entry48), value);

  // RST flag (1 bit)
  tcp4_flags[2] = 0;
  sprintf (value, "%i", tcp4_flags[2]);
  gtk_entry_set_text (GTK_ENTRY (data->entry49), value);

  // PSH flag (1 bit)
  tcp4_flags[3] = 0;
  sprintf (value, "%i", tcp4_flags[3]);
  gtk_entry_set_text (GTK_ENTRY (data->entry50), value);

  // ACK flag (1 bit)
  tcp4_flags[4] = 0;
  sprintf (value, "%i", tcp4_flags[4]);
  gtk_entry_set_text (GTK_ENTRY (data->entry51), value);

  // URG flag (1 bit)
  tcp4_flags[5] = 0;
  sprintf (value, "%i", tcp4_flags[5]);
  gtk_entry_set_text (GTK_ENTRY (data->entry52), value);

  // ECE flag (1 bit)
  tcp4_flags[6] = 0;
  sprintf (value, "%i", tcp4_flags[6]);
  gtk_entry_set_text (GTK_ENTRY (data->entry53), value);

  // CWR flag (1 bit)
  tcp4_flags[7] = 0;
  sprintf (value, "%i", tcp4_flags[7]);
  gtk_entry_set_text (GTK_ENTRY (data->entry54), value);

  // Flags (8 bits): 2 for SYN
  data->tcphdr[0].th_flags = bin8_to_dec (tcp4_flags);

  // Window size (16 bits): default to maximum value
  data->tcphdr[0].th_win = htons (0xffffu);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[0].th_win));
  gtk_entry_set_text (GTK_ENTRY (data->entry55), value);

  // Urgent pointer (16 bits): 0 (only valid if URG flag is set)
  data->tcphdr[0].th_urp = htons (0);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[0].th_urp));
  gtk_entry_set_text (GTK_ENTRY (data->entry77), value);

  // TCP checksum (16 bits)
  data->tcphdr[0].th_sum = tcp4_checksum (data->ip4hdr[0], data->tcphdr[0], data->tcp_nopt[0], data->tcp_opt_totlen[0], data->tcp_optlen[0], data->tcp_options[0], data->tcp_optpadlen[0], data->payload[0], data->payloadlen[0]);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[0].th_sum));
  gtk_entry_set_text (GTK_ENTRY (data->entry56), value);

  // Free allocated memory.
  free (ip4_flags);
  free (tcp4_flags);
  free (value);
  free (ipaddress);

  // Update ethernet frame.
  create_ip4_frame (0, data);

  return (EXIT_SUCCESS);
}

// Apply IPv4 ICMP default settings
int
icmp4_default (SPSData *data)
{
  int status, i, *ip4_flags;
  char *ipaddress, *value;
  GtkTextBuffer *textbuffer26;

  // IPv4 header fragmentation flags and offset
  ip4_flags = allocate_intmem (4);

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Array to hold an IPv4 or IPv6 address + '\0'
  ipaddress = allocate_strmem (INET6_ADDRSTRLEN);

  // Number of ethernet frames
  data->nframes[1] = 1;

  // Ethernet header

  // Default to have the user specify the ethernet header
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton17), TRUE);
  data->specify_ether[1] = 1;  // The toggling done above will trigger the callback, but we set it here to be sure.

  // Destination link-layer (MAC) address (48 bits): default to zero; user needs to fill out
  memset (data->ethhdr[1].dst_mac, 0, 6 * sizeof (uint8_t));
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  mac_bin2string (data->ethhdr[1].dst_mac, value);
  gtk_entry_set_text (GTK_ENTRY (data->entry141), value);

  // Source Interface Name: defaults to blank
  memset (data->ifname[1], 0, TMP_STRINGLEN * sizeof (char));
  gtk_entry_set_text (GTK_ENTRY (data->entry151), "");

  // Default interface MTU
  data->ifmtu[1] = 1500;

  // Set spinbutton value to interface MTU.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton6), data->ifmtu[1]);

  // Source link-layer (MAC) address (48 bits): default to zero; user needs to fill out
  memset (data->ethhdr[1].src_mac, 0, 6 * sizeof (uint8_t));
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  mac_bin2string (data->ethhdr[1].src_mac, value);
  gtk_entry_set_text (GTK_ENTRY (data->entry142), value);

  // Ethernet type code (16 bits): default to IPv4
  // http://www.iana.org/assignments/ethernet-numbers
  data->ethhdr[1].type_code = htons (ETH_P_IP);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ethhdr[1].type_code));
  gtk_entry_set_text (GTK_ENTRY (data->entry143), value);

  // Deal with IP header options and ICMP data first so that
  // lengths and offsets are correct for updating IP and ICMP headers.

  // IP header options

  // IP option data entry format: default to hexadecimal input
  data->dec_hex_ipopt_icmp4 = 1;

  // IP option entry format
  if (data->dec_hex_ipopt_icmp4 == 1) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton44), TRUE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton44), FALSE);
  }

  // No IP options
  data->ip_nopt[1] = 0;
  textbuffer26 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview26));
  sprintf (value, "%i", data->ip_nopt[1]);
  gtk_text_buffer_set_text (textbuffer26, value, -1);

  // Clear IP options buffer entry.
  gtk_entry_set_text (GTK_ENTRY (data->entry407), "");

  // Set all option data to zero.
  for (i=0; i<MAX_IP4OPTIONS; i++) {
    data->ip_optlen[1][i] = 0;
    memset (data->ip_options[1][i], 0, MAX_IP4OPTLEN * sizeof (uint8_t));
  }
  memset (data->ip_optionsbuf[1], 0, MAX_IP4OPTLEN * sizeof (uint8_t));

  // Length of option in buffer is zero.
  data->ip_optlenbuf[1] = 0;

  // Default option number after which to insert a new option
  data->ipopt_icmp4_after = 0;
  gtk_entry_set_text (GTK_ENTRY (data->entry408), "");

  // Number of IP option to remove (0 = none)
  data->ipopt_icmp4_remove = 0;
  gtk_entry_set_text (GTK_ENTRY (data->entry409), "");

  // ICMP data

  // Clear ICMP data buffer.
  memset (data->payload[1], 0, IP_MAXPACKET * sizeof (uint8_t));
  data->payloadlen[1] = 0;
  gtk_entry_set_text (GTK_ENTRY (data->entry126), "");

  // ICMP data entry format: default to hexadecimal input
  data->ascii_hex_icmp4 = 1;
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton10), TRUE);

  // IPv4 header

  // IPv4 header length (4 bits): Number of 32-bit words in header = 5
  // Assume no IP options by default.
  data->ip4hdr[1].ip_hl = IP4_HDRLEN / sizeof (uint32_t);
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[1].ip_hl);
  gtk_entry_set_text (GTK_ENTRY (data->entry57), value);

  // Internet Protocol version (4 bits): IPv4
  data->ip4hdr[1].ip_v = 4u;
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[1].ip_v);
  gtk_entry_set_text (GTK_ENTRY (data->entry58), value);

  // Type of service (8 bits): default is 0
  data->ip4hdr[1].ip_tos = 0;
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[1].ip_tos);
  gtk_entry_set_text (GTK_ENTRY (data->entry59), value);

  // Total length of datagram (16 bits): IP header + ICMP header + ICMP data
  // Assume no IP options by default.
  data->ip4hdr[1].ip_len = htons (IP4_HDRLEN + ICMP_HDRLEN + data->payloadlen[1]);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[1].ip_len));
  gtk_entry_set_text (GTK_ENTRY (data->entry60), value);

  // ID sequence number (16 bits): unused, since single datagram
  data->ip4hdr[1].ip_id = htons (0);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[1].ip_id));
  gtk_entry_set_text (GTK_ENTRY (data->entry61), value);

  // Zero (1 bit)
  ip4_flags[0] = 0;
  sprintf (value, "%i", ip4_flags[0]);
  gtk_entry_set_text (GTK_ENTRY (data->entry123), value);

  // Do not fragment flag (1 bit)
  ip4_flags[1] = 0;
  sprintf (value, "%i", ip4_flags[1]);
  gtk_entry_set_text (GTK_ENTRY (data->entry65), value);

  // More fragments following flag (1 bit)
  ip4_flags[2] = 0;
  sprintf (value, "%i", ip4_flags[2]);
  gtk_entry_set_text (GTK_ENTRY (data->entry66), value);

  // Fragmentation offset (13 bits)
  ip4_flags[3] = 0;
  sprintf (value, "%i", ip4_flags[3]);
  gtk_entry_set_text (GTK_ENTRY (data->entry67), value);

  // Flags, and Fragmentation offset (3, 13 bits): 0 since single datagram
  data->ip4hdr[1].ip_off = htons ((ip4_flags[0] << 15) +
   (ip4_flags[1] << 14) + (ip4_flags[2] << 13) + ip4_flags[3]);

  // Time-to-Live (8 bits): default to maximum value
  data->ip4hdr[1].ip_ttl = 255u;
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[1].ip_ttl);
  gtk_entry_set_text (GTK_ENTRY (data->entry68), value);

  // Transport layer protocol (8 bits): 1 for ICMP
  data->ip4hdr[1].ip_p = IPPROTO_ICMP;
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[1].ip_p);
  gtk_entry_set_text (GTK_ENTRY (data->entry75), value);

  // Source IPv4 address (32 bits): default to random
  data->ran_icmp4_sourceip = 1;
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton9), TRUE);
  if ((status = inet_pton (AF_INET, ran4_addr (ipaddress, data), &(data->ip4hdr[1].ip_src))) != 1) {
    sprintf (data->error_text, "icmp4_default(): inet_pton() failed.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    free (value);
    free (ipaddress);
    return (EXIT_FAILURE);
  }
  if (inet_ntop (AF_INET, &(data->ip4hdr[1].ip_src), value, INET_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "icmp4_default(): inet_ntop() failed.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    free (value);
    free (ipaddress);
    return (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry63), value);

  // Destination IPv4 address (32 bits): default to loopback IP address to be safe
  memset (ipaddress, 0, INET6_ADDRSTRLEN * sizeof (char));
  strncpy (ipaddress, "127.0.0.1", INET6_ADDRSTRLEN - 1);  // Minus 1 for string termination.
  if ((status = inet_pton (AF_INET, ipaddress, &(data->ip4hdr[1].ip_dst))) != 1) {
    sprintf (data->error_text, "icmp4_default(): inet_pton() failed.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    free (value);
    free (ipaddress);
    return (EXIT_FAILURE);
  }
  if (inet_ntop (AF_INET, &(data->ip4hdr[1].ip_dst), value, INET_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "icmp4_default(): inet_ntop() failed.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    free (value);
    free (ipaddress);
    return (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry64), value);

  // IPv4 header checksum (16 bits): set to 0 when calculating checksum
  data->ip4hdr[1].ip_sum = 0;
  data->ip4hdr[1].ip_sum = ip4_checksum (data->ip4hdr[1], data->ip_nopt[1], data->ip_optlen[1], data->ip_options[1], data->ip_optpadlen[1]);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[1].ip_sum));
  gtk_entry_set_text (GTK_ENTRY (data->entry62), value);

  // ICMP header (IPv4)

  // Message Type (8 bits): echo request
  data->icmp4hdr[1].icmp_type = ICMP_ECHO;
  sprintf (value, "%" PRIu8, (uint8_t) data->icmp4hdr[1].icmp_type);
  gtk_entry_set_text (GTK_ENTRY (data->entry69), value);

  // Message Code (8 bits): echo request
  data->icmp4hdr[1].icmp_code = 0;
  sprintf (value, "%" PRIu8, (uint8_t) data->icmp4hdr[1].icmp_code);
  gtk_entry_set_text (GTK_ENTRY (data->entry70), value);

  // Identifier (16 bits): usually pid of sending process - we'll arbitrarily use 1000
  data->icmp4hdr[1].icmp_id = htons (1000u);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->icmp4hdr[1].icmp_id));
  gtk_entry_set_text (GTK_ENTRY (data->entry72), value);

  // Sequence Number (16 bits): starts at 0
  data->icmp4hdr[1].icmp_seq = htons (0);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->icmp4hdr[1].icmp_seq));
  gtk_entry_set_text (GTK_ENTRY (data->entry73), value);

  // ICMP header checksum (16 bits)
  data->icmp4hdr[1].icmp_cksum = icmp4_checksum (data->icmp4hdr[1], data->payload[1], data->payloadlen[1]);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->icmp4hdr[1].icmp_cksum));
  gtk_entry_set_text (GTK_ENTRY (data->entry71), value);

  // Free allocated memory.
  free (ip4_flags);
  free (value);
  free (ipaddress);

  // Update ethernet frame.
  create_ip4_frame (1, data);

  return (EXIT_SUCCESS);
}

// Apply IPv4 UDP default settings
int
udp4_default (SPSData *data)
{
  int status, i, *ip4_flags;
  char *ipaddress, *value;
  GtkTextBuffer *textbuffer28;

  // IPv4 header fragmentation flags and offset
  ip4_flags = allocate_intmem (4);

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Array to hold an IPv4 or IPv6 address + '\0'
  ipaddress = allocate_strmem (INET6_ADDRSTRLEN);

  // Number of ethernet frames
  data->nframes[2] = 1;

  // Ethernet header

  // Default to have the user specify the ethernet header
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton19), TRUE);
  data->specify_ether[2] = 1;  // The toggling done above will trigger the callback, but we set it here to be sure.

  // Destination link-layer (MAC) address (48 bits): default to zero; user needs to fill out
  memset (data->ethhdr[2].dst_mac, 0, 6 * sizeof (uint8_t));
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  mac_bin2string (data->ethhdr[2].dst_mac, value);
  gtk_entry_set_text (GTK_ENTRY (data->entry147), value);

  // Source Interface Name: defaults to blank
  memset (data->ifname[2], 0, TMP_STRINGLEN * sizeof (char));
  gtk_entry_set_text (GTK_ENTRY (data->entry152), "");

  // Default interface MTU
  data->ifmtu[2] = 1500;

  // Set spinbutton value to interface MTU.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton7), data->ifmtu[2]);

  // Source link-layer (MAC) address (48 bits): default to zero; user needs to fill out
  memset (data->ethhdr[2].src_mac, 0, 6 * sizeof (uint8_t));
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  mac_bin2string (data->ethhdr[2].src_mac, value);
  gtk_entry_set_text (GTK_ENTRY (data->entry148), value);

  // Ethernet type code (16 bits): default to IPv4
  // http://www.iana.org/assignments/ethernet-numbers
  data->ethhdr[2].type_code = htons (ETH_P_IP);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ethhdr[2].type_code));
  gtk_entry_set_text (GTK_ENTRY (data->entry149), value);

  // Deal with IP header options and UDP data first so that
  // lengths and offsets are correct for updating IP and UDP headers.

  // IP header options

  // IP option data entry format: default to hexadecimal input
  data->dec_hex_ipopt_udp4 = 1;

  // IP option entry format
  if (data->dec_hex_ipopt_udp4 == 1) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton46), TRUE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton46), FALSE);
  }

  // No IP options
  data->ip_nopt[2] = 0;
  textbuffer28 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview28));
  sprintf (value, "%i", data->ip_nopt[2]);
  gtk_text_buffer_set_text (textbuffer28, value, -1);

  // Clear IP options buffer entry.
  gtk_entry_set_text (GTK_ENTRY (data->entry410), "");

  // Set all option data to zero.
  for (i=0; i<MAX_IP4OPTIONS; i++) {
    data->ip_optlen[2][i] = 0;
    memset (data->ip_options[2][i], 0, MAX_IP4OPTLEN * sizeof (uint8_t));
  }
  memset (data->ip_optionsbuf[2], 0, MAX_IP4OPTLEN * sizeof (uint8_t));

  // Length of option in buffer is zero.
  data->ip_optlenbuf[2] = 0;

  // Default option number after which to insert a new option
  data->ipopt_udp4_after = 0;
  gtk_entry_set_text (GTK_ENTRY (data->entry411), "");

  // Number of IP option to remove (0 = none)
  data->ipopt_udp4_remove = 0;
  gtk_entry_set_text (GTK_ENTRY (data->entry412), "");

  // UDP data

  // Clear UDP data buffer.
  memset (data->payload[2], 0, IP_MAXPACKET * sizeof (uint8_t));
  data->payloadlen[2] = 0;
  gtk_entry_set_text (GTK_ENTRY (data->entry17), "");

  // UDP data entry format: default to hexadecimal input
  data->ascii_hex_udp4 = 1;
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton14), TRUE);

  // IPv4 header

  // IPv4 header length (4 bits): Number of 32-bit words in header = 5
  // Assume no IP options by default.
  data->ip4hdr[2].ip_hl = IP4_HDRLEN / sizeof (uint32_t);
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[2].ip_hl);
  gtk_entry_set_text (GTK_ENTRY (data->entry1), value);

  // Internet Protocol version (4 bits): IPv4
  data->ip4hdr[2].ip_v = 4u;
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[2].ip_v);
  gtk_entry_set_text (GTK_ENTRY (data->entry2), value);

  // Type of service (8 bits): default is 0
  data->ip4hdr[2].ip_tos = 0;
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[2].ip_tos);
  gtk_entry_set_text (GTK_ENTRY (data->entry3), value);

  // Total length of datagram (16 bits): IP header + UDP header + UDP payload
  // Assume no IP options by default.
  data->ip4hdr[2].ip_len = htons (IP4_HDRLEN + UDP_HDRLEN + data->payloadlen[2]);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[2].ip_len));
  gtk_entry_set_text (GTK_ENTRY (data->entry4), value);

  // ID sequence number (16 bits): unused, since single datagram
  data->ip4hdr[2].ip_id = htons (0);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[2].ip_id));
  gtk_entry_set_text (GTK_ENTRY (data->entry5), value);

  // Zero (1 bit)
  ip4_flags[0] = 0;
  sprintf (value, "%i", ip4_flags[0]);
  gtk_entry_set_text (GTK_ENTRY (data->entry124), value);

  // Do not fragment flag (1 bit)
  ip4_flags[1] = 0;
  sprintf (value, "%i", ip4_flags[1]);
  gtk_entry_set_text (GTK_ENTRY (data->entry9), value);

  // More fragments following flag (1 bit)
  ip4_flags[2] = 0;
  sprintf (value, "%i", ip4_flags[2]);
  gtk_entry_set_text (GTK_ENTRY (data->entry10), value);

  // Fragmentation offset (13 bits)
  ip4_flags[3] = 0;
  sprintf (value, "%i", ip4_flags[3]);
  gtk_entry_set_text (GTK_ENTRY (data->entry11), value);

  // Flags, and Fragmentation offset (3, 13 bits): 0 since single datagram
  data->ip4hdr[2].ip_off = htons ((ip4_flags[0] << 15) +
   (ip4_flags[1] << 14) + (ip4_flags[2] << 13) + ip4_flags[3]);

  // Time-to-Live (8 bits): default to maximum value
  data->ip4hdr[2].ip_ttl = 255u;
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[2].ip_ttl);
  gtk_entry_set_text (GTK_ENTRY (data->entry12), value);

  // Transport layer protocol (8 bits): 17 for UDP
  data->ip4hdr[2].ip_p = IPPROTO_UDP;
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[2].ip_p);
  gtk_entry_set_text (GTK_ENTRY (data->entry76), value);

  // Source IPv4 address (32 bits): default to random
  data->ran_udp4_sourceip = 1;
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton1), TRUE);
  if ((status = inet_pton (AF_INET, ran4_addr (ipaddress, data), &(data->ip4hdr[2].ip_src))) != 1) {
    sprintf (data->error_text, "udp4_default(): inet_pton() failed.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    free (ipaddress);
    free (value);
    return (EXIT_FAILURE);
  }
  if (inet_ntop (AF_INET, &(data->ip4hdr[2].ip_src), value, INET_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "udp4_default(): inet_ntop() failed.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    free (ipaddress);
    free (value);
    return (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry7), value);

  // Destination IPv4 address (32 bits): default to loopback IP address to be safe
  memset (ipaddress, 0, INET6_ADDRSTRLEN * sizeof (char));
  strncpy (ipaddress, "127.0.0.1", INET6_ADDRSTRLEN - 1);  // Minus 1 for string termination.
  if ((status = inet_pton (AF_INET, ipaddress, &(data->ip4hdr[2].ip_dst))) != 1) {
    sprintf (data->error_text, "udp4_default(): inet_pton() failed.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    free (ipaddress);
    free (value);
    return (EXIT_FAILURE);
  }
  if (inet_ntop (AF_INET, &(data->ip4hdr[2].ip_dst), value, INET_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "udp4_default(): inet_ntop() failed.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    free (ipaddress);
    free (value);
    return (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry8), value);

  // IPv4 header checksum (16 bits): set to 0 when calculating checksum
  data->ip4hdr[2].ip_sum = 0;
  data->ip4hdr[2].ip_sum = ip4_checksum (data->ip4hdr[2], data->ip_nopt[2], data->ip_optlen[2], data->ip_options[2], data->ip_optpadlen[2]);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[2].ip_sum));
  gtk_entry_set_text (GTK_ENTRY (data->entry6), value);

  // UDP header (IPv4)

  // Source port number (16 bits): default to random
  data->ran_udp4_sourceport = 1;
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton3), TRUE);
  data->udphdr[2].uh_sport = htons (ran16_0to65535 (data));
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->udphdr[2].uh_sport));
  gtk_entry_set_text (GTK_ENTRY (data->entry13), value);

  // Destination port number (16 bits): we'll arbitrarily use 4950
  data->udphdr[2].uh_dport = htons (4950u);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->udphdr[2].uh_dport));
  gtk_entry_set_text (GTK_ENTRY (data->entry14), value);

  // Length of UDP datagram (16 bits): UDP header + UDP payload
  data->udphdr[2].uh_ulen = htons (UDP_HDRLEN + data->payloadlen[2]);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->udphdr[2].uh_ulen));
  gtk_entry_set_text (GTK_ENTRY (data->entry15), value);

  // UDP checksum (16 bits)
  data->udphdr[2].uh_sum = udp4_checksum (data->ip4hdr[2], data->udphdr[2], data->payload[2], data->payloadlen[2]);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->udphdr[2].uh_sum));
  gtk_entry_set_text (GTK_ENTRY (data->entry16), value);

  // Free allocated memory.
  free (ip4_flags);
  free (value);
  free (ipaddress);

  // Update ethernet frame.
  create_ip4_frame (2, data);

  return (EXIT_SUCCESS);
}
