/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Set the Next Header field to IPPROTO_FRAGMENT in last link of unfragmentable portion (IPv6 only).
int
next_hdr_to_frag (int type, struct ip6_hdr *ip6hdr, SPSData *data)
{
  switch (data->order[type][data->first_frag[type]-1]) {

    // New IPv6 header
    case 98:
      data->ip6hdr[type+20].ip6_nxt = IPPROTO_FRAGMENT;
      break;

    // IPv6 header
    case 0:
      ip6hdr->ip6_nxt = IPPROTO_FRAGMENT;
      break;

    // Hop-by-hop header
    case 1:
      data->hophdr[type].nxt_hdr = IPPROTO_FRAGMENT;
      break;

    // Destination header (first)
    case 2:
      data->dstfhdr[type].nxt_hdr = IPPROTO_FRAGMENT;
      break;

    // Routing header
    case 3:
      data->routehdr[type].nxt_hdr = IPPROTO_FRAGMENT;
      break;

    // Unknown index value
    default:
      fprintf (stderr, "ERROR: Unknown index value %i in next_hdr_to_frag().\n", data->order[type][data->first_frag[type]-1]);
      exit (EXIT_FAILURE);
  }

  return (EXIT_SUCCESS);
}

// Find length of unfragmentable portion (IPv6 only).
int
find6_unfraglen (int type, SPSData *data)
{
  int c, len;

  // Set order of all headers, extension headers, and data.
  // This must be called in order to ensure any new items are included in chain length.
  ip6_order (type, data);  // Note: This will set data->first_frag[type]

  c = 0;  // Index of order array (IPv6 header chain)
  len = 0;  // Index of unfragmentable portion

  // Loop though all unfragmentable links in IPv6 chain.
  for (c=0; c<data->first_frag[type]; c++) {

    switch (data->order[type][c]) {

      // New IP6 header (if tunnelling AH or ESP)
      case 98:
        len += IP6_HDRLEN;
        break;

      // IP6 header
      case 0:
        len += IP6_HDRLEN;
        break;

      // Hop-by-hop header
      case 1:
        len += HOP_HDRLEN + data->hbh_opt_totlen[type] + data->hbh_optpadlen[type];
        break;

      // Destination header (first)
      case 2:
        len += DST_HDRLEN + data->dstf_opt_totlen[type] + data->dstf_optpadlen[type];
        break;

      // Routing header
      case 3:
        len += RTE_HDRLEN + data->route_datlen[type];
        break;

      // Unknown index value
      default:
        fprintf (stderr, "ERROR: Unknown index value %i in find6_unfraglen().\n", data->order[type][c]);
        exit (EXIT_FAILURE);
    }
  }  // End loop through unfragmentable chain

  return (len);
}

// Returns length of fragmentable portion (IPv6 only).
int
find6_fraglen (int type, SPSData *data)
{
  int c, len;

  // Set order of all headers, extension headers, and data.
  // This must be called in order to ensure any new items are included in chain length.
  ip6_order (type, data);  // Note: This will set data->first_frag[type]

  c = data->first_frag[type];  // Index of IPv6 chain
  len = 0;  // Index of fragmentable portion

  // Loop though all fragmentable links in IPv6 chain.
  while ((data->order[type][c] != 99) && (c < MAX_IP6LINKS)) {

    switch (data->order[type][c]) {

      // IPv6 header
      case 0:
        len += IP6_HDRLEN;
        break;

      // Authentication header
      case 5:
        len += ATH_HDRLEN + data->auth_len[type];
        break;

      // ESP header, excluding payload data, ESP tail, and auth. data
      // All links in chain to follow are part of ESP payload.
      case 6:
        len += ESP_HDRLEN;
        break;

      // Destination header (last)
      case 8:
        len += DST_HDRLEN + data->dstl_opt_totlen[type] + data->dstl_optpadlen[type];
        break;

      // TCP header and options
      case 9:
        len += TCP_HDRLEN + data->tcp_opt_totlen[type] + data->tcp_optpadlen[type];
        break;

      // TCP payload data
      case 12:
        len += data->payloadlen[type];
        break;

      // ICMP header
      case 10:
        len += ICMP_HDRLEN;
        break;

      // ICMP payload data
      case 13:
        len += data->payloadlen[type];
        break;

      // UDP header
      case 11:
        len += UDP_HDRLEN;
        break;

      // UDP payload data
      case 14:
        len += data->payloadlen[type];
        break;

      // Encapsulating security payload trailer (transport and tunnel mode)
      // Add padding (Section 2.4 of RFC 2406).
      case 7:
        len += data->esptail[type].pad_len;
        len += ESP_TAILLEN;
        len += data->esp_auth_len[type];
        break;

      // Unknown index value
      default:
        fprintf (stderr, "ERROR: Unknown index value %i in find6_fraglen().\n", data->order[type][c]);
        exit (EXIT_FAILURE);
    }

    // Go to next link in chain.
    c++;

  }  // End loop through fragmentable chain

  return (len);
}

// Build unfragmentable portion of ethernet frame (IPv6 only).
int
build_unfrag (int type, struct ip6_hdr *ip6hdr, int *i, uint8_t *unfragbuffer, SPSData *data)
{
  int j, c;

  // i = Index of unfragbuffer

  // Loop though all unfragmentable links in IPv6 chain of headers, options, and payload etc.
  for (c=0; c<data->first_frag[type]; c++) {

    switch (data->order[type][c]) {

      // New IP6 header
      case 98:
        memcpy (unfragbuffer + (*i), &data->ip6hdr[type+20], IP6_HDRLEN * sizeof (uint8_t));
        (*i) += IP6_HDRLEN;
        break;

      // IP6 header
      case 0:
        memcpy (unfragbuffer + (*i), ip6hdr, IP6_HDRLEN * sizeof (uint8_t));
        (*i) += IP6_HDRLEN;
        break;

      // Hop-by-hop header
      case 1:
        // Copy hop-by-hop extension header (without options) to unfragbuffer.
        memcpy (unfragbuffer + (*i), &data->hophdr[type], HOP_HDRLEN * sizeof (uint8_t));
        (*i) += HOP_HDRLEN;

        // Copy hop-by_hop extension header options to unfragbuffer.
        for (j=0; j<data->hbh_nopt[type]; j++) {

          // Alignment padding
          memcpy (unfragbuffer + (*i), data->hbh_optleadpad[type][j], data->hbh_optleadpadlen[type][j] * sizeof (uint8_t));
          (*i) += data->hbh_optleadpadlen[type][j];

          // Copy hop-by-hop option to unfragbuffer.
          memcpy (unfragbuffer + (*i), data->hbh_options[type][j], data->hbh_optlen[type][j] * sizeof (uint8_t));
          (*i) += data->hbh_optlen[type][j];
        }

        // Trailing padding
        memcpy (unfragbuffer + (*i), data->hbh_opttailpad[type], data->hbh_opttailpadlen[type] * sizeof (uint8_t));
        (*i) += data->hbh_opttailpadlen[type];
        break;

      // Destination header (first)
      case 2:
        // Copy destination extension header (without options) to unfragbuffer.
        memcpy (unfragbuffer + (*i), &data->dstfhdr[type], DST_HDRLEN * sizeof (uint8_t));
        (*i) += DST_HDRLEN;

        // Copy destination extension header options to unfragbuffer.
        for (j=0; j<data->dstf_nopt[type]; j++) {

          // Alignment padding
          memcpy (unfragbuffer + (*i), data->dstf_optleadpad[type][j], data->dstf_optleadpadlen[type][j] * sizeof (uint8_t));
          (*i) += data->dstf_optleadpadlen[type][j];

          // Copy destination option to unfragbuffer.
          memcpy (unfragbuffer + (*i), data->dstf_options[type][j], data->dstf_optlen[type][j] * sizeof (uint8_t));
          (*i) += data->dstf_optlen[type][j];
        }

        // Trailing padding
        memcpy (unfragbuffer + (*i), data->dstf_opttailpad[type], data->dstf_opttailpadlen[type] * sizeof (uint8_t));
        (*i) += data->dstf_opttailpadlen[type];
        break;

      // Routing header
      case 3:
        // Copy routing extension header (without data) to unfragbuffer.
        memcpy (unfragbuffer + (*i), &data->routehdr[type], RTE_HDRLEN * sizeof (uint8_t));
        (*i) += RTE_HDRLEN;

        // Copy routing header data to unfragbuffer.
        memcpy (unfragbuffer + (*i), data->route_data[type], data->route_datlen[type] * sizeof (uint8_t));
        (*i) += data->route_datlen[type];
        break;

      // Unknown index value
      default:
        fprintf (stderr, "ERROR: Unknown index value %i in build_unfrag().\n", data->order[type][c]);
        exit (EXIT_FAILURE);
    }
  }  // End loop through unfragmentable chain

  return (EXIT_SUCCESS);
}

// Build fragmentable portion of ethernet frame (IPv6 only).
int
build_frag (int type, struct ip6_hdr *ip6hdr, uint8_t *fragbuffer, SPSData *data)
{
  int i, j, c;

  c = data->first_frag[type];  // Index of IPv6 chain
  i = 0;  // Index of fragbuffer.

  // Loop though all fragmentable links in IPv6 chain of headers, options, and payload etc.
  while ((data->order[type][c] != 99) && (c < MAX_IP6LINKS)) {

    switch (data->order[type][c]) {

      // IP6 header
      case 0:
        memcpy (fragbuffer + i, ip6hdr, IP6_HDRLEN * sizeof (uint8_t));
        i += IP6_HDRLEN;
        break;

      // Authentication header
      case 5:
        memcpy (fragbuffer + i, &data->authhdr[type], ATH_HDRLEN * sizeof (uint8_t));  // Authentication header, excluding authentication data
        i += ATH_HDRLEN;
        memcpy (fragbuffer + i, data->auth_data[type], data->auth_len[type] * sizeof (uint8_t));  // Authentication data
        i += data->auth_len[type];
        break;

      // ESP header, excluding payload data, ESP tail, and auth. data
      // All links in chain to follow are part of ESP payload.
      case 6:
        memcpy (fragbuffer + i, &data->esphdr[type], ESP_HDRLEN * sizeof (uint8_t));
        i += ESP_HDRLEN;
        break;

      // Destination header (last)
      case 8:
        // Copy destination header (without options) to fragbuffer.
        memcpy (fragbuffer + i, &data->dstlhdr[type], DST_HDRLEN * sizeof (uint8_t));
        i += DST_HDRLEN;

        // Copy destination header options to fragbuffer.
        for (j=0; j<data->dstl_nopt[type]; j++) {

          // Alignment padding
          memcpy (fragbuffer + i, data->dstl_optleadpad[type][j], data->dstl_optleadpadlen[type][j] * sizeof (uint8_t));
          i += data->dstl_optleadpadlen[type][j];

          // Copy destination option to fragbuffer.
          memcpy (fragbuffer + i, data->dstl_options[type][j], data->dstl_optlen[type][j] * sizeof (uint8_t));
          i += data->dstl_optlen[type][j];
        }

        // Trailing padding
        memcpy (fragbuffer + i, data->dstl_opttailpad[type], data->dstl_opttailpadlen[type] * sizeof (uint8_t));
        i += data->dstl_opttailpadlen[type];
        break;

      // TCP header and options
      case 9:
        memcpy (fragbuffer + i, &data->tcphdr[type], TCP_HDRLEN * sizeof (uint8_t));
        i += TCP_HDRLEN;
        for (j=0; j<data->tcp_nopt[type]; j++) {
          memcpy (fragbuffer + i, data->tcp_options[type][j], data->tcp_optlen[type][j] * sizeof (uint8_t));
          i += data->tcp_optlen[type][j];
        }
        i += data->tcp_optpadlen[type];  // TCP options padding
        break;

      // TCP payload data
      case 12:
        memcpy (fragbuffer + i, data->payload[type], data->payloadlen[type] * sizeof (uint8_t));
        i += data->payloadlen[type];
        break;

      // ICMP header
      case 10:
        memcpy (fragbuffer + i, &data->icmp6hdr[type], ICMP_HDRLEN * sizeof (uint8_t));
        i += ICMP_HDRLEN;
        break;

      // ICMP payload data
      case 13:
        memcpy (fragbuffer + i, data->payload[type], data->payloadlen[type] * sizeof (uint8_t));
        i += data->payloadlen[type];
        break;

      // UDP header
      case 11:
        memcpy (fragbuffer + i, &data->udphdr[type], UDP_HDRLEN * sizeof (uint8_t));
        i += UDP_HDRLEN;
        break;

      // UDP payload data
      case 14:
        memcpy (fragbuffer + i, data->payload[type], data->payloadlen[type] * sizeof (uint8_t));
        i += data->payloadlen[type];
        break;

      // Encapsulating security payload trailer (transport and tunnel mode)
      // Here we need to insert the ESP payload padding as well.
      case 7:
        memcpy (fragbuffer + i, &data->esp_pad[type], data->esptail[type].pad_len * sizeof (uint8_t));  // ESP payload padding
        memcpy (fragbuffer + i, &data->esptail[type], ESP_TAILLEN * sizeof (uint8_t));  // ESP trailer
        i += ESP_TAILLEN;
        memcpy (fragbuffer + i, data->esp_auth_data[type], data->esp_auth_len[type] * sizeof (uint8_t));  // Authentication data (ICV)
        i += data->esp_auth_len[type];
        break;

      // Unknown index value
      default:
        fprintf (stderr, "ERROR: Unknown index value %i in build_frag().\n", data->order[type][c]);
        exit (EXIT_FAILURE);
    }

    // Go to next link in chain.
    c++;

  }  // End loop through fragmentable chain

  return (EXIT_SUCCESS);
}

// Setup chain of header, extension headers, and data by setting Next Header fields (IPv6 only).
// Assume no fragmentation here.
int
ip6_chain (int type, struct ip6_hdr *ip6hdr, SPSData *data)
{
  int c;

  /*  0 = IPv6 header
      1 = hop-by-hop header
      2 = destination header (first)
      3 = routing header
      4 = fragment header (not used)
      5 = auth header
      6 = esp header
      7 = esp trailer
      8 = destination header (last)
      9 = TCP header
     10 = ICMPV6 header
     11 = UDP header
     12 = TCP payload data
     13 = ICMP payload data
     14 = UDP payload data
     98 = new IPv6 header
     99 = end of chain marker
 */

  c = 0;  // Index of order array (IPv6 header chain)
  while (data->order[type][c] != 99) {

    switch (data->order[type][c]) {

      // New IP6 header
      case 98:
        data->ip6hdr[type+20].ip6_nxt = set_proto (data->order[type][c+1]);
        break;

      // IP6 header
      // We don't change data->ip6hdr[type].ip6_nxt because that will make the upper layer protocol checksum incorrect.
      case 0:
        ip6hdr->ip6_nxt = set_proto (data->order[type][c+1]);
        break;

      // Hop-by-hop header
      case 1:
        data->hophdr[type].nxt_hdr = set_proto (data->order[type][c+1]);
        break;

      // Destination header (first)
      case 2:
        data->dstfhdr[type].nxt_hdr = set_proto (data->order[type][c+1]);
        break;

      // Routing header
      case 3:
        data->routehdr[type].nxt_hdr = set_proto (data->order[type][c+1]);
        break;

      // Authentication header
      case 5:
        data->authhdr[type].nxt_hdr = set_proto (data->order[type][c+1]);
        break;

      // ESP header
      case 6:
        data->esptail[type].nxt_hdr = set_proto (data->order[type][c+1]);
        break;

      // Destination header (last)
      case 8:
        data->dstlhdr[type].nxt_hdr = set_proto (data->order[type][c+1]);
        break;

      default:
        break;
    }

    // Go to next link in chain.
    c++;
  }

  return (EXIT_SUCCESS);
}

// Set order of all headers, extension headers, and data (IPv6 only).
// Determine where in chain to separate unfragmentable from fragmentable.
int
ip6_order (int type, SPSData *data)
{
  int c;

  // Clear order array.
  memset (data->order[type], 0, MAX_IP6LINKS * sizeof (int));

  /*  0 = IPv6 header
      1 = hop-by-hop header
      2 = destination header (first)
      3 = routing header
      4 = fragment header (not used)
      5 = auth header
      6 = esp header
      7 = esp trailer
      8 = destination header (last)
      9 = TCP header
     10 = ICMPV6 header
     11 = UDP header
     12 = TCP payload data
     13 = ICMP payload data
     14 = UDP payload data
     98 = new IPv6 header
     99 = end of chain marker
 */

  // *****************************************************************
  // NOTE: Here we choose not to allow both AH and ESP on same packet.
  //       ESP is generally considered the standard, since it provides
  //       both authentication and encryption.
  // *****************************************************************

  c = 0;  // Index of order array (IPv6 header chain)

  // Tunnel mode for AH or ESP
  if ((data->auth_hdr_flag[type] && data->auth_tr_tun_flag[type]) ||
      (data->esp_hdr_flag[type] && data->esp_tr_tun_flag[type])) {
    data->order[type][c] = 98;  // New IPv6 header
    c++;

    // Take note of the start of the fragmentable portion.
    data->first_frag[type] = c;

    // Authentication header
    if (data->auth_hdr_flag[type]) {
      data->order[type][c] = 5;  // Authentication header
      c++;

    // ESP header
    } else {
      data->order[type][c] = 6;  // ESP header
      c++;
    }
  }

  // IPv6 header
  data->order[type][c] = 0;  // IPv6 header
  c++;

  // Hop-by-hop header
  if (data->hbh_hdr_flag[type]) {
    data->order[type][c] = 1;  // Hop-by-hop header
    c++;
  }

  // Destination header (first)
  if (data->dstf_hdr_flag[type]) {
    data->order[type][c] = 2;  // Destination header (first)
    c++;
  }

  // Routing header
  if (data->route_hdr_flag[type]) {
    data->order[type][c] = 3;  // Routing header
    c++;
  }

  // Take note of the start of the fragmentable portion (when not in AH or ESP tunnel mode).
  if (!((data->auth_hdr_flag[type] && data->auth_tr_tun_flag[type]) ||
      (data->esp_hdr_flag[type] && data->esp_tr_tun_flag[type]))) {
    data->first_frag[type] = c;
  }

  // Authentication header (transport mode)
  if (data->auth_hdr_flag[type] && !data->auth_tr_tun_flag[type]) {
    data->order[type][c] = 5;  // Authentication header
    c++;
  }

  // Encapsulating security payload header (transport mode)
  if (data->esp_hdr_flag[type] && !data->esp_tr_tun_flag[type]) {
    data->order[type][c] = 6;  // ESP header
    c++;
  }

  // Destination header (last)
  if (data->dstl_hdr_flag[type]) {
    data->order[type][c] = 8;  // Destination header (last)
    c++;
  }

  // Upper layer protocol headers and payload data

  // TCP header and payload data
  if ((type == 3) || (type == 12)) {
    data->order[type][c] = 9;  // TCP header
    c++;

    if (data->payloadlen[type] > 0) {
      data->order[type][c] = 12;  // TCP payload data
      c++;
    }

  // ICMPv6 header and payload data
  } else if ((type == 4) || (type == 13)) {
    data->order[type][c] = 10;  // ICMPv6 header
    c++;
    if (data->payloadlen[type] > 0) {
      data->order[type][c] = 13;  // ICMP payload data
      c++;
    }

  // UDP header and payload data
  } else if ((type == 5) || (type == 14)) {
    data->order[type][c] = 11;  // UDP header
    c++;
    if (data->payloadlen[type] > 0) {
      data->order[type][c] = 14;  // UDP payload data
      c++;
    }
  }

  // Encapsulating security payload trailer (transport and tunnel mode)
  if (data->esp_hdr_flag[type]) {
    data->order[type][c] = 7;  // ESP trailer
    c++;
  }

  // End of chain
  data->order[type][c] = 99;  // End of chain marker

  return (EXIT_SUCCESS);
}

// Return appropriate protocol type value (IPPROTO), depending upon SPS header type index (IPv6 only).
int
set_proto (int val)
{
  /*  0 = IPv6 header
      1 = hop-by-hop header
      2 = destination header (first)
      3 = routing header
      4 = fragment header
      5 = auth header
      6 = esp header
      7 = esp trailer
      8 = destination header (last)
      9 = TCP header
     10 = ICMPV6 header
     11 = UDP header
     98 = new IPv6 header
 */

  switch (val) {
    case 0:
      return (IPPROTO_IPV6);  // 41
    case 1:
      return (IPPROTO_HOPOPTS);  // 0
    case 2:
      return (IPPROTO_DSTOPTS);  // 60
    case 3:
      return (IPPROTO_ROUTING);  // 43
    case 4:
      return (IPPROTO_FRAGMENT);  // 44
    case 5:
      return (IPPROTO_AH);  // 51
    case 6:
      return (IPPROTO_ESP);  // 50
    case 8:
      return (IPPROTO_DSTOPTS);  // 60
    case 9:
      return (IPPROTO_TCP);  // 6
    case 10:
      return (IPPROTO_ICMPV6);  // 58
    case 11:
      return (IPPROTO_UDP);  // 17
    default:
      fprintf (stderr, "ERROR: Unknown index value %i in set_proto().\n", val);
      exit (EXIT_FAILURE);
  }
}

// Determine required number of ethernet frames, frame lengths, and data offsets (IPv4 or IPv6).
int
find_nframes (int type, int mtu, int unfraglen, int fraglen, int *nframes, int *len, int *offset)
{
  int i, c, totlen, frag_hdrlen;

  // Total length of ethernet frame (excludes ethernet header).
  totlen = unfraglen + fraglen;

  // Clear all fragment lengths and offsets.
  memset (len, 0, MAX_FRAGS * sizeof (int));
  memset (offset, 0, MAX_FRAGS * sizeof (int));

  // No fragmentation required if total length is less than or equal to MTU.
  if (totlen <= mtu) {
    *nframes = 1;
    offset[0] = 0;
    len[0] = fraglen;
    return (EXIT_SUCCESS);
  }

  // Fragmentation required.
  // If IPv6, we need to allow for a fragmentation extension header.
  if ((type == 3) || (type ==4) || (type == 5) ||
      (type == 12) || (type == 13) || (type == 14)) {
    frag_hdrlen = FRG_HDRLEN;
  } else {
    frag_hdrlen = 0;
  }

  // Determine number of frames.
  i = 0;  // i is frame number.
  c = 0;  // c is index of fragmentable portion of packet.
  // len[i] is amount of fragmentable part we can include in frame i.
  while (c < fraglen) {

    // Do we still need to fragment remainder of fragmentable portion?

    // Yes, need to fragment more.
    if ((fraglen - c) > (mtu - unfraglen - frag_hdrlen)) {

      if (i > MAX_FRAGS) {
        fprintf (stderr, "ERROR: In find_nframes(), the number of frames i has now exceeded the maximum number of allowed fragments MAX_FRAGS (%i)\n", MAX_FRAGS);
        fprintf (stderr, "       mtu: %i, unfraglen: %i, fraglen: %i, frag_hdrlen: %i\n", mtu, unfraglen, fraglen, frag_hdrlen);
        exit (EXIT_FAILURE);
      }

      len[i] = mtu - unfraglen - frag_hdrlen;

      if (len[i] <= 0) {
        fprintf (stderr, "ERROR: In find_nframes(), len[i] <= 0\n");
        fprintf (stderr, "       len[i] = mtu (%i) - unfraglen (%i) - frag_hdrlen (%i) = %i\n", mtu, unfraglen, frag_hdrlen, len[i]);
        exit (EXIT_FAILURE);
      }

    // No, don't need to fragment any more.
    } else {
      len[i] = fraglen - c;
    }
    c += len[i];

    // If not last fragment, make sure we have an even number of 8-byte blocks.
    // Reduce length as necessary. Section Section 3.2 of RFC 791, and Section 4.5 of RFC 2460.
    if (c < (fraglen - 1)) {
      while ((len[i] % 8) > 0) {
        len[i]--;
        c--;
      }
    }

    i++;  // Increment number of frames.
    offset[i] = (len[i-1] / 8) + offset[i-1];  // Offset of this fragment
  }

  // Total number of ethernet frames.
  *nframes = i;

  return (EXIT_SUCCESS);
}

// Find length of unfragmentable portion (IPv4 only).
int
find4_unfraglen (int type, SPSData *data)
{
  int len;

  len = IP4_HDRLEN + data->ip_opt_totlen[type] + data->ip_optpadlen[type];

  return (len);
}

// Find length of fragmentable portion (IPv4 only).
int
find4_fraglen (int type, SPSData *data)
{
  int len;

  // Upper layer protocol header length.
  if ((type == 0) || (type == 9)) {
    len = TCP_HDRLEN;

  } else if ((type == 1) || (type == 10)) {
    len = ICMP_HDRLEN;

  } else if ((type == 2) || (type == 11)) {
    len = UDP_HDRLEN;
  }

  // Add TCP options (if appropriate).
  if ((type == 0) || (type == 9)) {
    len += data->tcp_opt_totlen[type] + data->tcp_optpadlen[type];
  }

  // Upper protocol payload data
  len += data->payloadlen[type];

  return (len);
}
