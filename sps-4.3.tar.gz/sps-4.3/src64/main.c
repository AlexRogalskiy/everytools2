/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Some flags
int flood_mode;          // Flood flag - indicates a flood is selected with flood checkbutton
int sending;             // Sending flag indicating SPS is sending finite number of packets
int downloading;         // Flag to indicate a file download thread is active
int message_available;   // A message is available to be displayed in a dialog by thread_listen()
int show_dl_messages;    // Flag to show sent and received messages on stdout as files download
int tracing;             // Flag to indicate a traceroute thread is active
int stop_thread_listen;  // Flag to cause timeout function thread_listen() to stop
int ip_asn_searching;    // Flag to indicate an IP delegation search or ASN delegation search thread is active

char send_message[TEXT_STRINGLEN];  // Character array for messages to appear in Activity Log textview

// MUTEXs for the flags
G_LOCK_DEFINE (sending);  // Obtain a MUTEX for flag indicating packets are being sent.
G_LOCK_DEFINE (downloading);  // Obtain a MUTEX for flag indicating a download thread is active.
G_LOCK_DEFINE (message_available);  // Obtain a MUTEX for flag indicating a message from a download or traceroute thread is available to be displayed in a dialog by thread_listen().
G_LOCK_DEFINE (show_dl_messages);  // Obtain a MUTEX for flag indicating messages from file download threads should be sent to stdout.
G_LOCK_DEFINE (tracing);  // Obtain a MUTEX for flag indicating a traceroute thread is active.
G_LOCK_DEFINE (ip_asn_searching);  // Obtain a MUTEX for flag indicating an ASN delegation search or IP address delegation search thread is active.
G_LOCK_DEFINE (send_message);  // Obtain a MUTEX for character array which holds messages to appear in Activity Log textview

int
main (int argc, char **argv)
{
  argc = argc;  // This statement suppresses compiler warning about unused parameter.
  argv = argv;  // This statement suppresses compiler warning about unused parameter.

  int i, j, k;
  char *value;
  GtkTextBuffer *textbuffer;
  GtkBuilder *builder;
  GError *error = NULL;
  unsigned int iseed;
  FILE *fi;

  // Establish an instance of struct SPSData and assign a pointer to it.
  SPSData spsdata, *data;
  data = &spsdata;

  // Initialize GTK+
  gtk_init (&argc, &argv);

  // Create new GtkBuilder object
  builder = gtk_builder_new ();
  if (!gtk_builder_add_from_file (builder, "sps.ui", &error)) {
    g_warning ("%s", error->message);
    g_free (error);
    exit (EXIT_FAILURE);
  }

  // Get objects from user interface
  data->main_window = GTK_WIDGET (gtk_builder_get_object (builder, "main_window"));
  data->menubar1    = GTK_WIDGET (gtk_builder_get_object (builder, "menubar1"));
  data->view        = GTK_WIDGET (gtk_builder_get_object (builder, "view"));

  // Send page

  // Select Packet Type
  data->radiobutton1 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton1"));  // TCP (IPv4) packet type
  data->radiobutton2 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton2"));  // ICMP (IPv4) packet type
  data->radiobutton3 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton3"));  // UDP (IPv4) packet type
  data->radiobutton4 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton4"));  // All (IPv4) packet types (i.e., cycle)
  data->radiobutton5 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton5"));  // TCP (IPv6) packet type
  data->radiobutton6 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton6"));  // ICMP (IPv6) packet type
  data->radiobutton7 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton7"));  // UDP (IPv6) packet type
  data->radiobutton8 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton8"));  // All (IPv6) packet types (i.e., cycle)
  // Number of Packets to Send
  data->entry18 = GTK_WIDGET (gtk_builder_get_object (builder, "entry18"));  // Number of packets to send
  data->checkbutton11 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton11"));  // Flood
  // Activity Log
  data->textview1 = GTK_WIDGET (gtk_builder_get_object (builder, "textview1"));  // SPS activity log
  // IPv6 over IPv4 (6to4)
  data->checkbutton12 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton12"));  // Tunnel IPv6 over IPv4
  data->spinbutton17 = GTK_WIDGET (gtk_builder_get_object (builder, "spinbutton17"));  // Interface maximum transmission unit
  data->checkbutton57 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton57"));  // Pad ethernet frame to meet minimum length, if required
  data->checkbutton14 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton14"));  // TCP - Specify ethernet header
  data->entry125 = GTK_WIDGET (gtk_builder_get_object (builder, "entry125"));  // TCP source IPv4 address for 6to4 packets
  data->checkbutton47 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton47"));  // ICMP - Specify ethernet header
  data->entry160 = GTK_WIDGET (gtk_builder_get_object (builder, "entry160"));  // ICMP source IPv4 address for 6to4 packets
  data->checkbutton32 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton32"));  // UDP - Specify ethernet header
  data->entry161 = GTK_WIDGET (gtk_builder_get_object (builder, "entry161"));  // UDP source IPv4 address for 6to4 packets
  data->checkbutton13 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton13"));  // TCP source IPv4 "Randomize"
  data->checkbutton26 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton26"));  // ICMP source IPv4 "Randomize"
  data->checkbutton27 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton27"));  // UDP source IPv4 "Randomize"
  // Send / Stop
  data->button1 = GTK_BUTTON (gtk_builder_get_object (builder, "button1"));  // Send
  data->button5 = GTK_BUTTON (gtk_builder_get_object (builder, "button5"));  // Stop Flood

  // TCP page (IPv4)

  // Ethernet header
  data->checkbutton18 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton18"));  // Specify ethernet header
  data->checkbutton58 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton58"));  // Pad ethernet frame to meet minimum length, if required
  data->entry144 = GTK_WIDGET (gtk_builder_get_object (builder, "entry144"));  // Destination link-layer (MAC) address
  data->entry145 = GTK_WIDGET (gtk_builder_get_object (builder, "entry145"));  // Source link-layer (MAC) address
  data->entry150 = GTK_WIDGET (gtk_builder_get_object (builder, "entry150"));  // Source interface name
  data->spinbutton5 = GTK_WIDGET (gtk_builder_get_object (builder, "spinbutton5"));  // Interface maximum transmission unit
  data->entry146 = GTK_WIDGET (gtk_builder_get_object (builder, "entry146"));  // Ethernet type code
  // IPv4 header
  data->entry29 = GTK_WIDGET (gtk_builder_get_object (builder, "entry29"));  // IP header length
  data->entry30 = GTK_WIDGET (gtk_builder_get_object (builder, "entry30"));  // Protocol version
  data->entry31 = GTK_WIDGET (gtk_builder_get_object (builder, "entry31"));  // Type of service
  data->entry32 = GTK_WIDGET (gtk_builder_get_object (builder, "entry32"));  // Total length of datagram
  data->entry33 = GTK_WIDGET (gtk_builder_get_object (builder, "entry33"));  // ID sequence number
  data->entry122 = GTK_WIDGET (gtk_builder_get_object (builder, "entry122"));  // Zero
  data->entry37 = GTK_WIDGET (gtk_builder_get_object (builder, "entry37"));  // Do not fragment flag
  data->entry38 = GTK_WIDGET (gtk_builder_get_object (builder, "entry38"));  // More fragments following flag
  data->entry39 = GTK_WIDGET (gtk_builder_get_object (builder, "entry39"));  // Fragmentation offset
  data->entry40 = GTK_WIDGET (gtk_builder_get_object (builder, "entry40"));  // Time-to-live
  data->entry74 = GTK_WIDGET (gtk_builder_get_object (builder, "entry74"));  // Transport layer protocol
  data->entry35 = GTK_WIDGET (gtk_builder_get_object (builder, "entry35"));  // Source IP address
  data->checkbutton5 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton5"));  // Source IP "Randomize" checkbutton
  data->entry36 = GTK_WIDGET (gtk_builder_get_object (builder, "entry36"));  // Destination IP address
  data->entry34 = GTK_WIDGET (gtk_builder_get_object (builder, "entry34"));  // IP checksum
  // IPv4 header options
  data->radiobutton24 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton24"));  // Decimal option data entry
  data->radiobutton25 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton25"));  // Hexadecimal option data entry
  data->entry400 = GTK_WIDGET (gtk_builder_get_object (builder, "entry400"));  // IPv4 options data
  data->button26 = GTK_BUTTON (gtk_builder_get_object (builder, "button26"));  // Insert IP Option After...
  data->entry401 = GTK_WIDGET (gtk_builder_get_object (builder, "entry401"));  // Option # to insert after
  data->button60 = GTK_BUTTON (gtk_builder_get_object (builder, "button60"));  // Append IP option
  data->textview30 = GTK_WIDGET (gtk_builder_get_object (builder, "textview30"));  // Number of IP options in packet
  data->button61 = GTK_BUTTON (gtk_builder_get_object (builder, "button61"));  // View IP options
  data->entry403 = GTK_WIDGET (gtk_builder_get_object (builder, "entry403"));  // Option number to remove
  data->button62 = GTK_BUTTON (gtk_builder_get_object (builder, "button62"));  // Remove option
  // TCP header (IPv4)
  data->entry41   = GTK_WIDGET (gtk_builder_get_object (builder, "entry41"));   // Source port number
  data->checkbutton7 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton7"));  // Source port "Randomize" checkbutton
  data->entry42   = GTK_WIDGET (gtk_builder_get_object (builder, "entry42"));   // Destination port number
  data->entry43   = GTK_WIDGET (gtk_builder_get_object (builder, "entry43"));   // Sequence number
  data->entry44   = GTK_WIDGET (gtk_builder_get_object (builder, "entry44"));   // Ack number
  data->entry45   = GTK_WIDGET (gtk_builder_get_object (builder, "entry45"));   // Reserved
  data->entry46   = GTK_WIDGET (gtk_builder_get_object (builder, "entry46"));   // Data offset
  data->entry47   = GTK_WIDGET (gtk_builder_get_object (builder, "entry47"));   // FIN flag
  data->entry48   = GTK_WIDGET (gtk_builder_get_object (builder, "entry48"));   // SYN flag
  data->entry49   = GTK_WIDGET (gtk_builder_get_object (builder, "entry49"));   // RST flag
  data->entry50   = GTK_WIDGET (gtk_builder_get_object (builder, "entry50"));   // PSH flag
  data->entry51   = GTK_WIDGET (gtk_builder_get_object (builder, "entry51"));   // ACK flag
  data->entry52   = GTK_WIDGET (gtk_builder_get_object (builder, "entry52"));   // URG flag
  data->entry53   = GTK_WIDGET (gtk_builder_get_object (builder, "entry53"));   // ECE flag
  data->entry54   = GTK_WIDGET (gtk_builder_get_object (builder, "entry54"));   // CWR flag
  data->entry55   = GTK_WIDGET (gtk_builder_get_object (builder, "entry55"));   // Window size
  data->entry56   = GTK_WIDGET (gtk_builder_get_object (builder, "entry56"));   // TCP Checksum
  data->entry77   = GTK_WIDGET (gtk_builder_get_object (builder, "entry77"));   // Urgent pointer
  data->radiobutton17 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton17"));  // ASCII data entry
  data->radiobutton18 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton18"));  // Hexadecimal data entry
  data->entry162  = GTK_WIDGET (gtk_builder_get_object (builder, "entry162"));  // TCP data from keyboard
  data->button20  = GTK_BUTTON (gtk_builder_get_object (builder, "button20"));  // TCP data from file
  // TCP (IPv4) options
  data->radiobutton41 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton41"));  // Decimal option data entry
  data->radiobutton42 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton42"));  // Hexadecimal option data entry
  data->entry404 = GTK_WIDGET (gtk_builder_get_object (builder, "entry404"));  // Option data
  data->button47 = GTK_BUTTON (gtk_builder_get_object (builder, "button47"));  // Insert TCP Option After...
  data->entry405 = GTK_WIDGET (gtk_builder_get_object (builder, "entry405"));  // Option # to insert after
  data->button48 = GTK_BUTTON (gtk_builder_get_object (builder, "button48"));  // Append TCP option
  data->textview24 = GTK_WIDGET (gtk_builder_get_object (builder, "textview24"));  // Number of TCP options in packet
  data->button49 = GTK_BUTTON (gtk_builder_get_object (builder, "button49"));  // View TCP options
  data->entry406 = GTK_WIDGET (gtk_builder_get_object (builder, "entry406"));  // Option number to remove
  data->button58 = GTK_BUTTON (gtk_builder_get_object (builder, "button58"));  // Remove option

  data->button3   = GTK_BUTTON (gtk_builder_get_object (builder, "button3"));   // View packet
  data->button11  = GTK_BUTTON (gtk_builder_get_object (builder, "button11"));  // Restore default values

  // TCP page (IPv6)

  // Ethernet header
  data->entry131 = GTK_WIDGET (gtk_builder_get_object (builder, "entry131"));  // Destination link-layer (MAC) address
  data->entry132 = GTK_WIDGET (gtk_builder_get_object (builder, "entry132"));  // Source link-layer (MAC) address
  data->entry154 = GTK_WIDGET (gtk_builder_get_object (builder, "entry154"));  // Source interface name
  data->spinbutton8 = GTK_WIDGET (gtk_builder_get_object (builder, "spinbutton8"));  // Interface maximum transmission unit
  data->entry133 = GTK_WIDGET (gtk_builder_get_object (builder, "entry133"));  // Ethernet type code
  // IPv6 header
  data->entry22  = GTK_WIDGET (gtk_builder_get_object (builder, "entry22"));   // IP version
  data->entry23  = GTK_WIDGET (gtk_builder_get_object (builder, "entry23"));   // Traffic class
  data->entry24  = GTK_WIDGET (gtk_builder_get_object (builder, "entry24"));   // Flow label
  data->entry25 = GTK_WIDGET (gtk_builder_get_object (builder, "entry25"));  // Payload length
  data->entry26 = GTK_WIDGET (gtk_builder_get_object (builder, "entry26"));  // Next header
  data->entry27 = GTK_WIDGET (gtk_builder_get_object (builder, "entry27"));  // Hop limit
  data->entry28 = GTK_WIDGET (gtk_builder_get_object (builder, "entry28"));    // Source IP address
  data->checkbutton2 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton2"));  // Source IP "Randomize" checkbutton
  data->entry78 = GTK_WIDGET (gtk_builder_get_object (builder, "entry78"));  // Destination IP address
  // TCP header (IPv6)
  data->entry79   = GTK_WIDGET (gtk_builder_get_object (builder, "entry79"));   // Source port number
  data->checkbutton4 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton4"));  // Source port "Randomize" checkbutton
  data->entry80   = GTK_WIDGET (gtk_builder_get_object (builder, "entry80"));   // Destination port number
  data->entry81   = GTK_WIDGET (gtk_builder_get_object (builder, "entry81"));   // Sequence number
  data->entry82   = GTK_WIDGET (gtk_builder_get_object (builder, "entry82"));   // Ack number
  data->entry83   = GTK_WIDGET (gtk_builder_get_object (builder, "entry83"));   // Reserved
  data->entry84   = GTK_WIDGET (gtk_builder_get_object (builder, "entry84"));   // Data offset
  data->entry85   = GTK_WIDGET (gtk_builder_get_object (builder, "entry85"));   // FIN flag
  data->entry86   = GTK_WIDGET (gtk_builder_get_object (builder, "entry86"));   // SYN flag
  data->entry87   = GTK_WIDGET (gtk_builder_get_object (builder, "entry87"));   // RST flag
  data->entry88   = GTK_WIDGET (gtk_builder_get_object (builder, "entry88"));   // PSH flag
  data->entry89   = GTK_WIDGET (gtk_builder_get_object (builder, "entry89"));   // ACK flag
  data->entry90   = GTK_WIDGET (gtk_builder_get_object (builder, "entry90"));   // URG flag
  data->entry91   = GTK_WIDGET (gtk_builder_get_object (builder, "entry91"));   // ECE flag
  data->entry92   = GTK_WIDGET (gtk_builder_get_object (builder, "entry92"));   // CWR flag
  data->entry93   = GTK_WIDGET (gtk_builder_get_object (builder, "entry93"));   // Window size
  data->entry94   = GTK_WIDGET (gtk_builder_get_object (builder, "entry94"));   // TCP Checksum
  data->entry95   = GTK_WIDGET (gtk_builder_get_object (builder, "entry95"));   // Urgent pointer
  data->radiobutton19 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton19"));  // ASCII data entry
  data->radiobutton20 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton20"));  // Hexadecimal data entry
  data->entry163  = GTK_WIDGET (gtk_builder_get_object (builder, "entry163"));  // TCP data from keyboard
  data->button22  = GTK_BUTTON (gtk_builder_get_object (builder, "button22"));  // TCP data from file
  // TCP (IPv6) options
  data->radiobutton47 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton47"));  // Decimal option data entry
  data->radiobutton48 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton48"));  // Hexadecimal option data entry
  data->entry413 = GTK_WIDGET (gtk_builder_get_object (builder, "entry413"));  // Option data
  data->button70 = GTK_BUTTON (gtk_builder_get_object (builder, "button70"));  // Insert TCP Option After...
  data->entry414 = GTK_WIDGET (gtk_builder_get_object (builder, "entry414"));  // Option # to insert after
  data->button71 = GTK_BUTTON (gtk_builder_get_object (builder, "button71"));  // Append TCP option
  data->textview32 = GTK_WIDGET (gtk_builder_get_object (builder, "textview32"));  // Number of TCP options in packet
  data->button72 = GTK_BUTTON (gtk_builder_get_object (builder, "button72"));  // View TCP options
  data->entry415 = GTK_WIDGET (gtk_builder_get_object (builder, "entry415"));  // Option number to remove
  data->button73 = GTK_BUTTON (gtk_builder_get_object (builder, "button73"));  // Remove option
  // Extension headers
  data->button98  = GTK_BUTTON (gtk_builder_get_object (builder, "button98"));  // Hop-by-hop extension header
  data->button110 = GTK_BUTTON (gtk_builder_get_object (builder, "button110"));  // Destination extension header
  data->button132 = GTK_BUTTON (gtk_builder_get_object (builder, "button132"));  // Routing extension header
  data->button116 = GTK_BUTTON (gtk_builder_get_object (builder, "button116"));  // Authentication extension header
  data->button126 = GTK_BUTTON (gtk_builder_get_object (builder, "button126"));  // Encapsulating security payload (ESP) extension header

  data->button6   = GTK_BUTTON (gtk_builder_get_object (builder, "button6"));   // View packet
  data->button16  = GTK_BUTTON (gtk_builder_get_object (builder, "button16"));  // Restore default values

  // ICMP page (IPv4)

  // Ethernet header
  data->checkbutton17 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton17"));  // Specify ethernet header
  data->checkbutton59 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton59"));  // Pad ethernet frame to meet minimum length, if required
  data->entry141 = GTK_WIDGET (gtk_builder_get_object (builder, "entry141"));   // Destination link-layer (MAC) address
  data->entry142 = GTK_WIDGET (gtk_builder_get_object (builder, "entry142"));   // Source link-layer (MAC) address
  data->entry151 = GTK_WIDGET (gtk_builder_get_object (builder, "entry151"));   // Source interface name
  data->spinbutton6 = GTK_WIDGET (gtk_builder_get_object (builder, "spinbutton6"));  // Interface maximum transmission unit
  data->entry143 = GTK_WIDGET (gtk_builder_get_object (builder, "entry143"));   // Ethernet type code
  // IPv4 header
  data->entry57   = GTK_WIDGET (gtk_builder_get_object (builder, "entry57"));   // IP header length
  data->entry58   = GTK_WIDGET (gtk_builder_get_object (builder, "entry58"));   // Protocol version
  data->entry59   = GTK_WIDGET (gtk_builder_get_object (builder, "entry59"));   // Type of service
  data->entry60   = GTK_WIDGET (gtk_builder_get_object (builder, "entry60"));   // Total length of datagram
  data->entry61   = GTK_WIDGET (gtk_builder_get_object (builder, "entry61"));   // ID sequence number
  data->entry123  = GTK_WIDGET (gtk_builder_get_object (builder, "entry123"));  // Zero
  data->entry65   = GTK_WIDGET (gtk_builder_get_object (builder, "entry65"));   // Do not fragment flag
  data->entry66   = GTK_WIDGET (gtk_builder_get_object (builder, "entry66"));   // More fragments following flag
  data->entry67   = GTK_WIDGET (gtk_builder_get_object (builder, "entry67"));   // Fragmentation offset
  data->entry68   = GTK_WIDGET (gtk_builder_get_object (builder, "entry68"));   // Time-to-live
  data->entry75   = GTK_WIDGET (gtk_builder_get_object (builder, "entry75"));   // Transport layer protocol
  data->entry63   = GTK_WIDGET (gtk_builder_get_object (builder, "entry63"));   // Source IP address
  data->checkbutton9 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton9"));  // Source IP "Randomize" checkbutton
  data->entry64   = GTK_WIDGET (gtk_builder_get_object (builder, "entry64"));   // Destination IP address
  data->entry62   = GTK_WIDGET (gtk_builder_get_object (builder, "entry62"));   // IP checksum
  // IPv4 header options
  data->radiobutton43 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton43"));  // Decimal option data entry
  data->radiobutton44 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton44"));  // Hexadecimal option data entry
  data->entry407 = GTK_WIDGET (gtk_builder_get_object (builder, "entry407"));  // IPv4 options data
  data->button59 = GTK_BUTTON (gtk_builder_get_object (builder, "button59"));  // Insert IP Option After...
  data->entry408 = GTK_WIDGET (gtk_builder_get_object (builder, "entry408"));  // Option # to insert after
  data->button63 = GTK_BUTTON (gtk_builder_get_object (builder, "button63"));  // Append IP option
  data->textview26 = GTK_WIDGET (gtk_builder_get_object (builder, "textview26"));  // Number of IP options in packet
  data->button64 = GTK_BUTTON (gtk_builder_get_object (builder, "button64"));  // View IP options
  data->entry409 = GTK_WIDGET (gtk_builder_get_object (builder, "entry409"));  // Option number to remove
  data->button65 = GTK_BUTTON (gtk_builder_get_object (builder, "button65"));  // Remove option
  // ICMP header (IPv4)
  data->entry69   = GTK_WIDGET (gtk_builder_get_object (builder, "entry69"));   // Message type
  data->entry70   = GTK_WIDGET (gtk_builder_get_object (builder, "entry70"));   // Message code
  data->entry71   = GTK_WIDGET (gtk_builder_get_object (builder, "entry71"));   // ICMP checksum
  data->entry72   = GTK_WIDGET (gtk_builder_get_object (builder, "entry72"));   // Identifier
  data->entry73   = GTK_WIDGET (gtk_builder_get_object (builder, "entry73"));   // Sequence number
  data->radiobutton9 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton9"));  // ASCII data entry
  data->radiobutton10 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton10"));  // Hexadecimal data entry
  data->entry126  = GTK_WIDGET (gtk_builder_get_object (builder, "entry126"));    // ICMP data from keyboard
  data->button7      = GTK_BUTTON (gtk_builder_get_object (builder, "button7"));  // ICMP data from file

  data->button2   = GTK_BUTTON (gtk_builder_get_object (builder, "button2"));   // View packet
  data->button12  = GTK_BUTTON (gtk_builder_get_object (builder, "button12"));  // Restore default values

  // ICMP page (IPv6)

  // Ethernet header
  data->entry128 = GTK_WIDGET (gtk_builder_get_object (builder, "entry128"));  // Destination link-layer (MAC) address
  data->entry129 = GTK_WIDGET (gtk_builder_get_object (builder, "entry129"));  // Source link-layer (MAC) address
  data->entry153 = GTK_WIDGET (gtk_builder_get_object (builder, "entry153"));  // Source interface name
  data->spinbutton9 = GTK_WIDGET (gtk_builder_get_object (builder, "spinbutton9"));  // Interface maximum transmission unit
  data->entry130 = GTK_WIDGET (gtk_builder_get_object (builder, "entry130"));  // Ethernet type code
  // IPv6 header
  data->entry110  = GTK_WIDGET (gtk_builder_get_object (builder, "entry110"));   // IP version
  data->entry111  = GTK_WIDGET (gtk_builder_get_object (builder, "entry111"));   // Traffic class
  data->entry112  = GTK_WIDGET (gtk_builder_get_object (builder, "entry112"));   // Flow label
  data->entry113 = GTK_WIDGET (gtk_builder_get_object (builder, "entry113"));  // Payload length
  data->entry114 = GTK_WIDGET (gtk_builder_get_object (builder, "entry114"));  // Next header
  data->entry115 = GTK_WIDGET (gtk_builder_get_object (builder, "entry115"));  // Hop limit
  data->entry109 = GTK_WIDGET (gtk_builder_get_object (builder, "entry109"));    // Source IP address
  data->checkbutton10 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton10"));  // Source IP "Randomize" checkbutton
  data->entry116 = GTK_WIDGET (gtk_builder_get_object (builder, "entry116"));  // Destination IP address
  // ICMP header (IPv6)
  data->entry117   = GTK_WIDGET (gtk_builder_get_object (builder, "entry117"));   // Message type
  data->entry118   = GTK_WIDGET (gtk_builder_get_object (builder, "entry118"));   // Message code
  data->entry119   = GTK_WIDGET (gtk_builder_get_object (builder, "entry119"));   // ICMP checksum
  data->entry120   = GTK_WIDGET (gtk_builder_get_object (builder, "entry120"));   // Identifier
  data->entry121   = GTK_WIDGET (gtk_builder_get_object (builder, "entry121"));   // Sequence number
  data->radiobutton11 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton11"));  // ASCII data entry
  data->radiobutton12 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton12"));  // Hexadecimal data entry
  data->entry127   = GTK_WIDGET (gtk_builder_get_object (builder, "entry127"));   // ICMP data from keyboard
  data->button9      = GTK_BUTTON (gtk_builder_get_object (builder, "button9"));  // ICMP data from file
  // Extension headers
  data->button99  = GTK_BUTTON (gtk_builder_get_object (builder, "button99"));  // Hop-by-hop extension header
  data->button111  = GTK_BUTTON (gtk_builder_get_object (builder, "button111"));  // Destination extension header
  data->button133 = GTK_BUTTON (gtk_builder_get_object (builder, "button133"));  // Routing extension header
  data->button117  = GTK_BUTTON (gtk_builder_get_object (builder, "button117"));  // Authentication extension header
  data->button127 = GTK_BUTTON (gtk_builder_get_object (builder, "button127"));  // Encapsulating security payload (ESP) extension header

  data->button17  = GTK_BUTTON (gtk_builder_get_object (builder, "button30"));   // View packet
  data->button18  = GTK_BUTTON (gtk_builder_get_object (builder, "button18"));  // Restore default values

  // UDP page (IPv4)

  // Ethernet header
  data->checkbutton19 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton19"));  // Specify ethernet header
  data->checkbutton60 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton60"));  // Pad ethernet frame to meet minimum length, if required
  data->entry147 = GTK_WIDGET (gtk_builder_get_object (builder, "entry147"));   // Destination link-layer (MAC) address
  data->entry148 = GTK_WIDGET (gtk_builder_get_object (builder, "entry148"));   // Source link-layer (MAC) address
  data->entry152 = GTK_WIDGET (gtk_builder_get_object (builder, "entry152"));   // Source interface name
  data->spinbutton7 = GTK_WIDGET (gtk_builder_get_object (builder, "spinbutton7"));  // Interface maximum transmission unit
  data->entry149 = GTK_WIDGET (gtk_builder_get_object (builder, "entry149"));   // Ethernet type code
  // IPv4 header
  data->entry1   = GTK_WIDGET (gtk_builder_get_object (builder, "entry1"));   // IP header length
  data->entry2   = GTK_WIDGET (gtk_builder_get_object (builder, "entry2"));   // Protocol version
  data->entry3   = GTK_WIDGET (gtk_builder_get_object (builder, "entry3"));   // Type of service
  data->entry4   = GTK_WIDGET (gtk_builder_get_object (builder, "entry4"));   // Total length of datagram
  data->entry5   = GTK_WIDGET (gtk_builder_get_object (builder, "entry5"));   // ID sequence number
  data->entry124  = GTK_WIDGET (gtk_builder_get_object (builder, "entry124"));  // Zero
  data->entry9   = GTK_WIDGET (gtk_builder_get_object (builder, "entry9"));   // Do not fragment flag
  data->entry10  = GTK_WIDGET (gtk_builder_get_object (builder, "entry10"));  // More fragments following flag
  data->entry11  = GTK_WIDGET (gtk_builder_get_object (builder, "entry11"));  // Fragmentation offset
  data->entry12  = GTK_WIDGET (gtk_builder_get_object (builder, "entry12"));  // Time-to-live
  data->entry76  = GTK_WIDGET (gtk_builder_get_object (builder, "entry76"));  // Transport layer protocol
  data->entry7   = GTK_WIDGET (gtk_builder_get_object (builder, "entry7"));   // Source IP address
  data->checkbutton1 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton1"));  // Source IP "Randomize" checkbutton
  data->entry8   = GTK_WIDGET (gtk_builder_get_object (builder, "entry8"));   // Destination IP address
  data->entry6   = GTK_WIDGET (gtk_builder_get_object (builder, "entry6"));   // IP checksum
  // IPv4 header options
  data->radiobutton45 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton45"));  // Decimal option data entry
  data->radiobutton46 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton46"));  // Hexadecimal option data entry
  data->entry410 = GTK_WIDGET (gtk_builder_get_object (builder, "entry410"));  // IPv4 options data
  data->button66 = GTK_BUTTON (gtk_builder_get_object (builder, "button66"));  // Insert IP Option After...
  data->entry411 = GTK_WIDGET (gtk_builder_get_object (builder, "entry411"));  // Option # to insert after
  data->button67 = GTK_BUTTON (gtk_builder_get_object (builder, "button67"));  // Append IP option
  data->textview28 = GTK_WIDGET (gtk_builder_get_object (builder, "textview28"));  // Number of IP options in packet
  data->button68 = GTK_BUTTON (gtk_builder_get_object (builder, "button68"));  // View IP options
  data->entry412 = GTK_WIDGET (gtk_builder_get_object (builder, "entry412"));  // Option number to remove
  data->button69 = GTK_BUTTON (gtk_builder_get_object (builder, "button69"));  // Remove option
  // UDP header (IPv4)
  data->entry13   = GTK_WIDGET (gtk_builder_get_object (builder, "entry13"));   // Source port
  data->checkbutton3 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton3"));  // Source IP "Randomize" checkbutton
  data->entry14   = GTK_WIDGET (gtk_builder_get_object (builder, "entry14"));   // Destination port
  data->entry15   = GTK_WIDGET (gtk_builder_get_object (builder, "entry15"));   // Length of UDP datagram
  data->entry16   = GTK_WIDGET (gtk_builder_get_object (builder, "entry16"));   // UDP checksum
  data->radiobutton13 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton13"));  // ASCII data entry
  data->radiobutton14 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton14"));  // Hexadecimal data entry
  data->entry17   = GTK_WIDGET (gtk_builder_get_object (builder, "entry17"));     // UDP data from keyboard
  data->button8      = GTK_BUTTON (gtk_builder_get_object (builder, "button8"));  // UDP data from file

  data->button4   = GTK_BUTTON (gtk_builder_get_object (builder, "button4"));   // View packet
  data->button15  = GTK_BUTTON (gtk_builder_get_object (builder, "button15"));  // Restore default values

  // UDP page (IPv6)

  // Ethernet header
  data->entry134 = GTK_WIDGET (gtk_builder_get_object (builder, "entry134"));  // Destination link-layer (MAC) address
  data->entry135 = GTK_WIDGET (gtk_builder_get_object (builder, "entry135"));  // Source link-layer (MAC) address
  data->entry155 = GTK_WIDGET (gtk_builder_get_object (builder, "entry155"));  // Source interface name
  data->spinbutton10 = GTK_WIDGET (gtk_builder_get_object (builder, "spinbutton10"));  // Interface maximum transmission unit
  data->entry136 = GTK_WIDGET (gtk_builder_get_object (builder, "entry136"));  // Ethernet type code
  // IPv6 header
  data->entry97  = GTK_WIDGET (gtk_builder_get_object (builder, "entry97"));   // IP version
  data->entry98  = GTK_WIDGET (gtk_builder_get_object (builder, "entry98"));   // Traffic class
  data->entry99  = GTK_WIDGET (gtk_builder_get_object (builder, "entry99"));   // Flow label
  data->entry100 = GTK_WIDGET (gtk_builder_get_object (builder, "entry100"));  // Payload length
  data->entry101 = GTK_WIDGET (gtk_builder_get_object (builder, "entry101"));  // Next header
  data->entry102 = GTK_WIDGET (gtk_builder_get_object (builder, "entry102"));  // Hop limit
  data->entry96 = GTK_WIDGET (gtk_builder_get_object (builder, "entry96"));    // Source IP address
  data->checkbutton6 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton6"));  // Source IP "Randomize" checkbutton
  data->entry103 = GTK_WIDGET (gtk_builder_get_object (builder, "entry103"));  // Destination IP address
  // UDP header (IPv6)
  data->entry104 = GTK_WIDGET (gtk_builder_get_object (builder, "entry104"));  // Source port
  data->checkbutton8 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton8"));  // Source IP "Randomize" checkbutton
  data->entry105 = GTK_WIDGET (gtk_builder_get_object (builder, "entry105"));  // Destination port
  data->entry106 = GTK_WIDGET (gtk_builder_get_object (builder, "entry106"));  // Length of UDP datagram
  data->entry107 = GTK_WIDGET (gtk_builder_get_object (builder, "entry107"));  // UDP checksum
  data->radiobutton15 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton15"));  // ASCII data entry
  data->radiobutton16 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton16"));  // Hexadecimal data entry
  data->entry108 = GTK_WIDGET (gtk_builder_get_object (builder, "entry108"));     // UDP data from keyboard
  data->button10    = GTK_BUTTON (gtk_builder_get_object (builder, "button10"));  // UDP data from file
  // Extension headers
  data->button100  = GTK_BUTTON (gtk_builder_get_object (builder, "button100"));  // Hop-by-hop extension header
  data->button112  = GTK_BUTTON (gtk_builder_get_object (builder, "button112"));  // Destination extension header
  data->button134 = GTK_BUTTON (gtk_builder_get_object (builder, "button134"));  // Routing extension header
  data->button118  = GTK_BUTTON (gtk_builder_get_object (builder, "button118"));  // Authentication extension header
  data->button128 = GTK_BUTTON (gtk_builder_get_object (builder, "button128"));  // Encapsulating security payload (ESP) extension header

  data->button13 = GTK_BUTTON (gtk_builder_get_object (builder, "button13"));  // View packet
  data->button19  = GTK_BUTTON (gtk_builder_get_object (builder, "button19"));  // Restore default values

  // Host/IP page
  data->entry19   = GTK_WIDGET (gtk_builder_get_object (builder, "entry19"));    // Host-to-IP: hostname
  data->textview3 = GTK_WIDGET (gtk_builder_get_object (builder, "textview3"));  // Host-to-IPv4 results
  data->textview6 = GTK_WIDGET (gtk_builder_get_object (builder, "textview6"));  // Host-to-IPv6 results

  data->entry20   = GTK_WIDGET (gtk_builder_get_object (builder, "entry20"));    // IP-to-Host IPv4 address
  data->entry21   = GTK_WIDGET (gtk_builder_get_object (builder, "entry21"));    // IP-to-Host IPv6 address
  data->textview2 = GTK_WIDGET (gtk_builder_get_object (builder, "textview2"));  // IP-to-Host hostname result

  data->textview4 = GTK_WIDGET (gtk_builder_get_object (builder, "textview4"));  // This host hostname
  data->textview23 = GTK_WIDGET (gtk_builder_get_object (builder, "textview23"));  // This host interfaces and IPv4 addresses
  data->textview5 = GTK_WIDGET (gtk_builder_get_object (builder, "textview5"));  // This host interfaces and IPv6 addresses

  data->entry139   = GTK_WIDGET (gtk_builder_get_object (builder, "entry139"));    // This host interface name
  data->textview10 = GTK_WIDGET (gtk_builder_get_object (builder, "textview10"));  // This host interface MAC address
  data->textview21 = GTK_WIDGET (gtk_builder_get_object (builder, "textview21"));  // This host interface current MTU

  data->entry140   = GTK_WIDGET (gtk_builder_get_object (builder, "entry140"));    // IP-to-MAC source interface name
  data->spinbutton1 = GTK_WIDGET (gtk_builder_get_object (builder, "spinbutton1"));  // Timeout for ARP/Neighbor discovery
  data->entry137   = GTK_WIDGET (gtk_builder_get_object (builder, "entry137"));    // IP-to-MAC IPv4 address
  data->entry138   = GTK_WIDGET (gtk_builder_get_object (builder, "entry138"));    // IP-to-MAC IPv6 address
  data->textview11 = GTK_WIDGET (gtk_builder_get_object (builder, "textview11"));  // IP-to-MAC results

  // Load/Save page
  // Load
  data->button21 = GTK_BUTTON (gtk_builder_get_object (builder, "button13"));                   // Load file ...
  // Save
  // Send Packet settings
  data->checkbutton25 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton25"));  // Send Packet settings
  // IPv6 over IPv4 (6to4)
  data->checkbutton15 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton15"));  // IPv4 Ethernet header and IPv4 header
  // IPv4
  data->checkbutton16 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton16"));  // TCP packet
  data->checkbutton20 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton20"));  // ICMP packet
  data->checkbutton21 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton21"));  // UDP packet
  // IPv6
  data->checkbutton22 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton22"));  // TCP packet
  data->checkbutton23 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton23"));  // ICMP packet
  data->checkbutton24 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton24"));  // UDP packet
  // Traceroute settings
  data->checkbutton36 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton36"));  // Traceroute settings
  // IPv6 over IPv4 (6to4)
  data->checkbutton46 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton46"));  // IPv4 Ethernet header and IPv4 header for traceroute
  // IPv4 traceroute
  data->checkbutton39 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton39"));  // TCP packet for traceroute
  data->checkbutton41 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton41"));  // ICMP packet for traceroute
  data->checkbutton42 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton42"));  // UDP packet for traceroute
  // IPv6 Traceroute
  data->checkbutton43 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton43"));  // TCP packet for traceroute
  data->checkbutton44 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton44"));  // ICMP packet for traceroute
  data->checkbutton45 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton45"));  // UDP packet for traceroute
  // Save file
  data->button14 = GTK_BUTTON (gtk_builder_get_object (builder, "button14"));                   // Save file ...

  // Traceroute page (sps.ui)

  // Probe Protocol
  data->radiobutton21 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton21"));  // TCP (IPv4) probe packet
  data->radiobutton22 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton22"));  // ICMP (IPv4) probe packet
  data->radiobutton23 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton23"));  // UDP (IPv4) probe packet
  data->radiobutton26 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton26"));  // TCP (IPv6) probe packet
  data->radiobutton27 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton27"));  // ICMP (IPv6) probe packet
  data->radiobutton28 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton28"));  // UDP (IPv6) probe packet
  // Number of Probes per Hop
  data->spinbutton2 = GTK_WIDGET (gtk_builder_get_object (builder, "spinbutton2"));  // Number of probes per hop
  // Timeout for Reply
  data->spinbutton4 = GTK_WIDGET (gtk_builder_get_object (builder, "spinbutton4"));  // Timeout for reply
  // Maximum Number of Hops
  data->spinbutton3 = GTK_WIDGET (gtk_builder_get_object (builder, "spinbutton3"));  // Timeout for reply
  // Resolve Node Hostnames
  data->checkbutton28 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton28"));  // Yes if checked
  // Edit, Start, Stop buttons
  data->button23 = GTK_BUTTON (gtk_builder_get_object (builder, "button23"));  // Edit packets
  data->button24 = GTK_BUTTON (gtk_builder_get_object (builder, "button24"));  // Start
  data->button25 = GTK_BUTTON (gtk_builder_get_object (builder, "button25"));  // Stop
  // Activity Log
  data->textview7 = GTK_WIDGET (gtk_builder_get_object (builder, "textview7"));  // Traceroute activity log

  // IP / ASN delegation page

  data->checkbutton38 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton38"));  // Flag to show sent and received messages on stdout when files downloading
  data->textview8 = GTK_WIDGET (gtk_builder_get_object (builder, "textview8"));  // Status of ARIN delegation file.
  data->button50 = GTK_BUTTON (gtk_builder_get_object (builder, "button50"));  // Download ARIN delegation file.
  data->textview9 = GTK_WIDGET (gtk_builder_get_object (builder, "textview9"));  // Status of RIPE delegation file.
  data->button51 = GTK_BUTTON (gtk_builder_get_object (builder, "button51"));  // Download RIPE delegation file.
  data->textview12 = GTK_WIDGET (gtk_builder_get_object (builder, "textview12"));  // Status of AFRINIC delegation file.
  data->button52 = GTK_BUTTON (gtk_builder_get_object (builder, "button52"));  // Download AFRINIC delegation file.
  data->textview13 = GTK_WIDGET (gtk_builder_get_object (builder, "textview13"));  // Status of APNIC delegation file.
  data->button53 = GTK_BUTTON (gtk_builder_get_object (builder, "button53"));  // Download APNIC delegation file.
  data->textview14 = GTK_WIDGET (gtk_builder_get_object (builder, "textview14"));  // Status of LACNIC delegation file.
  data->button54 = GTK_BUTTON (gtk_builder_get_object (builder, "button54"));  // Download LACNIC delegation file.
  data->textview15 = GTK_WIDGET (gtk_builder_get_object (builder, "textview15"));  // Status of ISO 3166-1 country code file.
  data->button55 = GTK_BUTTON (gtk_builder_get_object (builder, "button55"));  // Download www.iso.org's ISO 3166-1 country code file.
  data->button56 = GTK_BUTTON (gtk_builder_get_object (builder, "button56"));  // View www.iso.org's ISO 3166-1 country code file.
  data->button57 = GTK_BUTTON (gtk_builder_get_object (builder, "button57"));  // Download all RIR files and www.iso.org's country code list.

  data->entry500 = GTK_WIDGET (gtk_builder_get_object (builder, "entry500"));  // Country name for country name/code search.
  data->entry501 = GTK_WIDGET (gtk_builder_get_object (builder, "entry501"));  // Country code for country name/code search.
  data->entry502 = GTK_WIDGET (gtk_builder_get_object (builder, "entry502"));  // Country name for ASN search.
  data->entry503 = GTK_WIDGET (gtk_builder_get_object (builder, "entry503"));  // Country code for ASN search.
  data->textview16 = GTK_WIDGET (gtk_builder_get_object (builder, "textview16"));  // Results of search for ASN delegations by country.
  data->entry504 = GTK_WIDGET (gtk_builder_get_object (builder, "entry504"));  // ASN for reverse-search for delegation of an ASN.
  data->textview17 = GTK_WIDGET (gtk_builder_get_object (builder, "textview17"));  // Results of reverse-search for delegation of an ASN.
  data->entry505 = GTK_WIDGET (gtk_builder_get_object (builder, "entry505"));  // Country name for IP delegation search.
  data->entry506 = GTK_WIDGET (gtk_builder_get_object (builder, "entry506"));  // Country code for IP delegation search.
  data->textview18 = GTK_WIDGET (gtk_builder_get_object (builder, "textview18"));  // IPv4 address results for IP delegation search.
  data->textview19 = GTK_WIDGET (gtk_builder_get_object (builder, "textview19"));  // IPv6 address results for IP delegation search.
  data->entry507 = GTK_WIDGET (gtk_builder_get_object (builder, "entry507"));  // Country name for IP delegation reverse-search.
  data->entry508 = GTK_WIDGET (gtk_builder_get_object (builder, "entry508"));  // Country code for IP delegation reverse-search.
  data->textview20 = GTK_WIDGET (gtk_builder_get_object (builder, "textview20"));  // IPv4 or IPv6 address results for IP delegation reverse-search.

  // Pseudo-random number generator (PRNG) page
  data->entry319 = GTK_WIDGET (gtk_builder_get_object (builder, "entry319"));  // Seed for PRNG
  data->entry320 = GTK_WIDGET (gtk_builder_get_object (builder, "entry320"));  // Stride for PRNG

  // Initialize random number generator
  iseed = (unsigned int) time (NULL);
  srand (iseed);

  // Start the message listener. Checks every 100 ms for error
  // messages which are to be displayed in a pop-up dialog.
  g_timeout_add (100, (GSourceFunc) thread_listen, data);

  // String for error messages.
  data->error_text = allocate_strmem (TEXT_STRINGLEN);

  // String for warning messages.
  data->warning_text = allocate_strmem (TEXT_STRINGLEN);

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  /* The following are the definitions for variable 'type'.
     Type: 0 = IPv4 TCP, 1 = IPv4 ICMP, 2 = IPv4 UDP
     Type: 3 = IPv6 TCP, 4 = IPv6 ICMP, 5 = IPv6 UDP
     6to4:
     Type: 6 = IPv6 TCP, 7 = IPv6 ICMP, 8 = IPv6 UDP

     Traceroute:
     Type: 9 = IPv4 TCP, 10 = IPv4 ICMP, 11 = IPv4 UDP
     Type: 12 = IPv6 TCP, 13 = IPv6 ICMP, 14 = IPv6 UDP
     Traceroute (6to4):
     Type: 15 = IPv6 TCP, 16 = IPv6 ICMP, 17 = IPv6 UDP

     New IPv6 headers for Auth. and ESP tunnel modes
     Type: 23 = IPv6 TCP, 24 = IPv6 ICMP, 25 = IPv6 UDP
     Type: 32 = IPv6 TCP, 33 = IPv6 ICMP, 34 = IPv6 UDP

     Special type for sending all (cycling through) IPv4 or IPv6 packets:
     Type: 100 = all IPv4, 101 = all IPv6
  */

  data->ntypes = 18;  // Number of types listed above

  // Table of type values from above matched to protocol type values: protocol_type[type] = int
  data->protocol_type = allocate_intmem (data->ntypes);

  data->protocol_type[0] = IPPROTO_TCP;     // 6
  data->protocol_type[1] = IPPROTO_ICMP;    // 1
  data->protocol_type[2] = IPPROTO_UDP;     // 17
  data->protocol_type[3] = IPPROTO_TCP;     // 6
  data->protocol_type[4] = IPPROTO_ICMPV6;  // 58
  data->protocol_type[5] = IPPROTO_UDP;
  data->protocol_type[6] = IPPROTO_TCP;
  data->protocol_type[7] = IPPROTO_ICMPV6;
  data->protocol_type[8] = IPPROTO_UDP;
  data->protocol_type[9] = IPPROTO_TCP;
  data->protocol_type[10] = IPPROTO_ICMP;
  data->protocol_type[11] = IPPROTO_UDP;
  data->protocol_type[12] = IPPROTO_TCP;
  data->protocol_type[13] = IPPROTO_ICMPV6;
  data->protocol_type[14] = IPPROTO_UDP;
  data->protocol_type[15] = IPPROTO_TCP;
  data->protocol_type[16] = IPPROTO_ICMPV6;
  data->protocol_type[17] = IPPROTO_UDP;

  // Flag to indicate if using user-supplied the ethernet header
  data->specify_ether = allocate_intmem (data->ntypes);

  // Allocate memory for ethernet headers.
  // ethhdr[type] = Ethhdr
  data->ethhdr = allocate_ethhdr (data->ntypes);

  // Allocate memory for interface names.
  // ifname[type] = char *
  data->ifname = allocate_strmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->ifname[i] = allocate_strmem (TMP_STRINGLEN);
  }

  // Allocate memory for interface maximum transission unit (MTU).
  // ifmtu[type] = int
  data->ifmtu = allocate_intmem (data->ntypes);

  // Allocate memory for IPv4 headers.
  // These waste a bit of memory since there aren't ntypes IPv4 headers.
  // ip4hdr[type] = struct ip
  data->ip4hdr = allocate_ip4hdr (data->ntypes);

  // Allocate memory for IPv6 headers.
  // These waste a bit of memory since there aren't ntypes IPv6 headers.
  // Add extra for type+20, which are for "new" IPv6 headers required when using auth. and ESP headers in tunnel mode.
  // ip6hdr[type] = struct ip6_hdr
  data->ip6hdr = allocate_ip6hdr (data->ntypes + 20);

  // Allocate memory for IPv4 IP header options.
  // These waste a bit of memory since there aren't ntypes IPv4 headers.

  // ip_nopt[type] = int
  data->ip_nopt = allocate_intmem (data->ntypes);

  // ip_opt_totlen[type] = int
  data->ip_opt_totlen = allocate_intmem (data->ntypes);

  // ip_optlen[type][option #] = int
  data->ip_optlen = allocate_intmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->ip_optlen[i] = allocate_intmem (MAX_IP4OPTIONS);
  }

  // ip_options[type][option #] = unsigned char *
  data->ip_options = allocate_ustrmempp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->ip_options[i] = allocate_ustrmemp (MAX_IP4OPTIONS);
    for (j=0; j<MAX_IP4OPTIONS; j++) {
      data->ip_options[i][j] = allocate_ustrmem (MAX_IP4OPTLEN);
    }
  }

  // IPv4 header option padding length
  // ip_optpadlen[type] = int
  data->ip_optpadlen = allocate_intmem (data->ntypes);

  // ip_optlenbuf[type] = int
  data->ip_optlenbuf = allocate_intmem (data->ntypes);

  // ip_optionsbuf[type] = unsigned char *
  data->ip_optionsbuf = allocate_ustrmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->ip_optionsbuf[i] = allocate_ustrmem (MAX_IP4OPTLEN);
  }

  // Allocate memory for order array for chain of IPv6 headers, extension headers, payloads, etc.
  // These waste a bit of memory since there aren't ntypes IPv6 headers.
  // order[type][link #] = int
  data->order = allocate_intmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->order[i] = allocate_intmem (MAX_IP6LINKS);
  }

  // Link in chain at which fragmentable portion begins
  // first_frag[type] = int
  data->first_frag = allocate_intmem (data->ntypes);

  // Allocate memory for IPv6 hop-by-hop extension header options.

  // Flag indicating a hop-by-hop header
  // hbh_hdr_flag[type] = int
  data->hbh_hdr_flag = allocate_intmem (data->ntypes);

  // Allocate memory for hop-by-hop headers, excluding options.
  // These waste a bit of memory since there aren't ntypes IPv6 headers.
  // hophdr[type] = struct Hopdst_hdr
  data->hophdr = allocate_hopdsthdr (data->ntypes);

  // Number of hop-by-hop options
  // hbh_nopt[type] = int
  data->hbh_nopt = allocate_intmem (data->ntypes);

  // Alignment factor x (of xN + y): hbh_x[type][option #] = int
  data->hbh_x = allocate_intmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->hbh_x[i] = allocate_intmem (MAX_HBHOPTIONS);
  }

  // Alignment factor y (of xN + y): hbh_y[type][option #] = int
  data->hbh_y = allocate_intmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->hbh_y[i] = allocate_intmem (MAX_HBHOPTIONS);
  }

  // hbh_opt_totlen[type] = int
  data->hbh_opt_totlen = allocate_intmem (data->ntypes);

  // hbh_optlen[type][option #] = int
  data->hbh_optlen = allocate_intmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->hbh_optlen[i] = allocate_intmem (MAX_HBHOPTIONS);
  }

  // hbh_options[type][option #] = unsigned char *
  data->hbh_options = allocate_ustrmempp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->hbh_options[i] = allocate_ustrmemp (MAX_HBHOPTIONS);
    for (j=0; j<MAX_HBHOPTIONS; j++) {
      data->hbh_options[i][j] = allocate_ustrmem (MAX_HBHOPTLEN);
    }
  }

  // Hop-by-hop extension header options padding length
  // hbh_optpadlen[type] = int
  data->hbh_optpadlen = allocate_intmem (data->ntypes);

  // Hop-by-hop options alignment padding length
  // hbh_optleadpadlen[type][option #] = int
  data->hbh_optleadpadlen = allocate_intmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->hbh_optleadpadlen[i] = allocate_intmem (MAX_HBHOPTIONS);
  }

  // Hop-by-hop options alignment padding
  // hbh_optleadpad[type][option #] = unsigned char *
  data->hbh_optleadpad = allocate_ustrmempp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->hbh_optleadpad[i] = allocate_ustrmemp (MAX_HBHOPTIONS);
    for (j=0; j<MAX_HBHOPTIONS; j++) {
      data->hbh_optleadpad[i][j] = allocate_ustrmem (MAX_HBHOPTLEN);
    }
  }

  // Hop-by-hop header trailing padding length
  // hbh_opttailpadlen[type] = int
  data->hbh_opttailpadlen = allocate_intmem (data->ntypes);

  // Hop-by-hop header trailing padding
  // hbh_opttailpad[type] = unsigned char *
  data->hbh_opttailpad = allocate_ustrmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->hbh_opttailpad[i] = allocate_ustrmem (MAX_HBHOPTLEN);
  }

  // hbh_optlenbuf[type] = int
  data->hbh_optlenbuf = allocate_intmem (data->ntypes);

  // hbh_optionsbuf[type] = unsigned char *
  data->hbh_optionsbuf = allocate_ustrmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->hbh_optionsbuf[i] = allocate_ustrmem (MAX_HBHOPTLEN);
  }

  // Allocate memory for IPv6 destination extension header (first) options.

  // Flag indicating a destination header (first)
  // dstf_hdr_flag[type] = int
  data->dstf_hdr_flag = allocate_intmem (data->ntypes);

  // Allocate memory for (first) destination headers, excluding options.
  // These waste a bit of memory since there aren't ntypes IPv6 headers.
  // dstfhdr[type] = struct Hopdst_hdr
  data->dstfhdr = allocate_hopdsthdr (data->ntypes);

  // Number of destination header (first) options
  // dstf_nopt[type] = int
  data->dstf_nopt = allocate_intmem (data->ntypes);

  // Alignment factor x (of xN + y): dstf_x[type][option #] = int
  data->dstf_x = allocate_intmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->dstf_x[i] = allocate_intmem (MAX_DSTOPTIONS);
  }

  // Alignment factor y (of xN + y): dstf_y[type][option #] = int
  data->dstf_y = allocate_intmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->dstf_y[i] = allocate_intmem (MAX_DSTOPTIONS);
  }

  // dstf_opt_totlen[type] = int
  data->dstf_opt_totlen = allocate_intmem (data->ntypes);

  // dstf_optlen[type][option #] = int
  data->dstf_optlen = allocate_intmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->dstf_optlen[i] = allocate_intmem (MAX_DSTOPTIONS);
  }

  // dstf_options[type][option #] = unsigned char *
  data->dstf_options = allocate_ustrmempp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->dstf_options[i] = allocate_ustrmemp (MAX_DSTOPTIONS);
    for (j=0; j<MAX_DSTOPTIONS; j++) {
      data->dstf_options[i][j] = allocate_ustrmem (MAX_DSTOPTLEN);
    }
  }

  // Destination extension header (first) options padding length
  // dstf_optpadlen[type] = int
  data->dstf_optpadlen = allocate_intmem (data->ntypes);

  // Destination header (first) options alignment padding length
  // dstf_optleadpadlen[type][option #] = int
  data->dstf_optleadpadlen = allocate_intmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->dstf_optleadpadlen[i] = allocate_intmem (MAX_DSTOPTIONS);
  }

  // Destination header (first) options alignment padding
  // dstf_optleadpad[type][option #] = unsigned char *
  data->dstf_optleadpad = allocate_ustrmempp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->dstf_optleadpad[i] = allocate_ustrmemp (MAX_DSTOPTIONS);
    for (j=0; j<MAX_DSTOPTIONS; j++) {
      data->dstf_optleadpad[i][j] = allocate_ustrmem (MAX_DSTOPTLEN);
    }
  }

  // Destination header (first) trailing padding length
  // dstf_opttailpadlen[type] = int
  data->dstf_opttailpadlen = allocate_intmem (data->ntypes);

  // Destination header (first) trailing padding
  // dstf_opttailpad[type] = unsigned char *
  data->dstf_opttailpad = allocate_ustrmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->dstf_opttailpad[i] = allocate_ustrmem (MAX_DSTOPTLEN);
  }

  // Allocate memory for IPv6 destination (last) extension header options.

  // Flag indicating a destination header (last)
  // dstl_hdr_flag[type] = int
  data->dstl_hdr_flag = allocate_intmem (data->ntypes);

  // Allocate memory for (last) destination headers, excluding options.
  // These waste a bit of memory since there aren't ntypes IPv6 headers.
  // dstlhdr[type] = struct Hopdst_hdr
  data->dstlhdr = allocate_hopdsthdr (data->ntypes);

  // Number of destination (last) options
  // dstl_nopt[type] = int
  data->dstl_nopt = allocate_intmem (data->ntypes);

  // Alignment factor x (of xN + y): dstl_x[type][option #] = int
  data->dstl_x = allocate_intmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->dstl_x[i] = allocate_intmem (MAX_DSTOPTIONS);
  }

  // Alignment factor y (of xN + y): dstl_y[type][option #] = int
  data->dstl_y = allocate_intmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->dstl_y[i] = allocate_intmem (MAX_DSTOPTIONS);
  }

  // dstl_opt_totlen[type] = int
  data->dstl_opt_totlen = allocate_intmem (data->ntypes);

  // dstl_optlen[type][option #] = int
  data->dstl_optlen = allocate_intmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->dstl_optlen[i] = allocate_intmem (MAX_DSTOPTIONS);
  }

  // dstl_options[type][option #] = unsigned char *
  data->dstl_options = allocate_ustrmempp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->dstl_options[i] = allocate_ustrmemp (MAX_DSTOPTIONS);
    for (j=0; j<MAX_DSTOPTIONS; j++) {
      data->dstl_options[i][j] = allocate_ustrmem (MAX_DSTOPTLEN);
    }
  }

  // Destination (last) extension header options padding length
  // dstl_optpadlen[type] = int
  data->dstl_optpadlen = allocate_intmem (data->ntypes);

  // Destination header (last) options alignment padding length
  // dstl_optleadpadlen[type][option #] = int
  data->dstl_optleadpadlen = allocate_intmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->dstl_optleadpadlen[i] = allocate_intmem (MAX_DSTOPTIONS);
  }

  // Destination header (last) options alignment padding
  // dstl_optleadpad[type][option #] = unsigned char *
  data->dstl_optleadpad = allocate_ustrmempp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->dstl_optleadpad[i] = allocate_ustrmemp (MAX_DSTOPTIONS);
    for (j=0; j<MAX_DSTOPTIONS; j++) {
      data->dstl_optleadpad[i][j] = allocate_ustrmem (MAX_DSTOPTLEN);
    }
  }

  // Destination header (last) trailing padding length
  // dstl_opttailpadlen[type] = int
  data->dstl_opttailpadlen = allocate_intmem (data->ntypes);

  // Destination header (last) trailing padding
  // dstl_opttailpad[type] = unsigned char *
  data->dstl_opttailpad = allocate_ustrmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->dstl_opttailpad[i] = allocate_ustrmem (MAX_DSTOPTLEN);
  }

  // dst_optlenbuf[type] = int
  data->dst_optlenbuf = allocate_intmem (data->ntypes);

  // dst_optionsbuf[type] = unsigned char *
  data->dst_optionsbuf = allocate_ustrmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->dst_optionsbuf[i] = allocate_ustrmem (MAX_DSTOPTLEN);
  }

  // Allocate memory for routing extension headers.

  // Flag indicating a routing header
  // route_hdr_flag[type] = int
  data->route_hdr_flag = allocate_intmem (data->ntypes);

  // Allocate memory for routing extension headers.
  // These waste a bit of memory since there aren't ntypes IPv6 headers.
  // routehdr[type] = struct Route_hdr
  data->routehdr = allocate_routehdr (data->ntypes);

  // Routing header data length: route_datlen[type] = int
  data->route_datlen = allocate_intmem (data->ntypes);

  // Routing header data: route_data[type] = unsigned char *
  data->route_data = allocate_ustrmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->route_data[i] = allocate_ustrmem (MAX_ROUTEDATA);
  }

  // Allocate memory for authentication extension headers

  // Flag indicating an authentication header
  // auth_hdr_flag[type] = int
  data->auth_hdr_flag = allocate_intmem (data->ntypes);

  // Flag indicating an authentication header in transport or tunnel mode
  // auth_tr_tun_flag[type] = int
  data->auth_tr_tun_flag = allocate_intmem (data->ntypes);

  // Allocate memory for authentication headers.
  // These waste a bit of memory since there aren't ntypes IPv6 headers.
  // authhdr[type] = struct Auth_hdr
  data->authhdr = allocate_authhdr (data->ntypes);

  // Authentication header authentication data (integrity check value (ICV))
  // auth_data[type] = unsigned char *
  data->auth_data = allocate_ustrmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->auth_data[i] = allocate_ustrmem (MAX_AUTHICVLEN);
  }

  // Authentication header authentication data length (bytes)
  // auth_len[type] = int
  data->auth_len = allocate_intmem (data->ntypes);

  // Allocate memory for encapsulating security payload (ESP) extension headers

  // Flag indicating an ESP header
  // esp_hdr_flag[type] = int
  data->esp_hdr_flag = allocate_intmem (data->ntypes);

  // Flag indicating an ESP header in transport or tunnel mode
  // esp_tr_tun_flag[type] = int
  data->esp_tr_tun_flag = allocate_intmem (data->ntypes);

  // Allocate memory for encapsulating security payload (ESP) extension headers.
  // These waste a bit of memory since there aren't ntypes IPv6 headers.
  // esphdr[type] = struct Esp_hdr
  data->esphdr = allocate_esphdr (data->ntypes);

  // ESP payload padding
  // esp_pad[type] = unsigned char *
  // Section 2.4 of RFC 2406 says it should be up to 3 bytes in length, but
  // we'll allow user to use (invalid) values up to 255.
  data->esp_pad = allocate_ustrmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->esp_pad[i] = allocate_ustrmem (255);
  }

  // Allocate memory for encapsulating security payload (ESP) trailers.
  // These waste a bit of memory since there aren't ntypes IPv6 headers.
  // esptail[type] = struct Esp_tail
  data->esptail = allocate_esptail (data->ntypes);

  // ESP header authentication data (integrity check value (ICV))
  // esp_auth_data[type] = unsigned char *
  data->esp_auth_data = allocate_ustrmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->esp_auth_data[i] = allocate_ustrmem (MAX_AUTHICVLEN);
  }

  // ESP header authentication data length (bytes)
  // esp_auth_len[type] = int
  data->esp_auth_len = allocate_intmem (data->ntypes);

  // Allocate memory for TCP header options.
  // These waste a bit of memory since there aren't ntypes TCP packets.

  // tcp_nopt[type] = int
  // Same types as for ip_nopt. Wastes memory since we really only have 4 types.
  data->tcp_nopt = allocate_intmem (data->ntypes);

  // tcp_opt_totlen[type] = int
  data->tcp_opt_totlen = allocate_intmem (data->ntypes);

  // tcp_optlen[type][option #] = int
  // Same types as for ip_nopt. Wastes memory since we really only have 4 types.
  data->tcp_optlen = allocate_intmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->tcp_optlen[i] = allocate_intmem (MAX_TCPOPTIONS);
  }

  // tcp_options[type][option #] = unsigned char *
  // Same types as for ip_nopt. Wastes memory since we really only have 4 types.
  data->tcp_options = allocate_ustrmempp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->tcp_options[i] = allocate_ustrmemp (MAX_TCPOPTIONS);
    for (j=0; j<MAX_TCPOPTIONS; j++) {
      data->tcp_options[i][j] = allocate_ustrmem (MAX_TCPOPTLEN);
    }
  }

  // TCP header options padding length
  // tcp_optpadlen[type] = int
  // Same types as for ip_nopt. Wastes memory since we really only have 4 types.
  data->tcp_optpadlen = allocate_intmem (data->ntypes);

  // tcp_optlenbuf[type] = int
  // Same types as for ip_nopt. Wastes memory since we really only have 4 types.
  data->tcp_optlenbuf = allocate_intmem (data->ntypes);

  // tcp_optionsbuf[type] = unsigned char *
  // Same types as for ip_nopt. Wastes memory since we really only have 4 types.
  data->tcp_optionsbuf = allocate_ustrmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->tcp_optionsbuf[i] = allocate_ustrmem (MAX_TCPOPTLEN);
  }

  // Array of flags indicating which RIR files we have.
  // rir_file_loaded[file #] = int
  data->rir_file_loaded = allocate_intmem (5);

  // Allocate memory for TCP headers.
  // These waste a bit of memory since there aren't ntypes TCP packets.
  // tcphdr[type] = struct tcphdr *
  data->tcphdr = allocate_tcphdr (data->ntypes);

  // Allocate memory for IPv4 ICMP headers.
  // These waste a bit of memory since there aren't ntypes IPv4 ICMP packets.
  // icmp4hdr[type] = struct icmp
  data->icmp4hdr = allocate_icmp4hdr (data->ntypes);

  // Allocate memory for IPv6 ICMP headers.
  // These waste a bit of memory since there aren't ntypes IPv6 ICMP packets.
  // icmp6hdr[type] = struct icmp6_hdr
  data->icmp6hdr = allocate_icmp6hdr (data->ntypes);

  // Allocate memory for UDP headers.
  // These waste a bit of memory since there aren't ntypes UDP packets.
  // udphdr[type] = struct udphdr
  data->udphdr = allocate_udphdr (data->ntypes);

  // Allocate memory for upper layer protocol data.

  // payload[type] = unsigned char *
  data->payload = allocate_ustrmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->payload[i] = allocate_ustrmem (IP_MAXPACKET);
  }

  // payloadlen[type] = int
  data->payloadlen = allocate_intmem (data->ntypes);

  // Allocate memory for ethernet frame buffers.
  // Start with 1 frame per packet type. We'll use g_realloc() as needed for more frames.
  // ether_frame [type][frame #] = unsigned char *
  data->ether_frame = allocate_ustrmempp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->ether_frame[i] = allocate_ustrmemp (1);
    for (j=0; j<1; j++) {
      data->ether_frame[i][j] = allocate_ustrmem (IP_MAXPACKET + ETH_HDRLEN);
    }
  }

  // Allocate memory for ethernet frame lengths.
  // frame_length [type][frame #] = int
  data->frame_length = allocate_intmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->frame_length[i] = allocate_intmem (MAX_FRAGS);
  }

  // Allocate memory for array of number of frames per type.
  // nframes[type] = int, where type is defined above.
  data->nframes = allocate_intmem (data->ntypes);

  // Allocate memory for unfragmented packet buffers.
  // packet[type] = unsigned char *
  data->packet = allocate_ustrmemp (data->ntypes);
  for (i=0; i<data->ntypes; i++) {
    data->packet[i] = allocate_ustrmem (IP_MAXPACKET + ETH_HDRLEN);
  }

  // Allocate memory for array of packet lengths.
  data->packet_length = allocate_intmem (data->ntypes);

  // Allocate memory for flags which indicate which items to save to SPS file.
  data->save_flags = allocate_ustrmem (256);

  // SET DEFAULT VALUES FOR ALL PARAMETERS

  // Pseudo-random number generator initial iterate number.
  // LA-UR-07-7961
  data->RN_MULT = 9219741426499971445ull;
  data->RN_STRIDE = 1ull;
  data->RN_SEED0 = 1ull;
  data->RN_ADD = 1ull;
  data->RN_BITS = 63;
  data->RN_ITER = 0ull;
  sprintf (value, "%" PRIu64, data->RN_SEED0);
  gtk_entry_set_text (GTK_ENTRY (data->entry319), value);
  sprintf (value, "%" PRIu64, data->RN_STRIDE);
  gtk_entry_set_text (GTK_ENTRY (data->entry320), value);

  // Load/Save page
  // Default to saving all information
  data->save_flags[0] = 1;  // Send packet settings (packet type, number to send, flood flag)
  data->save_flags[1] = 1;  // Flag to specify tunneling IPv6 over IPv4 (6to4)
  data->save_flags[2] = 1;  // IPv4 TCP
  data->save_flags[3] = 1;  // IPv4 ICMP
  data->save_flags[4] = 1;  // IPv4 UDP
  data->save_flags[5] = 1;  // IPv6 TCP
  data->save_flags[6] = 1;  // IPv6 ICMP
  data->save_flags[7] = 1;  // IPv6 UDP
  data->save_flags[8] = 1;  // Traceroute settings (packet type, # of probes, timeout, maximum hops, resolve hostnames)
  data->save_flags[9] = 1;  // Flag to specify traceroute tunneling IPv6 over IPv4 (6to4)
  data->save_flags[10] = 1;  // IPv4 TCP for traceroute
  data->save_flags[11] = 1;  // IPv4 ICMP for traceroute
  data->save_flags[12] = 1;  // IPv4 UDP for traceroute
  data->save_flags[13] = 1;  // IPv6 TCP for traceroute
  data->save_flags[14] = 1;  // IPv6 ICMP for traceroute
  data->save_flags[15] = 1;  // IPv6 UDP for traceroute

  data->save_nitems = 16;  // Number of possible items to save

  // Host / IP page

  // Fill out hostname and IP address textview fields for this machine.
  this_host (data);

  // Manually set properties of timeout spin button (adjustment object method seems buggy).

  data->timeout = 2;

  gtk_spin_button_set_range (GTK_SPIN_BUTTON (data->spinbutton1), 1.0, 20.0);

  gtk_spin_button_set_digits (GTK_SPIN_BUTTON (data->spinbutton1), 0);

  gtk_spin_button_set_increments (GTK_SPIN_BUTTON (data->spinbutton1), 1.0, 0.0);

  gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (data->spinbutton1), TRUE);

  gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (data->spinbutton1), FALSE);

  gtk_spin_button_set_snap_to_ticks (GTK_SPIN_BUTTON (data->spinbutton1), TRUE);

  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton1), 2.0);

  // Send page

  // Select Packet Type:
  //   IPv4: 1 = TCP, 2 = ICMP, 3 = UDP, 4 = All (cycle)
  //   IPv6: 5 = TCP, 6 = ICMP, 7 = UDP, 8 = All (cycle)
  data->packet_type = 0;
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton1), TRUE);

  // Number of Packets to Send
  data->npackets = 1;
  sprintf (value, "%" PRIu64, data->npackets);
  gtk_entry_set_text (GTK_ENTRY (data->entry18), value);
  flood_mode = 0;  // Flood mode not selected
  sending = 0;  // Not currently sending (a set number of) packets

  // IPv6 over IPv4 (6to4) page

  // IPv6 over IPv4 flag
  data->sixto4_flag = 0;  // Default to pure IPv6 without tunnelling over IPv4

  // Default to user-specified 6to4 ethernet header
  data->specify_ether[6] = 1;
  data->specify_ether[7] = 1;
  data->specify_ether[7] = 1;

  // Traceroute page (sps.ui)

  // Probe protocol type: default to IPv4 TCP
  data->packet_type_tr = 9;

  // Number of Probes per Hop: Manually set properties of spin button (adjustment object method seems buggy).
  data->num_probes = 1;

  gtk_spin_button_set_range (GTK_SPIN_BUTTON (data->spinbutton2), 1.0, 20.0);

  gtk_spin_button_set_digits (GTK_SPIN_BUTTON (data->spinbutton2), 0);

  gtk_spin_button_set_increments (GTK_SPIN_BUTTON (data->spinbutton2), 1.0, 0.0);

  gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (data->spinbutton2), TRUE);

  gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (data->spinbutton2), FALSE);

  gtk_spin_button_set_snap_to_ticks (GTK_SPIN_BUTTON (data->spinbutton2), TRUE);

  // Timeout for Reply (seconds): Manually set properties of spin button for (adjustment object method seems buggy).
  data->timeout_tr = 2;

  gtk_spin_button_set_range (GTK_SPIN_BUTTON (data->spinbutton4), 1.0, 20.0);

  gtk_spin_button_set_digits (GTK_SPIN_BUTTON (data->spinbutton4), 0);

  gtk_spin_button_set_increments (GTK_SPIN_BUTTON (data->spinbutton4), 1.0, 0.0);

  gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (data->spinbutton4), TRUE);

  gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (data->spinbutton4), FALSE);

  gtk_spin_button_set_snap_to_ticks (GTK_SPIN_BUTTON (data->spinbutton4), TRUE);

  // Maximum Number of Hops: Manually set properties of spin button (adjustment object method seems buggy).
  data->maxhops = 30;

  gtk_spin_button_set_range (GTK_SPIN_BUTTON (data->spinbutton3), 1.0, 99.0);

  gtk_spin_button_set_digits (GTK_SPIN_BUTTON (data->spinbutton3), 0);

  gtk_spin_button_set_increments (GTK_SPIN_BUTTON (data->spinbutton3), 1.0, 0.0);

  gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (data->spinbutton3), FALSE);

  gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (data->spinbutton3), FALSE);

  gtk_spin_button_set_snap_to_ticks (GTK_SPIN_BUTTON (data->spinbutton3), TRUE);

  // Default to not resolve hostnames of nodes during traceroute.
  data->resolve_tr = 0;

  // Update traceroute setting in UI.
  tr_settings_show (data);

  // Traceroute page (traceroute.ui)

  // Traceroute IPv6 over IPv4 (6to4) page

  // IPv6 over IPv4 flag
  data->sixto4_tr_flag = 0;  // Default to pure IPv6 without tunnelling over IPv4

  // Default to user-specified 6to4 ethernet header
  data->specify_ether[15] = 1;
  data->specify_ether[16] = 1;
  data->specify_ether[17] = 1;

  // Set interface MTU spinbutton properties.

  // TCP (IPv4)
  gtk_spin_button_set_range (GTK_SPIN_BUTTON (data->spinbutton5), 0, 65536.0);  // Minimum is enforced by check_mtu().
  gtk_spin_button_set_digits (GTK_SPIN_BUTTON (data->spinbutton5), 0);
  gtk_spin_button_set_increments (GTK_SPIN_BUTTON (data->spinbutton5), 1.0, 0.0);
  gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (data->spinbutton5), TRUE);
  gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (data->spinbutton5), FALSE);
  gtk_spin_button_set_snap_to_ticks (GTK_SPIN_BUTTON (data->spinbutton5), TRUE);
  // TCP (IPv6)
  gtk_spin_button_set_range (GTK_SPIN_BUTTON (data->spinbutton8), 0, 65536.0);  // Minimum is enforced by check_mtu().
  gtk_spin_button_set_digits (GTK_SPIN_BUTTON (data->spinbutton8), 0);
  gtk_spin_button_set_increments (GTK_SPIN_BUTTON (data->spinbutton8), 1.0, 0.0);
  gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (data->spinbutton8), TRUE);
  gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (data->spinbutton8), FALSE);
  gtk_spin_button_set_snap_to_ticks (GTK_SPIN_BUTTON (data->spinbutton8), TRUE);
  // ICMP (IPv4)
  gtk_spin_button_set_range (GTK_SPIN_BUTTON (data->spinbutton6), 0, 65536.0);  // Minimum is enforced by check_mtu().
  gtk_spin_button_set_digits (GTK_SPIN_BUTTON (data->spinbutton6), 0);
  gtk_spin_button_set_increments (GTK_SPIN_BUTTON (data->spinbutton6), 1.0, 0.0);
  gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (data->spinbutton6), TRUE);
  gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (data->spinbutton6), FALSE);
  gtk_spin_button_set_snap_to_ticks (GTK_SPIN_BUTTON (data->spinbutton6), TRUE);
  // ICMP (IPv6)
  gtk_spin_button_set_range (GTK_SPIN_BUTTON (data->spinbutton9), 0, 65536.0);  // Minimum is enforced by check_mtu().
  gtk_spin_button_set_digits (GTK_SPIN_BUTTON (data->spinbutton9), 0);
  gtk_spin_button_set_increments (GTK_SPIN_BUTTON (data->spinbutton9), 1.0, 0.0);
  gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (data->spinbutton9), TRUE);
  gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (data->spinbutton9), FALSE);
  gtk_spin_button_set_snap_to_ticks (GTK_SPIN_BUTTON (data->spinbutton9), TRUE);
  // UDP (IPv4)
  gtk_spin_button_set_range (GTK_SPIN_BUTTON (data->spinbutton7), 0, 65536.0);  // Minimum is enforced by check_mtu().
  gtk_spin_button_set_digits (GTK_SPIN_BUTTON (data->spinbutton7), 0);
  gtk_spin_button_set_increments (GTK_SPIN_BUTTON (data->spinbutton7), 1.0, 0.0);
  gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (data->spinbutton7), TRUE);
  gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (data->spinbutton7), FALSE);
  gtk_spin_button_set_snap_to_ticks (GTK_SPIN_BUTTON (data->spinbutton7), TRUE);
  // UDP (IPv6)
  gtk_spin_button_set_range (GTK_SPIN_BUTTON (data->spinbutton10), 0, 65536.0);  // Minimum is enforced by check_mtu().
  gtk_spin_button_set_digits (GTK_SPIN_BUTTON (data->spinbutton10), 0);
  gtk_spin_button_set_increments (GTK_SPIN_BUTTON (data->spinbutton10), 1.0, 0.0);
  gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (data->spinbutton10), TRUE);
  gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (data->spinbutton10), FALSE);
  gtk_spin_button_set_snap_to_ticks (GTK_SPIN_BUTTON (data->spinbutton10), TRUE);
  // IPv6 over IPv4 (6to4)
  gtk_spin_button_set_range (GTK_SPIN_BUTTON (data->spinbutton17), 0, 65536.0);  // Minimum is enforced by check_mtu().
  gtk_spin_button_set_digits (GTK_SPIN_BUTTON (data->spinbutton17), 0);
  gtk_spin_button_set_increments (GTK_SPIN_BUTTON (data->spinbutton17), 1.0, 0.0);
  gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (data->spinbutton17), TRUE);
  gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (data->spinbutton17), FALSE);
  gtk_spin_button_set_snap_to_ticks (GTK_SPIN_BUTTON (data->spinbutton17), TRUE);

  // Default packet settings
  // IPv4 header options and TCP options are zero due to malloc()/memset() calls above.

  tcp4_default (data);  // Default IPv4 TCP settings

  tcp6_default (data);  // Default IPv6 TCP settings

  icmp4_default (data);  // Default IPv4 ICMP settings

  icmp6_default (data);  // Default IPv6 ICMP settings

  udp4_default (data);  // Default IPv4 UDP settings

  udp6_default (data);  // Default IPv6 UDP settings

  data->traceroute_flag = 0;  // Traceroute window is not activated at startup

  tcp4_tr_default (data);  // Default IPv4 TCP traceroute settings

  icmp4_tr_default (data);  // Default IPv4 ICMP traceroute settings

  udp4_tr_default (data);  // Default IPv4 UDP traceroute settings

  tcp6_tr_default (data);  // Default IPv6 TCP traceroute settings

  icmp6_tr_default (data);  // Default IPv6 ICMP traceroute settings

  udp6_tr_default (data);  // Default IPv6 UDP traceroute settings

  // Hop-by-hop header defaults
  data->hop_flag = 0;  // Hop-by-hop header window (hop_window) is not displayed.
  data->dec_hex_hbhopt = 0;  // Flag to indicate decimal (0) or hexadecimal (1) data entry
  data->hbhopt_after = 0;  // Option number after which to insert new option
  data->hbhopt_remove = 0;  // Option number to remove

  // Destination header defaults
  data->dst_flag = 0;  // Destination header window (dst_window) is not displayed.
  data->dec_hex_dstopt = 0;  // Flag to indicate decimal (0) or hexadecimal (1) data entry
  data->dst_fl_flag = 1;  // Default to last destination header in destination header editing window.
  data->dstopt_after = 0;  // Option number after which to insert new option
  data->dstopt_remove = 0;  // Option number to remove

  // Routing header defaults
  data->route_flag = 0;  // Routing header window (route_window) is not displayed.
  data->dec_hex_route = 0;  // Flag to indicate decimal (0) or hexadecimal (1) data entry

  // Authentication header defaults
  data->auth_flag = 0;  // Authentication header window (auth_window) is not displayed.
  data->dec_hex_auth = 0;  // Flag to indicate decimal (0) or hexadecimal (1) data entry

  // Encapsulating security payload (ESP) header defaults
  data->esp_flag = 0;  // ESP header window (esp_window) is not displayed.
  data->dec_hex_esp = 0;  // Flag to indicate decimal (0) or hexadecimal (1) data entry

  // Default values for "new" IPv6 headers to be used for authentication or ESP
  // header use in tunnel mode.

  // IPv6 version (4 bits), Traffic class (8 bits), Flow label (20 bits)
  data->ip6hdr[23].ip6_flow = htonl ((6 << 28) | (0 << 20) | 0);
  data->ip6hdr[24].ip6_flow = htonl ((6 << 28) | (0 << 20) | 0);
  data->ip6hdr[25].ip6_flow = htonl ((6 << 28) | (0 << 20) | 0);
  data->ip6hdr[32].ip6_flow = htonl ((6 << 28) | (0 << 20) | 0);
  data->ip6hdr[33].ip6_flow = htonl ((6 << 28) | (0 << 20) | 0);
  data->ip6hdr[34].ip6_flow = htonl ((6 << 28) | (0 << 20) | 0);

  // Payload length (16 bits): will be filled-out when required.

  // Next header (8 bits): will be filled-out when required.

  // Hop limit (8 bits): default to maximum value
  data->ip6hdr[23].ip6_hops = 255u;
  data->ip6hdr[24].ip6_hops = 255u;
  data->ip6hdr[25].ip6_hops = 255u;
  data->ip6hdr[32].ip6_hops = 255u;
  data->ip6hdr[33].ip6_hops = 255u;
  data->ip6hdr[34].ip6_hops = 255u;

  // Source and destination IP addresses will be filled-out when required.

  // Allocate memory for RIR names, URLs, directories, and filenames.

  // Regional Internet Registry (RIR) names
  // rir_name[RIR index] = char *
  data->rir_name = allocate_strmemp (5);
  for (i=0; i<5; i++) {
    data->rir_name[i] = allocate_strmem (TEXT_STRINGLEN);
  }

  // Regional Internet Registry (RIR) HTTP URLs
  // rir_www[RIR index] = char *
  data->rir_www = allocate_strmemp (5);
  for (i=0; i<5; i++) {
    data->rir_www[i] = allocate_strmem (TEXT_STRINGLEN);
  }

  // Regional Internet Registry (RIR) FTP URLs
  // rir_ftp[RIR index] = char *
  data->rir_ftp = allocate_strmemp (5);
  for (i=0; i<5; i++) {
    data->rir_ftp[i] = allocate_strmem (TEXT_STRINGLEN);
  }

  // RIR directory location of IP delegation files
  // rir_dir[RIR index] = char *
  data->rir_dir = allocate_strmemp (5);
  for (i=0; i<5; i++) {
    data->rir_dir[i] = allocate_strmem (TEXT_STRINGLEN);
  }

  // RIR IP delegation filenames
  // rir_file[RIR index] = char *
  data->rir_file = allocate_strmemp (5);
  for (i=0; i<5; i++) {
    data->rir_file[i] = allocate_strmem (TEXT_STRINGLEN);
  }

  // Allocate memory for array[rir][record][field] = uint8_t *
  // Further allocation is performed in read_delegations().
  data->array = allocate_ustrmemppp (5);

  // Allocate memory for country code URL, directory, and filename.

  // International Organization for Standardization (ISO) HTTP URL.
  // country_www = char *
  data->country_www = allocate_strmem (TEXT_STRINGLEN);

  // Country code file directory location.
  // country_dir = char *
  data->country_dir = allocate_strmem (TEXT_STRINGLEN);

  // Country code filename.
  // country_file = char *
  data->country_file = allocate_strmem (TEXT_STRINGLEN);

  // Country name for IP delegation search
  // cname = char *
  data->cname = allocate_strmem (TEXT_STRINGLEN);

  // Country code for IP delegation search
  // ccode = char *
  data->ccode = allocate_strmem (TEXT_STRINGLEN);

  // IPv4 address for IP delegation reverse_search
  // ip4string = char *
  data->ip4string = allocate_strmem (INET_ADDRSTRLEN);

  // IPv6 address for IP delegation reverse_search
  // ip6string = char *
  data->ip6string = allocate_strmem (INET6_ADDRSTRLEN);

  // Open Regional Internet Registry (RIR) information file.
  fi = fopen ("rir-info.txt", "rb");
  if (fi == NULL) {
    fprintf (stderr, "ERROR: Unable to open RIR information file rir-info.txt\n");
    exit (EXIT_FAILURE);
  }

  // Read Regional Internet Registry (RIR) names.
  while (fgetc (fi) != '\n');  // Skip a line
  while (fgetc (fi) != '\n');  // Skip a line
  for (i=0; i<5; i++) {
    if (fgets (data->rir_name[i], TEXT_STRINGLEN, fi) == NULL) {
      fprintf (stderr, "ERROR: Unable to read RIR information file rir-info.txt.\n");
      exit (EXIT_FAILURE);
    }
    data->rir_name[i][strnlen (data->rir_name[i], TEXT_STRINGLEN) - 1] = 0;  // Change \n to 0;
  }

  // Read Regional Internet Registry (RIR) HTTP URLs.
  while (fgetc (fi) != '\n');  // Skip a line
  while (fgetc (fi) != '\n');  // Skip a line
  for (i=0; i<5; i++) {
    if (fgets (data->rir_www[i], TEXT_STRINGLEN, fi) == NULL) {
      fprintf (stderr, "ERROR: Unable to read RIR information file rir-info.txt.\n");
      exit (EXIT_FAILURE);
    }
    data->rir_www[i][strnlen (data->rir_www[i], TEXT_STRINGLEN) - 1] = 0;  // Change \n to 0;
  }

  // Read Regional Internet Registry (RIR) FTP URLs.
  while (fgetc (fi) != '\n');  // Skip a line
  while (fgetc (fi) != '\n');  // Skip a line
  for (i=0; i<5; i++) {
    if (fgets (data->rir_ftp[i], TEXT_STRINGLEN, fi) == NULL) {
      fprintf (stderr, "ERROR: Unable to read RIR information file rir-info.txt.\n");
      exit (EXIT_FAILURE);
    }
    data->rir_ftp[i][strnlen (data->rir_ftp[i], TEXT_STRINGLEN) - 1] = 0;  // Change \n to 0;
  }

  // Read Regional Internet Registry (RIR) IP delegation file directory locations.
  while (fgetc (fi) != '\n');  // Skip a line
  while (fgetc (fi) != '\n');  // Skip a line
  for (i=0; i<5; i++) {
    if (fgets (data->rir_dir[i], TEXT_STRINGLEN, fi) == NULL) {
      fprintf (stderr, "ERROR: Unable to read RIR information file rir-info.txt.\n");
      exit (EXIT_FAILURE);
    }
    data->rir_dir[i][strnlen (data->rir_dir[i], TEXT_STRINGLEN) - 1] = 0;  // Change \n to 0;
  }

  // Read Regional Internet Registry (RIR) IP delegation filenames.
  while (fgetc (fi) != '\n');  // Skip a line
  while (fgetc (fi) != '\n');  // Skip a line
  for (i=0; i<5; i++) {
    if (fgets (data->rir_file[i], TEXT_STRINGLEN, fi) == NULL) {
      fprintf (stderr, "ERROR: Unable to read RIR information file rir-info.txt.\n");
      exit (EXIT_FAILURE);
    }
    data->rir_file[i][strnlen (data->rir_file[i], TEXT_STRINGLEN) - 1] = 0;  // Change \n to 0;
  }

  // Close file descriptor.
  fclose (fi);

  // Load UTF-8 small-capital cross-reference file to array utf8_xref.
  if (load_utf8 (data) != EXIT_SUCCESS) {
    fprintf (stderr, "ERROR: Unable to load small-capital UTF-8 cross-reference file %s.\n", UTF8_FILENAME);
    exit (EXIT_FAILURE);
  }

  // Open country code information file.
  fi = fopen ("country-info.txt", "rb");
  if (fi == NULL) {
    fprintf (stderr, "ERROR: Unable to open country code information file country-info.txt\n");
    exit (EXIT_FAILURE);
  }

  // Read International Organization for Standardization (ISO) HTTP URL
  while (fgetc (fi) != '\n');  // Skip a line
  while (fgetc (fi) != '\n');  // Skip a line
  if (fgets (data->country_www, TEXT_STRINGLEN, fi) == NULL) {
    fprintf (stderr, "ERROR: Unable to read country code information file country-info.txt.\n");
    exit (EXIT_FAILURE);
  }
  data->country_www[strnlen (data->country_www, TEXT_STRINGLEN) - 1] = 0;  // Change \n to 0;

  // Read country code file directory location.
  while (fgetc (fi) != '\n');  // Skip a line
  while (fgetc (fi) != '\n');  // Skip a line
  if (fgets (data->country_dir, TEXT_STRINGLEN, fi) == NULL) {
    fprintf (stderr, "ERROR: Unable to read country code information file country-info.txt.\n");
    exit (EXIT_FAILURE);
  }
  data->country_dir[strnlen (data->country_dir, TEXT_STRINGLEN) - 1] = 0;  // Change \n to 0;

  // Read country code filename.
  while (fgetc (fi) != '\n');  // Skip a line
  while (fgetc (fi) != '\n');  // Skip a line
  if (fgets (data->country_file, TEXT_STRINGLEN, fi) == NULL) {
    fprintf (stderr, "ERROR: Unable to read country code information file country-info.txt.\n");
    exit (EXIT_FAILURE);
  }
  data->country_file[strnlen (data->country_file, TEXT_STRINGLEN) - 1] = 0;  // Change \n to 0;

  // Close file descriptor.
  fclose (fi);

  // IP / ASN delegation page

  // Start with no records by default.
  data->nrecords = allocate_intmem (5);
  for (i=0; i<5; i++) {
    data->nrecords[i] = 0;
  }

  // Check which RIR files are available, if any.
  textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview8));
  if (file_exists (data->rir_file[0])) {
    gtk_text_buffer_set_text (textbuffer, "Available", -1);
  } else {
    gtk_text_buffer_set_text (textbuffer, "Not Available", -1);
  }
  textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview9));
  if (file_exists (data->rir_file[1])) {
    gtk_text_buffer_set_text (textbuffer, "Available", -1);
  } else {
    gtk_text_buffer_set_text (textbuffer, "Not Available", -1);
  }
  textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview12));
  if (file_exists (data->rir_file[2])) {
    gtk_text_buffer_set_text (textbuffer, "Available", -1);
  } else {
    gtk_text_buffer_set_text (textbuffer, "Not Available", -1);
  }
  textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview13));
  if (file_exists (data->rir_file[3])) {
    gtk_text_buffer_set_text (textbuffer, "Available", -1);
  } else {
    gtk_text_buffer_set_text (textbuffer, "Not Available", -1);
  }
  textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview14));
  if (file_exists (data->rir_file[4])) {
    gtk_text_buffer_set_text (textbuffer, "Available", -1);
  } else {
    gtk_text_buffer_set_text (textbuffer, "Not Available", -1);
  }
  textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview15));

  // Flag to indicate no files are currently downloading.
  downloading = 0;

  // Start with no messages available to be reported via thread_listen().
  message_available = 0;

  // Flag to stop timeout function thread_listen().
  // thread_listen() gets invoked when a file download or traceroute thread is started.
  stop_thread_listen = 0;

  // Load RIR files into memory, if available.
  for (i=0; i<5; i++) {
    data->rir_file_loaded[i] = 0;
  }

  // First RIR file.
  if (file_exists (data->rir_file[0])) {
    read_delegation (0, data);
  }
  textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview8));
  if (data->rir_file_loaded[0]) {
    gtk_text_buffer_set_text (textbuffer, "Loaded", -1);
  } else {
    gtk_text_buffer_set_text (textbuffer, "Not Available", -1);
  }

  // Second RIR file.
  if (file_exists (data->rir_file[1])) {
    read_delegation (1, data);
  }
  textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview9));
  if (data->rir_file_loaded[1]) {
    gtk_text_buffer_set_text (textbuffer, "Loaded", -1);
  } else {
    gtk_text_buffer_set_text (textbuffer, "Not Available", -1);
  }

  // Third RIR file.
  if (file_exists (data->rir_file[2])) {
    read_delegation (2, data);
  }
  textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview12));
  if (data->rir_file_loaded[2]) {
    gtk_text_buffer_set_text (textbuffer, "Loaded", -1);
  } else {
    gtk_text_buffer_set_text (textbuffer, "Not Available", -1);
  }

  // Fourth RIR file.
  if (file_exists (data->rir_file[3])) {
    read_delegation (3, data);
  }
  textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview13));
  if (data->rir_file_loaded[3]) {
    gtk_text_buffer_set_text (textbuffer, "Loaded", -1);
  } else {
    gtk_text_buffer_set_text (textbuffer, "Not Available", -1);
  }

  // Fifth RIR file.
  if (file_exists (data->rir_file[4])) {
    read_delegation (4, data);
  }
  textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview14));
  if (data->rir_file_loaded[4]) {
    gtk_text_buffer_set_text (textbuffer, "Loaded", -1);
  } else {
    gtk_text_buffer_set_text (textbuffer, "Not Available", -1);
  }
  textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview15));

  // Load country code file into memory, if available.
  data->countries_loaded = 0;
  if (file_exists (data->country_file)) {
    read_countries (data);
  }
  if (data->countries_loaded) {
    gtk_text_buffer_set_text (textbuffer, "Loaded", -1);
  } else {
    gtk_text_buffer_set_text (textbuffer, "Not Available", -1);
  }

  // Default to show sent and received messages on stdout as files download.
  show_dl_messages = 1;

  // Connect signals to user interface.
  gtk_builder_connect_signals (builder, data);

  // Destroy builder since we don't need it anymore.
  g_object_unref (G_OBJECT (builder));

  // Show window. All other widgets are automatically shown by GtkBuilder.
  gtk_widget_show (data->main_window);

  // Hand over control to GTK+
  gtk_main ();

  // Free allocated memory.
  free (data->error_text);
  free (data->warning_text);

  for (i=0; i<data->nutf8; i++) {
    for (j=0; j<2; j++) {
      free (data->utf8[i][j]);
    }
    free (data->utf8[i]);
  }
  free (data->utf8);

  free (value);

  // Table of protocol type values
  free (data->protocol_type);

  // IPv4 header options
  free (data->ip_nopt);
  free (data->ip_opt_totlen);

  for (i=0; i<data->ntypes; i++) {
    free (data->ip_optlen[i]);
  }
  free (data->ip_optlen);

  for (i=0; i<data->ntypes; i++) {
    for (j=0; j<MAX_IP4OPTIONS; j++) {
      free (data->ip_options[i][j]);
    }
    free (data->ip_options[i]);
  }
  free (data->ip_options);

  free (data->ip_optpadlen);
  free (data->ip_optlenbuf);

  for (i=0; i<data->ntypes; i++) {
    free (data->ip_optionsbuf[i]);
  }
  free (data->ip_optionsbuf);

  // IPv6 order array
  for (i=0; i<data->ntypes; i++) {
    free (data->order[i]);
  }
  free (data->order);
  free (data->first_frag);

  // Hop-by-hop extension header options
  free (data->hbh_hdr_flag);
  free (data->hophdr);
  free (data->hbh_nopt);

  for (i=0; i<data->ntypes; i++) {
    free (data->hbh_x[i]);
  }
  free (data->hbh_x);

  for (i=0; i<data->ntypes; i++) {
    free (data->hbh_y[i]);
  }
  free (data->hbh_y);

  free (data->hbh_opt_totlen);

  for (i=0; i<data->ntypes; i++) {
    free (data->hbh_optlen[i]);
  }
  free (data->hbh_optlen);

  for (i=0; i<data->ntypes; i++) {
    for (j=0; j<MAX_HBHOPTIONS; j++) {
      free (data->hbh_options[i][j]);
    }
    free (data->hbh_options[i]);
  }
  free (data->hbh_options);

  free (data->hbh_optpadlen);

  for (i=0; i<data->ntypes; i++) {
    free (data->hbh_optleadpadlen[i]);
  }
  free (data->hbh_optleadpadlen);

  for (i=0; i<data->ntypes; i++) {
    for (j=0; j<MAX_HBHOPTIONS; j++) {
      free (data->hbh_optleadpad[i][j]);
    }
    free (data->hbh_optleadpad[i]);
  }
  free (data->hbh_optleadpad);

  free (data->hbh_opttailpadlen);

  for (i=0; i<data->ntypes; i++) {
    free (data->hbh_opttailpad[i]);
  }
  free (data->hbh_opttailpad);

  free (data->hbh_optlenbuf);

  for (i=0; i<data->ntypes; i++) {
    free (data->hbh_optionsbuf[i]);
  }
  free (data->hbh_optionsbuf);

  // Destination (first) extension header
  free (data->dstf_hdr_flag);
  free (data->dstfhdr);
  free (data->dstf_nopt);

  for (i=0; i<data->ntypes; i++) {
    free (data->dstf_x[i]);
  }
  free (data->dstf_x);

  for (i=0; i<data->ntypes; i++) {
    free (data->dstf_y[i]);
  }
  free (data->dstf_y);

  free (data->dstf_opt_totlen);

  for (i=0; i<data->ntypes; i++) {
    free (data->dstf_optlen[i]);
  }
  free (data->dstf_optlen);

  for (i=0; i<data->ntypes; i++) {
    for (j=0; j<MAX_DSTOPTIONS; j++) {
      free (data->dstf_options[i][j]);
    }
    free (data->dstf_options[i]);
  }
  free (data->dstf_options);

  free (data->dstf_optpadlen);

  for (i=0; i<data->ntypes; i++) {
    free (data->dstf_optleadpadlen[i]);
  }
  free (data->dstf_optleadpadlen);

  for (i=0; i<data->ntypes; i++) {
    for (j=0; j<MAX_DSTOPTIONS; j++) {
      free (data->dstf_optleadpad[i][j]);
    }
    free (data->dstf_optleadpad[i]);
  }
  free (data->dstf_optleadpad);

  free (data->dstf_opttailpadlen);

  for (i=0; i<data->ntypes; i++) {
    free (data->dstf_opttailpad[i]);
  }
  free (data->dstf_opttailpad);

  // Destination (last) extension header
  free (data->dstl_hdr_flag);
  free (data->dstlhdr);
  free (data->dstl_nopt);

  for (i=0; i<data->ntypes; i++) {
    free (data->dstl_x[i]);
  }
  free (data->dstl_x);

  for (i=0; i<data->ntypes; i++) {
    free (data->dstl_y[i]);
  }
  free (data->dstl_y);

  free (data->dstl_opt_totlen);

  for (i=0; i<data->ntypes; i++) {
    free (data->dstl_optlen[i]);
  }
  free (data->dstl_optlen);

  for (i=0; i<data->ntypes; i++) {
    for (j=0; j<MAX_DSTOPTIONS; j++) {
      free (data->dstl_options[i][j]);
    }
    free (data->dstl_options[i]);
  }
  free (data->dstl_options);

  free (data->dstl_optpadlen);

  for (i=0; i<data->ntypes; i++) {
    free (data->dstl_optleadpadlen[i]);
  }
  free (data->dstl_optleadpadlen);

  for (i=0; i<data->ntypes; i++) {
    for (j=0; j<MAX_DSTOPTIONS; j++) {
      free (data->dstl_optleadpad[i][j]);
    }
    free (data->dstl_optleadpad[i]);
  }
  free (data->dstl_optleadpad);

  free (data->dstl_opttailpadlen);

  for (i=0; i<data->ntypes; i++) {
    free (data->dstl_opttailpad[i]);
  }
  free (data->dstl_opttailpad);

  free (data->dst_optlenbuf);

  for (i=0; i<data->ntypes; i++) {
    free (data->dst_optionsbuf[i]);
  }
  free (data->dst_optionsbuf);

  // Routing extension header
  free (data->route_hdr_flag);
  free (data->routehdr);
  free (data->route_datlen);
  for (i=0; i<data->ntypes; i++) {
    free (data->route_data[i]);
  }
  free (data->route_data);

  // Authentication extension header
  free (data->auth_hdr_flag);
  free (data->authhdr);
  free (data->auth_tr_tun_flag);
  for (i=0; i<data->ntypes; i++) {
    free (data->auth_data[i]);
  }
  free (data->auth_data);

  free (data->auth_len);

  // Encapsulating security payload (ESP) extension header
  free (data->esphdr);
  for (i=0; i<data->ntypes; i++) {
    free (data->esp_pad[i]);
  }
  free (data->esp_pad);
  free (data->esptail);
  free (data->esp_hdr_flag);
  free (data->esp_tr_tun_flag);
  for (i=0; i<data->ntypes; i++) {
    free (data->esp_auth_data[i]);
  }
  free (data->esp_auth_data);

  free (data->esp_auth_len);

  // TCP header options
  free (data->tcp_nopt);
  free (data->tcp_opt_totlen);

  for (i=0; i<data->ntypes; i++) {
    free (data->tcp_optlen[i]);
  }
  free (data->tcp_optlen);

  for (i=0; i<data->ntypes; i++) {
    for (j=0; j<MAX_TCPOPTIONS; j++) {
      free (data->tcp_options[i][j]);
    }
    free (data->tcp_options[i]);
  }
  free (data->tcp_options);

  free (data->tcp_optpadlen);
  free (data->tcp_optlenbuf);

  for (i=0; i<data->ntypes; i++) {
    free (data->tcp_optionsbuf[i]);
  }
  free (data->tcp_optionsbuf);

  // Upper layer protocol payload data
  for (i=0; i<data->ntypes; i++) {
    free (data->payload[i]);
  }
  free (data->payload);
  free (data->payloadlen);

  // Regional internet registry (RIR) data
  for (i=0; i<5; i++) {
    if (data->rir_file_loaded[i]) {
      for (j=0; j<data->nrecords[i]; j++) {
        for (k=0; k<7; k++) {
          free (data->array[i][j][k]);
        }
        free (data->array[i][j]);
      }
      free (data->array[i]);
    }
  }
  free (data->array);
  free (data->rir_file_loaded);
  free (data->nrecords);

  for (i=0; i<5; i++) {
    free (data->rir_name[i]);
    free (data->rir_www[i]);
    free (data->rir_ftp[i]);
    free (data->rir_dir[i]);
    free (data->rir_file[i]);
  }
  free (data->rir_name);
  free (data->rir_www);
  free (data->rir_ftp);
  free (data->rir_dir);
  free (data->rir_file);
  free (data->cname);
  free (data->ccode);
  free (data->ip4string);
  free (data->ip6string);

  // Country code file information.
  free (data->country_www);
  free (data->country_dir);
  free (data->country_file);

  // Country code data
  if (data->countries_loaded) {
    for (i=0; i<data->ncountries; i++) {
      for (j=0; j<2; j++) {
        free (data->cc[i][j]);
      }
      free (data->cc[i]);
    }
    free (data->cc);
  }

  // Ethernet frame data
  free (data->specify_ether);
  free (data->ethhdr);
  for (i=0; i<data->ntypes; i++) {
    free (data->ifname[i]);
  }
  free (data->ifname);
  free (data->ifmtu);
  free (data->ip4hdr);
  free (data->ip6hdr);
  free (data->tcphdr);
  free (data->icmp4hdr);
  free (data->icmp6hdr);
  free (data->udphdr);

  for (i=0; i<data->ntypes; i++) {
    for (j=0; j<data->nframes[i]; j++) {
      free (data->ether_frame[i][j]);
    }
    free (data->ether_frame[i]);
  }
  free (data->ether_frame);

  for (i=0; i<data->ntypes; i++) {
    free (data->frame_length[i]);
  }
  free (data->frame_length);

  free (data->nframes);

  for (i=0; i<data->ntypes; i++) {
    free (data->packet[i]);
  }
  free (data->packet);

  free (data->packet_length);

  free (data->save_flags);

  // Remove thread_listen() timeout function.
  stop_thread_listen = 1;
  sleep (1);  // Give it a chance to stop.

  return (EXIT_SUCCESS);
}
