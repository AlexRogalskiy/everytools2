/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// UDP source port (16 bits)
int
udp_sport_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 65535)) {
    sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->udphdr[type].uh_sport));
    gtk_entry_set_text (GTK_ENTRY (entry), value);
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->udphdr[type].uh_sport = htons ((uint16_t) ascii_to_int64 ((char *) entry_text));  // Update UDP header with new value

    // UDP header checksum (16 bits)
    udp_chksum (type, data);

    // Update ethernet frames.
    if ((type == 2) || (type == 11)) {
      create_ip4_frame (type, data);
    } else if ((type == 5) || (type == 14)) {
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Create a random UDP source port number (16 bits).
int
udp_ran_sport (int *ran_sourceport, int type, GtkWidget *entry, SPSData *data)
{
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  if (!(*ran_sourceport)) {
    *ran_sourceport = 1;
    data->udphdr[type].uh_sport = htons (ran16_0to65535 (data));
    sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->udphdr[type].uh_sport));
    gtk_entry_set_text (GTK_ENTRY (entry), value);

    // UDP checksum (16 bits)
    udp_chksum (type, data);

    // Update ethernet frames.
    if ((type == 2) || (type == 11)) {
      create_ip4_frame (type, data);

    } else if ((type == 5) || (type == 14)) {
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }

  } else {
    *ran_sourceport = 0;
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// UDP destination port (16 bits).
int
udp_dport_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 65535)) {
    sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->udphdr[type].uh_dport));
    gtk_entry_set_text (GTK_ENTRY (entry), value);
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->udphdr[type].uh_dport = htons ((uint16_t) ascii_to_int64 ((char *) entry_text));  // Update UDP header with new value

    // UDP header checksum (16 bits)
    udp_chksum (type, data);

    // Update ethernet frames.
    if ((type == 2) || (type == 11)) {
      create_ip4_frame (type, data);

    } else if ((type == 5) || (type == 14)) {
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Length of UDP datagram (16 bits)
int
udp_len_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 65535)) {
    sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->udphdr[type].uh_ulen));
    gtk_entry_set_text (GTK_ENTRY (entry), value);
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->udphdr[type].uh_ulen = htons ((uint16_t) ascii_to_int64 ((char *) entry_text));  // Update UDP header with new value

    // UDP header checksum (16 bits)
    udp_chksum (type, data);

    // Update ethernet frames.
    if ((type == 2) || (type == 11)) {
      create_ip4_frame (type, data);

    } else if ((type == 5) || (type == 14)) {
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// UDP checksum (16 bits)
int
udp_chksum_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 65535)) {
    sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->udphdr[type].uh_sum));
    gtk_entry_set_text (GTK_ENTRY (entry), value);
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->udphdr[type].uh_sum = htons ((uint16_t) ascii_to_int64 ((char *) entry_text));  // Update UDP header with new value

    // Update ethernet frames.
    if ((type == 2) || (type == 11)) {
      create_ip4_frame (type, data);

    } else if ((type == 5) || (type == 14)) {
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Re-calculate length of UDP datagram and update text entry (IPv4 or IPv6).
int
udp_len (int type, SPSData *data)
{
  GtkWidget *udplen_entry;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Length of UDP datagram (16 bits): UDP header + UDP payload
  data->udphdr[type].uh_ulen = htons (UDP_HDRLEN + data->payloadlen[type]);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->udphdr[type].uh_ulen));

  switch (type) {
    case 2:  // IPv4 UDP
      udplen_entry = data->entry15;
      break;
    case 5:  // IPv6 UDP
      udplen_entry = data->entry106;
      break;
    case 11:  // IPv4 UDP for traceroute
      udplen_entry = data->entry244;
      break;
    case 14:  // IPv6 UDP for traceroute
      udplen_entry = data->entry309;
      break;
    default:
      fprintf (stderr, "ERROR: Invalid upper layer protocol type %i in udp_len().\n", type);
      free (value);
      exit (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (udplen_entry), value);

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Re-calculate UDP checksum and update text entry (IPv4 or IPv6).
int
udp_chksum (int type, SPSData *data)
{
  GtkWidget *chksum_entry;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // UDP header checksum (16 bits)
  if ((type == 2) || (type == 11)) {
    data->udphdr[type].uh_sum = udp4_checksum (data->ip4hdr[type], data->udphdr[type], data->payload[type], data->payloadlen[type]);

  } else if ((type == 5) || (type == 14)) {
    data->udphdr[type].uh_sum = udp6_checksum (data->ip6hdr[type], data->udphdr[type], data->payload[type], data->payloadlen[type]);
  }
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->udphdr[type].uh_sum));

  switch (type) {
    case 2:  // IPv4 UDP
      chksum_entry = data->entry16;
      break;
    case 5:  // IPv6 UDP
      chksum_entry = data->entry107;
      break;
    case 11:  // IPv4 UDP for traceroute
      chksum_entry = data->entry245;
      break;
    case 14:  // IPv6 UDP for traceroute
      chksum_entry = data->entry310;
      break;
    default:
      fprintf (stderr, "ERROR: Invalid upper layer protocol type %i in udp_chksum().\n", type);
      free (value);
      exit (EXIT_FAILURE);
  }

  gtk_entry_set_text (GTK_ENTRY (chksum_entry), value);

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}
