/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Apply defaults for IPv6 TCP over IPv4 (6to4).
int
sixto4_tcp6_default (SPSData *data)
{
  int status, *ip4_flags;
  char *value, *ipaddress;

  // IPv4 header fragmentation flags and offset
  ip4_flags = allocate_intmem (4);

  // Array to hold an IPv4 or IPv6 address + '\0'
  ipaddress = allocate_strmem (INET6_ADDRSTRLEN);

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Number of ethernet frames
  data->nframes[6] = 1;

  // Ethernet header
  
  // Set flag for user to specify ethernet header.
  data->specify_ether[6] = 1;

  // Default interface MTU
  data->ifmtu[6] = 1280;

  // Set spinbutton value to interface MTU.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton17), data->ifmtu[6]);

  // Destination link-layer (MAC) address (48 bits): N/A
  // Address from IPv6 TCP page will be used.

  // Source Interface Name: N/A
  // Interface name from IPv6 TCP page will be used.

  // Source link-layer (MAC) address (48 bits): N/A
  // Address from IPv6 TCP page will be used.

  // Ethernet type code (16 bits): IPv4
  // http://www.iana.org/assignments/ethernet-numbers
  data->ethhdr[6].type_code = htons (ETH_P_IP);

  // IPv4 header for tunnelling IPv6 over IPv4 (6to4) (Section 3.5 of RFC 4213)

  // IPv4 header length (4 bits): Number of 32-bit words in header = 5
  data->ip4hdr[6].ip_hl = IP4_HDRLEN / sizeof (uint32_t);

  // Internet Protocol version (4 bits): IPv4
  data->ip4hdr[6].ip_v = 4u;

  // Type of service (8 bits)
  data->ip4hdr[6].ip_tos = 0;

  // Total length of datagram (16 bits): IPv4 header + IPv6 header + IPv6 payload length
  // Assumes neither IPv4 header options nor TCP options.
  data->ip4hdr[6].ip_len = htons (IP4_HDRLEN + IP6_HDRLEN + TCP_HDRLEN + data->payloadlen[3]);

  // ID sequence number (16 bits): unused, since single datagram
  data->ip4hdr[6].ip_id = htons (31415);

  // Flags, and Fragmentation offset (3, 13 bits): 0 since single datagram
  ip4_flags[0] = 0;  // Zero (1 bit)
  ip4_flags[1] = 0;  // Do not fragment flag (1 bit): 0 (see Section 3.2.1 of RFC 4213)
  ip4_flags[2] = 0;  // More fragments following flag (1 bit)
  ip4_flags[3] = 0;  // Fragmentation offset (13 bits)
  data->ip4hdr[6].ip_off = htons ((ip4_flags[0] << 15) + (ip4_flags[1] << 14) +
    (ip4_flags[2] << 13) + ip4_flags[3]);

  // Time-to-Live (8 bits): use maximum value
  data->ip4hdr[6].ip_ttl = 255u;

  // Transport layer protocol (8 bits): 41 for IPv6 (Section 3.5 of RFC 4213)
  data->ip4hdr[6].ip_p = IPPROTO_IPV6;

  // Source IPv4 address (32 bits): default to random
  data->ran_tcp6to4_sourceip = 1;
  if ((status = inet_pton (AF_INET, ran4_addr (ipaddress, data), &(data->ip4hdr[6].ip_src))) != 1) {
    sprintf (data->error_text, "sixto4_tcp6_default(): inet_pton() failed for source IPv4 address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    free (ipaddress);
    free (value);
    return (EXIT_FAILURE);
  }
  if (inet_ntop (AF_INET, &(data->ip4hdr[6].ip_src), value, INET_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "sixto4_tcp6_default(): inet_ntop() failed for source IPv4 address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    free (ipaddress);
    free (value);
    return (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry125), value);

  // Destination IPv4 address (32 bits): 6to4 anycast address
  if ((status = inet_pton (AF_INET, "192.88.99.1", &(data->ip4hdr[6].ip_dst))) != 1) {
    sprintf (data->error_text, "sixto4_tcp6_default(): inet_pton() failed for destination IPv4 address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    free (ipaddress);
    free (value);
    return (EXIT_FAILURE);
  }

  // IPv4 header checksum (16 bits): set to 0 when calculating checksum
  data->ip4hdr[6].ip_sum = 0;
  data->ip4hdr[6].ip_sum = checksum ((uint16_t *) &data->ip4hdr[6], IP4_HDRLEN);

  // Free allocated memory.
  free (ip4_flags);
  free (ipaddress);
  free (value);

  // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
  memcpy (&data->ip6hdr[6], &data->ip6hdr[3], IP6_HDRLEN * sizeof (uint8_t));

  // Update ethernet frame.
  create_6to4_frame (6, data);

  return (EXIT_SUCCESS);
}

// Apply defaults for IPv6 ICMP over IPv4 (6to4).
int
sixto4_icmp6_default (SPSData *data)
{
  int status, *ip4_flags;
  char *value, *ipaddress;

  // IPv4 header fragmentation flags and offset
  ip4_flags = allocate_intmem (4);

  // Array to hold an IPv4 or IPv6 address + '\0'
  ipaddress = allocate_strmem (INET6_ADDRSTRLEN);

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Number of ethernet frames
  data->nframes[7] = 1;

  // Ethernet header
  
  // Set flag for user to specify ethernet header.
  data->specify_ether[7] = 1;

  // Default interface MTU
  data->ifmtu[7] = 1280;

  // Set spinbutton value to interface MTU.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton17), data->ifmtu[7]);

  // Destination link-layer (MAC) address (48 bits): N/A
  // Address from IPv6 ICMP page will be used.

  // Source Interface Name: N/A
  // Interface name from IPv6 ICMP page will be used.

  // Source link-layer (MAC) address (48 bits): N/A
  // Address from IPv6 ICMP page will be used.

  // Ethernet type code (16 bits): IPv4
  // http://www.iana.org/assignments/ethernet-numbers
  data->ethhdr[7].type_code = htons (ETH_P_IP);

  // IPv4 header for tunnelling IPv6 over IPv4 (6to4) (Section 3.5 of RFC 4213)

  // IPv4 header length (4 bits): Number of 32-bit words in header = 5
  data->ip4hdr[7].ip_hl = IP4_HDRLEN / sizeof (uint32_t);

  // Internet Protocol version (4 bits): IPv4
  data->ip4hdr[7].ip_v = 4u;

  // Type of service (8 bits)
  data->ip4hdr[7].ip_tos = 0;

  // Total length of datagram (16 bits): IPv4 header + IPv6 header + IPv6 payload length
  // Assumes n0 IPv4 header options.
  data->ip4hdr[7].ip_len = htons (IP4_HDRLEN + IP6_HDRLEN + ICMP_HDRLEN + data->payloadlen[4]);

  // ID sequence number (16 bits): unused, since single datagram
  data->ip4hdr[7].ip_id = htons (31415);

  // Flags, and Fragmentation offset (3, 13 bits): 0 since single datagram
  ip4_flags[0] = 0;  // Zero (1 bit)
  ip4_flags[1] = 0;  // Do not fragment flag (1 bit): 0 (see Section 3.2.1 of RFC 4213)
  ip4_flags[2] = 0;  // More fragments following flag (1 bit)
  ip4_flags[3] = 0;  // Fragmentation offset (13 bits)
  data->ip4hdr[7].ip_off = htons ((ip4_flags[0] << 15) + (ip4_flags[1] << 14) +
    (ip4_flags[2] << 13) + ip4_flags[3]);

  // Time-to-Live (8 bits): use maximum value
  data->ip4hdr[7].ip_ttl = 255u;

  // Transport layer protocol (8 bits): 41 for IPv6 (Section 3.5 of RFC 4213)
  data->ip4hdr[7].ip_p = IPPROTO_IPV6;

  // Source IPv4 address (32 bits): default to random
  data->ran_icmp6to4_sourceip = 1;
  if ((status = inet_pton (AF_INET, ran4_addr (ipaddress, data), &(data->ip4hdr[7].ip_src))) != 1) {
    sprintf (data->error_text, "sixto4_icmp6_default(): inet_pton() failed for source IPv4 address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    free (ipaddress);
    free (value);
    return (EXIT_FAILURE);
  }
  if (inet_ntop (AF_INET, &(data->ip4hdr[7].ip_src), value, INET_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "sixto4_icmp6_default(): inet_ntop() failed for source IPv4 address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    free (ipaddress);
    free (value);
    return (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry160), value);

  // Destination IPv4 address (32 bits): 6to4 anycast address
  if ((status = inet_pton (AF_INET, "192.88.99.1", &(data->ip4hdr[7].ip_dst))) != 1) {
    sprintf (data->error_text, "sixto4_icmp6_default(): inet_pton() failed for destination IPv4 address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    free (ipaddress);
    free (value);
    return (EXIT_FAILURE);
  }

  // IPv4 header checksum (16 bits): set to 0 when calculating checksum
  data->ip4hdr[7].ip_sum = 0;
  data->ip4hdr[7].ip_sum = checksum ((uint16_t *) &data->ip4hdr[7], IP4_HDRLEN);

  // Free allocated memory.
  free (ip4_flags);
  free (ipaddress);
  free (value);

  // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
  memcpy (&data->ip6hdr[7], &data->ip6hdr[4], IP6_HDRLEN * sizeof (uint8_t));

  // Update ethernet frame.
  create_6to4_frame (7, data);

  return (EXIT_SUCCESS);
}

// Apply defaults for IPv6 UDP over IPv4 (6to4).
int
sixto4_udp6_default (SPSData *data)
{
  int status, *ip4_flags;
  char *value, *ipaddress;

  // IPv4 header fragmentation flags and offset
  ip4_flags = allocate_intmem (4);

  // Array to hold an IPv4 or IPv6 address + '\0'
  ipaddress = allocate_strmem (INET6_ADDRSTRLEN);

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Number of ethernet frames
  data->nframes[8] = 1;

  // Ethernet header
  
  // Set flag for user to specify ethernet header.
  data->specify_ether[8] = 1;

  // Default interface MTU
  data->ifmtu[8] = 1280;

  // Set spinbutton value to interface MTU.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton17), data->ifmtu[8]);

  // Destination link-layer (MAC) address (48 bits): N/A
  // Address from IPv6 UDP page will be used.

  // Source Interface Name: N/A
  // Interface name from IPv6 UDP page will be used.

  // Source link-layer (MAC) address (48 bits): N/A
  // Address from IPv6 UDP page will be used.

  // Ethernet type code (16 bits): IPv4
  // http://www.iana.org/assignments/ethernet-numbers
  data->ethhdr[8].type_code = htons (ETH_P_IP);

  // IPv4 header length (4 bits): Number of 32-bit words in header = 5
  data->ip4hdr[8].ip_hl = IP4_HDRLEN / sizeof (uint32_t);

  // Internet Protocol version (4 bits): IPv4
  data->ip4hdr[8].ip_v = 4u;

  // Type of service (8 bits)
  data->ip4hdr[8].ip_tos = 0;

  // Total length of datagram (16 bits): IPv4 header + IPv6 header + IPv6 payload length
  // Assumes no IPv4 header options.
  data->ip4hdr[8].ip_len = htons (IP4_HDRLEN + IP6_HDRLEN + UDP_HDRLEN + data->payloadlen[5]);

  // ID sequence number (16 bits): unused, since single datagram
  data->ip4hdr[8].ip_id = htons (31415);

  // Flags, and Fragmentation offset (3, 13 bits): 0 since single datagram
  ip4_flags[0] = 0;  // Zero (1 bit)
  ip4_flags[1] = 0;  // Do not fragment flag (1 bit): 0 (see Section 3.2.1 of RFC 4213)
  ip4_flags[2] = 0;  // More fragments following flag (1 bit)
  ip4_flags[3] = 0;  // Fragmentation offset (13 bits)
  data->ip4hdr[8].ip_off = htons ((ip4_flags[0] << 15) + (ip4_flags[1] << 14) +
    (ip4_flags[2] << 13) + ip4_flags[3]);

  // Time-to-Live (8 bits): use maximum value
  data->ip4hdr[8].ip_ttl = 255u;

  // Transport layer protocol (8 bits): 41 for IPv6 (Section 3.5 of RFC 4213)
  data->ip4hdr[8].ip_p = IPPROTO_IPV6;

  // Source IPv4 address (32 bits): default to random
  data->ran_udp6to4_sourceip = 1;
  if ((status = inet_pton (AF_INET, ran4_addr (ipaddress, data), &(data->ip4hdr[8].ip_src))) != 1) {
    sprintf (data->error_text, "sixto4_udp6_default(): inet_pton() failed for source IPv4 address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    free (ipaddress);
    free (value);
    return (EXIT_FAILURE);
  }
  if (inet_ntop (AF_INET, &(data->ip4hdr[8].ip_src), value, INET_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "sixto4_udp6_default(): inet_ntop() failed for source IPv4 address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    free (ipaddress);
    free (value);
    return (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry161), value);

  // Destination IPv4 address (32 bits): 6to4 anycast address
  if ((status = inet_pton (AF_INET, "192.88.99.1", &(data->ip4hdr[8].ip_dst))) != 1) {
    sprintf (data->error_text, "sixto4_udp6_default(): inet_pton() failed for destination IPv4 address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ip4_flags);
    free (ipaddress);
    free (value);
    return (EXIT_FAILURE);
  }

  // IPv4 header checksum (16 bits): set to 0 when calculating checksum
  data->ip4hdr[8].ip_sum = 0;
  data->ip4hdr[8].ip_sum = checksum ((uint16_t *) &data->ip4hdr[8], IP4_HDRLEN);

  // Free allocated memory.
  free (ip4_flags);
  free (ipaddress);
  free (value);

  // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
  memcpy (&data->ip6hdr[8], &data->ip6hdr[5], IP6_HDRLEN * sizeof (uint8_t));

  // Update ethernet frame.
  create_6to4_frame (8, data);

  return (EXIT_SUCCESS);
}
