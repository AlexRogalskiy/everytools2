/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Function to generate pseudo-random numbers from 0 to 65535, inclusive.
uint16_t
ran16_0to65535 (SPSData *data)
{
  return ((uint16_t) (65536 * prng (data)));  // Gives [0, 65535]
}

// Generate a pseudo-random IPv4 address.
char *
ran4_addr (char *ipaddress, SPSData *data)
{
  uint8_t a, b, c, d;

  a = ((uint8_t) (255.0 * prng (data)) + 1u);  // Gives [1, 255]
  b = (uint8_t) (256.0 * prng (data));  // Gives [0, 255]
  c = (uint8_t) (256.0 * prng (data));  // Gives [0, 255]
  d = (uint8_t) (256.0 * prng (data));  // Gives [0, 255]

  sprintf (ipaddress,"%" PRIu8 "." "%" PRIu8 "." "%" PRIu8 "." "%" PRIu8, a, b, c, d);

  return (ipaddress);
}

// Generate a pseudo-random IPv6 address.
char *
ran6_addr (char *ipaddress, SPSData *data)
{
  uint16_t a, b, c, d, e, f, g, h;

  a = ((uint16_t) (65535 * prng (data))) + 1u;  // Gives [1, 65535]
  b = (uint16_t) (65536 * prng (data));  // Gives [0, 65535]
  c = (uint16_t) (65536 * prng (data));  // Gives [0, 65535]
  d = (uint16_t) (65536 * prng (data));  // Gives [0, 65535]
  e = (uint16_t) (65536 * prng (data));  // Gives [0, 65535]
  f = (uint16_t) (65536 * prng (data));  // Gives [0, 65535]
  g = (uint16_t) (65536 * prng (data));  // Gives [0, 65535]
  h = (uint16_t) (65536 * prng (data));  // Gives [0, 65535]

  sprintf (ipaddress,"%x:%x:%x:%x:%x:%x:%x:%x", a, b, c, d, e, f, g, h);

  return (ipaddress);
}

// Generate a pseudo-random number.
// Note that this modifies RN_SEED.
// LA-UR-07-7961
// Some applications of prng():
//   val = prng ();                              // Gives [0, 1), where val is type double
//   val = (uint8_t) (256.0 * prng ());          // Gives [0, 255]
//   val = ((uint8_t) (255.0 * prng ()) + 1u);   // Gives [1, 255]
//   val = (uint16_t) (65536 * prng ());         // Gives [0, 65535]
//   val = ((uint16_t) (65535 * prng ())) + 1u;  // Gives [1, 65535]
double
prng (SPSData *data)
{
  // Initialize random number parameters for iterate data->RN_ITER.
  prng_init (data);

  // Generate and return pseudo-random number for this iteration.
  data->RN_SEED = ((data->RN_MULT * data->RN_SEED) + data->RN_ADD) & data->RN_MASK;

  // Increment pseudo-random number iteration number.
  data->RN_ITER++;

  return ((double) (data->RN_SEED * data->RN_NORM));
}

// Initialize random number parameters for iterate "iter".
// LA-UR-07-7961
void
prng_init (SPSData *data)
{
  int64_t nskip;
  data->RN_MOD = 1ull << data->RN_BITS;
  data->RN_PERIOD = 1ull << data->RN_BITS;
  data->RN_MASK = (~0ull) >> (64 - data->RN_BITS);
  data->RN_NORM = 1.0 / (double) data->RN_MOD;

  // Generate a new seed from the base seed.
  nskip = data->RN_ITER * data->RN_STRIDE;
  data->RN_SEED = RN_skip_ahead (&nskip, data);
}

// Skip ahead n pseudo-random numbers
// RN_SEED*RN_MULT^n mod RN_MOD
// LA-UR-07-7961
uint64_t
RN_skip_ahead (int64_t *n, SPSData *data)
{
  uint64_t gen, g, inc, c, rn;

  uint64_t seed;
  int64_t nskip = *n;

  seed = data->RN_SEED0;
  nskip = *n;
  gen = 1ull;
  g = data->RN_MULT;
  inc = 0ull;
  c = data->RN_ADD;

  while (nskip < 0ll) nskip += data->RN_PERIOD;  // Add period until nskip > 0
  nskip &= data->RN_MASK;  // mod RN_MOD

  // Get gen = RN_MULT^n, in log2(n) operations, not n operations.
  while (nskip) {
    if (nskip & 1) {
      gen *=  g & data->RN_MASK;
      inc = (inc * g + c) & data->RN_MASK;
    }
    c = (g * c) + (c & data->RN_MASK);
    g *= g & data->RN_MASK;
    nskip >>= 1;
  }
  rn = ((gen * seed) + inc) & data->RN_MASK;

  return ((uint64_t) rn);
}
