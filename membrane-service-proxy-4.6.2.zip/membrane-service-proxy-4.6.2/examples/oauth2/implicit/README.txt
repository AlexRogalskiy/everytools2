This example shows the OAuth2 implicit flow. It uses a Javascript client.

Please follow https://www.membrane-soa.org/service-proxy-doc/4.4/oauth2-implicit-flow-example.htm