This example shows the OAuth2 password flow. A client requests an access token and the token is verified through a token validator.

Please follow https://www.membrane-soa.org/service-proxy-doc/4.4/security/oauth2-credentials-flow.htm