/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

extern int flood_mode;  // Flood flag
extern int sending;  // Sending flag for sending finite number of packets
extern int tracing;  // Flag to indicate a traceroute thread is active
extern int show_dl_messages;  // Flag to show sent and received messages on stdout as files download
extern int downloading;  // Flag to indicate a file download thread is active
extern int ip_asn_searching;  // Flag to indicate an IP delegation search or ASN delegation search thread is active

// Someone has entered a hostname in Host-to-IP converter
int
on_entry19_activate (GtkWidget *entry19, SPSData *data)
{
  const char *entry19_text;
  GtkTextBuffer *textbuffer3, *textbuffer6;  // IPv4 textview, IPv6 textview
  GtkTextIter end;
  struct addrinfo hints, *res, *p;
  int status;
  char ipstr [INET6_ADDRSTRLEN];
  void *ptr;

  entry19_text = gtk_entry_get_text (GTK_ENTRY (entry19));

  memset (&hints, 0, sizeof (struct addrinfo));
  hints.ai_family = AF_UNSPEC;
  hints.ai_socktype = SOCK_STREAM;
  hints.ai_flags = hints.ai_flags | AI_CANONNAME;

  textbuffer3 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview3));
  textbuffer6 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview6));

  if ((status = getaddrinfo (entry19_text, NULL, &hints, &res)) != 0) {
    sprintf (data->error_text, "In callbacks.c: getaddrinfo() failed in on_entry19_activate().\nError message: %s", gai_strerror (status));
    data->parent = data->main_window;
    report_error (data);
    gtk_text_buffer_set_text (textbuffer3, "", -1);
    gtk_text_buffer_set_text (textbuffer6, "", -1);
    return (EXIT_FAILURE);
  }

  // Clear previous IP results from textviews.
  gtk_text_buffer_set_text (textbuffer3, "", -1);
  gtk_text_buffer_set_text (textbuffer6, "", -1);
 
  for (p = res; p != NULL; p = p->ai_next) {

    switch (p->ai_family) {
      case AF_INET:
        ptr = &((struct sockaddr_in *) p->ai_addr)->sin_addr;
        break;
      case AF_INET6:
        ptr = &((struct sockaddr_in6 *) p->ai_addr)->sin6_addr;
        break;
      default:
        ptr = NULL;
        break;
    }
    if (ptr == NULL) {
      sprintf (data->error_text, "In callbacks.c: Unable to find anything in results from getaddrinfo() in on_entry19_activate().\n");
      data->parent = data->main_window;
      report_error (data);
      freeaddrinfo (res);
      textbuffer3 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview3));
      gtk_text_buffer_set_text (textbuffer3, "", -1);
      textbuffer6 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview6));
      gtk_text_buffer_set_text (textbuffer6, "", -1);
      return (EXIT_FAILURE);
    }

    if (inet_ntop (p->ai_family, ptr, ipstr, sizeof ipstr) == NULL) {
      status = errno;
      sprintf (data->error_text, "In callbacks.c: inet_ntop() failed in on_entry19_activate().\nError message: %s", strerror (status));
      data->parent = data->main_window;
      report_error (data);
      freeaddrinfo (res);
      textbuffer3 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview3));
      gtk_text_buffer_set_text (textbuffer3, "", -1);
      textbuffer6 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview6));
      gtk_text_buffer_set_text (textbuffer6, "", -1);
      return (EXIT_FAILURE);
    }
    sprintf (ipstr, "%s\n", ipstr);

    if (p->ai_family == AF_INET6) {
      textbuffer6 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview6));
      gtk_text_buffer_get_end_iter (textbuffer6, &end);
      gtk_text_buffer_insert (textbuffer6, &end, ipstr, -1);
      gtk_text_view_scroll_to_iter (GTK_TEXT_VIEW (data->textview6), &end, 0.0, FALSE, 0, 0);
    } else {
      textbuffer3 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview3));
      gtk_text_buffer_get_end_iter (textbuffer3, &end);
      gtk_text_buffer_insert (textbuffer3, &end, ipstr, -1);
      gtk_text_view_scroll_to_iter (GTK_TEXT_VIEW (data->textview3), &end, 0.0, FALSE, 0, 0);
    }
  }

  freeaddrinfo (res);

  return (EXIT_SUCCESS);
}

// Someone has entered an IPv4 address in IP-to-Hostname converter
int
on_entry20_activate (GtkWidget *entry20, SPSData *data)
{
  int status;
  const char *entry20_text;
  GtkTextBuffer *textbuffer2;
  struct sockaddr_in sa; 
  sa.sin_family = AF_INET;
  char hostname[NI_MAXHOST];

  memset (hostname, 0, NI_MAXHOST * sizeof (char));

  entry20_text = gtk_entry_get_text (GTK_ENTRY (entry20));
  textbuffer2 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview2));

  // Is it a valid IP address?
  if (!is_valid_ip4 (entry20_text)) {
    sprintf (data->error_text, "In callbacks.c: is_valid_ip4() failed in on_entry20_activate().\nAppears to be an invalid IPv4 address.");
    data->parent = data->main_window;
    report_error (data);
    gtk_text_buffer_set_text (textbuffer2, "", -1);
    gtk_entry_set_text (GTK_ENTRY (data->entry21), "");
    return (EXIT_FAILURE);
  }

  if ((status = inet_pton (AF_INET, entry20_text, &sa.sin_addr)) != 1) {
    sprintf (data->error_text, "In callbacks.c: inet_pton() failed in on_entry20_activate().\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    gtk_text_buffer_set_text (textbuffer2, "", -1);
    gtk_entry_set_text (GTK_ENTRY (data->entry21), "");
    return (EXIT_FAILURE);
  }

  if ((status = getnameinfo ((struct sockaddr*)&sa, sizeof (sa), hostname, sizeof (hostname), NULL, 0, 0)) != 0) {
    sprintf (data->error_text, "In callbacks.c: getnameinfo() failed in on_entry20_activate().\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    gtk_text_buffer_set_text (textbuffer2, "", -1);
    gtk_entry_set_text (GTK_ENTRY (data->entry21), "");
    return (EXIT_FAILURE);
  }

  // Clear IPv6 text entry so there's no confusion about which IP belongs to the hostname
  gtk_entry_set_text (GTK_ENTRY (data->entry21), "");

  // Show hostname
  gtk_text_buffer_set_text (textbuffer2, hostname, -1);

  return (EXIT_SUCCESS);
}

// Someone has entered an IPv6 address in IP-to-Hostname converter
int
on_entry21_activate (GtkWidget *entry21, SPSData *data)
{
  int status;
  const char *entry21_text;
  GtkTextBuffer *textbuffer2;
  struct sockaddr_in6 sa;
  sa.sin6_family = AF_INET6;
  char hostname[NI_MAXHOST];

  memset (hostname, 0, NI_MAXHOST * sizeof (char));

  entry21_text = gtk_entry_get_text (GTK_ENTRY (entry21));

  textbuffer2 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview2));

  // Is it a valid IP address? Valid if inet_pton returns 1.
  if (inet_pton (AF_INET6, entry21_text, &sa.sin6_addr) != 1) {

    // Invalid IP
    sprintf (data->error_text, "In callbacks.c: inet_pton() failed in on_entry21_activate().\nAppears to be an invalid IPv6 address.");
    data->parent = data->main_window;
    report_error (data);
    gtk_text_buffer_set_text (textbuffer2, "", -1);
    gtk_entry_set_text (GTK_ENTRY (data->entry20), "");
    return (EXIT_FAILURE);

  // Valid IP
  } else {
    if ((status = getnameinfo ((struct sockaddr *)&sa, sizeof (sa), hostname, sizeof (hostname), NULL, 0, 0)) != 0) {
      sprintf (data->error_text, "In callbacks.c: getnameinfo() failed in on_entry21_activate().\nError message: %s", strerror (status));
      data->parent = data->main_window;
      report_error (data);
      gtk_text_buffer_set_text (textbuffer2, "", -1);
      gtk_entry_set_text (GTK_ENTRY (data->entry20), "");
      return (EXIT_FAILURE);
    }

    // Clear IPv4 text entry so there's no confusion about which IP belongs to the hostname
    gtk_entry_set_text (GTK_ENTRY (data->entry20), "");

    // Show hostname
    textbuffer2 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview2));
    gtk_text_buffer_set_text (textbuffer2, hostname, -1);

    return (EXIT_SUCCESS);
  }
}

// This host's interface name to be converted to link-layer (MAC) address.
int
on_entry139_activate (GtkWidget *entry139, SPSData *data)
{
  int i, mtu;
  const char *entry139_text;
  GtkTextBuffer *textbuffer10, *textbuffer21;
  char *text;
  uint8_t *mac;

  // Array to hold various strings of text
  text = allocate_strmem (TEXT_STRINGLEN);

  // Array of unsigned chars
  mac = allocate_ustrmem (6);

  entry139_text = gtk_entry_get_text (GTK_ENTRY (entry139));
  textbuffer10 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview10));
  textbuffer21 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview21));

  // Obtain MAC address for interface.
  if ((mac = interface_getmac ((char *) entry139_text, mac, data->main_window, data)) == NULL) {
    gtk_text_buffer_set_text (textbuffer10, "", -1);
    gtk_text_buffer_set_text (textbuffer21, "", -1);
    free (text);
    free (mac);
    return (EXIT_FAILURE);
  }

  // Put MAC address into a string.
  memset (text, 0, TEXT_STRINGLEN * sizeof (char));
  for (i=0; i<5; i++) {
    sprintf (text, "%s%02x:", text, (uint8_t) mac[i]);
  }
  sprintf (text, "%s%02x", text, (uint8_t) mac[5]);

  // Print MAC address in textview.
  gtk_text_buffer_set_text (textbuffer10, text, -1);

  // Obtain interface's current MTU.
  if ((mtu = interface_getmtu ((char *) entry139_text, data->main_window, data)) == 0) {
    gtk_text_buffer_set_text (textbuffer10, "", -1);
    gtk_text_buffer_set_text (textbuffer21, "", -1);
    free (text);
    free (mac);
    return (EXIT_FAILURE);
  }

  // Print MTU in textview.
  memset (text, 0, TEXT_STRINGLEN * sizeof (char));
  sprintf (text, "%i", mtu);
  gtk_text_buffer_set_text (textbuffer21, text, -1);

  // Free allocated memory.
  free (text);
  free (mac);

  return (EXIT_SUCCESS);
}

// Interface name for IP-to-link-layer (MAC) address conversion.
int
on_entry140_activate (GtkWidget *entry140, SPSData *data)
{
  int status;
  const char *entry140_text;
  struct sockaddr_ll device;

  entry140_text = gtk_entry_get_text (GTK_ENTRY (entry140));

  // We attempt to resolve interface index only to see if interface name exists.
  // The contents of entry140 will be accessed by arp() or neighbor_discovery().
  if ((device.sll_ifindex = if_nametoindex (entry140_text)) == 0) {
    status = errno;
    sprintf (data->error_text, "In callbacks.c: if_nametoindex() failed to get interface index in on_entry140_activate().\nAppears to be an invalid interface name.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    return (EXIT_FAILURE);
  }

  return (EXIT_SUCCESS);
}

// Someone has entered an IPv4 address into IP-to-link-layer (MAC) address converter
int
on_entry137_activate (GtkWidget *entry137, SPSData *data)
{
  int i;
  const char *entry137_text, *entry140_text;
  GtkTextBuffer *textbuffer11;
  uint8_t *dst_mac;
  char *text;

  // Get IPv4 address from UI.
  entry137_text = gtk_entry_get_text (GTK_ENTRY (entry137));

  // Get interface name from UI.
  entry140_text = gtk_entry_get_text (GTK_ENTRY (data->entry140));

  // Array to hold various strings of text
  text = allocate_strmem (TEXT_STRINGLEN);

  // Array of unsigned chars
  dst_mac = allocate_ustrmem (6);

  textbuffer11 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview11));

  // Do ARP request
  arp (dst_mac, entry137_text, entry140_text, data);

  // Put MAC address into a string.
  memset (text, 0, TEXT_STRINGLEN * sizeof (char));
  for (i=0; i<5; i++) {
    sprintf (text, "%s%02x:", text, (uint8_t) dst_mac[i]);
  }
  sprintf (text, "%s%02x", text, (uint8_t) dst_mac[5]);

  // Print MAC address in textview
  textbuffer11 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview11));
  gtk_text_buffer_set_text (textbuffer11, text, -1);

  // Free allocated memory.
  free (text);
  free (dst_mac);

  return (EXIT_SUCCESS);
}

// Someone has entered an IPv6 address into IP-to-link-layer (MAC) address converter
int
on_entry138_activate (GtkWidget *entry138, SPSData *data)
{
  int i;
  const char *entry138_text, *entry140_text;
  GtkTextBuffer *textbuffer11;
  char *text;
  uint8_t *dst_mac;

  // Get IPv6 address from UI.
  entry138_text = gtk_entry_get_text (GTK_ENTRY (entry138));

  // Get interface name from UI.
  entry140_text = gtk_entry_get_text (GTK_ENTRY (data->entry140));

  // Array to hold various strings of text
  text = allocate_strmem (TEXT_STRINGLEN);

  // Array of unsigned chars
  dst_mac = allocate_ustrmem (6);

  textbuffer11 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview11));

  // Do neighbor discovery
  neighbor_discovery (dst_mac, entry138_text, entry140_text, data);

  // Put MAC address into a string.
  memset (text, 0, TEXT_STRINGLEN * sizeof (char));
  for (i=0; i<5; i++) {
    sprintf (text, "%s%02x:", text, (uint8_t) dst_mac[i]);
  }
  sprintf (text, "%s%02x", text, (uint8_t) dst_mac[5]);

  // Print MAC address in textview
  textbuffer11 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview11));
  gtk_text_buffer_set_text (textbuffer11, text, -1);

  // Free allocate memory.
  free (text);
  free (dst_mac);

  return (EXIT_SUCCESS);
}

// Someone has requested the About page
int
on_about_requested ()
{
  GtkWidget *window, *textview, *scrolled_window;
  GtkTextBuffer *buffer;
  GdkPixbuf *about;
  GtkTextIter line;

  // Create new window to display About information.
  window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_position (GTK_WINDOW (window), GTK_WIN_POS_CENTER);
  gtk_window_set_title (GTK_WINDOW (window), "About");
  gtk_container_set_border_width (GTK_CONTAINER (window), 1);
  gtk_window_set_default_size ((GtkWindow *) window, 1024, 768);

  // Create scrolled window and set its policy to automatic. i.e., only appear when needed
  scrolled_window = gtk_scrolled_window_new (NULL, NULL);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolled_window), GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS);

  // Create a textview object to put image into.
  textview = gtk_text_view_new ();
  buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (textview));
  gtk_text_view_set_cursor_visible (GTK_TEXT_VIEW (textview), FALSE);

  // Load GdkPixbuf image "about" from file.
  about = gdk_pixbuf_new_from_file ("./about.png", NULL);

  // Pack GdkPixbuf into textview.
  gtk_text_buffer_get_iter_at_line (buffer, &line, 0);
  gtk_text_buffer_insert_pixbuf (buffer, &line, about);

  // Pack textview into scrolled window.
  gtk_container_add (GTK_CONTAINER (scrolled_window), textview);

  // Pack scrolled window into new window.
  gtk_container_add (GTK_CONTAINER (window), scrolled_window);

  // Display window.
  gtk_widget_show_all (window);

  return (EXIT_SUCCESS);
}

// Someone has requested the Documentation page
int
on_documentation_activate (SPSData *data)
{
  GtkWidget *window, *scrolled_win, *textview;
  int i, n, nbytes;
  uint8_t *filedata;
  GtkTextBuffer *buffer;
  FILE *fi;

  // Create new window to display documentation
  window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_position (GTK_WINDOW (window), GTK_WIN_POS_CENTER);
  gtk_window_set_resizable (GTK_WINDOW (window), TRUE);
  gtk_window_set_title (GTK_WINDOW (window), "SPS Documentation");
  gtk_container_set_border_width (GTK_CONTAINER (window), 1);
  gtk_window_set_default_size (GTK_WINDOW (window), 900, 600);

  // Create a textview object to put image in
  textview = gtk_text_view_new ();
  buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (textview));
  gtk_text_view_set_cursor_visible (GTK_TEXT_VIEW (textview), TRUE);
  gtk_text_view_set_wrap_mode (GTK_TEXT_VIEW (textview), GTK_WRAP_WORD);

  // Open documentation file
  fi = fopen ("documentation.txt", "rb");
  if (fi == NULL) {
    memset (data->error_text, 0, TEXT_STRINGLEN * sizeof (char));
    strncpy (data->error_text, "Can't open file documentation.txt.", TEXT_STRINGLEN - 1);  // Minus 1 for string termination.
    data->parent = data->menubar1;
    report_error (data);
    return (EXIT_FAILURE);
  }

  // Count number of bytes in file.
  nbytes = 0;
  while ((n = fgetc (fi)) != EOF) {
    nbytes++;
  }
  rewind (fi);

  if (nbytes < 1) {
    memset (data->error_text, 0, TEXT_STRINGLEN * sizeof (char));
    strncpy (data->error_text, "File documentation.txt has 0 bytes.", TEXT_STRINGLEN - 1);  // Minus 1 for string termination.
    data->parent = data->menubar1;
    report_error (data);
    return (EXIT_FAILURE);
  } else {
    filedata = allocate_ustrmem (nbytes + 1);
  }

  // Read file into array.
  for (i=0; i<nbytes; i++) {
    filedata[i] = (uint8_t) fgetc (fi);
  }
  filedata[nbytes] = 0u;  // Ensure string termination.

  // Close file descriptor.
  fclose (fi);

  // Examine documentation file and report any non-UTF-8 characters.
  if (!is_valid_utf8 (filedata, nbytes, data->menubar1, data)) {
    free (filedata);
    return (EXIT_FAILURE);
  }

  gtk_text_buffer_set_text (buffer, (const char *) filedata, -1);

  scrolled_win = gtk_scrolled_window_new (NULL, NULL);
  gtk_container_add (GTK_CONTAINER (scrolled_win), textview);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolled_win), GTK_POLICY_NEVER, GTK_POLICY_ALWAYS);
  gtk_container_add (GTK_CONTAINER (window), scrolled_win);
  gtk_widget_show_all (window);

  // Free allocated memory.
  free (filedata);

  return (EXIT_SUCCESS);
}

// Display TCP packet contents (IPv4)
int
on_button3_clicked (GtkButton *button3, SPSData *data)
{
  int i;
  char **title;

  (void) button3;  // This statement suppresses compiler warning about unused parameter.

  title = allocate_strmemp (2);
  for (i=0; i<2; i++) {
    title[i] = allocate_strmem (80);
  }
  strncpy (title[0], "TCP (IPv4) Ethernet Frame Contents (fragmented)", 80 - 1);
  strncpy (title[1], "TCP (IPv4) Ethernet Frame Contents (unfragmented)", 80 - 1);

  show_packet (0, title, data);  // type, title, data

  // Free allocated memory.
  for (i=0; i<2; i++) {
    free (title[i]);
  }
  free (title);

  return (EXIT_SUCCESS);
}

// Display ICMP packet contents (IPv4)
int
on_button2_clicked (GtkButton *button2, SPSData *data)
{
  int i;
  char **title;

  (void) button2;  // This statement suppresses compiler warning about unused parameter.

  title = allocate_strmemp (2);
  for (i=0; i<2; i++) {
    title[i] = allocate_strmem (80);
  }
  strncpy (title[0], "ICMP (IPv4) Ethernet Frame Contents (fragmented)", 80 - 1);
  strncpy (title[1], "ICMP (IPv4) Ethernet Frame Contents (unfragmented)", 80 - 1);

  show_packet (1, title, data);  // type, title, data

  // Free allocated memory.
  for (i=0; i<2; i++) {
    free (title[i]);
  }
  free (title);

  return (EXIT_SUCCESS);
}

// Display UDP packet contents (IPv4)
int
on_button4_clicked (GtkButton *button4, SPSData *data)
{
  int i;
  char **title;

  (void) button4;  // This statement suppresses compiler warning about unused parameter.

  title = allocate_strmemp (2);
  for (i=0; i<2; i++) {
    title[i] = allocate_strmem (80);
  }
  strncpy (title[0], "UDP (IPv4) Ethernet Frame Contents (fragmented)", 80 - 1);
  strncpy (title[1], "UDP (IPv4) Ethernet Frame Contents (unfragmented)", 80 - 1);

  show_packet (2, title, data);  // type, title, data

  // Free allocated memory.
  for (i=0; i<2; i++) {
    free (title[i]);
  }
  free (title);

  return (EXIT_SUCCESS);
}

// Display TCP packet contents (IPv6)
int
on_button6_clicked (GtkButton *button6, SPSData *data)
{
  int i;
  char **title;

  (void) button6;  // This statement suppresses compiler warning about unused parameter.

  title = allocate_strmemp (2);
  for (i=0; i<2; i++) {
    title[i] = allocate_strmem (80);
  }
  if (data->sixto4_flag) {
    strncpy (title[0], "TCP (IPv6 tunneled over IPv4) Ethernet Frame Contents (fragmented)", 80 - 1);
    strncpy (title[1], "TCP (IPv6 tunneled over IPv4) Ethernet Frame Contents (unfragmented)", 80 - 1);
    show_packet (6, title, data);  // type, title, data
  } else {
    strncpy (title[0], "TCP (IPv6) Ethernet Frame Contents (fragmented)", 80 - 1);
    strncpy (title[1], "TCP (IPv6) Ethernet Frame Contents (unfragmented)", 80 - 1);
    show_packet (3, title, data);  // type, title, data
  }

  // Free allocated memory.
  for (i=0; i<2; i++) {
    free (title[i]);
  }
  free (title);

  return (EXIT_SUCCESS);
}

// Display ICMP packet contents (IPv6)
int
on_button17_clicked (GtkButton *button17, SPSData *data)
{
  int i;
  char **title;

  (void) button17;  // This statement suppresses compiler warning about unused parameter.

  title = allocate_strmemp (2);
  for (i=0; i<2; i++) {
    title[i] = allocate_strmem (80);
  }
  if (data->sixto4_flag) {
    strncpy (title[0], "ICMP (IPv6 tunneled over IPv4) Ethernet Frame Contents (fragmented)", 80 - 1);
    strncpy (title[1], "ICMP (IPv6 tunneled over IPv4) Ethernet Frame Contents (unfragmented)", 80 - 1);
    show_packet (7, title, data);  // type, title, data
  } else {
    strncpy (title[0], "ICMP (IPv6) Ethernet Frame Contents (fragmented)", 80 - 1);
    strncpy (title[1], "ICMP (IPv6) Ethernet Frame Contents (unfragmented)", 80 - 1);
    show_packet (4, title, data);  // type, title, data
  }

  // Free allocated memory.
  for (i=0; i<2; i++) {
    free (title[i]);
  }
  free (title);

  return (EXIT_SUCCESS);
}

// Display UDP packet contents (IPv6)
int
on_button13_clicked (GtkButton *button13, SPSData *data)
{
  int i;
  char **title;

  (void) button13;  // This statement suppresses compiler warning about unused parameter.

  title = allocate_strmemp (2);
  for (i=0; i<2; i++) {
    title[i] = allocate_strmem (80);
  }
  if (data->sixto4_flag) {
    strncpy (title[0], "UDP (IPv6 tunneled over IPv4) Ethernet Frame Contents (fragmented)", 80 - 1);
    strncpy (title[1], "UDP (IPv6 tunneled over IPv4) Ethernet Frame Contents (unfragmented)", 80 - 1);
    show_packet (8, title, data);  // type, title, data
  } else {
    strncpy (title[0], "UDP (IPv6) Ethernet Frame Contents (fragmented)", 80 - 1);
    strncpy (title[1], "UDP (IPv6) Ethernet Frame Contents (unfragmented)", 80 - 1);
    show_packet (5, title, data);  // type, title, data
  }

  // Free allocated memory.
  for (i=0; i<2; i++) {
    free (title[i]);
  }
  free (title);

  return (EXIT_SUCCESS);
}

// Display TCP traceroute packet contents (IPv4)
int
on_button28_clicked (GtkButton *button28, SPSData *data)
{
  int i;
  char **title;

  (void) button28;  // This statement suppresses compiler warning about unused parameter.

  title = allocate_strmemp (2);
  for (i=0; i<2; i++) {
    title[i] = allocate_strmem (80);
  }
  strncpy (title[0], "TCP (IPv4) Ethernet Frame Contents for Traceroute (fragmented)", 80 - 1);
  strncpy (title[1], "TCP (IPv4) Ethernet Frame Contents for Traceroute (unfragmented)", 80 - 1);

  show_packet (9, title, data);  // type, title, data

  // Free allocated memory.
  for (i=0; i<2; i++) {
    free (title[i]);
  }
  free (title);

  return (EXIT_SUCCESS);
}

// Display ICMP traceroute packet contents (IPv4)
int
on_button31_clicked (GtkButton *button31, SPSData *data)
{
  int i;
  char **title;

  (void) button31;  // This statement suppresses compiler warning about unused parameter.

  title = allocate_strmemp (2);
  for (i=0; i<2; i++) {
    title[i] = allocate_strmem (80);
  }
  strncpy (title[0], "ICMP (IPv4) Ethernet Frame Contents for Traceroute (fragmented)", 80 - 1);
  strncpy (title[1], "ICMP (IPv4) Ethernet Frame Contents for Traceroute (unfragmented)", 80 - 1);

  show_packet (10, title, data);  // type, title, data

  // Free allocated memory.
  for (i=0; i<2; i++) {
    free (title[i]);
  }
  free (title);

  return (EXIT_SUCCESS);
}

// Display UDP traceroute packet contents (IPv4)
int
on_button34_clicked (GtkButton *button34, SPSData *data)
{
  int i;
  char **title;

  (void) button34;  // This statement suppresses compiler warning about unused parameter.

  title = allocate_strmemp (2);
  for (i=0; i<2; i++) {
    title[i] = allocate_strmem (80);
  }
  strncpy (title[0], "UDP (IPv4) Ethernet Frame Contents for Traceroute (fragmented)", 80 - 1);
  strncpy (title[1], "UDP (IPv4) Ethernet Frame Contents for Traceroute (unfragmented)", 80 - 1);

  show_packet (11, title, data);  // type, title, data

  // Free allocated memory.
  for (i=0; i<2; i++) {
    free (title[i]);
  }
  free (title);

  return (EXIT_SUCCESS);
}

// Display TCP traceroute packet contents (IPv6)
int
on_button37_clicked (GtkButton *button37, SPSData *data)
{
  int i;
  char **title;

  (void) button37;  // This statement suppresses compiler warning about unused parameter.

  title = allocate_strmemp (2);
  for (i=0; i<2; i++) {
    title[i] = allocate_strmem (80);
  }
  if (data->sixto4_tr_flag) {
    strncpy (title[0], "TCP (IPv6 tunneled over IPv4) Ethernet Frame Contents for Traceroute (fragmented)", 80 - 1);
    strncpy (title[1], "TCP (IPv6 tunneled over IPv4) Ethernet Frame Contents for Traceroute (unfragmented)", 80 - 1);
    show_packet (15, title, data);  // type, title, data
  } else {
    strncpy (title[0], "TCP (IPv6) Ethernet Frame Contents for Traceroute (fragmented)", 80 - 1);
    strncpy (title[1], "TCP (IPv6) Ethernet Frame Contents for Traceroute (unfragmented)", 80 - 1);
    show_packet (12, title, data);  // type, title, data
  }

  // Free allocated memory.
  for (i=0; i<2; i++) {
    free (title[i]);
  }
  free (title);

  return (EXIT_SUCCESS);
}

// Display ICMP traceroute packet contents (IPv6)
int
on_button40_clicked (GtkButton *button40, SPSData *data)
{
  int i;
  char **title;

  (void) button40;  // This statement suppresses compiler warning about unused parameter.

  title = allocate_strmemp (2);
  for (i=0; i<2; i++) {
    title[i] = allocate_strmem (80);
  }
  if (data->sixto4_tr_flag) {
    strncpy (title[0], "ICMP (IPv6 tunneled over IPv4) Ethernet Frame Contents for Traceroute (fragmented)", 80 - 1);
    strncpy (title[1], "ICMP (IPv6 tunneled over IPv4) Ethernet Frame Contents for Traceroute (unfragmented)", 80 - 1);
    show_packet (16, title, data);  // type, title, data
  } else {
    strncpy (title[0], "ICMP (IPv6) Ethernet Frame Contents for Traceroute (fragmented)", 80 - 1);
    strncpy (title[1], "ICMP (IPv6) Ethernet Frame Contents (unfragmented)", 80 - 1);
    show_packet (13, title, data);  // type, title, data
  }

  // Free allocated memory.
  for (i=0; i<2; i++) {
    free (title[i]);
  }
  free (title);

  return (EXIT_SUCCESS);
}

// Display UDP traceroute packet contents (IPv6)
int
on_button43_clicked (GtkButton *button43, SPSData *data)
{
  int i;
  char **title;

  (void) button43;  // This statement suppresses compiler warning about unused parameter.

  title = allocate_strmemp (2);
  for (i=0; i<2; i++) {
    title[i] = allocate_strmem (80);
  }
  if (data->sixto4_tr_flag) {
    strncpy (title[0], "UDP (IPv6 tunneled over IPv4) Ethernet Frame Contents for Traceroute (fragmented)", 80 - 1);
    strncpy (title[1], "UDP (IPv6 tunneled over IPv4) Ethernet Frame Contents for Traceroute (unfragmented)", 80 - 1);
    show_packet (17, title, data);  // type, title, data
  } else {
    strncpy (title[0], "UDP (IPv6) Ethernet Frame Contents for Traceroute (fragmented)", 80 - 1);
    strncpy (title[1], "UDP (IPv6) Ethernet Frame Contents for Traceroute (unfragmented)", 80 - 1);
    show_packet (14, title, data);  // type, title, data
  }

  // Free allocated memory.
  for (i=0; i<2; i++) {
    free (title[i]);
  }
  free (title);

  return (EXIT_SUCCESS);
}

// TCP page (IPv4)

// Specify ethernet header
int
on_checkbutton18_toggled (GtkButton *checkbutton18, SPSData *data)
{
  (void) checkbutton18;  // This statement suppresses compiler warning about unused parameter.

  if (data->specify_ether[0]) {
    data->specify_ether[0] = 0;
  } else {
    data->specify_ether[0] = 1;
  }

  return (EXIT_SUCCESS);
}

// Destination link-layer (MAC) address (48 bits)
int
on_entry144_activate (GtkWidget *entry144, SPSData *data)
{
  mac_entry (entry144, data->ethhdr[0].dst_mac, 0, data);

  return (EXIT_SUCCESS);
}

// Source link-layer (MAC) address (48 bits)
int
on_entry145_activate (GtkWidget *entry145, SPSData *data)
{
  mac_entry (entry145, data->ethhdr[0].src_mac, 0, data);

  return (EXIT_SUCCESS);
}

// This host's interface name to be converted to link-layer (MAC) address and find MTU.
int
on_entry150_activate (GtkWidget *entry150, SPSData *data)
{
  // Check for valid source interface name, check MTU, and update source MAC address.
  ifname_entry (entry150, data->ifname[0], data->ethhdr[0].src_mac, data->entry145, 0, data);

  // Update MTU spinbutton.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton5), data->ifmtu[0]);

  return (EXIT_SUCCESS);
}

// Maximum transmission unit (MTU)
int
on_spinbutton5_value_changed (GtkWidget *spinbutton5, SPSData *data)
{
  data->ifmtu[0] = (int) gtk_spin_button_get_value (GTK_SPIN_BUTTON (spinbutton5));

  // Check if MTU is sufficiently large to accomodate packet. If not, revise.
  check_mtu (0, data);

  // Update spinbutton value.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (spinbutton5), data->ifmtu[0]);

  // Update ethernet frames.
  create_ip4_frame (0, data);

  return (EXIT_SUCCESS);
}

// Ethernet type code (16 bits)
// http://www.iana.org/assignments/ethernet-numbers
int
on_entry146_activate (GtkWidget *entry146, SPSData *data)
{
  ethtype_entry (entry146, 0, data);

  return (EXIT_SUCCESS);
}

// IPv4 header length (4 bits)
int
on_entry29_activate (GtkWidget *entry29, SPSData *data)
{
  ip4_hdrlen_entry (entry29, 0, data);

  return (EXIT_SUCCESS);
}

// IP version (4 bits)
int
on_entry30_activate (GtkWidget *entry30, SPSData *data)
{
  ip4_ver_entry (entry30, 0, data);

  return (EXIT_SUCCESS);
}

// Type of service (8 bits)
int
on_entry31_activate (GtkWidget *entry31, SPSData *data)
{
  ip4_tos_entry (entry31, 0, data);

  return (EXIT_SUCCESS);
}

// Total length of datagram (16 bits)
int
on_entry32_activate (GtkWidget *entry32, SPSData *data)
{
  ip4_tld_entry (entry32, 0, data);

  return (EXIT_SUCCESS);
}

// ID sequence number (16 bits)
int
on_entry33_activate (GtkWidget *entry33, SPSData *data)
{
  ip4_seq_entry (entry33, 0, data);

  return (EXIT_SUCCESS);
}

// Zero (1 bit)
int
on_entry122_activate (GtkWidget *entry122, SPSData *data)
{
  ip4_zero_entry (entry122, data->entry37, data->entry38, data->entry39, 0, data);

  return (EXIT_SUCCESS);
}

// Do not fragment flag (1 bit)
int
on_entry37_activate (GtkWidget *entry37, SPSData *data)
{
  ip4_dnf_entry (data->entry122, entry37, data->entry38, data->entry39, 0, data);

  return (EXIT_SUCCESS);
}

// More fragments following flag (1 bit)
int
on_entry38_activate (GtkWidget *entry38, SPSData *data)
{
  ip4_mff_entry (data->entry122, data->entry37, entry38, data->entry39, 0, data);

  return (EXIT_SUCCESS);
}

// Fragmentation offset (13 bits)
int
on_entry39_activate (GtkWidget *entry39, SPSData *data)
{
  ip4_fo_entry (data->entry122, data->entry37, data->entry38, entry39, 0, data);

  return (EXIT_SUCCESS);
}

// Time-to-Live (8 bits)
int
on_entry40_activate (GtkWidget *entry40, SPSData *data)
{
  ip4_ttl_entry (entry40, 0, data);

  return (EXIT_SUCCESS);
}

// Transport layer protocol (8 bits)
int
on_entry74_activate (GtkWidget *entry74, SPSData *data)
{
  ip4_tlp_entry (entry74, 0, data);

  return (EXIT_SUCCESS);
}

// Source IPv4 address (32 bits)
int
on_entry35_activate (GtkWidget *entry35, SPSData *data)
{
  ip4_sip_entry (entry35, 0, data);

  // IP address has been entered manually. Uncheck "Randomize" checkbutton.
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton5), FALSE);
  data->ran_tcp4_sourceip = 0;

  return (EXIT_SUCCESS);
}

// Randomize source IPv4 address
int
on_checkbutton5_toggled (GtkButton *checkbutton5, SPSData *data)
{
  (void) checkbutton5;  // This statement suppresses compiler warning about unused parameter.

  ip4_ransip_checkbutton (&data->ran_tcp4_sourceip, data->entry35, 0, data);

  if (data->ran_tcp4_sourceip) {
    tcp_chksum (0, data);
  }

  return (EXIT_SUCCESS);
}

// Destination IPv4 address (32 bits)
int
on_entry36_activate (GtkWidget *entry36, SPSData *data)
{
  ip4_dip_entry (entry36, 0, data);

  return (EXIT_SUCCESS);
}

// IPv4 checksum (16 bits)
int
on_entry34_activate (GtkWidget *entry34, SPSData *data)
{
  ip4_chksum_entry (entry34, 0, data);

  return (EXIT_SUCCESS);
}

// IP options for IPv4 TCP

// Decimal option data entry
int
on_radiobutton24_toggled (GtkButton *radiobutton24, SPSData *data)
{
  (void) radiobutton24;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_ipopt_tcp4 = 0;

  return (EXIT_SUCCESS);
}

// Hexadecimal option data entry
int
on_radiobutton25_toggled (GtkButton *radiobutton25, SPSData *data)
{
  (void) radiobutton25;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_ipopt_tcp4 = 1;

  return (EXIT_SUCCESS);
}

// IPv4 option data
int
on_entry400_activate (GtkWidget *entry400, SPSData *data)
{
  data_entry (entry400, &data->ip_optlenbuf[0], MAX_IP4OPTLEN, data->ip_optionsbuf[0], data->dec_hex_ipopt_tcp4, data->main_window, data);

  return (EXIT_SUCCESS);
}

// Insert IPv4 option after another, as specified by user.
int
on_button26_clicked (GtkButton *button26, SPSData *data)
{
  (void) button26;  // This statement suppresses compiler warning about unused parameter.

  ip4_option (0, 0, data->ipopt_tcp4_after, data->textview30, data->spinbutton5, data);

  return (EXIT_SUCCESS);
}

// Number of option after which to insert new IPv4 option.
int
on_entry401_activate (GtkWidget *entry401, SPSData *data)
{
  ip4_opt_insert_after_entry (entry401, 0, &data->ipopt_tcp4_after, data);

  return (EXIT_SUCCESS);
}

// Append an IPv4 option.
int
on_button60_clicked (GtkButton *button60, SPSData *data)
{
  (void) button60;  // This statement suppresses compiler warning about unused parameter.

  ip4_option (2, 0, 0, data->textview30, data->spinbutton5, data);

  return (EXIT_SUCCESS);
}

// View IPv4 header options for TCP.
int
on_button61_clicked (GtkButton *button61, SPSData *data)
{
  (void) button61;  // This statement suppresses compiler warning about unused parameter.

  opt_view (0, 0, data);

  return (EXIT_SUCCESS);
}

// Number of IPv4 option to remove.
int
on_entry403_activate (GtkWidget *entry403, SPSData *data)
{
  ip4_opt_remove_entry (entry403, 0, &data->ipopt_tcp4_remove, data);

  return (EXIT_SUCCESS);
}

// Remove selected IPv4 option.
int
on_button62_clicked (GtkButton *button62, SPSData *data)
{
  (void) button62;  // This statement suppresses compiler warning about unused parameter.

  ip4_option (1, 0, data->ipopt_tcp4_remove, data->textview30, data->spinbutton6, data);

  return (EXIT_SUCCESS);
}

// TCP header (IPv4)

// TCP source port (16 bits)
int
on_entry41_activate (GtkWidget *entry41, SPSData *data)
{
  tcp_sport_entry (entry41, 0, data);

  // Source port has been entered manually. Uncheck "Randomize" checkbutton.
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton7), FALSE);
  data->ran_tcp4_sourceport = 0;

  return (EXIT_SUCCESS);
}

// Randomize TCP source port number.
int
on_checkbutton7_toggled (GtkButton *checkbutton7, SPSData *data)
{
  (void) checkbutton7;  // This statement suppresses compiler warning about unused parameter.

  tcp_ran_sport (&data->ran_tcp4_sourceport, 0, data->entry41, data);

  return (EXIT_SUCCESS);
}

// TCP destination port (16 bits)
int
on_entry42_activate (GtkWidget *entry42, SPSData *data)
{
  tcp_dport_entry (entry42, 0, data);

  return (EXIT_SUCCESS);
}

// TCP sequence number (32 bits)
int
on_entry43_activate (GtkWidget *entry43, SPSData *data)
{
  tcp_seqnum_entry (entry43, 0, data);

  return (EXIT_SUCCESS);
}

// TCP acknowledgement number (32 bits)
int
on_entry44_activate (GtkWidget *entry44, SPSData *data)
{
  tcp_acknum_entry (entry44, 0, data);

  return (EXIT_SUCCESS);
}

// TCP reserved (4 bits)
int
on_entry45_activate (GtkWidget *entry45, SPSData *data)
{
  tcp_res_entry (entry45, 0, data);

  return (EXIT_SUCCESS);
}

// TCP data offset (4 bits)
int
on_entry46_activate (GtkWidget *entry46, SPSData *data)
{
  tcp_off_entry (entry46, 0, data);

  return (EXIT_SUCCESS);
}

// TCP FIN flag (1 bit)
int
on_entry47_activate (GtkWidget *entry47, SPSData *data)
{
  tcp_fin_entry (entry47, 0, data);

  return (EXIT_SUCCESS);
}

// TCP SYN flag (1 bit)
int
on_entry48_activate (GtkWidget *entry48, SPSData *data)
{
  tcp_syn_entry (entry48, 0, data);

  return (EXIT_SUCCESS);
}

// TCP RST flag (1 bit)
int
on_entry49_activate (GtkWidget *entry49, SPSData *data)
{
  tcp_rst_entry (entry49, 0, data);

  return (EXIT_SUCCESS);
}

// TCP PSH flag (1 bit)
int
on_entry50_activate (GtkWidget *entry50, SPSData *data)
{
  tcp_psh_entry (entry50, 0, data);

  return (EXIT_SUCCESS);
}

// TCP ACK flag (1 bit)
int
on_entry51_activate (GtkWidget *entry51, SPSData *data)
{
  tcp_ack_entry (entry51, 0, data);

  return (EXIT_SUCCESS);
}

// TCP URG flag (1 bit)
int
on_entry52_activate (GtkWidget *entry52, SPSData *data)
{
  tcp_urg_entry (entry52, 0, data);

  return (EXIT_SUCCESS);
}

// TCP ECE flag (1 bit)
int
on_entry53_activate (GtkWidget *entry53, SPSData *data)
{
  tcp_ece_entry (entry53, 0, data);

  return (EXIT_SUCCESS);
}

// TCP CWR flag (1 bit)
int
on_entry54_activate (GtkWidget *entry54, SPSData *data)
{
  tcp_cwr_entry (entry54, 0, data);

  return (EXIT_SUCCESS);
}

// TCP window size (16 bits)
int
on_entry55_activate (GtkWidget *entry55, SPSData *data)
{
  tcp_win_entry (entry55, 0, data);

  return (EXIT_SUCCESS);
}

// TCP checksum (16 bits)
int
on_entry56_activate (GtkWidget *entry56, SPSData *data)
{
  tcp_chksum_entry (entry56, 0, data);

  return (EXIT_SUCCESS);
}

// TCP urgent pointer (16 bits)
int
on_entry77_activate (GtkWidget *entry77, SPSData *data)
{
  tcp_urgptr_entry (entry77, 0, data);

  return (EXIT_SUCCESS);
}

// TCP options (IPv4)

// Decimal option data entry
int
on_radiobutton41_toggled (GtkButton *radiobutton41, SPSData *data)
{
  (void) radiobutton41;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_tcpopt_tcp4 = 0;

  return (EXIT_SUCCESS);
}

// Hexadecimal option data entry
int
on_radiobutton42_toggled (GtkButton *radiobutton42, SPSData *data)
{
  (void) radiobutton42;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_tcpopt_tcp4 = 1;

  return (EXIT_SUCCESS);
}

// TCP option data (IPv4)
int
on_entry404_activate (GtkWidget *entry404, SPSData *data)
{
  data_entry (entry404, &data->tcp_optlenbuf[0], MAX_TCPOPTLEN, data->tcp_optionsbuf[0], data->dec_hex_tcpopt_tcp4, data->main_window, data);

  return (EXIT_SUCCESS);
}

// Insert TCP option after another, as specified by user.
int
on_button47_clicked (GtkButton *button47, SPSData *data)
{
  (void) button47;  // This statement suppresses compiler warning about unused parameter.

  tcp4_option (0, 0, data->tcpopt_tcp4_after, data->textview24, data);

  return (EXIT_SUCCESS);
}

// Number of option after which to insert new TCP option.
int
on_entry405_activate (GtkWidget *entry405, SPSData *data)
{
  tcp_opt_insert_after_entry (entry405, 0, &data->tcpopt_tcp4_after, data);

  return (EXIT_SUCCESS);
}

// Append TCP option for IPv4 TCP packet.
int
on_button48_clicked (GtkButton *button48, SPSData *data)
{
  (void) button48;  // This statement suppresses compiler warning about unused parameter.

  tcp4_option (2, 0, 0, data->textview24, data);

  return (EXIT_SUCCESS);
}

// View TCP options for IPv4 TCP.
int
on_button49_clicked (GtkButton *button49, SPSData *data)
{
  (void) button49;  // This statement suppresses compiler warning about unused parameter.

  opt_view (0, 1, data);

  return (EXIT_SUCCESS);
}

// Number of TCP option to remove.
int
on_entry406_activate (GtkWidget *entry406, SPSData *data)
{
  tcp_opt_remove_entry (entry406, 0, &data->tcpopt_tcp4_remove, data);

  return (EXIT_SUCCESS);
}

// Remove selected TCP option.
int
on_button58_clicked (GtkButton *button58, SPSData *data)
{
  (void) button58;

  tcp4_option (1, 0, data->tcpopt_tcp4_remove, data->textview24, data);

  return (EXIT_SUCCESS);
}

// TCP payload (IPv4)

// ASCII data entry
int
on_radiobutton17_toggled (GtkButton *radiobutton17, SPSData *data)
{
  (void) radiobutton17;  // This statement suppresses compiler warning about unused parameter.

  data->ascii_hex_tcp4 = 0;

  return (EXIT_SUCCESS);
}

// Hexadecimal data entry
int
on_radiobutton18_toggled (GtkButton *radiobutton18, SPSData *data)
{
  (void) radiobutton18;  // This statement suppresses compiler warning about unused parameter.

  data->ascii_hex_tcp4 = 1;

  return (EXIT_SUCCESS);
}

// TCP data from keyboard (IPv4)
int
on_entry162_activate (GtkWidget *entry162, SPSData *data)
{
  key_data (entry162, 0, data->ascii_hex_tcp4, data);

  if (data->nframes[0] > 1) {
    sprintf (data->warning_text, "Packet will be fragmented to accomodate TCP data.");
    data->parent = data->main_window;
    report_warning (data);
  }

  return (EXIT_SUCCESS);
}

// TCP data from file (IPv4)
int
on_button20_clicked (GtkButton *button20, SPSData *data)
{
  (void) button20;  // This statement suppresses compiler warning about unused parameter.

  file_payload_data (data->entry162, 0, data);

  if (data->nframes[0] > 1) {
    sprintf (data->warning_text, "Packet will be fragmented to accomodate TCP data.");
    data->parent = data->main_window;
    report_warning (data);
  }

  return (EXIT_SUCCESS);
}

// TCP page (IPv6)

// Destination link-layer (MAC) address (48 bits)
int
on_entry131_activate (GtkWidget *entry131, SPSData *data)
{
  mac_entry (entry131, data->ethhdr[3].dst_mac, 3, data);

  return (EXIT_SUCCESS);
}

// Source link-layer (MAC) address (48 bits)
int
on_entry132_activate (GtkWidget *entry132, SPSData *data)
{
  mac_entry (entry132, data->ethhdr[3].src_mac, 3, data);

  return (EXIT_SUCCESS);
}

// This host's interface name to be converted to link-layer (MAC) address and find MTU.
int
on_entry154_activate (GtkWidget *entry154, SPSData *data)
{
  // Check for valid source interface name, check MTU, and update source MAC address.
  ifname_entry (entry154, data->ifname[3], data->ethhdr[3].src_mac, data->entry132, 3, data);

  // Update MTU spinbutton.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton8), data->ifmtu[3]);

  return (EXIT_SUCCESS);
}

// Maximum transmission unit (MTU)
int
on_spinbutton8_value_changed (GtkWidget *spinbutton8, SPSData *data)
{
  data->ifmtu[3] = (int) gtk_spin_button_get_value (GTK_SPIN_BUTTON (spinbutton8));

  // Check if MTU is sufficiently large to accomodate packet. If not, revise.
  check_mtu (3, data);

  // Update spinbutton value.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (spinbutton8), data->ifmtu[3]);

  // Update ethernet frames.
  create_ip6_frame (3, data);
  create_6to4_frame (6, data);

  return (EXIT_SUCCESS);
}

// Ethernet type code (16 bits)
// http://www.iana.org/assignments/ethernet-numbers
int
on_entry133_activate (GtkWidget *entry133, SPSData *data)
{
  ethtype_entry (entry133, 3, data);

  return (EXIT_SUCCESS);
}

// IP version (4 bits)
int
on_entry22_activate (GtkWidget *entry22, SPSData *data)
{
  ip6_ver_entry (entry22, 3, data);

  return (EXIT_SUCCESS);
}

// Traffic class (8 bits)
int
on_entry23_activate (GtkWidget *entry23, SPSData *data)
{
  ip6_tc_entry (entry23, 3, data);

  return (EXIT_SUCCESS);
}

// Flow label (20 bits)
int
on_entry24_activate (GtkWidget *entry24, SPSData *data)
{
  ip6_fl_entry (entry24, 3, data);

  return (EXIT_SUCCESS);
}

// Payload length (16 bits)
int
on_entry25_activate (GtkWidget *entry25, SPSData *data)
{
  ip6_plen_entry (entry25, 3, data);

  return (EXIT_SUCCESS);
}

// Next header (8 bits)
int
on_entry26_activate (GtkWidget *entry26, SPSData *data)
{
  ip6_nxt_entry (entry26, 3, data);

  return (EXIT_SUCCESS);
}

// Hop limit (8 bits)
int
on_entry27_activate (GtkWidget *entry27, SPSData *data)
{
  ip6_hops_entry (entry27, 3, data);

  return (EXIT_SUCCESS);
}

// Source IP address (128 bits)
int
on_entry28_activate (GtkWidget *entry28, SPSData *data)
{
  ip6_sip_entry (entry28, 3, data);

  // IP address has been entered manually. Uncheck "Randomize" checkbutton.
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton2), FALSE);
  data->ran_tcp6_sourceip = 0;

  return (EXIT_SUCCESS);
}

// Randomize source IP address
int
on_checkbutton2_toggled (GtkButton *checkbutton2, SPSData *data)
{
  (void) checkbutton2;  // This statement suppresses compiler warning about unused parameter.

  ip6_ransip_checkbutton (&data->ran_tcp6_sourceip, data->entry28, 3, data);

  return (EXIT_SUCCESS);
}

// Destination IP address (128 bits)
int
on_entry78_activate (GtkWidget *entry78, SPSData *data)
{
  ip6_dip_entry (entry78, 3, data);

  return (EXIT_SUCCESS);
}

// Hop-by-Hop extension header
int
on_button98_clicked (GtkWidget *button98, SPSData *data)
{
  (void) button98;  // This statement suppresses compiler warning about unused parameter.

  data->exthdr_type = 3;
  hop_win (data);

  return (EXIT_SUCCESS);
}

// Destination extension header
int
on_button110_clicked (GtkWidget *button110, SPSData *data)
{
  (void) button110;  // This statement suppresses compiler warning about unused parameter.

  data->exthdr_type = 3;
  dst_win (data);

  return (EXIT_SUCCESS);
}

// Routing extension header
int
on_button132_clicked (GtkWidget *button132, SPSData *data)
{
  (void) button132;  // This statement suppresses compiler warning about unused parameter.

  data->exthdr_type = 3;
  route_win (data);

  return (EXIT_SUCCESS);
}

// Authentication extension header
int
on_button116_clicked (GtkWidget *button116, SPSData *data)
{
  (void) button116;  // This statement suppresses compiler warning about unused parameter.

  data->exthdr_type = 3;
  auth_win (data);

  return (EXIT_SUCCESS);
}

// ESP extension header
int
on_button126_clicked (GtkWidget *button126, SPSData *data)
{
  (void) button126;  // This statement suppresses compiler warning about unused parameter.

  data->exthdr_type = 3;
  esp_win (data);

  return (EXIT_SUCCESS);
}

// TCP header (IPv6)

// TCP source port (16 bits)
int
on_entry79_activate (GtkWidget *entry79, SPSData *data)
{
  tcp_sport_entry (entry79, 3, data);

  // Source port has been entered manually. Uncheck "Randomize" checkbutton.
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton4), FALSE);
  data->ran_tcp6_sourceport = 0;

  return (EXIT_SUCCESS);
}

// Randomize TCP source port number.
int
on_checkbutton4_toggled (GtkButton *checkbutton4, SPSData *data)
{
  (void) checkbutton4;  // This statement suppresses compiler warning about unused parameter.

  tcp_ran_sport (&data->ran_tcp6_sourceport, 3, data->entry79, data);

  return (EXIT_SUCCESS);
}

// TCP destination port (16 bits)
int
on_entry80_activate (GtkWidget *entry80, SPSData *data)
{
  tcp_dport_entry (entry80, 3, data);

  return (EXIT_SUCCESS);
}

// TCP sequence number (32 bits)
int
on_entry81_activate (GtkWidget *entry81, SPSData *data)
{
  tcp_seqnum_entry (entry81, 3, data);

  return (EXIT_SUCCESS);
}

// TCP acknowledgement number (32 bits)
int
on_entry82_activate (GtkWidget *entry82, SPSData *data)
{
  tcp_acknum_entry (entry82, 3, data);

  return (EXIT_SUCCESS);
}

// TCP reserved (4 bits)
int
on_entry83_activate (GtkWidget *entry83, SPSData *data)
{
  tcp_res_entry (entry83, 3, data);

  return (EXIT_SUCCESS);
}

// TCP data offset (4 bits)
int
on_entry84_activate (GtkWidget *entry84, SPSData *data)
{
  tcp_off_entry (entry84, 3, data);

  return (EXIT_SUCCESS);
}

// TCP FIN flag (1 bit)
int
on_entry85_activate (GtkWidget *entry85, SPSData *data)
{
  tcp_fin_entry (entry85, 3, data);

  return (EXIT_SUCCESS);
}

// TCP SYN flag (1 bit)
int
on_entry86_activate (GtkWidget *entry86, SPSData *data)
{
  tcp_syn_entry (entry86, 3, data);

  return (EXIT_SUCCESS);
}

// TCP RST flag (1 bit)
int
on_entry87_activate (GtkWidget *entry87, SPSData *data)
{
  tcp_rst_entry (entry87, 3, data);

  return (EXIT_SUCCESS);
}

// TCP PSH flag (1 bit)
int
on_entry88_activate (GtkWidget *entry88, SPSData *data)
{
  tcp_psh_entry (entry88, 3, data);

  return (EXIT_SUCCESS);
}

// TCP ACK flag (1 bit)
int
on_entry89_activate (GtkWidget *entry89, SPSData *data)
{
  tcp_ack_entry (entry89, 3, data);

  return (EXIT_SUCCESS);
}

// TCP URG flag (1 bit)
int
on_entry90_activate (GtkWidget *entry90, SPSData *data)
{
  tcp_urg_entry (entry90, 3, data);

  return (EXIT_SUCCESS);
}

// TCP ECE flag (1 bit)
int
on_entry91_activate (GtkWidget *entry91, SPSData *data)
{
  tcp_ece_entry (entry91, 3, data);

  return (EXIT_SUCCESS);
}

// TCP CWR flag (1 bit)
int
on_entry92_activate (GtkWidget *entry92, SPSData *data)
{
  tcp_cwr_entry (entry92, 3, data);

  return (EXIT_SUCCESS);
}

// TCP window size (16 bits)
int
on_entry93_activate (GtkWidget *entry93, SPSData *data)
{
  tcp_win_entry (entry93, 3, data);

  return (EXIT_SUCCESS);
}

// TCP checksum (16 bits)
int
on_entry94_activate (GtkWidget *entry94, SPSData *data)
{
  tcp_chksum_entry (entry94, 3, data);

  return (EXIT_SUCCESS);
}

// TCP urgent pointer (16 bits)
int
on_entry95_activate (GtkWidget *entry95, SPSData *data)
{
  tcp_urgptr_entry (entry95, 3, data);

  return (EXIT_SUCCESS);
}

// TCP options (IPv6)

// Decimal option data entry
int
on_radiobutton47_toggled (GtkButton *radiobutton47, SPSData *data)
{
  (void) radiobutton47;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_tcpopt_tcp6 = 0;

  return (EXIT_SUCCESS);
}

// Hexadecimal option data entry
int
on_radiobutton48_toggled (GtkButton *radiobutton48, SPSData *data)
{
  (void) radiobutton48;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_tcpopt_tcp6 = 1;

  return (EXIT_SUCCESS);
}

// TCP option data (IPv6)
int
on_entry413_activate (GtkWidget *entry413, SPSData *data)
{
  data_entry (entry413, &data->tcp_optlenbuf[3], MAX_TCPOPTLEN, data->tcp_optionsbuf[3], data->dec_hex_tcpopt_tcp6, data->main_window, data);

  return (EXIT_SUCCESS);
}

// Insert TCP option after another, as specified by user.
int
on_button70_clicked (GtkButton *button70, SPSData *data)
{
  (void) button70;  // This statement suppresses compiler warning about unused parameter.

  tcp6_option (0, 3, data->tcpopt_tcp6_after, data->textview32, data);

  return (EXIT_SUCCESS);
}

// Number of option after which to insert new TCP option.
int
on_entry414_activate (GtkWidget *entry414, SPSData *data)
{
  tcp_opt_insert_after_entry (entry414, 3, &data->tcpopt_tcp6_after, data);

  return (EXIT_SUCCESS);
}

// Append TCP option for IPv6 TCP packet.
int
on_button71_clicked (GtkButton *button71, SPSData *data)
{
  (void) button71;  // This statement suppresses compiler warning about unused parameter.

  tcp6_option (2, 3, 0, data->textview32, data);

  return (EXIT_SUCCESS);
}

// View TCP options for IPv6 TCP.
int
on_button72_clicked (GtkButton *button72, SPSData *data)
{
  (void) button72;  // This statement suppresses compiler warning about unused parameter.

  opt_view (3, 1, data);

  return (EXIT_SUCCESS);
}

// Number of TCP option to remove.
int
on_entry415_activate (GtkWidget *entry415, SPSData *data)
{
  tcp_opt_remove_entry (entry415, 3, &data->tcpopt_tcp6_remove, data);

  return (EXIT_SUCCESS);
}

// Remove selected TCP option.
int
on_button73_clicked (GtkButton *button73, SPSData *data)
{
  (void) button73;  // This statement suppresses compiler warning about unused parameter.

  tcp6_option (1, 3, data->tcpopt_tcp6_remove, data->textview32, data);

  return (EXIT_SUCCESS);
}

// TCP payload (IPv6)

// ASCII data entry
int
on_radiobutton19_toggled (GtkButton *radiobutton19, SPSData *data)
{
  (void) radiobutton19;  // This statement suppresses compiler warning about unused parameter.

  data->ascii_hex_tcp6 = 0;

  return (EXIT_SUCCESS);
}

// Hexadecimal data entry
int
on_radiobutton20_toggled (GtkButton *radiobutton20, SPSData *data)
{
  (void) radiobutton20;  // This statement suppresses compiler warning about unused parameter.

  data->ascii_hex_tcp6 = 1;

  return (EXIT_SUCCESS);
}

// TCP data from keyboard (IPv6)
int
on_entry163_activate (GtkWidget *entry163, SPSData *data)
{
  key_data (entry163, 3, data->ascii_hex_tcp6, data);

  if (data->nframes[3] > 1) {
    sprintf (data->warning_text, "Packet will be fragmented to accomodate TCP data.");
    data->parent = data->main_window;
    report_warning (data);
  }

  // Update ethernet frame and extension header editing window widgets, if visible.
  ip6data_update (3, data);

  return (EXIT_SUCCESS);
}

// TCP data from file (IPv6)
int
on_button22_clicked (GtkButton *button22, SPSData *data)
{
  (void) button22;  // This statement suppresses compiler warning about unused parameter.

  file_payload_data (data->entry163, 3, data);

  if (data->nframes[3] > 1) {
    sprintf (data->warning_text, "Packet will be fragmented to accomodate TCP data.");
    data->parent = data->main_window;
    report_warning (data);
  }

  // Update ethernet frame and extension header editing window widgets, if visible.
  ip6data_update (3, data);

  return (EXIT_SUCCESS);
}

// ICMP page (IPv4)

// Specify ethernet header
int
on_checkbutton17_toggled (GtkButton *checkbutton17, SPSData *data)
{
  (void) checkbutton17;  // This statement suppresses compiler warning about unused parameter.

  if (data->specify_ether[1]) {
    data->specify_ether[1] = 0;
  } else {
    data->specify_ether[1] = 1;
  }

  return (EXIT_SUCCESS);
}

// Destination link-layer (MAC) address (48 bits)
int
on_entry141_activate (GtkWidget *entry141, SPSData *data)
{
  mac_entry (entry141, data->ethhdr[1].dst_mac, 1, data);

  return (EXIT_SUCCESS);
}

// Source link-layer (MAC) address (48 bits)
int
on_entry142_activate (GtkWidget *entry142, SPSData *data)
{
  mac_entry (entry142, data->ethhdr[1].src_mac, 1, data);

  return (EXIT_SUCCESS);
}

// This host's interface name to be converted to link-layer (MAC) address and find MTU.
int
on_entry151_activate (GtkWidget *entry151, SPSData *data)
{
  // Check for valid source interface name, check MTU, and update source MAC address.
  ifname_entry (entry151, data->ifname[1], data->ethhdr[1].src_mac, data->entry142, 1, data);

  // Update MTU spinbutton.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton6), data->ifmtu[1]);

  return (EXIT_SUCCESS);
}

// Maximum transmission unit (MTU)
int
on_spinbutton6_value_changed (GtkWidget *spinbutton6, SPSData *data)
{
  data->ifmtu[1] = (int) gtk_spin_button_get_value (GTK_SPIN_BUTTON (spinbutton6));

  // Check if MTU is sufficiently large to accomodate packet. If not, revise.
  check_mtu (1, data);

  // Update spinbutton value.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (spinbutton6), data->ifmtu[1]);

  // Update ethernet frames.
  create_ip4_frame (1, data);

  return (EXIT_SUCCESS);
}

// Ethernet type code (16 bits)
// http://www.iana.org/assignments/ethernet-numbers
int
on_entry143_activate (GtkWidget *entry143, SPSData *data)
{
  ethtype_entry (entry143, 1, data);

  return (EXIT_SUCCESS);
}

// IPv4 header length (4 bits)
int
on_entry57_activate (GtkWidget *entry57, SPSData *data)
{
  ip4_hdrlen_entry (entry57, 1, data);

  return (EXIT_SUCCESS);
}

// IP version (4 bits)
int
on_entry58_activate (GtkWidget *entry58, SPSData *data)
{
  ip4_ver_entry (entry58, 1, data);

  return (EXIT_SUCCESS);
}

// Type of service (8 bits)
int
on_entry59_activate (GtkWidget *entry59, SPSData *data)
{
  ip4_tos_entry (entry59, 1, data);

  return (EXIT_SUCCESS);
}

// Total length of datagram (16 bits)
int
on_entry60_activate (GtkWidget *entry60, SPSData *data)
{
  ip4_tld_entry (entry60, 1, data);

  return (EXIT_SUCCESS);
}

// ID sequence number (16 bits)
int
on_entry61_activate (GtkWidget *entry61, SPSData *data)
{
  ip4_seq_entry (entry61, 1, data);

  return (EXIT_SUCCESS);
}

// Zero (1 bit)
int
on_entry123_activate (GtkWidget *entry123, SPSData *data)
{
  ip4_zero_entry (entry123, data->entry65, data->entry66, data->entry67, 1, data);

  return (EXIT_SUCCESS);
}

// Do not fragment flag (1 bit)
int
on_entry65_activate (GtkWidget *entry65, SPSData *data)
{
  ip4_dnf_entry (data->entry123, entry65, data->entry66, data->entry67, 1, data);

  return (EXIT_SUCCESS);
}

// More fragments following flag (1 bit)
int
on_entry66_activate (GtkWidget *entry66, SPSData *data)
{
  ip4_mff_entry (data->entry123, data->entry65, entry66, data->entry67, 1, data);

  return (EXIT_SUCCESS);
}

// Fragmentation offset (13 bits)
int
on_entry67_activate (GtkWidget *entry67, SPSData *data)
{
  ip4_fo_entry (data->entry123, data->entry65, data->entry66, entry67, 1, data);

  return (EXIT_SUCCESS);
}

// Time-to-Live (8 bits)
int
on_entry68_activate (GtkWidget *entry68, SPSData *data)
{
  ip4_ttl_entry (entry68, 1, data);

  return (EXIT_SUCCESS);
}

// Transport layer protocol (8 bits)
int
on_entry75_activate (GtkWidget *entry75, SPSData *data)
{
  ip4_tlp_entry (entry75, 1, data);

  return (EXIT_SUCCESS);
}

// Source IPv4 address (32 bits)
int
on_entry63_activate (GtkWidget *entry63, SPSData *data)
{
  ip4_sip_entry (entry63, 1, data);

  //  IP address has been entered manually. Uncheck "Randomize" checkbutton.
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton9), FALSE);
  data->ran_icmp4_sourceip = 0;

  return (EXIT_SUCCESS);
}

// Randomize source IPv4 address
int
on_checkbutton9_toggled (GtkButton *checkbutton9, SPSData *data)
{
  (void) checkbutton9;  // This statement suppresses compiler warning about unused parameter.

  ip4_ransip_checkbutton (&data->ran_icmp4_sourceip, data->entry63, 1, data);

  return (EXIT_SUCCESS);
}

// Destination IPv4 address (32 bits)
int
on_entry64_activate (GtkWidget *entry64, SPSData *data)
{
  ip4_dip_entry (entry64, 1, data);

  return (EXIT_SUCCESS);
}

// IPv4 checksum (16 bits)
int
on_entry62_activate (GtkWidget *entry62, SPSData *data)
{
  ip4_chksum_entry (entry62, 1, data);

  return (EXIT_SUCCESS);
}

// IP options for IPv4 ICMP 

// Decimal option data entry
int
on_radiobutton43_toggled (GtkButton *radiobutton43, SPSData *data)
{
  (void) radiobutton43;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_ipopt_icmp4 = 0;

  return (EXIT_SUCCESS);
}

// Hexadecimal option data entry
int
on_radiobutton44_toggled (GtkButton *radiobutton44, SPSData *data)
{
  (void) radiobutton44;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_ipopt_icmp4 = 1;

  return (EXIT_SUCCESS);
}

// IPv4 option data
int
on_entry407_activate (GtkWidget *entry407, SPSData *data)
{
  data_entry (entry407, &data->ip_optlenbuf[1], MAX_IP4OPTLEN, data->ip_optionsbuf[1], data->dec_hex_ipopt_icmp4, data->main_window, data);

  return (EXIT_SUCCESS);
}

// Insert IPv4 option after another, as specified by user.
int
on_button59_clicked (GtkButton *button59, SPSData *data)
{
  (void) button59;  // This statement suppresses compiler warning about unused parameter.

  ip4_option (0, 1, data->ipopt_icmp4_after, data->textview26, data->spinbutton6, data);

  return (EXIT_SUCCESS);
}

// Number of option after which to insert new IPv4 option.
int
on_entry408_activate (GtkWidget *entry408, SPSData *data)
{
  ip4_opt_insert_after_entry (entry408, 1, &data->ipopt_icmp4_after, data);

  return (EXIT_SUCCESS);
}

// Append IP option for IPv4 ICMP packet.
int
on_button63_clicked (GtkButton *button63, SPSData *data)
{
  (void) button63;  // This statement suppresses compiler warning about unused parameter.

  ip4_option (2, 1, 0, data->textview26, data->spinbutton6, data);

  return (EXIT_SUCCESS);
}

// View IPv4 header options for ICMP.
int
on_button64_clicked (GtkButton *button64, SPSData *data)
{
  (void) button64;  // This statement suppresses compiler warning about unused parameter.

  opt_view (1, 0, data);

  return (EXIT_SUCCESS);
}

// Number of IPv4 option to remove.
int
on_entry409_activate (GtkWidget *entry409, SPSData *data)
{
  ip4_opt_remove_entry (entry409, 1, &data->ipopt_icmp4_remove, data);

  return (EXIT_SUCCESS);
}

// Remove selected IPv4 option.
int
on_button65_clicked (GtkButton *button65, SPSData *data)
{
  (void) button65;  // This statement suppresses compiler warning about unused parameter.

  ip4_option (1, 1, data->ipopt_icmp4_remove, data->textview26, data->spinbutton6, data);

  return (EXIT_SUCCESS);
}

// ICMP header (IPv4)

// Message Type (8 bits)
int
on_entry69_activate (GtkWidget *entry69, SPSData *data)
{
  icmp_mt_entry (entry69, 1, data);

  return (EXIT_SUCCESS);
}

// Message Code (8 bits)
int
on_entry70_activate (GtkWidget *entry70, SPSData *data)
{
  icmp_mc_entry (entry70, 1, data);

  return (EXIT_SUCCESS);
}

// ICMP checksum (16 bits)
int
on_entry71_activate (GtkWidget *entry71, SPSData *data)
{
  icmp_chksum_entry (entry71, 1, data);

  return (EXIT_SUCCESS);
}

// ID (16 bits)
int
on_entry72_activate (GtkWidget *entry72, SPSData *data)
{
  icmp_id_entry (entry72, 1, data);

  return (EXIT_SUCCESS);
}

// Sequence number (16 bits)
int
on_entry73_activate (GtkWidget *entry73, SPSData *data)
{
  icmp_seq_entry (entry73, 1, data);

  return (EXIT_SUCCESS);
}

// ASCII data entry
int
on_radiobutton9_toggled (GtkButton *radiobutton9, SPSData *data)
{
  (void) radiobutton9;  // This statement suppresses compiler warning about unused parameter.

  data->ascii_hex_icmp4 = 0;

  return (EXIT_SUCCESS);
}

// Hexadecimal data entry
int
on_radiobutton10_toggled (GtkButton *radiobutton10, SPSData *data)
{
  (void) radiobutton10;  // This statement suppresses compiler warning about unused parameter.

  data->ascii_hex_icmp4 = 1;

  return (EXIT_SUCCESS);
}

// ICMP data from keyboard (IPv4)
int
on_entry126_activate (GtkWidget *entry126, SPSData *data)
{
  key_data (entry126, 1, data->ascii_hex_icmp4, data);

  if (data->nframes[1] > 1) {
    sprintf (data->warning_text, "Packet will be fragmented to accomodate ICMP data.");
    data->parent = data->main_window;
    report_warning (data);
  }

  return (EXIT_SUCCESS);
}

// ICMP data from file (IPv4)
int
on_button7_clicked (GtkButton *button7, SPSData *data)
{
  (void) button7;  // This statement suppresses compiler warning about unused parameter.

  file_payload_data (data->entry126, 1, data);

  if (data->nframes[1] > 1) {
    sprintf (data->warning_text, "Packet will be fragmented to accomodate ICMP data.");
    data->parent = data->main_window;
    report_warning (data);
  }

  return (EXIT_SUCCESS);
}

// ICMP page (IPv6)

// Destination link-layer (MAC) address (48 bits)
int
on_entry128_activate (GtkWidget *entry128, SPSData *data)
{
  mac_entry (entry128, data->ethhdr[4].dst_mac, 4, data);

  return (EXIT_SUCCESS);
}

// Source link-layer (MAC) address (48 bits)
int
on_entry129_activate (GtkWidget *entry129, SPSData *data)
{
  mac_entry (entry129, data->ethhdr[4].src_mac, 4, data);

  return (EXIT_SUCCESS);
}

// This host's interface name to be converted to link-layer (MAC) address and find MTU.
int
on_entry153_activate (GtkWidget *entry153, SPSData *data)
{
  // Check for valid source interface name, check MTU, and update source MAC address.
  ifname_entry (entry153, data->ifname[4], data->ethhdr[4].src_mac, data->entry129, 4, data);

  // Update MTU spinbutton.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton9), data->ifmtu[4]);

  return (EXIT_SUCCESS);
}

// Maximum transmission unit (MTU)
int
on_spinbutton9_value_changed (GtkWidget *spinbutton9, SPSData *data)
{
  data->ifmtu[4] = (int) gtk_spin_button_get_value (GTK_SPIN_BUTTON (spinbutton9));

  // Check if MTU is sufficiently large to accomodate packet. If not, revise.
  check_mtu (4, data);

  // Update spinbutton value.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (spinbutton9), data->ifmtu[4]);

  // Update ethernet frames.
  create_ip6_frame (4, data);
  create_6to4_frame (7, data);

  return (EXIT_SUCCESS);
}

// Ethernet type code (16 bits)
// http://www.iana.org/assignments/ethernet-numbers
int
on_entry130_activate (GtkWidget *entry130, SPSData *data)
{
  ethtype_entry (entry130, 4, data);

  return (EXIT_SUCCESS);
}

// IP version (4 bits)
int
on_entry110_activate (GtkWidget *entry110, SPSData *data)
{
  ip6_ver_entry (entry110, 4, data);

  return (EXIT_SUCCESS);
}

// Traffic class (8 bits)
int
on_entry111_activate (GtkWidget *entry111, SPSData *data)
{
  ip6_tc_entry (entry111, 4, data);

  return (EXIT_SUCCESS);
}

// Flow label (20 bits)
int
on_entry112_activate (GtkWidget *entry112, SPSData *data)
{
  ip6_fl_entry (entry112, 4, data);

  return (EXIT_SUCCESS);
}

// Payload length (16 bits)
int
on_entry113_activate (GtkWidget *entry113, SPSData *data)
{
  ip6_plen_entry (entry113, 4, data);

  return (EXIT_SUCCESS);
}

// Next header (8 bits)
int
on_entry114_activate (GtkWidget *entry114, SPSData *data)
{
  ip6_nxt_entry (entry114, 4, data);

  return (EXIT_SUCCESS);
}

// Hop limit (8 bits)
int
on_entry115_activate (GtkWidget *entry115, SPSData *data)
{
  ip6_hops_entry (entry115, 4, data);

  return (EXIT_SUCCESS);
}

// Source IP address (128 bits)
int
on_entry109_activate (GtkWidget *entry109, SPSData *data)
{
  ip6_sip_entry (entry109, 4, data);

  // IP address has been entered manually. Uncheck "Randomize" checkbutton.
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton10), FALSE);
  data->ran_icmp6_sourceip = 0;

  return (EXIT_SUCCESS);
}

// Randomize source IP address
int
on_checkbutton10_toggled (GtkButton *checkbutton10, SPSData *data)
{
  (void) checkbutton10;  // This statement suppresses compiler warning about unused parameter.

  ip6_ransip_checkbutton (&data->ran_icmp6_sourceip, data->entry109, 4, data);

  return (EXIT_SUCCESS);
}

// Destination IP address (128 bits)
int
on_entry116_activate (GtkWidget *entry116, SPSData *data)
{
  ip6_dip_entry (entry116, 4, data);

  return (EXIT_SUCCESS);
}

// Hop-by-Hop extension header
int
on_button99_clicked (GtkWidget *button99, SPSData *data)
{
  (void) button99;  // This statement suppresses compiler warning about unused parameter.

  data->exthdr_type = 4;
  hop_win (data);

  return (EXIT_SUCCESS);
}

// Destination extension header
int
on_button111_clicked (GtkWidget *button111, SPSData *data)
{
  (void) button111;  // This statement suppresses compiler warning about unused parameter.

  data->exthdr_type = 4;
  dst_win (data);

  return (EXIT_SUCCESS);
}

// Routing extension header
int
on_button133_clicked (GtkWidget *button133, SPSData *data)
{
  (void) button133;  // This statement suppresses compiler warning about unused parameter.

  data->exthdr_type = 4;
  route_win (data);

  return (EXIT_SUCCESS);
}

// Authentication extension header
int
on_button117_clicked (GtkWidget *button117, SPSData *data)
{
  (void) button117;  // This statement suppresses compiler warning about unused parameter.

  data->exthdr_type = 4;
  auth_win (data);

  return (EXIT_SUCCESS);
}

// ESP extension header
int
on_button127_clicked (GtkWidget *button127, SPSData *data)
{
  (void) button127;  // This statement suppresses compiler warning about unused parameter.

  data->exthdr_type = 4;
  esp_win (data);

  return (EXIT_SUCCESS);
}

// ICMP header (IPv6)

// Message Type (8 bits)
int
on_entry117_activate (GtkWidget *entry117, SPSData *data)
{
  icmp_mt_entry (entry117, 4, data);

  return (EXIT_SUCCESS);
}

// Message Code (8 bits)
int
on_entry118_activate (GtkWidget *entry118, SPSData *data)
{
  icmp_mc_entry (entry118, 4, data);

  return (EXIT_SUCCESS);
}

// ICMP checksum (16 bits)
int
on_entry119_activate (GtkWidget *entry119, SPSData *data)
{
  icmp_chksum_entry (entry119, 4, data);

  return (EXIT_SUCCESS);
}

// ID (16 bits)
int
on_entry120_activate (GtkWidget *entry120, SPSData *data)
{
  icmp_id_entry (entry120, 4, data);

  return (EXIT_SUCCESS);
}

// Sequence number (16 bits)
int
on_entry121_activate (GtkWidget *entry121, SPSData *data)
{
  icmp_seq_entry (entry121, 4, data);

  return (EXIT_SUCCESS);
}

// ASCII data entry
int
on_radiobutton11_toggled (GtkButton *radiobutton11, SPSData *data)
{
  (void) radiobutton11;  // This statement suppresses compiler warning about unused parameter.

  data->ascii_hex_icmp6 = 0;

  return (EXIT_SUCCESS);
}

// Hexadecimal data entry
int
on_radiobutton12_toggled (GtkButton *radiobutton12, SPSData *data)
{
  (void) radiobutton12;  // This statement suppresses compiler warning about unused parameter.

  data->ascii_hex_icmp6 = 1;

  return (EXIT_SUCCESS);
}

// ICMP data from keyboard (IPv6)
int
on_entry127_activate (GtkWidget *entry127, SPSData *data)
{
  key_data (entry127, 4, data->ascii_hex_icmp6, data);

  if (data->nframes[4] > 1) {
    sprintf (data->warning_text, "Packet will be fragmented to accomodate ICMP data.");
    data->parent = data->main_window;
    report_warning (data);
  }

  // Update ethernet frame and extension header editing window widgets, if visible.
  ip6data_update (4, data);

  return (EXIT_SUCCESS);
}

// ICMP data from file (IPv6)
int
on_button9_clicked (GtkButton *button9, SPSData *data)
{
  (void) button9;  // This statement suppresses compiler warning about unused parameter.

  file_payload_data (data->entry127, 4, data);

  if (data->nframes[4] > 1) {
    sprintf (data->warning_text, "Packet will be fragmented to accomodate ICMP data.");
    data->parent = data->main_window;
    report_warning (data);
  }

  // Update ethernet frame and extension header editing window widgets, if visible.
  ip6data_update (4, data);

  return (EXIT_SUCCESS);
}

// UDP page (IPv4)

// Specify ethernet header
int
on_checkbutton19_toggled (GtkButton *checkbutton19, SPSData *data)
{
  (void) checkbutton19;  // This statement suppresses compiler warning about unused parameter.

  if (data->specify_ether[2]) {
    data->specify_ether[2] = 0;
  } else {
    data->specify_ether[2] = 1;
  }

  return (EXIT_SUCCESS);
}

// Destination link-layer (MAC) address (48 bits)
int
on_entry147_activate (GtkWidget *entry147, SPSData *data)
{
  mac_entry (entry147, data->ethhdr[2].dst_mac, 2, data);

  return (EXIT_SUCCESS);
}

// Source link-layer (MAC) address (48 bits)
int
on_entry148_activate (GtkWidget *entry148, SPSData *data)
{
  mac_entry (entry148, data->ethhdr[2].src_mac, 2, data);

  return (EXIT_SUCCESS);
}

// This host's interface name to be converted to link-layer (MAC) address and find MTU.
int
on_entry152_activate (GtkWidget *entry152, SPSData *data)
{
  // Check for valid source interface name, check MTU, and update source MAC address.
  ifname_entry (entry152, data->ifname[2], data->ethhdr[2].src_mac, data->entry148, 2, data);

  // Update MTU spinbutton.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton7), data->ifmtu[2]);

  return (EXIT_SUCCESS);
}

// Maximum transmission unit (MTU)
int
on_spinbutton7_value_changed (GtkWidget *spinbutton7, SPSData *data)
{
  data->ifmtu[2] = (int) gtk_spin_button_get_value (GTK_SPIN_BUTTON (spinbutton7));

  // Check if MTU is sufficiently large to accomodate packet. If not, revise.
  check_mtu (2, data);

  // Update spinbutton value.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (spinbutton7), data->ifmtu[2]);

  // Update ethernet frames.
  create_ip4_frame (2, data);

  return (EXIT_SUCCESS);
}

// Ethernet type code (16 bits)
// http://www.iana.org/assignments/ethernet-numbers
int
on_entry149_activate (GtkWidget *entry149, SPSData *data)
{
  ethtype_entry (entry149, 2, data);

  return (EXIT_SUCCESS);
}

// IPv4 header length (4 bits)
int
on_entry1_activate (GtkWidget *entry1, SPSData *data)
{
  ip4_hdrlen_entry (entry1, 2, data);

  return (EXIT_SUCCESS);
}

// IP version (4 bits)
int
on_entry2_activate (GtkWidget *entry2, SPSData *data)
{
  ip4_ver_entry (entry2, 2, data);

  return (EXIT_SUCCESS);
}

// Type of service (8 bits)
int
on_entry3_activate (GtkWidget *entry3, SPSData *data)
{
  ip4_tos_entry (entry3, 2, data);

  return (EXIT_SUCCESS);
}

// Total length of datagram (16 bits)
int
on_entry4_activate (GtkWidget *entry4, SPSData *data)
{
  ip4_tld_entry (entry4, 2, data);

  return (EXIT_SUCCESS);
}

// ID sequence number (16 bits)
int
on_entry5_activate (GtkWidget *entry5, SPSData *data)
{
  ip4_seq_entry (entry5, 2, data);

  return (EXIT_SUCCESS);
}

// Zero (1 bit)
int
on_entry124_activate (GtkWidget *entry124, SPSData *data)
{
  ip4_zero_entry (entry124, data->entry9, data->entry10, data->entry11, 2, data);

  return (EXIT_SUCCESS);
}

// Do not fragment flag (1 bit)
int
on_entry9_activate (GtkWidget *entry9, SPSData *data)
{
  ip4_dnf_entry (data->entry124, entry9, data->entry10, data->entry11, 2, data);

  return (EXIT_SUCCESS);
}

// More fragments following flag (1 bit)
int
on_entry10_activate (GtkWidget *entry10, SPSData *data)
{
  ip4_mff_entry (data->entry124, data->entry9, entry10, data->entry11, 2, data);

  return (EXIT_SUCCESS);
}

// Fragmentation offset (13 bits)
int
on_entry11_activate (GtkWidget *entry11, SPSData *data)
{
  ip4_fo_entry (data->entry124, data->entry9, data->entry10, entry11, 2, data);

  return (EXIT_SUCCESS);
}

// Time-to-Live (8 bits)
int
on_entry12_activate (GtkWidget *entry12, SPSData *data)
{
  ip4_ttl_entry (entry12, 2, data);

  return (EXIT_SUCCESS);
}

// Transport layer protocol (8 bits)
int
on_entry76_activate (GtkWidget *entry76, SPSData *data)
{
  ip4_tlp_entry (entry76, 2, data);

  return (EXIT_SUCCESS);
}

// Source IPv4 address (32 bits)
int
on_entry7_activate (GtkWidget *entry7, SPSData *data)
{
  ip4_sip_entry (entry7, 2, data);

  // IP address has been entered manually. Uncheck "Randomize" checkbutton.
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton1), FALSE);
  data->ran_udp4_sourceip = 0;

  return (EXIT_SUCCESS);
}

// Randomize source IPv4 address
int
on_checkbutton1_toggled (GtkButton *checkbutton1, SPSData *data)
{
  (void) checkbutton1;  // This statement suppresses compiler warning about unused parameter.

  ip4_ransip_checkbutton (&data->ran_udp4_sourceip, data->entry7, 2, data);

  if (data->ran_udp4_sourceip) {
    udp_chksum (2, data);
  }

  return (EXIT_SUCCESS);
}

// Destination IPv4 address (32 bits)
int
on_entry8_activate (GtkWidget *entry8, SPSData *data)
{
  ip4_dip_entry (entry8, 2, data);

  return (EXIT_SUCCESS);
}

// IPv4 checksum (16 bits)
int
on_entry6_activate (GtkWidget *entry6, SPSData *data)
{
  ip4_chksum_entry (entry6, 2, data);

  return (EXIT_SUCCESS);
}

// IP options for IPv4 UDP

// Decimal option data entry
int
on_radiobutton45_toggled (GtkButton *radiobutton45, SPSData *data)
{
  (void) radiobutton45;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_ipopt_udp4 = 0;

  return (EXIT_SUCCESS);
}

// Hexadecimal option data entry
int
on_radiobutton46_toggled (GtkButton *radiobutton46, SPSData *data)
{
  (void) radiobutton46;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_ipopt_udp4 = 1;

  return (EXIT_SUCCESS);
}

// IPv4 option data
int
on_entry410_activate (GtkWidget *entry410, SPSData *data)
{
  data_entry (entry410, &data->ip_optlenbuf[2], MAX_IP4OPTLEN, data->ip_optionsbuf[2], data->dec_hex_ipopt_udp4, data->main_window, data);

  return (EXIT_SUCCESS);
}

// Insert IPv4 option after another, as specified by user.
int
on_button66_clicked (GtkButton *button66, SPSData *data)
{
  (void) button66;  // This statement suppresses compiler warning about unused parameter.

  ip4_option (0, 2, data->ipopt_udp4_after, data->textview28, data->spinbutton7, data);

  return (EXIT_SUCCESS);
}

// Number of option after which to insert new IPv4 option.
int
on_entry411_activate (GtkWidget *entry411, SPSData *data)
{
  ip4_opt_insert_after_entry (entry411, 2, &data->ipopt_udp4_after, data);

  return (EXIT_SUCCESS);
}

// Append IP option for IPv4 UDP packet.
int
on_button67_clicked (GtkButton *button67, SPSData *data)
{
  (void) button67;  // This statement suppresses compiler warning about unused parameter.

  ip4_option (2, 2, 0, data->textview28, data->spinbutton7, data);

  return (EXIT_SUCCESS);
}

// View IPv4 header options for UDP.
int
on_button68_clicked (GtkButton *button68, SPSData *data)
{
  (void) button68;  // This statement suppresses compiler warning about unused parameter.

  opt_view (2, 0, data);

  return (EXIT_SUCCESS);
}

// Number of IPv4 option to remove.
int
on_entry412_activate (GtkWidget *entry412, SPSData *data)
{
  ip4_opt_remove_entry (entry412, 2, &data->ipopt_tcp4_remove, data);

  return (EXIT_SUCCESS);
}

// Remove selected IPv4 option.
int
on_button69_clicked (GtkButton *button69, SPSData *data)
{
  (void) button69;  // This statement suppresses compiler warning about unused parameter.

  ip4_option (1, 2, data->ipopt_udp4_remove, data->textview28, data->spinbutton7, data);

  return (EXIT_SUCCESS);
}

// UDP header (IPv4)

// UDP source port (16 bits)
int
on_entry13_activate (GtkWidget *entry13, SPSData *data)
{
  udp_sport_entry (entry13, 2, data);

  // Source port has been entered manually. Uncheck "Randomize" checkbutton.
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton3), FALSE);
  data->ran_udp4_sourceport = 0;

  return (EXIT_SUCCESS);
}

// Randomize UDP source port number.
int
on_checkbutton3_toggled (GtkButton *checkbutton3, SPSData *data)
{
  (void) checkbutton3;  // This statement suppresses compiler warning about unused parameter.

  udp_ran_sport (&data->ran_udp6_sourceport, 2, data->entry13, data);

  return (EXIT_SUCCESS);
}

// UDP destination port (16 bits)
int
on_entry14_activate (GtkWidget *entry14, SPSData *data)
{
  udp_dport_entry (entry14, 2, data);

  return (EXIT_SUCCESS);
}

// Length of UDP datagram (16 bits)
int
on_entry15_activate (GtkWidget *entry15, SPSData *data)
{
  udp_len_entry (entry15, 2, data);

  return (EXIT_SUCCESS);
}

// UDP checksum (16 bits)
int
on_entry16_activate (GtkWidget *entry16, SPSData *data)
{
  udp_chksum_entry (entry16, 2, data);

  return (EXIT_SUCCESS);
}

// ASCII data entry
int
on_radiobutton13_toggled (GtkButton *radiobutton13, SPSData *data)
{
  (void) radiobutton13;  // This statement suppresses compiler warning about unused parameter.

  data->ascii_hex_udp4 = 0;

  return (EXIT_SUCCESS);
}

// Hexadecimal data entry
int
on_radiobutton14_toggled (GtkButton *radiobutton14, SPSData *data)
{
  (void) radiobutton14;  // This statement suppresses compiler warning about unused parameter.

  data->ascii_hex_udp4 = 1;

  return (EXIT_SUCCESS);
}

// UDP data from keyboard (IPv4)
int
on_entry17_activate (GtkWidget *entry17, SPSData *data)
{
  key_data (entry17, 2, data->ascii_hex_udp4, data);

  if (data->nframes[2] > 1) {
    sprintf (data->warning_text, "Packet will be fragmented to accomodate UDP data.");
    data->parent = data->main_window;
    report_warning (data);
  }

  return (EXIT_SUCCESS);
}

// UDP data from file (IPv4)
int
on_button8_clicked (GtkButton *button8, SPSData *data)
{
  (void) button8;  // This statement suppresses compiler warning about unused parameter.

  file_payload_data (data->entry17, 2, data);

  if (data->nframes[2] > 1) {
    sprintf (data->warning_text, "Packet will be fragmented to accomodate UDP data.");
    data->parent = data->main_window;
    report_warning (data);
  }

  return (EXIT_SUCCESS);
}

// UDP page (IPv6)

// Destination link-layer (MAC) address (48 bits)
int
on_entry134_activate (GtkWidget *entry134, SPSData *data)
{
  mac_entry (entry134, data->ethhdr[5].dst_mac, 5, data);

  return (EXIT_SUCCESS);
}

// Source link-layer (MAC) address (48 bits)
int
on_entry135_activate (GtkWidget *entry135, SPSData *data)
{
  mac_entry (entry135, data->ethhdr[5].src_mac, 5, data);

  return (EXIT_SUCCESS);
}

// This host's interface name to be converted to link-layer (MAC) address and find MTU.
int
on_entry155_activate (GtkWidget *entry155, SPSData *data)
{
  // Check for valid source interface name, check MTU, and update source MAC address.
  ifname_entry (entry155, data->ifname[5], data->ethhdr[5].src_mac, data->entry135, 5, data);

  // Update MTU spinbutton.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton10), data->ifmtu[5]);

  return (EXIT_SUCCESS);
}

// Maximum transmission unit (MTU)
int
on_spinbutton10_value_changed (GtkWidget *spinbutton10, SPSData *data)
{
  data->ifmtu[5] = (int) gtk_spin_button_get_value (GTK_SPIN_BUTTON (spinbutton10));

  // Check if MTU is sufficiently large to accomodate packet. If not, revise.
  check_mtu (5, data);

  // Update spinbutton value.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (spinbutton10), data->ifmtu[5]);

  // Update ethernet frames.
  create_ip6_frame (5, data);
  create_6to4_frame (8, data);

  return (EXIT_SUCCESS);
}

// Ethernet type code (16 bits)
// http://www.iana.org/assignments/ethernet-numbers
int
on_entry136_activate (GtkWidget *entry136, SPSData *data)
{
  ethtype_entry (entry136, 5, data);

  return (EXIT_SUCCESS);
}

// IP version (4 bits)
int
on_entry97_activate (GtkWidget *entry97, SPSData *data)
{
  ip6_ver_entry (entry97, 5, data);

  return (EXIT_SUCCESS);
}

// Traffic class (8 bits)
int
on_entry98_activate (GtkWidget *entry98, SPSData *data)
{
  ip6_tc_entry (entry98, 5, data);

  return (EXIT_SUCCESS);
}

// Flow label (20 bits)
int
on_entry99_activate (GtkWidget *entry99, SPSData *data)
{
  ip6_fl_entry (entry99, 5, data);

  return (EXIT_SUCCESS);
}

// Payload length (16 bits)
int
on_entry100_activate (GtkWidget *entry100, SPSData *data)
{
  ip6_plen_entry (entry100, 5, data);

  return (EXIT_SUCCESS);
}

// Next header (8 bits)
int
on_entry101_activate (GtkWidget *entry101, SPSData *data)
{
  ip6_nxt_entry (entry101, 5, data);

  return (EXIT_SUCCESS);
}

// Hop limit (8 bits)
int
on_entry102_activate (GtkWidget *entry102, SPSData *data)
{
  ip6_hops_entry (entry102, 5, data);

  return (EXIT_SUCCESS);
}

// Source IP address (128 bits)
int
on_entry96_activate (GtkWidget *entry96, SPSData *data)
{
  ip6_sip_entry (entry96, 5, data);

  //  IP address has been entered manually. Uncheck "Randomize" checkbutton.
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton6), FALSE);
  data->ran_udp6_sourceip = 0;

  return (EXIT_SUCCESS);
}

// Randomize source IP address
int
on_checkbutton6_toggled (GtkButton *checkbutton6, SPSData *data)
{
  (void) checkbutton6;  // This statement suppresses compiler warning about unused parameter.

  ip6_ransip_checkbutton (&data->ran_udp6_sourceip, data->entry96, 5, data);

  return (EXIT_SUCCESS);
}

// Destination IP address (128 bits)
int
on_entry103_activate (GtkWidget *entry103, SPSData *data)
{
  ip6_dip_entry (entry103, 5, data);

  return (EXIT_SUCCESS);
}

// Hop-by-Hop extension header
int
on_button100_clicked (GtkWidget *button100, SPSData *data)
{
  (void) button100;  // This statement suppresses compiler warning about unused parameter.
  data->exthdr_type = 5;
  hop_win (data);

  return (EXIT_SUCCESS);
}

// Destination extension header
int
on_button112_clicked (GtkWidget *button112, SPSData *data)
{
  (void) button112;  // This statement suppresses compiler warning about unused parameter.

  data->exthdr_type = 5;
  dst_win (data);

  return (EXIT_SUCCESS);
}

// Routing extension header
int
on_button134_clicked (GtkWidget *button134, SPSData *data)
{
  (void) button134;  // This statement suppresses compiler warning about unused parameter.

  data->exthdr_type = 5;
  route_win (data);

  return (EXIT_SUCCESS);
}

// Authentication extension header
int
on_button118_clicked (GtkWidget *button118, SPSData *data)
{
  (void) button118;  // This statement suppresses compiler warning about unused parameter.

  data->exthdr_type = 5;
  auth_win (data);

  return (EXIT_SUCCESS);
}

// ESP extension header
int
on_button128_clicked (GtkWidget *button128, SPSData *data)
{
  (void) button128;  // This statement suppresses compiler warning about unused parameter.

  data->exthdr_type = 5;
  esp_win (data);

  return (EXIT_SUCCESS);
}

// UDP header (IPv6)

// UDP source port (16 bits)
int
on_entry104_activate (GtkWidget *entry104, SPSData *data)
{
  udp_sport_entry (entry104, 5, data);

  //  Source port has been entered manually. Uncheck "Randomize" checkbutton.
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton8), FALSE);
  data->ran_udp6_sourceport = 0;

  return (EXIT_SUCCESS);
}

// Randomize UDP source port number.
int
on_checkbutton8_toggled (GtkButton *checkbutton8, SPSData *data)
{
  (void) checkbutton8;  // This statement suppresses compiler warning about unused parameter.

  udp_ran_sport (&data->ran_udp6_sourceport, 5, data->entry104, data);

  return (EXIT_SUCCESS);
}

// UDP destination port (16 bits)
int
on_entry105_activate (GtkWidget *entry105, SPSData *data)
{
  udp_dport_entry (entry105, 5, data);

  return (EXIT_SUCCESS);
}

// Length of UDP datagram (16 bits)
int
on_entry106_activate (GtkWidget *entry106, SPSData *data)
{
  udp_len_entry (entry106, 5, data);

  return (EXIT_SUCCESS);
}

// UDP checksum (16 bits)
int
on_entry107_activate (GtkWidget *entry107, SPSData *data)
{
  udp_chksum_entry (entry107, 5, data);

  return (EXIT_SUCCESS);
}

// ASCII data entry
int
on_radiobutton15_toggled (GtkButton *radiobutton15, SPSData *data)
{
  (void) radiobutton15;  // This statement suppresses compiler warning about unused parameter.

  data->ascii_hex_udp6 = 0;

  return (EXIT_SUCCESS);
}

// Hexadecimal data entry
int
on_radiobutton16_toggled (GtkButton *radiobutton16, SPSData *data)
{
  (void) radiobutton16;  // This statement suppresses compiler warning about unused parameter.

  data->ascii_hex_udp6 = 1;

  return (EXIT_SUCCESS);
}

// UDP data from keyboard (IPv6)
int
on_entry108_activate (GtkWidget *entry108, SPSData *data)
{
  key_data (entry108, 5, data->ascii_hex_udp6, data);

  if (data->nframes[5] > 1) {
    sprintf (data->warning_text, "Packet will be fragmented to accomodate UDP data.");
    data->parent = data->main_window;
    report_warning (data);
  }

  // Update ethernet frame and extension header editing window widgets, if visible.
  ip6data_update (5, data);

  return (EXIT_SUCCESS);
}

// UDP data from file (IPv6)
int
on_button10_clicked (GtkButton *button10, SPSData *data)
{
  (void) button10;  // This statement suppresses compiler warning about unused parameter.

  file_payload_data (data->entry108, 5, data);

  if (data->nframes[5] > 1) {
    sprintf (data->warning_text, "Packet will be fragmented to accomodate UDP data.");
    data->parent = data->main_window;
    report_warning (data);
  }

  // Update ethernet frame and extension header editing window widgets, if visible.
  ip6data_update (5, data);

  return (EXIT_SUCCESS);
}

// Send page entries

// TCP (IPv4) packet type
int
on_radiobutton1_toggled (GtkButton *radiobutton1, SPSData *data)
{
  (void) radiobutton1;  // This statement suppresses compiler warning about unused parameter.

  data->packet_type = 0;

  return (EXIT_SUCCESS);
}

// ICMP (IPv4) packet type
int
on_radiobutton2_toggled (GtkButton *radiobutton2, SPSData *data)
{
  (void) radiobutton2;  // This statement suppresses compiler warning about unused parameter.

  data->packet_type = 1;

  return (EXIT_SUCCESS);
}

// UDP (IPv4) packet type
int
on_radiobutton3_toggled (GtkButton *radiobutton3, SPSData *data)
{
  (void) radiobutton3;  // This statement suppresses compiler warning about unused parameter.

  data->packet_type = 2;

  return (EXIT_SUCCESS);
}

// All (IPv4) packet types (i.e., cycle)
int
on_radiobutton4_toggled (GtkButton *radiobutton4, SPSData *data)
{
  (void) radiobutton4;  // This statement suppresses compiler warning about unused parameter.

  data->packet_type = 100;

  return (EXIT_SUCCESS);
}

// TCP (IPv6) packet type
int
on_radiobutton5_toggled (GtkButton *radiobutton5, SPSData *data)
{
  (void) radiobutton5;  // This statement suppresses compiler warning about unused parameter.

  data->packet_type = 3;

  return (EXIT_SUCCESS);
}

// ICMP (IPv6) packet type
int
on_radiobutton6_toggled (GtkButton *radiobutton6, SPSData *data)
{
  (void) radiobutton6;  // This statement suppresses compiler warning about unused parameter.

  data->packet_type = 4;

  return (EXIT_SUCCESS);
}

// UDP (IPv6) packet type
int
on_radiobutton7_toggled (GtkButton *radiobutton7, SPSData *data)
{
  (void) radiobutton7;  // This statement suppresses compiler warning about unused parameter.

  data->packet_type = 5;

  return (EXIT_SUCCESS);
}

// All (IPv6) packet types (i.e., cycle)
int
on_radiobutton8_toggled (GtkButton *radiobutton8, SPSData *data)
{
  (void) radiobutton8;  // This statement suppresses compiler warning about unused parameter.

  data->packet_type = 101;

  return (EXIT_SUCCESS);
}

// Tunnelling IPv6 over IPv4 (6to4)

// Tunnel IPv6 over IPv4
int
on_checkbutton12_toggled (GtkButton *checkbutton12, SPSData *data)
{
  (void) checkbutton12;  // This statement suppresses compiler warning about unused parameter.

  if (data->sixto4_flag) {
    data->sixto4_flag = 0;
  } else {
    data->sixto4_flag = 1;
  }

  return (EXIT_SUCCESS);
}

// Maximum transmission unit (MTU)
int
on_spinbutton17_value_changed (GtkWidget *spinbutton17, SPSData *data)
{
  data->ifmtu[6] = (int) gtk_spin_button_get_value (GTK_SPIN_BUTTON (spinbutton17));

  // Check if MTU is sufficiently large to accomodate packet. If not, revise.
  check_mtu (6, data);

  data->ifmtu[7] = data->ifmtu[6];
  data->ifmtu[8] = data->ifmtu[6];

  // Update spinbutton value.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (spinbutton17), data->ifmtu[6]);

  // Update ethernet frames.
  create_6to4_frame (6, data);
  create_6to4_frame (7, data);
  create_6to4_frame (8, data);

  return (EXIT_SUCCESS);
}

// TCP - Use ethernet header specified on IPv6 page
int
on_checkbutton14_toggled (GtkButton *checkbutton14, SPSData *data)
{
  (void) checkbutton14;  // This statement suppresses compiler warning about unused parameter.

  if (data->specify_ether[6]) {
    data->specify_ether[6] = 0;
  } else {
    data->specify_ether[6] = 1;
  }

  return (EXIT_SUCCESS);
}

// TCP IPv4 Source Address for 6to4 tunnel of IPv6 over IPv4
int
on_entry125_activate (GtkWidget *entry125, SPSData *data)
{
  ip4_sip_entry (entry125, 6, data);

  // Note: The TCP checksum does not need updating since it contains the IPv6
  // source and destination addresses, not the IPv4 6to4 header addresses.

  // IP address has been entered manually. Uncheck "Randomize" checkbutton.
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton13), FALSE);
  data->ran_tcp6to4_sourceip = 0;

  return (EXIT_SUCCESS);
}

// Randomize TCP IPv4 source address for 6to4 tunneling of IPv6 over IPv4
int
on_checkbutton13_toggled (GtkButton *checkbutton13, SPSData *data)
{
  (void) checkbutton13; // This statement suppresses compiler warning about unused parameter.

  ip4_ransip_checkbutton (&data->ran_tcp6to4_sourceip, data->entry125, 6, data);

  // Note: The TCP checksum does not need updating since it contains the IPv6
  // source and destination addresses, not the IPv4 6to4 header addresses.

  return (EXIT_SUCCESS);
}

// ICMP - Use ethernet header specified on IPv6 page
int
on_checkbutton47_toggled (GtkButton *checkbutton47, SPSData *data)
{
  (void) checkbutton47;  // This statement suppresses compiler warning about unused parameter.

  if (data->specify_ether[7]) {
    data->specify_ether[7] = 0;
  } else {
    data->specify_ether[7] = 1;
  }

  return (EXIT_SUCCESS);
}

// ICMP IPv4 Source Address for 6to4 tunnel of IPv6 over IPv4
int
on_entry160_activate (GtkWidget *entry160, SPSData *data)
{
  ip4_sip_entry (entry160, 7, data);

  // Note: The ICMP6 checksum does not need updating since it contains the IPv6
  // source and destination addresses, not the IPv4 6to4 header addresses.

  // IP address has been entered manually. Uncheck "Randomize" checkbutton.
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton26), FALSE);
  data->ran_icmp6to4_sourceip = 0;

  return (EXIT_SUCCESS);
}

// Randomize ICMP source IPv4 address for 6to4 tunneling of IPv6 over IPv4
int
on_checkbutton26_toggled (GtkButton *checkbutton26, SPSData *data)
{
  (void) checkbutton26;  // This statement suppresses compiler warning about unused parameter.

  ip4_ransip_checkbutton (&data->ran_icmp6to4_sourceip, data->entry160, 7, data);

  // Note: The ICMP6 checksum does not need updating since it contains the IPv6
  // source and destination addresses, not the IPv4 6to4 header addresses.

  return (EXIT_SUCCESS);
}

// UDP - Use ethernet header specified on IPv6 page
int
on_checkbutton32_toggled (GtkButton *checkbutton32, SPSData *data)
{
  (void) checkbutton32;  // This statement suppresses compiler warning about unused parameter.

  if (data->specify_ether[8]) {
    data->specify_ether[8] = 0;
  } else {
    data->specify_ether[8] = 1;
  }

  return (EXIT_SUCCESS);
}

// UDP IPv4 Source Address for 6to4 tunnel of IPv6 over IPv4
int
on_entry161_activate (GtkWidget *entry161, SPSData *data)
{
  ip4_sip_entry (entry161, 8, data);

  // Note: The UDP checksum does not need updating since it contains the IPv6
  // source and destination addresses, not the IPv4 6to4 header addresses.

  // IP address has been entered manually. Uncheck "Randomize" checkbutton.
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton27), FALSE);
  data->ran_udp6to4_sourceip = 0;

  return (EXIT_SUCCESS);
}

// Randomize UDP source IPv4 address for 6to4 tunneling of IPv6 over IPv4
int
on_checkbutton27_toggled (GtkButton *checkbutton27, SPSData *data)
{
  (void) checkbutton27;  // This statement suppresses compiler warning about unused parameter.

  ip4_ransip_checkbutton (&data->ran_udp6to4_sourceip, data->entry161, 8, data);

  // Note: The UDP checksum does not need updating since it contains the IPv6
  // source and destination addresses, not the IPv4 6to4 header addresses.

  return (EXIT_SUCCESS);
}

// Number of packets to send
int
on_entry18_activate (GtkWidget *entry18, SPSData *data)
{
  const char *entry18_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry18_text = gtk_entry_get_text (GTK_ENTRY (entry18));

  // Is value too large or small, or are there non-numeric characters?
  if ((!is_ascii_uint (entry18_text)) || (ascii_to_int64 ((char *) entry18_text) >= (int64_t) 0x7fffffffffffffffull) ||
      (ascii_to_int64 ((char *) entry18_text) < 1u)) {
    sprintf (value, "%" PRIu64, data->npackets);
    gtk_entry_set_text (GTK_ENTRY (data->entry18), value);
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->npackets = ascii_to_int64 ((char *) entry18_text);  // Update npackets with new value
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Set flood mode
int
on_checkbutton11_toggled (GtkButton *checkbutton11, SPSData *data)
{
  (void) checkbutton11;  // This statement suppresses compiler warning about unused parameter.
  (void) data;  // This statement suppresses compiler warning about unused parameter.

  if (flood_mode) {
    flood_mode = 0;
  } else {
    flood_mode = 1;
  }

  return (EXIT_SUCCESS);
}

// Send packet(s)
int
on_button1_clicked (GtkButton *button1, SPSData *data)
{
  (void) button1;  // This statement suppresses compiler warning about unused parameter.

  GThread *thread;

  if ((data->packet_type == 0) || (data->packet_type == 1) ||
      (data->packet_type == 2) || (data->packet_type == 100)) {
    // Spawn thread to send IPv4 packet(s).
    thread = g_thread_new ("ipv4_send", (GThreadFunc) ipv4_send, data);
    if (! thread) {
      fprintf (stderr, "Error: Unable to create new thread for ipv4_send() in on_button1_clicked().\n");
      exit (EXIT_FAILURE);
    }

  } else if ((data->packet_type == 3) || (data->packet_type == 4) ||
             (data->packet_type == 5) || (data->packet_type == 101)) {
    if (data->sixto4_flag) {
      // Spawn thread to send 6to4 IPv6 packet(s).
      thread = g_thread_new ("sixto4_send", (GThreadFunc) sixto4_send, data);
      if (! thread) {
        fprintf (stderr, "Error: Unable to create new thread for sixto4_send() in on_button1_clicked().\n");
        exit (EXIT_FAILURE);
      }
    } else {
      // Spawn thread to send IPv6 packet(s).
      thread = g_thread_new ("ipv6_send", (GThreadFunc) ipv6_send, data);
      if (! thread) {
        fprintf (stderr, "Error: Unable to create new thread for ipv6_send() in on_button1_clicked().\n");
        exit (EXIT_FAILURE);
      }
    }
  }

  return (EXIT_SUCCESS);
}

// Stop sending packets
int
on_button5_clicked (GtkButton *button5, SPSData *data)
{
  (void) button5;  // This statement suppresses compiler warning about unused parameter.

  // By toggling the checkbutton, the on_checkbutton11_toggled callback will be called
  // and it will set flood_mode to 0 for us.
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton11), FALSE);

  // If we're not flooding but sending a finite number of packets but want to stop,
  // set sending to 0 to stop.
  sending = 0;

  return (EXIT_SUCCESS);
}

// Load SPS file, which contains settings selected by user when saved
int
on_button21_clicked (GtkButton *button21, SPSData *data)
{
  (void) button21;  // This statement suppresses compiler warning about unused parameter.

  load_file (data);

  return (EXIT_SUCCESS);
}

// Save SPS file, which contains settings selected by user.
int
on_button14_clicked (GtkButton *button14, SPSData *data)
{
  (void) button14;  // This statement suppresses compiler warning about unused parameter.

  save_file (data);

  return (EXIT_SUCCESS);
}

// Send Packet settings
int
on_checkbutton25_toggled (GtkButton *checkbutton25, SPSData *data)
{
  (void) checkbutton25;  // This statement suppresses compiler warning about unused parameter.

  if (data->save_flags[0]) {
    data->save_flags[0] = 0;
  } else {
    data->save_flags[0] = 1;
  }

  return (EXIT_SUCCESS);
}

// Select to save IPv6 over IPv4 (6to4)
int
on_checkbutton15_toggled (GtkButton *checkbutton15, SPSData *data)
{
  (void) checkbutton15;  // This statement suppresses compiler warning about unused parameter.

  if (data->save_flags[1]) {
    data->save_flags[1] = 0;
  } else {
    data->save_flags[1] = 1;
  }

  return (EXIT_SUCCESS);
}

// Select to save IPv4 TCP packet
int
on_checkbutton16_toggled (GtkButton *checkbutton16, SPSData *data)
{
  (void) checkbutton16;  // This statement suppresses compiler warning about unused parameter.

  if (data->save_flags[2]) {
    data->save_flags[2] = 0;
  } else {
    data->save_flags[2] = 1;
  }

  return (EXIT_SUCCESS);
}

// Select to save IPv4 ICMP packet
int
on_checkbutton20_toggled (GtkButton *checkbutton20, SPSData *data)
{
  (void) checkbutton20;  // This statement suppresses compiler warning about unused parameter.

  if (data->save_flags[3]) {
    data->save_flags[3] = 0;
  } else {
    data->save_flags[3] = 1;
  }

  return (EXIT_SUCCESS);
}

// Select to save IPv4 UDP packet
int
on_checkbutton21_toggled (GtkButton *checkbutton21, SPSData *data)
{
  (void) checkbutton21;  // This statement suppresses compiler warning about unused parameter.

  if (data->save_flags[4]) {
    data->save_flags[4] = 0;
  } else {
    data->save_flags[4] = 1;
  }

  return (EXIT_SUCCESS);
}

// Select to save IPv6 TCP packet
int
on_checkbutton22_toggled (GtkButton *checkbutton22, SPSData *data)
{
  (void) checkbutton22;  // This statement suppresses compiler warning about unused parameter.

  if (data->save_flags[5]) {
    data->save_flags[5] = 0;
  } else {
    data->save_flags[5] = 1;
  }

  return (EXIT_SUCCESS);
}

// Select to save IPv6 ICMP packet
int
on_checkbutton23_toggled (GtkButton *checkbutton23, SPSData *data)
{
  (void) checkbutton23;  // This statement suppresses compiler warning about unused parameter.

  if (data->save_flags[6]) {
    data->save_flags[6] = 0;
  } else {
    data->save_flags[6] = 1;
  }

  return (EXIT_SUCCESS);
}

// Select to save IPv6 UDP packet
int
on_checkbutton24_toggled (GtkButton *checkbutton24, SPSData *data)
{
  (void) checkbutton24;  // This statement suppresses compiler warning about unused parameter.

  if (data->save_flags[7]) {
    data->save_flags[7] = 0;
  } else {
    data->save_flags[7] = 1;
  }

  return (EXIT_SUCCESS);
}

// Select to save traceroute settings
int
on_checkbutton36_toggled (GtkButton *checkbutton36, SPSData *data)
{
  (void) checkbutton36;  // This statement suppresses compiler warning about unused parameter.

  if (data->save_flags[8]) {
    data->save_flags[8] = 0;
  } else {
    data->save_flags[8] = 1;
  }

  return (EXIT_SUCCESS);
}

// Select to save IPv6 over IPv4 (6to4) for traceroute
int
on_checkbutton46_toggled (GtkButton *checkbutton46, SPSData *data)
{
  (void) checkbutton46;  // This statement suppresses compiler warning about unused parameter.

  if (data->save_flags[9]) {
    data->save_flags[9] = 0;
  } else {
    data->save_flags[9] = 1;
  }

  return (EXIT_SUCCESS);
}

// Select to save IPv4 TCP packet for traceroute
int
on_checkbutton39_toggled (GtkButton *checkbutton39, SPSData *data)
{
  (void) checkbutton39;  // This statement suppresses compiler warning about unused parameter.

  if (data->save_flags[10]) {
    data->save_flags[10] = 0;
  } else {
    data->save_flags[10] = 1;
  }

  return (EXIT_SUCCESS);
}

// Select to save IPv4 ICMP packet for traceroute
int
on_checkbutton41_toggled (GtkButton *checkbutton41, SPSData *data)
{
  (void) checkbutton41;  // This statement suppresses compiler warning about unused parameter.

  if (data->save_flags[11]) {
    data->save_flags[11] = 0;
  } else {
    data->save_flags[11] = 1;
  }

  return (EXIT_SUCCESS);
}

// Select to save IPv4 UDP packet for traceroute
int
on_checkbutton42_toggled (GtkButton *checkbutton42, SPSData *data)
{
  (void) checkbutton42;  // This statement suppresses compiler warning about unused parameter.

  if (data->save_flags[12]) {
    data->save_flags[12] = 0;
  } else {
    data->save_flags[12] = 1;
  }

  return (EXIT_SUCCESS);
}

// Select to save IPv6 TCP packet for traceroute
int
on_checkbutton43_toggled (GtkButton *checkbutton43, SPSData *data)
{
  (void) checkbutton43;  // This statement suppresses compiler warning about unused parameter.

  if (data->save_flags[13]) {
    data->save_flags[13] = 0;
  } else {
    data->save_flags[13] = 1;
  }

  return (EXIT_SUCCESS);
}

// Select to save IPv6 ICMP packet for traceroute
int
on_checkbutton44_toggled (GtkButton *checkbutton44, SPSData *data)
{
  (void) checkbutton44;  // This statement suppresses compiler warning about unused parameter.

  if (data->save_flags[14]) {
    data->save_flags[14] = 0;
  } else {
    data->save_flags[14] = 1;
  }

  return (EXIT_SUCCESS);
}

// Select to save IPv6 UDP packet for traceroute
int
on_checkbutton45_toggled (GtkButton *checkbutton45, SPSData *data)
{
  (void) checkbutton45;  // This statement suppresses compiler warning about unused parameter.

  if (data->save_flags[15]) {
    data->save_flags[15] = 0;
  } else {
    data->save_flags[15] = 1;
  }

  return (EXIT_SUCCESS);
}

// Timeout for ARP/ND to receive reply
int
on_spinbutton1_value_changed (GtkWidget *spinbutton1, SPSData *data)
{
  data->timeout = (int) gtk_spin_button_get_value (GTK_SPIN_BUTTON (spinbutton1));

  return (EXIT_SUCCESS);
}

// Call tcp4_default()
int
on_button11_clicked (GtkButton *button11, SPSData *data)
{
  (void) button11;  // This statement suppresses compiler warning about unused parameter.

  tcp4_default (data);

  return (EXIT_SUCCESS);
}

// Call icmp4_default()
int
on_button12_clicked (GtkButton *button12, SPSData *data)
{
  (void) button12;  // This statement suppresses compiler warning about unused parameter.

  icmp4_default (data);

  return (EXIT_SUCCESS);
}

// Call udp4_default()
int
on_button15_clicked (GtkButton *button15, SPSData *data)
{
  (void) button15;  // This statement suppresses compiler warning about unused parameter.

  udp4_default (data);

  return (EXIT_SUCCESS);
}

// Call tcp6_default()
int
on_button16_clicked (GtkButton *button16, SPSData *data)
{
  (void) button16;  // This statement suppresses compiler warning about unused parameter.

  tcp6_default (data);

  return (EXIT_SUCCESS);
}

// Call icmp6_default()
int
on_button18_clicked (GtkButton *button18, SPSData *data)
{
  (void) button18;  // This statement suppresses compiler warning about unused parameter.

  icmp6_default (data);

  return (EXIT_SUCCESS);
}

// Call udp6_default()
int
on_button19_clicked (GtkButton *button19, SPSData *data)
{
  (void) button19;  // This statement suppresses compiler warning about unused parameter.

  udp6_default (data);

  return (EXIT_SUCCESS);
}

// Tunnel IPv6 over IPv4 (6to4) (traceroute.ui)

// Tunnel IPv6 over IPv4 for traceroute
int
on_checkbutton29_toggled (GtkButton *checkbutton29, SPSData *data)
{
  (void) checkbutton29;  // This statement suppresses compiler warning about unused parameter.

  if (data->sixto4_tr_flag) {
    data->sixto4_tr_flag = 0;
  } else {
    data->sixto4_tr_flag = 1;
  }

  return (EXIT_SUCCESS);
}

// Maximum transmission unit (MTU)
int
on_spinbutton18_value_changed (GtkWidget *spinbutton18, SPSData *data)
{
  data->ifmtu[15] = (int) gtk_spin_button_get_value (GTK_SPIN_BUTTON (spinbutton18));

  // Check if MTU is sufficiently large to accomodate packet. If not, revise.
  check_mtu (15, data);

  data->ifmtu[16] = data->ifmtu[15];
  data->ifmtu[17] = data->ifmtu[15];

  // Update spinbutton value.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (spinbutton18), data->ifmtu[15]);

  // Update ethernet frames.
  create_6to4_frame (15, data);
  create_6to4_frame (16, data);
  create_6to4_frame (17, data);

  return (EXIT_SUCCESS);
}

// TCP (traceroute) - Use ethernet header specified on IPv6 page
int
on_checkbutton48_toggled (GtkButton *checkbutton48, SPSData *data)
{
  (void) checkbutton48;  // This statement suppresses compiler warning about unused parameter.

  if (data->specify_ether[15]) {
    data->specify_ether[15] = 0;
  } else {
    data->specify_ether[15] = 1;
  }

  return (EXIT_SUCCESS);
}

// TCP IPv4 Source Address for traceroute 6to4 tunnel of IPv6 over IPv4
int
on_entry316_activate (GtkWidget *entry316, SPSData *data)
{
  ip4_sip_entry (entry316, 15, data);

  // Note: The TCP checksum does not need updating since it contains the IPv6
  // source and destination addresses, not the IPv4 6to4 header addresses.

  return (EXIT_SUCCESS);
}

// ICMP (traceroute) - Use ethernet header specified on IPv6 page
int
on_checkbutton49_toggled (GtkButton *checkbutton49, SPSData *data)
{
  (void) checkbutton49;  // This statement suppresses compiler warning about unused parameter.

  if (data->specify_ether[16]) {
    data->specify_ether[16] = 0;
  } else {
    data->specify_ether[16] = 1;
  }

  return (EXIT_SUCCESS);
}

// ICMP IPv4 Source Address for traceroute 6to4 tunnel of IPv6 over IPv4
int
on_entry317_activate (GtkWidget *entry317, SPSData *data)
{
  ip4_sip_entry (entry317, 16, data);

  // Note: The ICMP checksum does not need updating since it contains the IPv6
  // source and destination addresses, not the IPv4 6to4 header addresses.

  return (EXIT_SUCCESS);
}

// UDP (traceroute) - Use ethernet header specified on IPv6 page
int
on_checkbutton50_toggled (GtkButton *checkbutton50, SPSData *data)
{
  (void) checkbutton50;  // This statement suppresses compiler warning about unused parameter.

  if (data->specify_ether[17]) {
    data->specify_ether[17] = 0;
  } else {
    data->specify_ether[17] = 1;
  }

  return (EXIT_SUCCESS);
}

// UDP IPv4 Source Address for traceroute 6to4 tunnel of IPv6 over IPv4
int
on_entry318_activate (GtkWidget *entry318, SPSData *data)
{
  ip4_sip_entry (entry318, 17, data);

  // Note: The UDP checksum does not need updating since it contains the IPv6
  // source and destination addresses, not the IPv4 6to4 header addresses.

  return (EXIT_SUCCESS);
}

// TCP page (IPv4) for Traceroute

// Specify ethernet header
int
on_checkbutton34_toggled (GtkButton *checkbutton34, SPSData *data)
{
  (void) checkbutton34;  // This statement suppresses compiler warning about unused parameter.

  if (data->specify_ether[9]) {
    data->specify_ether[9] = 0;
  } else {
    data->specify_ether[9] = 1;
  }

  return (EXIT_SUCCESS);
}

// Destination link-layer (MAC) address (48 bits)
int
on_entry164_activate (GtkWidget *entry164, SPSData *data)
{
  mac_entry (entry164, data->ethhdr[9].dst_mac, 9, data);

  return (EXIT_SUCCESS);
}

// Source link-layer (MAC) address (48 bits)
int
on_entry165_activate (GtkWidget *entry165, SPSData *data)
{
  mac_entry (entry165, data->ethhdr[9].src_mac, 9, data);

  return (EXIT_SUCCESS);
}

// This host's interface name to be converted to link-layer (MAC) address and find MTU.
int
on_entry166_activate (GtkWidget *entry166, SPSData *data)
{
  // Check for valid source interface name, check MTU, and update source MAC address.
  ifname_entry (entry166, data->ifname[9], data->ethhdr[9].src_mac, data->entry165, 9, data);

  // Update MTU spinbutton.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton11), data->ifmtu[9]);

  return (EXIT_SUCCESS);
}

// Maximum transmission unit (MTU)
int
on_spinbutton11_value_changed (GtkWidget *spinbutton11, SPSData *data)
{
  data->ifmtu[9] = (int) gtk_spin_button_get_value (GTK_SPIN_BUTTON (spinbutton11));

  // Check if MTU is sufficiently large to accomodate packet. If not, revise.
  check_mtu (9, data);

  // Update spinbutton value.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (spinbutton11), data->ifmtu[9]);

  // Update ethernet frames.
  create_ip4_frame (9, data);

  return (EXIT_SUCCESS);
}

// Ethernet type code (16 bits)
// http://www.iana.org/assignments/ethernet-numbers
int
on_entry167_activate (GtkWidget *entry167, SPSData *data)
{
  ethtype_entry (entry167, 9, data);

  return (EXIT_SUCCESS);
}

// IPv4 header length (4 bits)
int
on_entry168_activate (GtkWidget *entry168, SPSData *data)
{
  ip4_hdrlen_entry (entry168, 9, data);

  return (EXIT_SUCCESS);
}

// IP version (4 bits)
int
on_entry169_activate (GtkWidget *entry169, SPSData *data)
{
  ip4_ver_entry (entry169, 9, data);

  return (EXIT_SUCCESS);
}

// Type of service (8 bits)
int
on_entry170_activate (GtkWidget *entry170, SPSData *data)
{
  ip4_tos_entry (entry170, 9, data);

  return (EXIT_SUCCESS);
}

// Total length of datagram (16 bits)
int
on_entry171_activate (GtkWidget *entry171, SPSData *data)
{
  ip4_tld_entry (entry171, 9, data);

  return (EXIT_SUCCESS);
}

// ID sequence number (16 bits)
int
on_entry172_activate (GtkWidget *entry172, SPSData *data)
{
  ip4_seq_entry (entry172, 9, data);

  return (EXIT_SUCCESS);
}

// Zero (1 bit)
int
on_entry173_activate (GtkWidget *entry173, SPSData *data)
{
  ip4_zero_entry (entry173, data->entry174, data->entry175, data->entry176, 9, data);

  return (EXIT_SUCCESS);
}

// Do not fragment flag (1 bit)
int
on_entry174_activate (GtkWidget *entry174, SPSData *data)
{
  ip4_dnf_entry (data->entry173, entry174, data->entry175, data->entry176, 9, data);

  return (EXIT_SUCCESS);
}

// More fragments following flag (1 bit)
int
on_entry175_activate (GtkWidget *entry175, SPSData *data)
{
  ip4_mff_entry (data->entry173, data->entry174, entry175, data->entry176, 9, data);

  return (EXIT_SUCCESS);
}

// Fragmentation offset (13 bits)
int
on_entry176_activate (GtkWidget *entry176, SPSData *data)
{
  ip4_fo_entry (data->entry173, data->entry174, data->entry175, entry176, 9, data);

  return (EXIT_SUCCESS);
}

// Time-to-Live (8 bits)
int
on_entry177_activate (GtkWidget *entry177, SPSData *data)
{
  ip4_ttl_entry (entry177, 9, data);

  return (EXIT_SUCCESS);
}

// Transport layer protocol (8 bits)
int
on_entry178_activate (GtkWidget *entry178, SPSData *data)
{
  ip4_tlp_entry (entry178, 9, data);

  return (EXIT_SUCCESS);
}

// Source IPv4 address (32 bits)
int
on_entry179_activate (GtkWidget *entry179, SPSData *data)
{
  ip4_sip_entry (entry179, 9, data);

  return (EXIT_SUCCESS);
}

// Destination IPv4 address (32 bits)
int
on_entry180_activate (GtkWidget *entry180, SPSData *data)
{
  ip4_dip_entry (entry180, 9, data);

  return (EXIT_SUCCESS);
}

// IPv4 checksum (16 bits)
int
on_entry181_activate (GtkWidget *entry181, SPSData *data)
{
  ip4_chksum_entry (entry181, 9, data);

  return (EXIT_SUCCESS);
}

// IP options for IPv4 TCP for traceroute

// Decimal option data entry
int
on_radiobutton49_toggled (GtkButton *radiobutton49, SPSData *data)
{
  (void) radiobutton49;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_ipopt_tcp4_tr = 0;

  return (EXIT_SUCCESS);
}

// Hexadecimal option data entry
int
on_radiobutton50_toggled (GtkButton *radiobutton50, SPSData *data)
{
  (void) radiobutton50;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_ipopt_tcp4_tr = 1;

  return (EXIT_SUCCESS);
}

// IPv4 option data
int
on_entry416_activate (GtkWidget *entry416, SPSData *data)
{
  data_entry (entry416, &data->ip_optlenbuf[9], MAX_IP4OPTLEN, data->ip_optionsbuf[9], data->dec_hex_ipopt_tcp4_tr, data->traceroute_window, data);

  return (EXIT_SUCCESS);
}

// Insert IPv4 option after another, as specified by user.
int
on_button74_clicked (GtkButton *button74, SPSData *data)
{
  (void) button74;  // This statement suppresses compiler warning about unused parameter.

  ip4_option (0, 9, data->ipopt_tcp4_tr_after, data->textview34, data->spinbutton11, data);

  return (EXIT_SUCCESS);
}

// Number of option after which to insert new IPv4 option.
int
on_entry417_activate (GtkWidget *entry417, SPSData *data)
{
  ip4_opt_insert_after_entry (entry417, 9, &data->ipopt_tcp4_tr_after, data);

  return (EXIT_SUCCESS);
}

// Append IP option for IPv4 TCP packet for traceroute.
int
on_button75_clicked (GtkButton *button75, SPSData *data)
{
  (void) button75;  // This statement suppresses compiler warning about unused parameter.

  ip4_option (2, 9, 0, data->textview34, data->spinbutton11, data);

  return (EXIT_SUCCESS);
}

// View IPv4 header options for TCP for traceroute.
int
on_button76_clicked (GtkButton *button76, SPSData *data)
{
  (void) button76;  // This statement suppresses compiler warning about unused parameter.

  opt_view (9, 0, data);

  return (EXIT_SUCCESS);
}

// Number of IPv4 option to remove,
int
on_entry418_activate (GtkWidget *entry418, SPSData *data)
{
  ip4_opt_remove_entry (entry418, 9, &data->ipopt_tcp4_tr_remove, data);

  return (EXIT_SUCCESS);
}

// Remove selected IPv4 option.
int
on_button77_clicked (GtkButton *button77, SPSData *data)
{
  (void) button77;  // This statement suppresses compiler warning about unused parameter.

  ip4_option (1, 9, data->ipopt_tcp4_tr_remove, data->textview34, data->spinbutton11, data);

  return (EXIT_SUCCESS);
}

// TCP header (IPv4) for traceroute

// TCP source port (16 bits)
int
on_entry182_activate (GtkWidget *entry182, SPSData *data)
{
  tcp_sport_entry (entry182, 9, data);

  // Source port has been entered manually. Uncheck "Randomize" checkbutton.
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton30), FALSE);
  data->ran_tcp4_tr_sourceport = 0;

  return (EXIT_SUCCESS);
}

// Randomize TCP source port number.
int
on_checkbutton30_toggled (GtkButton *checkbutton30, SPSData *data)
{
  (void) checkbutton30;  // This statement suppresses compiler warning about unused parameter.

  tcp_ran_sport (&data->ran_tcp4_tr_sourceport, 9, data->entry182, data);

  return (EXIT_SUCCESS);
}

// TCP destination port (16 bits)
int
on_entry183_activate (GtkWidget *entry183, SPSData *data)
{
  tcp_dport_entry (entry183, 9, data);

  return (EXIT_SUCCESS);
}

// TCP sequence number (32 bits)
int
on_entry184_activate (GtkWidget *entry184, SPSData *data)
{
  tcp_seqnum_entry (entry184, 9, data);

  return (EXIT_SUCCESS);
}

// TCP acknowledgement number (32 bits)
int
on_entry185_activate (GtkWidget *entry185, SPSData *data)
{
  tcp_acknum_entry (entry185, 9, data);

  return (EXIT_SUCCESS);
}

// TCP reserved (4 bits)
int
on_entry186_activate (GtkWidget *entry186, SPSData *data)
{
  tcp_res_entry (entry186, 9, data);

  return (EXIT_SUCCESS);
}

// TCP data offset (4 bits)
int
on_entry187_activate (GtkWidget *entry187, SPSData *data)
{
  tcp_off_entry (entry187, 9, data);

  return (EXIT_SUCCESS);
}

// TCP FIN flag (1 bit)
int
on_entry188_activate (GtkWidget *entry188, SPSData *data)
{
  tcp_fin_entry (entry188, 9, data);

  return (EXIT_SUCCESS);
}

// TCP SYN flag (1 bit)
int
on_entry189_activate (GtkWidget *entry189, SPSData *data)
{
  tcp_syn_entry (entry189, 9, data);

  return (EXIT_SUCCESS);
}

// TCP RST flag (1 bit)
int
on_entry190_activate (GtkWidget *entry190, SPSData *data)
{
  tcp_rst_entry (entry190, 9, data);

  return (EXIT_SUCCESS);
}

// TCP PSH flag (1 bit)
int
on_entry191_activate (GtkWidget *entry191, SPSData *data)
{
  tcp_psh_entry (entry191, 9, data);

  return (EXIT_SUCCESS);
}

// TCP ACK flag (1 bit)
int
on_entry192_activate (GtkWidget *entry192, SPSData *data)
{
  tcp_ack_entry (entry192, 9, data);

  return (EXIT_SUCCESS);
}

// TCP URG flag (1 bit)
int
on_entry193_activate (GtkWidget *entry193, SPSData *data)
{
  tcp_urg_entry (entry193, 9, data);

  return (EXIT_SUCCESS);
}

// TCP ECE flag (1 bit)
int
on_entry194_activate (GtkWidget *entry194, SPSData *data)
{
  tcp_ece_entry (entry194, 9, data);

  return (EXIT_SUCCESS);
}

// TCP CWR flag (1 bit)
int
on_entry195_activate (GtkWidget *entry195, SPSData *data)
{
  tcp_cwr_entry (entry195, 9, data);

  return (EXIT_SUCCESS);
}

// TCP window size (16 bits)
int
on_entry196_activate (GtkWidget *entry196, SPSData *data)
{
  tcp_win_entry (entry196, 9, data);

  return (EXIT_SUCCESS);
}

// TCP checksum (16 bits)
int
on_entry197_activate (GtkWidget *entry197, SPSData *data)
{
  tcp_chksum_entry (entry197, 9, data);

  return (EXIT_SUCCESS);
}

// TCP urgent pointer (16 bits)
int
on_entry198_activate (GtkWidget *entry198, SPSData *data)
{
  tcp_urgptr_entry (entry198, 9, data);

  return (EXIT_SUCCESS);
}

// TCP options (IPv4) for traceroute

// Decimal option data entry
int
on_radiobutton51_toggled (GtkButton *radiobutton51, SPSData *data)
{
  (void) radiobutton51;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_tcpopt_tcp4_tr = 0;

  return (EXIT_SUCCESS);
}

// Hexadecimal option data entry
int
on_radiobutton52_toggled (GtkButton *radiobutton52, SPSData *data)
{
  (void) radiobutton52;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_tcpopt_tcp4_tr = 1;

  return (EXIT_SUCCESS);
}

// TCP option data (IPv4) for traceroute
int
on_entry419_activate (GtkWidget *entry419, SPSData *data)
{ 
  data_entry (entry419, &data->tcp_optlenbuf[9], MAX_TCPOPTLEN, data->tcp_optionsbuf[9], data->dec_hex_tcpopt_tcp4_tr, data->traceroute_window, data);

  return (EXIT_SUCCESS);
}

// Insert TCP option after another, as specified by user.
int
on_button78_clicked (GtkButton *button78, SPSData *data)
{
  (void) button78;  // This statement suppresses compiler warning about unused parameter.

  tcp4_option (0, 9, data->tcpopt_tcp4_tr_after, data->textview36, data);

  return (EXIT_SUCCESS);
}

// Number of option after which to insert new TCP option.
int
on_entry420_activate (GtkWidget *entry420, SPSData *data)
{
  tcp_opt_insert_after_entry (entry420, 9, &data->tcpopt_tcp4_tr_after, data);

  return (EXIT_SUCCESS);
}

// Append TCP option for IPv4 TCP packet for traceroute.
int
on_button79_clicked (GtkButton *button79, SPSData *data)
{
  (void) button79;  // This statement suppresses compiler warning about unused parameter.

  tcp4_option (2, 9, 0, data->textview36, data);

  return (EXIT_SUCCESS);
}

// View TCP options for IPv4 TCP for traceroute.
int
on_button80_clicked (GtkButton *button80, SPSData *data)
{
  (void) button80;  // This statement suppresses compiler warning about unused parameter.

  opt_view (9, 1, data);

  return (EXIT_SUCCESS);
}

// Number of TCP option to remove.
int
on_entry421_activate (GtkWidget *entry421, SPSData *data)
{
  tcp_opt_remove_entry (entry421, 9, &data->tcpopt_tcp4_tr_remove, data);

  return (EXIT_SUCCESS);
}

// Remove selected TCP option. (IPv4 TCP for Traceroute)
int
on_button81_clicked (GtkButton *button81, SPSData *data)
{
  (void) button81;  // This statement suppresses compiler warning about unused parameter.

  tcp4_option (1, 9, data->tcpopt_tcp4_tr_remove, data->textview36, data);

  return (EXIT_SUCCESS);
}

// ASCII data entry
int
on_radiobutton29_toggled (GtkButton *radiobutton29, SPSData *data)
{
  (void) radiobutton29;  // This statement suppresses compiler warning about unused parameter.

  data->ascii_hex_tcp4_tr = 0;

  return (EXIT_SUCCESS);
}

// Hexadecimal data entry
int
on_radiobutton30_toggled (GtkButton *radiobutton30, SPSData *data)
{
  (void) radiobutton30;  // This statement suppresses compiler warning about unused parameter.

  data->ascii_hex_tcp4_tr = 1;

  return (EXIT_SUCCESS);
}

// TCP data from keyboard (IPv4 traceroute)
int
on_entry199_activate (GtkWidget *entry199, SPSData *data)
{
  key_data (entry199, 9, data->ascii_hex_tcp4_tr, data);

  if (data->nframes[9] > 1) {
    sprintf (data->warning_text, "Packet will be fragmented to accomodate TCP data.");
    data->parent = data->traceroute_window;
    report_warning (data);
  }

  return (EXIT_SUCCESS);
}

// TCP data from file (IPv4 traceroute)
int
on_button29_clicked (GtkButton *button29, SPSData *data)
{
  (void) button29;  // This statement suppresses compiler warning about unused parameter.

  file_payload_data (data->entry199, 9, data);

  if (data->nframes[9] > 1) {
    sprintf (data->warning_text, "Packet will be fragmented to accomodate TCP data.");
    data->parent = data->traceroute_window;
    report_warning (data);
  }

  return (EXIT_SUCCESS);
}

// TCP page (IPv6) for traceroute

// Destination link-layer (MAC) address (48 bits)
int
on_entry247_activate (GtkWidget *entry247, SPSData *data)
{
  mac_entry (entry247, data->ethhdr[12].dst_mac, 12, data);

  return (EXIT_SUCCESS);
}

// Source link-layer (MAC) address (48 bits)
int
on_entry248_activate (GtkWidget *entry248, SPSData *data)
{
  mac_entry (entry248, data->ethhdr[12].src_mac, 12, data);

  return (EXIT_SUCCESS);
}

// This host's interface name to be converted to link-layer (MAC) address and find MTU.
int
on_entry249_activate (GtkWidget *entry249, SPSData *data)
{
  // Check for valid source interface name, check MTU, and update source MAC address.
  ifname_entry (entry249, data->ifname[12], data->ethhdr[12].src_mac, data->entry248, 12, data);

  // Update MTU spinbutton.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton14), data->ifmtu[12]);

  return (EXIT_SUCCESS);
}

// Maximum transmission unit (MTU)
int
on_spinbutton14_value_changed (GtkWidget *spinbutton14, SPSData *data)
{
  data->ifmtu[12] = (int) gtk_spin_button_get_value (GTK_SPIN_BUTTON (spinbutton14));

  // Check if MTU is sufficiently large to accomodate packet. If not, revise.
  check_mtu (12, data);

  // Update spinbutton value.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (spinbutton14), data->ifmtu[12]);

  // Update ethernet frames.
  create_ip6_frame (12, data);
  create_6to4_frame (15, data);

  return (EXIT_SUCCESS);
}

// Ethernet type code (16 bits)
// http://www.iana.org/assignments/ethernet-numbers
int
on_entry250_activate (GtkWidget *entry250, SPSData *data)
{
  ethtype_entry (entry250, 12, data);

  return (EXIT_SUCCESS);
}

// IP version (4 bits)
int
on_entry251_activate (GtkWidget *entry251, SPSData *data)
{
  ip6_ver_entry (entry251, 12, data);

  return (EXIT_SUCCESS);
}

// Traffic class (8 bits)
int
on_entry252_activate (GtkWidget *entry252, SPSData *data)
{
  ip6_tc_entry (entry252, 12, data);

  return (EXIT_SUCCESS);
}

// Flow label (20 bits)
int
on_entry253_activate (GtkWidget *entry253, SPSData *data)
{
  ip6_fl_entry (entry253, 12, data);

  return (EXIT_SUCCESS);
}

// Payload length (16 bits)
int
on_entry254_activate (GtkWidget *entry254, SPSData *data)
{
  ip6_plen_entry (entry254, 12, data);

  return (EXIT_SUCCESS);
}

// Next header (8 bits)
int
on_entry255_activate (GtkWidget *entry255, SPSData *data)
{
  ip6_nxt_entry (entry255, 12, data);

  return (EXIT_SUCCESS);
}

// Hop limit (8 bits)
int
on_entry256_activate (GtkWidget *entry256, SPSData *data)
{
  ip6_hops_entry (entry256, 12, data);

  return (EXIT_SUCCESS);
}

// Source IP address (128 bits)
int
on_entry257_activate (GtkWidget *entry257, SPSData *data)
{
  ip6_sip_entry (entry257, 12, data);

  return (EXIT_SUCCESS);
}

// Destination IP address (128 bits)
int
on_entry258_activate (GtkWidget *entry258, SPSData *data)
{
  ip6_dip_entry (entry258, 12, data);

  return (EXIT_SUCCESS);
}

// Hop-by-Hop extension header
int
on_button101_clicked (GtkWidget *button101, SPSData *data)
{
  (void) button101;  // This statement suppresses compiler warning about unused parameter.

  data->exthdr_type = 12;
  hop_win (data);

  return (EXIT_SUCCESS);
}

// Destination extension header
int
on_button113_clicked (GtkWidget *button113, SPSData *data)
{
  (void) button113;  // This statement suppresses compiler warning about unused parameter.

  data->exthdr_type = 12;
  dst_win (data);

  return (EXIT_SUCCESS);
}

// Routing extension header
int
on_button135_clicked (GtkWidget *button135, SPSData *data)
{
  (void) button135;  // This statement suppresses compiler warning about unused parameter.

  data->exthdr_type = 12;
  route_win (data);

  return (EXIT_SUCCESS);
}

// Authentication extension header
int
on_button119_clicked (GtkWidget *button119, SPSData *data)
{
  (void) button119;  // This statement suppresses compiler warning about unused parameter.

  data->exthdr_type = 12;
  auth_win (data);

  return (EXIT_SUCCESS);
}

// ESP extension header
int
on_button129_clicked (GtkWidget *button129, SPSData *data)
{
  (void) button129;  // This statement suppresses compiler warning about unused parameter.

  data->exthdr_type = 12;
  esp_win (data);

  return (EXIT_SUCCESS);
}

// TCP header (IPv6) for Traceroute

// TCP source port (16 bits)
int
on_entry259_activate (GtkWidget *entry259, SPSData *data)
{
  tcp_sport_entry (entry259, 12, data);

  // Source port has been entered manually. Uncheck "Randomize" checkbutton.
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton37), FALSE);
  data->ran_tcp6_tr_sourceport = 0;

  return (EXIT_SUCCESS);
}

// Randomize TCP source port number.
int
on_checkbutton37_toggled (GtkButton *checkbutton37, SPSData *data)
{
  (void) checkbutton37;  // This statement suppresses compiler warning about unused parameter.

  tcp_ran_sport (&data->ran_tcp6_tr_sourceport, 12, data->entry259, data);

  return (EXIT_SUCCESS);
}

// TCP destination port (16 bits)
int
on_entry260_activate (GtkWidget *entry260, SPSData *data)
{
  tcp_dport_entry (entry260, 12, data);

  return (EXIT_SUCCESS);
}

// TCP sequence number (32 bits)
int
on_entry261_activate (GtkWidget *entry261, SPSData *data)
{
  tcp_seqnum_entry (entry261, 12, data);

  return (EXIT_SUCCESS);
}

// TCP acknowledgement number (32 bits)
int
on_entry262_activate (GtkWidget *entry262, SPSData *data)
{
  tcp_acknum_entry (entry262, 12, data);

  return (EXIT_SUCCESS);
}

// TCP reserved (4 bits)
int
on_entry263_activate (GtkWidget *entry263, SPSData *data)
{
  tcp_res_entry (entry263, 12, data);

  return (EXIT_SUCCESS);
}

// TCP data offset (4 bits)
int
on_entry264_activate (GtkWidget *entry264, SPSData *data)
{
  tcp_off_entry (entry264, 12, data);

  return (EXIT_SUCCESS);
}

// TCP FIN flag (1 bit)
int
on_entry265_activate (GtkWidget *entry265, SPSData *data)
{
  tcp_fin_entry (entry265, 12, data);

  return (EXIT_SUCCESS);
}

// TCP SYN flag (1 bit)
int
on_entry266_activate (GtkWidget *entry266, SPSData *data)
{
  tcp_syn_entry (entry266, 12, data);

  return (EXIT_SUCCESS);
}

// TCP RST flag (1 bit)
int
on_entry267_activate (GtkWidget *entry267, SPSData *data)
{
  tcp_rst_entry (entry267, 12, data);

  return (EXIT_SUCCESS);
}

// TCP PSH flag (1 bit)
int
on_entry268_activate (GtkWidget *entry268, SPSData *data)
{
  tcp_psh_entry (entry268, 12, data);

  return (EXIT_SUCCESS);
}

// TCP ACK flag (1 bit)
int
on_entry269_activate (GtkWidget *entry269, SPSData *data)
{
  tcp_ack_entry (entry269, 12, data);

  return (EXIT_SUCCESS);
}

// TCP URG flag (1 bit)
int
on_entry270_activate (GtkWidget *entry270, SPSData *data)
{
  tcp_urg_entry (entry270, 12, data);

  return (EXIT_SUCCESS);
}

// TCP ECE flag (1 bit)
int
on_entry271_activate (GtkWidget *entry271, SPSData *data)
{
  tcp_ece_entry (entry271, 12, data);

  return (EXIT_SUCCESS);
}

// TCP CWR flag (1 bit)
int
on_entry272_activate (GtkWidget *entry272, SPSData *data)
{
  tcp_cwr_entry (entry272, 12, data);

  return (EXIT_SUCCESS);
}

// TCP window size (16 bits)
int
on_entry273_activate (GtkWidget *entry273, SPSData *data)
{
  tcp_win_entry (entry273, 12, data);

  return (EXIT_SUCCESS);
}

// TCP checksum (16 bits)
int
on_entry274_activate (GtkWidget *entry274, SPSData *data)
{
  tcp_chksum_entry (entry274, 12, data);

  return (EXIT_SUCCESS);
}

// TCP urgent pointer (16 bits)
int
on_entry275_activate (GtkWidget *entry275, SPSData *data)
{
  tcp_urgptr_entry (entry275, 12, data);

  return (EXIT_SUCCESS);
}

// TCP options (IPv6) for traceroute

// Decimal option data entry
int
on_radiobutton53_toggled (GtkButton *radiobutton53, SPSData *data)
{
  (void) radiobutton53;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_tcpopt_tcp6_tr = 0;

  return (EXIT_SUCCESS);
}

// Hexadecimal option data entry
int
on_radiobutton54_toggled (GtkButton *radiobutton54, SPSData *data)
{
  (void) radiobutton54;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_tcpopt_tcp6_tr = 1;

  return (EXIT_SUCCESS);
}

// TCP option data (IPv6) for traceroute
int
on_entry422_activate (GtkWidget *entry422, SPSData *data)
{
  data_entry (entry422, &data->tcp_optlenbuf[12], MAX_TCPOPTLEN, data->tcp_optionsbuf[12], data->dec_hex_tcpopt_tcp6_tr, data->traceroute_window, data);

  return (EXIT_SUCCESS);
}

// Insert TCP option after another, as specified by user.
int
on_button82_clicked (GtkButton *button82, SPSData *data)
{
  (void) button82;  // This statement suppresses compiler warning about unused parameter.

  tcp6_option (0, 12, data->tcpopt_tcp6_tr_after, data->textview38, data);

  return (EXIT_SUCCESS);
}

// Number of option after which to insert new TCP option.
int
on_entry423_activate (GtkWidget *entry423, SPSData *data)
{
  tcp_opt_insert_after_entry (entry423, 12, &data->tcpopt_tcp6_tr_after, data);

  return (EXIT_SUCCESS);
}

// Append TCP option for IPv6 TCP packet for traceroute.
int
on_button83_clicked (GtkButton *button83, SPSData *data)
{
  (void) button83;  // This statement suppresses compiler warning about unused parameter.

  tcp6_option (2, 12, 0, data->textview38, data);

  return (EXIT_SUCCESS);
}

// View TCP options for IPv6 TCP for traceroute.
int
on_button84_clicked (GtkButton *button84, SPSData *data)
{
  (void) button84;  // This statement suppresses compiler warning about unused parameter.

  opt_view (12, 1, data);

  return (EXIT_SUCCESS);
}

// Number of TCP option to remove.
int
on_entry424_activate (GtkWidget *entry424, SPSData *data)
{
  tcp_opt_remove_entry (entry424, 12, &data->tcpopt_tcp6_tr_remove, data);

  return (EXIT_SUCCESS);
}

// Remove selected TCP option. (IPv6 TCP for traceroute)
int
on_button85_clicked (GtkButton *button85, SPSData *data)
{
  (void) button85;  // This statement suppresses compiler warning about unused parameter.

  tcp6_option (1, 12, data->tcpopt_tcp6_tr_remove, data->textview38, data);

  return (EXIT_SUCCESS);
}

// TCP data (IPv6) for traceroute

// ASCII data entry
int
on_radiobutton35_toggled (GtkButton *radiobutton35, SPSData *data)
{
  (void) radiobutton35;  // This statement suppresses compiler warning about unused parameter.

  data->ascii_hex_tcp6_tr = 0;

  return (EXIT_SUCCESS);
}

// Hexadecimal data entry
int
on_radiobutton36_toggled (GtkButton *radiobutton36, SPSData *data)
{
  (void) radiobutton36;  // This statement suppresses compiler warning about unused parameter.

  data->ascii_hex_tcp6_tr = 1;

  return (EXIT_SUCCESS);
}

// TCP data from keyboard (IPv6 traceroute)
int
on_entry276_activate (GtkWidget *entry276, SPSData *data)
{
  key_data (entry276, 12, data->ascii_hex_tcp6_tr, data);

  if (data->nframes[12] > 1) {
    sprintf (data->warning_text, "Packet will be fragmented to accomodate TCP data.");
    data->parent = data->traceroute_window;
    report_warning (data);
  }

  // Update ethernet frame and extension header editing window widgets, if visible.
  ip6data_update (12, data);

  return (EXIT_SUCCESS);
}

// TCP data from file (IPv6 traceroute)
int
on_button38_clicked (GtkButton *button38, SPSData *data)
{
  (void) button38;  // This statement suppresses compiler warning about unused parameter.

  file_payload_data (data->entry276, 12, data);

  if (data->nframes[12] > 1) {
    sprintf (data->warning_text, "Packet will be fragmented to accomodate TCP data.");
    data->parent = data->traceroute_window;
    report_warning (data);
  }

  // Update ethernet frame and extension header editing window widgets, if visible.
  ip6data_update (12, data);

  return (EXIT_SUCCESS);
}

// ICMP page (IPv4) for traceroute

// Specify ethernet header
int
on_checkbutton31_toggled (GtkButton *checkbutton31, SPSData *data)
{
  (void) checkbutton31;  // This statement suppresses compiler warning about unused parameter.

  if (data->specify_ether[10]) {
    data->specify_ether[10] = 0;
  } else {
    data->specify_ether[10] = 1;
  }

  return (EXIT_SUCCESS);
}

// Destination link-layer (MAC) address (48 bits)
int
on_entry200_activate (GtkWidget *entry200, SPSData *data)
{
  mac_entry (entry200, data->ethhdr[10].dst_mac, 10, data);

  return (EXIT_SUCCESS);
}

// Source link-layer (MAC) address (48 bits)
int
on_entry201_activate (GtkWidget *entry201, SPSData *data)
{
  mac_entry (entry201, data->ethhdr[10].src_mac, 10, data);

  return (EXIT_SUCCESS);
}

// This host's interface name to be converted to link-layer (MAC) address and find MTU.
int
on_entry202_activate (GtkWidget *entry202, SPSData *data)
{
  // Check for valid source interface name, check MTU, and update source MAC address.
  ifname_entry (entry202, data->ifname[10], data->ethhdr[10].src_mac, data->entry201, 10, data);

  // Update MTU spinbutton.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton12), data->ifmtu[10]);

  return (EXIT_SUCCESS);
}

// Maximum transmission unit (MTU)
int
on_spinbutton12_value_changed (GtkWidget *spinbutton12, SPSData *data)
{
  data->ifmtu[10] = (int) gtk_spin_button_get_value (GTK_SPIN_BUTTON (spinbutton12));

  // Check if MTU is sufficiently large to accomodate packet. If not, revise.
  check_mtu (10, data);

  // Update spinbutton value.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (spinbutton12), data->ifmtu[10]);

  // Update ethernet frames.
  create_ip4_frame (10, data);

  return (EXIT_SUCCESS);
}

// Ethernet type code (16 bits)
// http://www.iana.org/assignments/ethernet-numbers
int
on_entry203_activate (GtkWidget *entry203, SPSData *data)
{
  ethtype_entry (entry203, 10, data);

  return (EXIT_SUCCESS);
}

// IP header length (4 bits)
int
on_entry204_activate (GtkWidget *entry204, SPSData *data)
{
  ip4_hdrlen_entry (entry204, 10, data);

  return (EXIT_SUCCESS);
}

// IP version (4 bits)
int
on_entry205_activate (GtkWidget *entry205, SPSData *data)
{
  ip4_ver_entry (entry205, 10, data);

  return (EXIT_SUCCESS);
}

// Type of service (8 bits)
int
on_entry206_activate (GtkWidget *entry206, SPSData *data)
{
  ip4_tos_entry (entry206, 10, data);

  return (EXIT_SUCCESS);
}

// Total length of datagram (16 bits)
int
on_entry207_activate (GtkWidget *entry207, SPSData *data)
{
  ip4_tld_entry (entry207, 10, data);

  return (EXIT_SUCCESS);
}

// ID sequence number (16 bits)
int
on_entry208_activate (GtkWidget *entry208, SPSData *data)
{
  ip4_seq_entry (entry208, 10, data);

  return (EXIT_SUCCESS);
}

// Zero (1 bit)
int
on_entry209_activate (GtkWidget *entry209, SPSData *data)
{
  ip4_zero_entry (entry209, data->entry210, data->entry211, data->entry212, 10, data);

  return (EXIT_SUCCESS);
}

// Do not fragment flag (1 bit)
int
on_entry210_activate (GtkWidget *entry210, SPSData *data)
{
  ip4_dnf_entry (data->entry209, entry210, data->entry211, data->entry212, 10, data);

  return (EXIT_SUCCESS);
}

// More fragments following flag (1 bit)
int
on_entry211_activate (GtkWidget *entry211, SPSData *data)
{
  ip4_mff_entry (data->entry209, data->entry210, entry211, data->entry212, 10, data);

  return (EXIT_SUCCESS);
}

// Fragmentation offset (13 bits)
int
on_entry212_activate (GtkWidget *entry212, SPSData *data)
{
  ip4_fo_entry (data->entry209, data->entry210, data->entry211, entry212, 10, data);

  return (EXIT_SUCCESS);
}

// Time-to-Live (8 bits)
int
on_entry213_activate (GtkWidget *entry213, SPSData *data)
{
  ip4_ttl_entry (entry213, 10, data);

  return (EXIT_SUCCESS);
}

// Transport layer protocol (8 bits)
int
on_entry214_activate (GtkWidget *entry214, SPSData *data)
{
  ip4_tlp_entry (entry214, 10, data);

  return (EXIT_SUCCESS);
}

// Source IPv4 address (32 bits)
int
on_entry215_activate (GtkWidget *entry215, SPSData *data)
{
  ip4_sip_entry (entry215, 10, data);

  return (EXIT_SUCCESS);
}

// Destination IPv4 address (32 bits)
int
on_entry216_activate (GtkWidget *entry216, SPSData *data)
{
  ip4_dip_entry (entry216, 10, data);

  return (EXIT_SUCCESS);
}

// IPv4 checksum (16 bits)
int
on_entry217_activate (GtkWidget *entry217, SPSData *data)
{
  ip4_chksum_entry (entry217, 10, data);

  return (EXIT_SUCCESS);
}

// IP options for IPv4 ICMP for Traceroute

// Decimal option data entry
int
on_radiobutton55_toggled (GtkButton *radiobutton55, SPSData *data)
{
  (void) radiobutton55;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_ipopt_icmp4_tr = 0;

  return (EXIT_SUCCESS);
}

// Hexadecimal option data entry
int
on_radiobutton56_toggled (GtkButton *radiobutton56, SPSData *data)
{
  (void) radiobutton56;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_ipopt_icmp4_tr = 1;

  return (EXIT_SUCCESS);
}

// IPv4 option data
int
on_entry425_activate (GtkWidget *entry425, SPSData *data)
{
  data_entry (entry425, &data->ip_optlenbuf[10], MAX_IP4OPTLEN, data->ip_optionsbuf[10], data->dec_hex_ipopt_icmp4_tr, data->traceroute_window, data);

  return (EXIT_SUCCESS);
}

// Insert IPv4 option after another, as specified by user.
int
on_button86_clicked (GtkButton *button86, SPSData *data)
{
  (void) button86;  // This statement suppresses compiler warning about unused parameter.

  ip4_option (0, 10, data->ipopt_icmp4_tr_after, data->textview40, data->spinbutton12, data);

  return (EXIT_SUCCESS);
}

// Number of option after which to insert new option.
int
on_entry426_activate (GtkWidget *entry426, SPSData *data)
{
  ip4_opt_insert_after_entry (entry426, 10, &data->ipopt_icmp4_tr_after, data);

  return (EXIT_SUCCESS);
}

// Append IP option for IPv4 ICMP packet.
int
on_button87_clicked (GtkButton *button87, SPSData *data)
{
  (void) button87;  // This statement suppresses compiler warning about unused parameter.

  ip4_option (2, 10, 0, data->textview40, data->spinbutton12, data);

  return (EXIT_SUCCESS);
}

// View IPv4 header options for ICMP for traceroute.
int
on_button88_clicked (GtkButton *button88, SPSData *data)
{
  (void) button88;  // This statement suppresses compiler warning about unused parameter.

  opt_view (10, 0, data);

  return (EXIT_SUCCESS);
}

// Number of IPv4 option to remove.
int
on_entry427_activate (GtkWidget *entry427, SPSData *data)
{
  ip4_opt_remove_entry (entry427, 10, &data->ipopt_icmp4_tr_remove, data);

  return (EXIT_SUCCESS);
}

// Remove selected IPv4 option.
int
on_button89_clicked (GtkButton *button89, SPSData *data)
{
  (void) button89;  // This statement suppresses compiler warning about unused parameter.

  ip4_option (1, 10, data->ipopt_icmp4_tr_remove, data->textview40, data->spinbutton12, data);

  return (EXIT_SUCCESS);
}

// ICMP header (IPv4) for trcaeroute

// Message Type (8 bits)
int
on_entry218_activate (GtkWidget *entry218, SPSData *data)
{
  icmp_mt_entry (entry218, 10, data);

  return (EXIT_SUCCESS);
}

// Message Code (8 bits)
int
on_entry219_activate (GtkWidget *entry219, SPSData *data)
{
  icmp_mc_entry (entry219, 10, data);

  return (EXIT_SUCCESS);
}

// ICMP checksum (16 bits)
int
on_entry220_activate (GtkWidget *entry220, SPSData *data)
{
  icmp_chksum_entry (entry220, 10, data);

  return (EXIT_SUCCESS);
}

// ID (16 bits)
int
on_entry221_activate (GtkWidget *entry221, SPSData *data)
{
  icmp_id_entry (entry221, 10, data);

  return (EXIT_SUCCESS);
}

// Sequence number (16 bits)
int
on_entry222_activate (GtkWidget *entry222, SPSData *data)
{
  icmp_seq_entry (entry222, 10, data);

  return (EXIT_SUCCESS);
}

// ASCII data entry
int
on_radiobutton31_toggled (GtkButton *radiobutton31, SPSData *data)
{
  (void) radiobutton31;  // This statement suppresses compiler warning about unused parameter.

  data->ascii_hex_icmp4_tr = 0;

  return (EXIT_SUCCESS);
}

// Hexadecimal data entry
int
on_radiobutton32_toggled (GtkButton *radiobutton32, SPSData *data)
{
  (void) radiobutton32;  // This statement suppresses compiler warning about unused parameter.

  data->ascii_hex_icmp4_tr = 1;

  return (EXIT_SUCCESS);
}

// ICMP data from keyboard (IPv4 traceroute)
int
on_entry223_activate (GtkWidget *entry223, SPSData *data)
{
  key_data (entry223, 10, data->ascii_hex_icmp4_tr, data);

  if (data->nframes[10] > 1) {
    sprintf (data->warning_text, "Packet will be fragmented to accomodate ICMP data.");
    data->parent = data->traceroute_window;
    report_warning (data);
  }

  return (EXIT_SUCCESS);
}

// ICMP data from file (IPv4 traceroute)
int
on_button32_clicked (GtkButton *button32, SPSData *data)
{
  (void) button32;  // This statement suppresses compiler warning about unused parameter.

  file_payload_data (data->entry223, 10, data);

  if (data->nframes[10] > 1) {
    sprintf (data->warning_text, "Packet will be fragmented to accomodate ICMP data.");
    data->parent = data->traceroute_window;
    report_warning (data);
  }

  return (EXIT_SUCCESS);
}

// ICMP page (IPv6) for traceroute

// Destination link-layer (MAC) address (48 bits)
int
on_entry277_activate (GtkWidget *entry277, SPSData *data)
{
  mac_entry (entry277, data->ethhdr[13].dst_mac, 13, data);

  return (EXIT_SUCCESS);
}

// Source link-layer (MAC) address (48 bits)
int
on_entry278_activate (GtkWidget *entry278, SPSData *data)
{
  mac_entry (entry278, data->ethhdr[13].src_mac, 13, data);

  return (EXIT_SUCCESS);
}

// This host's interface name to be converted to link-layer (MAC) address and find MTU.
int
on_entry279_activate (GtkWidget *entry279, SPSData *data)
{
  // Check for valid source interface name, check MTU, and update source MAC address.
  ifname_entry (entry279, data->ifname[13], data->ethhdr[13].src_mac, data->entry278, 13, data);

  // Update MTU spinbutton.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton15), data->ifmtu[13]);

  return (EXIT_SUCCESS);
}

// Maximum transmission unit (MTU)
int
on_spinbutton15_value_changed (GtkWidget *spinbutton15, SPSData *data)
{
  data->ifmtu[13] = (int) gtk_spin_button_get_value (GTK_SPIN_BUTTON (spinbutton15));

  // Check if MTU is sufficiently large to accomodate packet. If not, revise.
  check_mtu (13, data);

  // Update spinbutton value.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (spinbutton15), data->ifmtu[13]);

  // Update ethernet frames.
  create_ip6_frame (13, data);
  create_6to4_frame (16, data);

  return (EXIT_SUCCESS);
}

// Ethernet type code (16 bits)
// http://www.iana.org/assignments/ethernet-numbers
int
on_entry280_activate (GtkWidget *entry280, SPSData *data)
{
  ethtype_entry (entry280, 13, data);

  return (EXIT_SUCCESS);
}

// IP version (4 bits)
int
on_entry281_activate (GtkWidget *entry281, SPSData *data)
{
  ip6_ver_entry (entry281, 13, data);

  return (EXIT_SUCCESS);
}

// Traffic class (8 bits)
int
on_entry282_activate (GtkWidget *entry282, SPSData *data)
{
  ip6_tc_entry (entry282, 13, data);

  return (EXIT_SUCCESS);
}

// Flow label (20 bits)
int
on_entry283_activate (GtkWidget *entry283, SPSData *data)
{
  ip6_fl_entry (entry283, 13, data);

  return (EXIT_SUCCESS);
}

// Payload length (16 bits)
int
on_entry284_activate (GtkWidget *entry284, SPSData *data)
{
  ip6_plen_entry (entry284, 13, data);

  return (EXIT_SUCCESS);
}

// Next header (8 bits)
int
on_entry285_activate (GtkWidget *entry285, SPSData *data)
{
  ip6_nxt_entry (entry285, 13, data);

  return (EXIT_SUCCESS);
}

// Hop limit (8 bits)
int
on_entry286_activate (GtkWidget *entry286, SPSData *data)
{
  ip6_hops_entry (entry286, 13, data);

  return (EXIT_SUCCESS);
}

// Source IP address (128 bits)
int
on_entry287_activate (GtkWidget *entry287, SPSData *data)
{
  ip6_sip_entry (entry287, 13, data);

  return (EXIT_SUCCESS);
}

// Destination IP address (128 bits)
int
on_entry288_activate (GtkWidget *entry288, SPSData *data)
{
  ip6_dip_entry (entry288, 13, data);

  return (EXIT_SUCCESS);
}

// Hop-by-Hop extension header
int
on_button102_clicked (GtkWidget *button102, SPSData *data)
{
  (void) button102;  // This statement suppresses compiler warning about unused parameter.

  data->exthdr_type = 13;
  hop_win (data);

  return (EXIT_SUCCESS);
}

// Destination extension header
int
on_button114_clicked (GtkWidget *button114, SPSData *data)
{
  (void) button114;  // This statement suppresses compiler warning about unused parameter.

  data->exthdr_type = 13;
  dst_win (data);

  return (EXIT_SUCCESS);
}

// Routing extension header
int
on_button136_clicked (GtkWidget *button136, SPSData *data)
{
  (void) button136;  // This statement suppresses compiler warning about unused parameter.

  data->exthdr_type = 13;
  route_win (data);

  return (EXIT_SUCCESS);
}

// Authentication extension header
int
on_button120_clicked (GtkWidget *button120, SPSData *data)
{
  (void) button120;  // This statement suppresses compiler warning about unused parameter.

  data->exthdr_type = 13;
  auth_win (data);

  return (EXIT_SUCCESS);
}

// ESP extension header
int
on_button130_clicked (GtkWidget *button130, SPSData *data)
{
  (void) button130;  // This statement suppresses compiler warning about unused parameter.

  data->exthdr_type = 13;
  esp_win (data);

  return (EXIT_SUCCESS);
}

// ICMP header (IPv6) for traceroute

// Message Type (8 bits)
int
on_entry289_activate (GtkWidget *entry289, SPSData *data)
{
  icmp_mt_entry (entry289, 13, data);

  return (EXIT_SUCCESS);
}

// Message Code (8 bits)
int
on_entry290_activate (GtkWidget *entry290, SPSData *data)
{
  icmp_mc_entry (entry290, 13, data);

  return (EXIT_SUCCESS);
}

// ICMP checksum (16 bits)
int
on_entry291_activate (GtkWidget *entry291, SPSData *data)
{
  icmp_chksum_entry (entry291, 13, data);

  return (EXIT_SUCCESS);
}

// ID (16 bits)
int
on_entry292_activate (GtkWidget *entry292, SPSData *data)
{
  icmp_id_entry (entry292, 13, data);

  return (EXIT_SUCCESS);
}

// Sequence number (16 bits)
int
on_entry293_activate (GtkWidget *entry293, SPSData *data)
{
  icmp_seq_entry (entry293, 13, data);

  return (EXIT_SUCCESS);
}

// ASCII data entry
int
on_radiobutton37_toggled (GtkButton *radiobutton37, SPSData *data)
{
  (void) radiobutton37;  // This statement suppresses compiler warning about unused parameter.

  data->ascii_hex_icmp6_tr = 0;

  return (EXIT_SUCCESS);
}

// Hexadecimal data entry
int
on_radiobutton38_toggled (GtkButton *radiobutton38, SPSData *data)
{
  (void) radiobutton38;  // This statement suppresses compiler warning about unused parameter.

  data->ascii_hex_icmp6_tr = 1;

  return (EXIT_SUCCESS);
}

// ICMP data from keyboard (IPv6 traceroute)
int
on_entry294_activate (GtkWidget *entry294, SPSData *data)
{
  key_data (entry294, 13, data->ascii_hex_icmp6_tr, data);

  if (data->nframes[13] > 1) {
    sprintf (data->warning_text, "Packet will be fragmented to accomodate ICMP data.");
    data->parent = data->traceroute_window;
    report_warning (data);
  }

  // Update ethernet frame and extension header editing window widgets, if visible.
  ip6data_update (13, data);

  return (EXIT_SUCCESS);
}

// ICMP data from file (IPv6 traceroute)
int
on_button41_clicked (GtkButton *button41, SPSData *data)
{
  (void) button41;  // This statement suppresses compiler warning about unused parameter.

  file_payload_data (data->entry294, 13, data);

  if (data->nframes[13] > 1) {
    sprintf (data->warning_text, "Packet will be fragmented to accomodate ICMP data.");
    data->parent = data->traceroute_window;
    report_warning (data);
  }

  // Update ethernet frame and extension header editing window widgets, if visible.
  ip6data_update (13, data);

  return (EXIT_SUCCESS);
}

// UDP page (IPv4) for traceroute

// Specify ethernet header
int
on_checkbutton33_toggled (GtkButton *checkbutton33, SPSData *data)
{
  (void) checkbutton33;  // This statement suppresses compiler warning about unused parameter.

  if (data->specify_ether[11]) {
    data->specify_ether[11] = 0;
  } else {
    data->specify_ether[11] = 1;
  }

  return (EXIT_SUCCESS);
}

// Destination link-layer (MAC) address (48 bits)
int
on_entry224_activate (GtkWidget *entry224, SPSData *data)
{
  mac_entry (entry224, data->ethhdr[11].dst_mac, 11, data);

  return (EXIT_SUCCESS);
}

// Source link-layer (MAC) address (48 bits)
int
on_entry225_activate (GtkWidget *entry225, SPSData *data)
{
  mac_entry (entry225, data->ethhdr[11].src_mac, 11, data);

  return (EXIT_SUCCESS);
}


// This host's interface name to be converted to link-layer (MAC) address and find MTU.
int
on_entry226_activate (GtkWidget *entry226, SPSData *data)
{
  // Check for valid source interface name, check MTU, and update source MAC address.
  ifname_entry (entry226, data->ifname[11], data->ethhdr[11].src_mac, data->entry225, 11, data);

  // Update MTU spinbutton.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton13), data->ifmtu[11]);

  return (EXIT_SUCCESS);
}

// Maximum transmission unit (MTU)
int
on_spinbutton13_value_changed (GtkWidget *spinbutton13, SPSData *data)
{
  data->ifmtu[11] = (int) gtk_spin_button_get_value (GTK_SPIN_BUTTON (spinbutton13));

  // Check if MTU is sufficiently large to accomodate packet. If not, revise.
  check_mtu (11, data);

  // Update spinbutton value.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (spinbutton13), data->ifmtu[11]);

  // Update ethernet frames.
  create_ip4_frame (11, data);

  return (EXIT_SUCCESS);
}

// Ethernet type code (16 bits)
// http://www.iana.org/assignments/ethernet-numbers
int
on_entry227_activate (GtkWidget *entry227, SPSData *data)
{
  ethtype_entry (entry227, 11, data);

  return (EXIT_SUCCESS);
}

// IP header length (4 bits)
int
on_entry228_activate (GtkWidget *entry228, SPSData *data)
{
  ip4_hdrlen_entry (entry228, 11, data);

  return (EXIT_SUCCESS);
}

// IP version (4 bits)
int
on_entry229_activate (GtkWidget *entry229, SPSData *data)
{
  ip4_ver_entry (entry229, 11, data);

  return (EXIT_SUCCESS);
}

// Type of service (8 bits)
int
on_entry230_activate (GtkWidget *entry230, SPSData *data)
{
  ip4_tos_entry (entry230, 11, data);

  return (EXIT_SUCCESS);
}

// Total length of datagram (16 bits)
int
on_entry231_activate (GtkWidget *entry231, SPSData *data)
{
  ip4_tld_entry (entry231, 11, data);

  return (EXIT_SUCCESS);
}

// ID sequence number (16 bits)
int
on_entry232_activate (GtkWidget *entry232, SPSData *data)
{
  ip4_seq_entry (entry232, 11, data);

  return (EXIT_SUCCESS);
}

// Zero (1 bit)
int
on_entry233_activate (GtkWidget *entry233, SPSData *data)
{
  ip4_zero_entry (entry233, data->entry234, data->entry235, data->entry236, 11, data);

  return (EXIT_SUCCESS);
}

// Do not fragment flag (1 bit)
int
on_entry234_activate (GtkWidget *entry234, SPSData *data)
{
  ip4_dnf_entry (data->entry233, entry234, data->entry235, data->entry236, 11, data);

  return (EXIT_SUCCESS);
}

// More fragments following flag (1 bit)
int
on_entry235_activate (GtkWidget *entry235, SPSData *data)
{
  ip4_mff_entry (data->entry233, data->entry234, entry235, data->entry236, 11, data);

  return (EXIT_SUCCESS);
}

// Fragmentation offset (13 bits)
int
on_entry236_activate (GtkWidget *entry236, SPSData *data)
{
  ip4_fo_entry (data->entry233, data->entry234, data->entry235, entry236, 11, data);

  return (EXIT_SUCCESS);
}

// Time-to-Live (8 bits)
int
on_entry237_activate (GtkWidget *entry237, SPSData *data)
{
  ip4_ttl_entry (entry237, 11, data);

  return (EXIT_SUCCESS);
}

// Transport layer protocol (8 bits)
int
on_entry238_activate (GtkWidget *entry238, SPSData *data)
{
  ip4_tlp_entry (entry238, 11, data);

  return (EXIT_SUCCESS);
}

// Source IPv4 address (32 bits)
int
on_entry239_activate (GtkWidget *entry239, SPSData *data)
{
  ip4_sip_entry (entry239, 11, data);

  return (EXIT_SUCCESS);
}

// Destination IP address (32 bits)
int
on_entry240_activate (GtkWidget *entry240, SPSData *data)
{
  ip4_dip_entry (entry240, 11, data);

  return (EXIT_SUCCESS);
}

// IPv4 checksum (16 bits)
int
on_entry241_activate (GtkWidget *entry241, SPSData *data)
{
  ip4_chksum_entry (entry241, 11, data);

  return (EXIT_SUCCESS);
}

// IP options for IPv4 UDP for Traceroute

// Decimal option data entry
int
on_radiobutton57_toggled (GtkButton *radiobutton57, SPSData *data)
{
  (void) radiobutton57;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_ipopt_udp4_tr = 0;

  return (EXIT_SUCCESS);
}

// Hexadecimal option data entry
int
on_radiobutton58_toggled (GtkButton *radiobutton58, SPSData *data)
{
  (void) radiobutton58;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_ipopt_udp4_tr = 1;

  return (EXIT_SUCCESS);
}

// IPv4 option data
int
on_entry428_activate (GtkWidget *entry428, SPSData *data)
{
  data_entry (entry428, &data->ip_optlenbuf[11], MAX_IP4OPTLEN, data->ip_optionsbuf[11], data->dec_hex_ipopt_udp4_tr, data->traceroute_window, data);

  return (EXIT_SUCCESS);
}

// Insert IPv4 option after another, as specified by user.
int
on_button90_clicked (GtkButton *button90, SPSData *data)
{
  (void) button90;  // This statement suppresses compiler warning about unused parameter.

  ip4_option (0, 11, data->ipopt_udp4_tr_after, data->textview42, data->spinbutton13, data);

  return (EXIT_SUCCESS);
}

// Number of option after which to insert new option.
int
on_entry429_activate (GtkWidget *entry429, SPSData *data)
{
  ip4_opt_insert_after_entry (entry429, 11, &data->ipopt_udp4_tr_after, data);

  return (EXIT_SUCCESS);
}

// Append IP option for IPv4 UDP packet.
int
on_button91_clicked (GtkButton *button91, SPSData *data)
{
  (void) button91;  // This statement suppresses compiler warning about unused parameter.

  ip4_option (2, 11, 0, data->textview42, data->spinbutton13, data);

  return (EXIT_SUCCESS);
}

// View IPv4 header options for UDP for traceroute.
int
on_button92_clicked (GtkButton *button92, SPSData *data)
{
  (void) button92;  // This statement suppresses compiler warning about unused parameter.

  opt_view (11, 0, data);

  return (EXIT_SUCCESS);
}

// Number of IPv4 option to remove.
int
on_entry430_activate (GtkWidget *entry430, SPSData *data)
{
  ip4_opt_remove_entry (entry430, 11, &data->ipopt_udp4_tr_remove, data);

  return (EXIT_SUCCESS);
}

// Remove selected IP option.
int
on_button93_clicked (GtkButton *button93, SPSData *data)
{
  (void) button93;  // This statement suppresses compiler warning about unused parameter.

  ip4_option (1, 11, data->ipopt_udp4_tr_remove, data->textview42, data->spinbutton13, data);

  return (EXIT_SUCCESS);
}

// UDP header (IPv4) for traceroute

// UDP source port (16 bits)
int
on_entry242_activate (GtkWidget *entry242, SPSData *data)
{
  udp_sport_entry (entry242, 11, data);

  //  Source port has been entered manually. Uncheck "Randomize" checkbutton.
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton35), FALSE);
  data->ran_udp4_tr_sourceport = 0;

  return (EXIT_SUCCESS);
}

// Randomize UDP source port number.
int
on_checkbutton35_toggled (GtkButton *checkbutton35, SPSData *data)
{
  (void) checkbutton35;  // This statement suppresses compiler warning about unused parameter.

  udp_ran_sport (&data->ran_udp4_tr_sourceport, 11, data->entry242, data);

  return (EXIT_SUCCESS);
}

// UDP destination port (16 bits)
int
on_entry243_activate (GtkWidget *entry243, SPSData *data)
{
  udp_dport_entry (entry243, 11, data);

  return (EXIT_SUCCESS);
}

// Length of UDP datagram (16 bits)
int
on_entry244_activate (GtkWidget *entry244, SPSData *data)
{
  udp_len_entry (entry244, 11, data);

  return (EXIT_SUCCESS);
}

// UDP checksum (16 bits)
int
on_entry245_activate (GtkWidget *entry245, SPSData *data)
{
  udp_chksum_entry (entry245, 11, data);

  return (EXIT_SUCCESS);
}

// ASCII data entry
int
on_radiobutton33_toggled (GtkButton *radiobutton33, SPSData *data)
{
  (void) radiobutton33;  // This statement suppresses compiler warning about unused parameter.

  data->ascii_hex_udp4_tr = 0;

  return (EXIT_SUCCESS);
}

// Hexadecimal data entry
int
on_radiobutton34_toggled (GtkButton *radiobutton34, SPSData *data)
{
  (void) radiobutton34;  // This statement suppresses compiler warning about unused parameter.

  data->ascii_hex_udp4_tr = 1;

  return (EXIT_SUCCESS);
}

// UDP data from keyboard (IPv4 traceroute)
int
on_entry246_activate (GtkWidget *entry246, SPSData *data)
{
  key_data (entry246, 11, data->ascii_hex_udp4_tr, data);

  if (data->nframes[11] > 1) {
    sprintf (data->warning_text, "Packet will be fragmented to accomodate UDP data.");
    data->parent = data->traceroute_window;
    report_warning (data);
  }

  return (EXIT_SUCCESS);
}

// UDP data from file (IPv4 traceroute)
int
on_button35_clicked (GtkButton *button35, SPSData *data)
{
  (void) button35;  // This statement suppresses compiler warning about unused parameter.

  file_payload_data (data->entry246, 11, data);

  if (data->nframes[11] > 1) {
    sprintf (data->warning_text, "Packet will be fragmented to accomodate UDP data.");
    data->parent = data->traceroute_window;
    report_warning (data);
  }

  return (EXIT_SUCCESS);
}

// UDP page (IPv6) for traceroute

// Destination link-layer (MAC) address (48 bits)
int
on_entry295_activate (GtkWidget *entry295, SPSData *data)
{
  mac_entry (entry295, data->ethhdr[14].dst_mac, 14, data);

  return (EXIT_SUCCESS);
}

// Source link-layer (MAC) address (48 bits)
int
on_entry296_activate (GtkWidget *entry296, SPSData *data)
{
  mac_entry (entry296, data->ethhdr[14].src_mac, 14, data);

  return (EXIT_SUCCESS);
}


// This host's interface name to be converted to link-layer (MAC) address and find MTU.
int
on_entry297_activate (GtkWidget *entry297, SPSData *data)
{
  // Check for valid source interface name, check MTU, and update source MAC address.
  ifname_entry (entry297, data->ifname[14], data->ethhdr[14].src_mac, data->entry296, 14, data);

  // Update MTU spinbutton.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton16), data->ifmtu[14]);

  return (EXIT_SUCCESS);
}

// Maximum transmission unit (MTU)
int
on_spinbutton16_value_changed (GtkWidget *spinbutton16, SPSData *data)
{
  data->ifmtu[14] = (int) gtk_spin_button_get_value (GTK_SPIN_BUTTON (spinbutton16));

  // Check if MTU is sufficiently large to accomodate packet. If not, revise.
  check_mtu (14, data);

  // Update spinbutton value.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (spinbutton16), data->ifmtu[14]);

  // Update ethernet frames.
  create_ip6_frame (14, data);
  create_6to4_frame (17, data);

  return (EXIT_SUCCESS);
}

// Ethernet type code (16 bits)
// http://www.iana.org/assignments/ethernet-numbers
int
on_entry298_activate (GtkWidget *entry298, SPSData *data)
{
  ethtype_entry (entry298, 14, data);

  return (EXIT_SUCCESS);
}

// IP version (4 bits)
int
on_entry299_activate (GtkWidget *entry299, SPSData *data)
{
  ip6_ver_entry (entry299, 14, data);

  return (EXIT_SUCCESS);
}

// Traffic class (8 bits)
int
on_entry300_activate (GtkWidget *entry300, SPSData *data)
{
  ip6_tc_entry (entry300, 14, data);

  return (EXIT_SUCCESS);
}

// Flow label (20 bits)
int
on_entry301_activate (GtkWidget *entry301, SPSData *data)
{
  ip6_fl_entry (entry301, 14, data);

  return (EXIT_SUCCESS);
}

// Payload length (16 bits)
int
on_entry302_activate (GtkWidget *entry302, SPSData *data)
{
  ip6_plen_entry (entry302, 14, data);

  return (EXIT_SUCCESS);
}

// Next header (8 bits)
int
on_entry303_activate (GtkWidget *entry303, SPSData *data)
{
  ip6_nxt_entry (entry303, 14, data);

  return (EXIT_SUCCESS);
}

// Hop limit (8 bits)
int
on_entry304_activate (GtkWidget *entry304, SPSData *data)
{
  ip6_hops_entry (entry304, 14, data);

  return (EXIT_SUCCESS);
}

// Source IP address (128 bits)
int
on_entry305_activate (GtkWidget *entry305, SPSData *data)
{
  ip6_sip_entry (entry305, 14, data);

  return (EXIT_SUCCESS);
}

// Destination IP address (128 bits)
int
on_entry306_activate (GtkWidget *entry306, SPSData *data)
{
  ip6_dip_entry (entry306, 14, data);

  return (EXIT_SUCCESS);
}

// Hop-by-Hop extension header
int
on_button103_clicked (GtkWidget *button103, SPSData *data)
{
  (void) button103;  // This statement suppresses compiler warning about unused parameter.

  data->exthdr_type = 14;
  hop_win (data);

  return (EXIT_SUCCESS);
}

// Destination extension header
int
on_button115_clicked (GtkWidget *button115, SPSData *data)
{
  (void) button115;  // This statement suppresses compiler warning about unused parameter.

  data->exthdr_type = 14;
  dst_win (data);

  return (EXIT_SUCCESS);
}

// Routing extension header
int
on_button137_clicked (GtkWidget *button137, SPSData *data)
{
  (void) button137;  // This statement suppresses compiler warning about unused parameter.

  data->exthdr_type = 14;
  route_win (data);

  return (EXIT_SUCCESS);
}

// Authentication extension header
int
on_button121_clicked (GtkWidget *button121, SPSData *data)
{
  (void) button121;  // This statement suppresses compiler warning about unused parameter.

  data->exthdr_type = 14;
  auth_win (data);

  return (EXIT_SUCCESS);
}

// ESP extension header
int
on_button131_clicked (GtkWidget *button131, SPSData *data)
{
  (void) button131;  // This statement suppresses compiler warning about unused parameter.

  data->exthdr_type = 14;
  esp_win (data);

  return (EXIT_SUCCESS);
}

// UDP header (IPv6) for traceroute

// UDP source port (16 bits)
int
on_entry307_activate (GtkWidget *entry307, SPSData *data)
{
  udp_sport_entry (entry307, 14, data);

  //  Source port has been entered manually. Uncheck "Randomize" checkbutton.
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton40), FALSE);
  data->ran_udp6_tr_sourceport = 0;

  return (EXIT_SUCCESS);
}

// Randomize UDP source port number.
int
on_checkbutton40_toggled (GtkButton *checkbutton40, SPSData *data)
{
  (void) checkbutton40;  // This statement suppresses compiler warning about unused parameter.

  udp_ran_sport (&data->ran_udp6_tr_sourceport, 14, data->entry307, data);

  return (EXIT_SUCCESS);
}

// UDP destination port (16 bits)
int
on_entry308_activate (GtkWidget *entry308, SPSData *data)
{
  udp_dport_entry (entry308, 14, data);

  return (EXIT_SUCCESS);
}

// Length of UDP datagram (16 bits)
int
on_entry309_activate (GtkWidget *entry309, SPSData *data)
{
  udp_len_entry (entry309, 14, data);

  return (EXIT_SUCCESS);
}

// UDP checksum (16 bits)
int
on_entry310_activate (GtkWidget *entry310, SPSData *data)
{
  udp_chksum_entry (entry310, 14, data);

  return (EXIT_SUCCESS);
}

// ASCII data entry
int
on_radiobutton39_toggled (GtkButton *radiobutton39, SPSData *data)
{
  (void) radiobutton39;  // This statement suppresses compiler warning about unused parameter.

  data->ascii_hex_udp6_tr = 0;

  return (EXIT_SUCCESS);
}

// Hexadecimal data entry
int
on_radiobutton40_toggled (GtkButton *radiobutton40, SPSData *data)
{
  (void) radiobutton40;  // This statement suppresses compiler warning about unused parameter.

  data->ascii_hex_udp6_tr = 1;

  return (EXIT_SUCCESS);
}

// UDP data from keyboard (IPv6 traceroute)
int
on_entry311_activate (GtkWidget *entry311, SPSData *data)
{
  key_data (entry311, 14, data->ascii_hex_udp6_tr, data);

  if (data->nframes[14] > 1) {
    sprintf (data->warning_text, "Packet will be fragmented to accomodate UDP data.");
    data->parent = data->traceroute_window;
    report_warning (data);
  }

  // Update ethernet frame and extension header editing window widgets, if visible.
  ip6data_update (14, data);

  return (EXIT_SUCCESS);
}

// UDP data from file (IPv6 traceroute)
int
on_button44_clicked (GtkButton *button44, SPSData *data)
{
  (void) button44;  // This statement suppresses compiler warning about unused parameter.

  file_payload_data (data->entry311, 14, data);

  if (data->nframes[14] > 1) {
    sprintf (data->warning_text, "Packet will be fragmented to accomodate UDP data.");
    data->parent = data->traceroute_window;
    report_warning (data);
  }

  // Update ethernet frame and extension header editing window widgets, if visible.
  ip6data_update (14, data);

  return (EXIT_SUCCESS);
}

// Call tcp4_tr_default()
int
on_button30_clicked (GtkButton *button30, SPSData *data)
{
  (void) button30;  // This statement suppresses compiler warning about unused parameter.

  tcp4_tr_default (data);
  tcp4_tr_show (data);

  // Update ethernet frame
  create_ip4_frame (9, data);

  return (EXIT_SUCCESS);
}

// Call tcp6_tr_default()
int
on_button39_clicked (GtkButton *button39, SPSData *data)
{
  (void) button39;  // This statement suppresses compiler warning about unused parameter.

  tcp6_tr_default (data);
  tcp6_tr_show (data);

  return (EXIT_SUCCESS);
}

// Call icmp4_tr_default()
int
on_button33_clicked (GtkButton *button33, SPSData *data)
{
  (void) button33;  // This statement suppresses compiler warning about unused parameter.

  icmp4_tr_default (data);
  icmp4_tr_show (data);

  return (EXIT_SUCCESS);
}

// Call icmp6_tr_default()
int
on_button42_clicked (GtkButton *button42, SPSData *data)
{
  (void) button42;  // This statement suppresses compiler warning about unused parameter.

  icmp6_tr_default (data);
  icmp6_tr_show (data);

  return (EXIT_SUCCESS);
}

// Call udp4_tr_default()
int
on_button36_clicked (GtkButton *button36, SPSData *data)
{
  (void) button36;  // This statement suppresses compiler warning about unused parameter.

  udp4_tr_default (data);
  udp4_tr_show (data);

  return (EXIT_SUCCESS);
}

// Call udp6_tr_default()
int
on_button45_clicked (GtkButton *button45, SPSData *data)
{
  (void) button45;  // This statement suppresses compiler warning about unused parameter.

  udp6_tr_default (data);
  udp6_tr_show (data);

  return (EXIT_SUCCESS);
}

// Traceroute page (sps.ui)

// TCP (IPv4) packet type for traceroute (sps.ui)
int
on_radiobutton21_toggled (GtkButton *radiobutton21, SPSData *data)
{
  (void) radiobutton21;  // This statement suppresses compiler warning about unused parameter.

  data->packet_type_tr = 9;

  return (EXIT_SUCCESS);
}

// ICMP (IPv4) packet type for traceroute (sps.ui)
int
on_radiobutton22_toggled (GtkButton *radiobutton22, SPSData *data)
{
  (void) radiobutton22;  // This statement suppresses compiler warning about unused parameter.

  data->packet_type_tr = 10;

  return (EXIT_SUCCESS);
}

// UDP (IPv4) packet type for traceroute (sps.ui)
int
on_radiobutton23_toggled (GtkButton *radiobutton23, SPSData *data)
{
  (void) radiobutton23;  // This statement suppresses compiler warning about unused parameter.

  data->packet_type_tr = 11;

  return (EXIT_SUCCESS);
}

// TCP (IPv6) packet type for traceroute (sps.ui)
int
on_radiobutton26_toggled (GtkButton *radiobutton26, SPSData *data)
{
  (void) radiobutton26;  // This statement suppresses compiler warning about unused parameter.

  data->packet_type_tr = 12;

  return (EXIT_SUCCESS);
}

// ICMP (IPv6) packet type for traceroute (sps.ui)
int
on_radiobutton27_toggled (GtkButton *radiobutton27, SPSData *data)
{
  (void) radiobutton27;  // This statement suppresses compiler warning about unused parameter.

  data->packet_type_tr = 13;

  return (EXIT_SUCCESS);
}

// UDP (IPv6) packet type for traceroute (sps.ui)
int
on_radiobutton28_toggled (GtkButton *radiobutton28, SPSData *data)
{
  (void) radiobutton28;  // This statement suppresses compiler warning about unused parameter.

  data->packet_type_tr = 14;

  return (EXIT_SUCCESS);
}

// Number of Probes per Hop for Traceroute
int
on_spinbutton2_value_changed (GtkWidget *spinbutton2, SPSData *data)
{
  data->num_probes = (int) gtk_spin_button_get_value (GTK_SPIN_BUTTON (spinbutton2));

  return (EXIT_SUCCESS);
}

// Timeout for Reply for Traceroute
int
on_spinbutton4_value_changed (GtkWidget *spinbutton4, SPSData *data)
{

  data->timeout_tr = (int) gtk_spin_button_get_value (GTK_SPIN_BUTTON (spinbutton4));

  return (EXIT_SUCCESS);
}

// Maximum Number of Hops for Traceroute
int
on_spinbutton3_value_changed (GtkWidget *spinbutton3, SPSData *data)
{

  data->maxhops = (int) gtk_spin_button_get_value (GTK_SPIN_BUTTON (spinbutton3));

  return (EXIT_SUCCESS);
}

// Resolve hostnames for nodes during Traceroute
int
on_checkbutton28_toggled (GtkButton *checkbutton28, SPSData *data)
{
  (void) checkbutton28;  // This statement suppresses compiler warning about unused parameter.

  if (data->resolve_tr) {
    data->resolve_tr = 0;
  } else {
    data->resolve_tr = 1;
  }

  return (EXIT_SUCCESS);
}

// Launch Traceroute Packet Editing UI
int
on_button23_clicked (GtkButton *button23, SPSData *data)
{
  (void) button23;  // This statement suppresses compiler warning about unused parameter.

  GtkBuilder *builder;
  GError *error = NULL;

  // If a traceroute is already running, return with no action.
  if (tracing) {
    return (EXIT_FAILURE);
  }

  if (!data->traceroute_flag) {
    data->traceroute_flag = 1;
    // Create new GtkBuilder object
    builder = gtk_builder_new();
    if (!gtk_builder_add_from_file (builder, "traceroute.ui", &error)) {
      g_warning ("%s", error->message );
      g_free (error);
      exit (EXIT_SUCCESS);
    }

    // Get objects from UI file
    data->traceroute_window = GTK_WIDGET (gtk_builder_get_object (builder, "traceroute_window"));

    // IPv6 over IPv4 (6to4) (traceroute.ui)
    data->checkbutton29 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton29"));  // Tunnel IPv6 over IPv4
    data->spinbutton18 = GTK_WIDGET (gtk_builder_get_object (builder, "spinbutton18"));  // Interface maximum transmission unit
    data->checkbutton61 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton61"));  // Pad ethernet frame to meet minimum length, if required

    // Ethernet headers and IPv4 addresses for 6to4
    // TCP
    data->checkbutton48 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton48"));  // Specify ethernet header
    data->entry316   = GTK_WIDGET (gtk_builder_get_object (builder, "entry316"));  // Source IPv4 address
    // ICMP
    data->checkbutton49 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton49"));  // Specify ethernet header
    data->entry317   = GTK_WIDGET (gtk_builder_get_object (builder, "entry317"));  // Source IPv4 address
    // UDP
    data->checkbutton50 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton50"));  // Specify ethernet header
    data->entry318   = GTK_WIDGET (gtk_builder_get_object (builder, "entry318"));  // Source IPv4 address

    // Traceroute TCP (IPv4) page (traceroute.ui)

    // Ethernet header
    data->checkbutton34 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton34"));  // Specify ethernet header
    data->checkbutton62 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton62"));  // Pad ethernet frame to meet minimum length, if required
    data->entry164 = GTK_WIDGET (gtk_builder_get_object (builder, "entry164"));  // Destination link-layer (MAC) address
    data->entry165 = GTK_WIDGET (gtk_builder_get_object (builder, "entry165"));  // Source link-layer (MAC) address
    data->entry166 = GTK_WIDGET (gtk_builder_get_object (builder, "entry166"));  // Source interface name
    data->spinbutton11 = GTK_WIDGET (gtk_builder_get_object (builder, "spinbutton11"));  // Interface maximum transmission unit
    data->entry167 = GTK_WIDGET (gtk_builder_get_object (builder, "entry167"));  // Ethernet type code
    // IPv4 header
    data->entry168   = GTK_WIDGET (gtk_builder_get_object (builder, "entry168"));  // IP header length
    data->entry169   = GTK_WIDGET (gtk_builder_get_object (builder, "entry169"));  // Protocol version
    data->entry170   = GTK_WIDGET (gtk_builder_get_object (builder, "entry170"));  // Type of service
    data->entry171   = GTK_WIDGET (gtk_builder_get_object (builder, "entry171"));  // Total length of datagram
    data->entry172   = GTK_WIDGET (gtk_builder_get_object (builder, "entry172"));  // ID sequence number
    data->entry173  = GTK_WIDGET (gtk_builder_get_object (builder, "entry173"));  // Zero
    data->entry174   = GTK_WIDGET (gtk_builder_get_object (builder, "entry174"));  // Do not fragment flag
    data->entry175   = GTK_WIDGET (gtk_builder_get_object (builder, "entry175"));  // More fragments following flag
    data->entry176   = GTK_WIDGET (gtk_builder_get_object (builder, "entry176"));  // Fragmentation offset
    data->entry177   = GTK_WIDGET (gtk_builder_get_object (builder, "entry177"));  // Time-to-live
    data->entry178   = GTK_WIDGET (gtk_builder_get_object (builder, "entry178"));  // Transport layer protocol
    data->entry179   = GTK_WIDGET (gtk_builder_get_object (builder, "entry179"));  // Source IP address
    data->entry180   = GTK_WIDGET (gtk_builder_get_object (builder, "entry180"));  // Destination IP address
    data->entry181   = GTK_WIDGET (gtk_builder_get_object (builder, "entry181"));  // IP checksum
    // IPv4 header options
    data->radiobutton49 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton49"));  // Decimal option data entry
    data->radiobutton50 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton50"));  // Hexadecimal option data entry
    data->entry416 = GTK_WIDGET (gtk_builder_get_object (builder, "entry416"));  // IPv4 options data
    data->button74 = GTK_BUTTON (gtk_builder_get_object (builder, "button74"));  // Insert IP Option After...
    data->entry417 = GTK_WIDGET (gtk_builder_get_object (builder, "entry417"));  // Option # to insert after
    data->button75 = GTK_BUTTON (gtk_builder_get_object (builder, "button75"));  // Append IP option
    data->textview34 = GTK_WIDGET (gtk_builder_get_object (builder, "textview34"));  // Number of IP options in packet
    data->button76 = GTK_BUTTON (gtk_builder_get_object (builder, "button76"));  // View IP options
    data->entry418 = GTK_WIDGET (gtk_builder_get_object (builder, "entry418"));  // Option number to remove
    data->button77 = GTK_BUTTON (gtk_builder_get_object (builder, "button77"));  // Remove option
    // TCP header (IPv4)
    data->entry182   = GTK_WIDGET (gtk_builder_get_object (builder, "entry182"));  // Source port number
    data->checkbutton30 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton30"));  // Source port "Randomize" checkbutton
    data->entry183   = GTK_WIDGET (gtk_builder_get_object (builder, "entry183"));  // Destination port number
    data->entry184   = GTK_WIDGET (gtk_builder_get_object (builder, "entry184"));  // Sequence number
    data->entry185   = GTK_WIDGET (gtk_builder_get_object (builder, "entry185"));  // Ack number
    data->entry186   = GTK_WIDGET (gtk_builder_get_object (builder, "entry186"));  // Reserved
    data->entry187   = GTK_WIDGET (gtk_builder_get_object (builder, "entry187"));  // Data offset
    data->entry188   = GTK_WIDGET (gtk_builder_get_object (builder, "entry188"));  // FIN flag
    data->entry189   = GTK_WIDGET (gtk_builder_get_object (builder, "entry189"));  // SYN flag
    data->entry190   = GTK_WIDGET (gtk_builder_get_object (builder, "entry190"));  // RST flag
    data->entry191   = GTK_WIDGET (gtk_builder_get_object (builder, "entry191"));  // PSH flag
    data->entry192   = GTK_WIDGET (gtk_builder_get_object (builder, "entry192"));  // ACK flag
    data->entry193   = GTK_WIDGET (gtk_builder_get_object (builder, "entry193"));  // URG flag
    data->entry194   = GTK_WIDGET (gtk_builder_get_object (builder, "entry194"));  // ECE flag
    data->entry195   = GTK_WIDGET (gtk_builder_get_object (builder, "entry195"));  // CWR flag
    data->entry196   = GTK_WIDGET (gtk_builder_get_object (builder, "entry196"));  // Window size
    data->entry197   = GTK_WIDGET (gtk_builder_get_object (builder, "entry197"));  // TCP Checksum
    data->entry198   = GTK_WIDGET (gtk_builder_get_object (builder, "entry198"));  // Urgent pointer
    data->radiobutton29 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton29"));  // ASCII data entry
    data->radiobutton30 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton30"));  // Hexadecimal data entry
    data->entry199  = GTK_WIDGET (gtk_builder_get_object (builder, "entry199"));  // TCP data from keyboard
    data->button29  = GTK_BUTTON (gtk_builder_get_object (builder, "button29"));  // TCP data from file
    // TCP options (IPv4)
    data->radiobutton51 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton51"));  // Decimal option data entry
    data->radiobutton52 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton52"));  // Hexadecimal option data entry
    data->entry419 = GTK_WIDGET (gtk_builder_get_object (builder, "entry419"));  // Option data
    data->button78 = GTK_BUTTON (gtk_builder_get_object (builder, "button78"));  // Insert TCP Option After...
    data->entry420 = GTK_WIDGET (gtk_builder_get_object (builder, "entry420"));  // Option # to insert after
    data->button79 = GTK_BUTTON (gtk_builder_get_object (builder, "button79"));  // Append TCP option
    data->textview36 = GTK_WIDGET (gtk_builder_get_object (builder, "textview36"));  // Number of TCP options in packet
    data->button80 = GTK_BUTTON (gtk_builder_get_object (builder, "button80"));  // View TCP options
    data->entry421 = GTK_WIDGET (gtk_builder_get_object (builder, "entry421"));  // Option number to remove
    data->button81 = GTK_BUTTON (gtk_builder_get_object (builder, "button81"));  // Remove option

    data->button28   = GTK_BUTTON (gtk_builder_get_object (builder, "button28"));  // View packet
    data->button30  = GTK_BUTTON (gtk_builder_get_object (builder, "button30"));  // Restore default values

    // Traceroute TCP (IPv6) page (traceroute.ui)

    // Ethernet header
    data->entry247 = GTK_WIDGET (gtk_builder_get_object (builder, "entry247"));  // Destination link-layer (MAC) address
    data->entry248 = GTK_WIDGET (gtk_builder_get_object (builder, "entry248"));  // Source link-layer (MAC) address
    data->entry249 = GTK_WIDGET (gtk_builder_get_object (builder, "entry249"));  // Source interface name
    data->spinbutton14 = GTK_WIDGET (gtk_builder_get_object (builder, "spinbutton14"));  // Interface maximum transmission unit
    data->entry250 = GTK_WIDGET (gtk_builder_get_object (builder, "entry250"));  // Ethernet type code
    // IPv6 header
    data->entry251 = GTK_WIDGET (gtk_builder_get_object (builder, "entry251"));  // IP version
    data->entry252 = GTK_WIDGET (gtk_builder_get_object (builder, "entry252"));  // Traffic class
    data->entry253 = GTK_WIDGET (gtk_builder_get_object (builder, "entry253"));  // Flow label
    data->entry254 = GTK_WIDGET (gtk_builder_get_object (builder, "entry254"));  // Payload length
    data->entry255 = GTK_WIDGET (gtk_builder_get_object (builder, "entry255"));  // Next header
    data->entry256 = GTK_WIDGET (gtk_builder_get_object (builder, "entry256"));  // Hop limit
    data->entry257 = GTK_WIDGET (gtk_builder_get_object (builder, "entry257"));  // Source IP address
    data->entry258 = GTK_WIDGET (gtk_builder_get_object (builder, "entry258"));  // Destination IP address
    // TCP header (IPv6)
    data->entry259 = GTK_WIDGET (gtk_builder_get_object (builder, "entry259"));  // Source port number
    data->checkbutton37 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton37"));  // Source port "Randomize" checkbutton
    data->entry260 = GTK_WIDGET (gtk_builder_get_object (builder, "entry260"));  // Destination port number
    data->entry261 = GTK_WIDGET (gtk_builder_get_object (builder, "entry261"));  // Sequence number
    data->entry262 = GTK_WIDGET (gtk_builder_get_object (builder, "entry262"));  // Ack number
    data->entry263 = GTK_WIDGET (gtk_builder_get_object (builder, "entry263"));  // Reserved
    data->entry264 = GTK_WIDGET (gtk_builder_get_object (builder, "entry264"));  // Data offset
    data->entry265 = GTK_WIDGET (gtk_builder_get_object (builder, "entry265"));  // FIN flag
    data->entry266 = GTK_WIDGET (gtk_builder_get_object (builder, "entry266"));  // SYN flag
    data->entry267 = GTK_WIDGET (gtk_builder_get_object (builder, "entry267"));  // RST flag
    data->entry268 = GTK_WIDGET (gtk_builder_get_object (builder, "entry268"));  // PSH flag
    data->entry269 = GTK_WIDGET (gtk_builder_get_object (builder, "entry269"));  // ACK flag
    data->entry270 = GTK_WIDGET (gtk_builder_get_object (builder, "entry270"));  // URG flag
    data->entry271 = GTK_WIDGET (gtk_builder_get_object (builder, "entry271"));  // ECE flag
    data->entry272 = GTK_WIDGET (gtk_builder_get_object (builder, "entry272"));  // CWR flag
    data->entry273 = GTK_WIDGET (gtk_builder_get_object (builder, "entry273"));  // Window size
    data->entry274 = GTK_WIDGET (gtk_builder_get_object (builder, "entry274"));  // TCP Checksum
    data->entry275 = GTK_WIDGET (gtk_builder_get_object (builder, "entry275"));  // Urgent pointer
    data->radiobutton35 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton35"));  // ASCII data entry
    data->radiobutton36 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton36"));  // Hexadecimal data entry
    data->entry276 = GTK_WIDGET (gtk_builder_get_object (builder, "entry276"));  // TCP data from keyboard
    data->button38 = GTK_BUTTON (gtk_builder_get_object (builder, "button38"));  // TCP data from file
    // TCP options (IPv6)
    data->radiobutton53 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton53"));  // Decimal option data entry
    data->radiobutton54 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton54"));  // Hexadecimal option data entry
    data->entry422 = GTK_WIDGET (gtk_builder_get_object (builder, "entry422"));  // Option data
    data->button82 = GTK_BUTTON (gtk_builder_get_object (builder, "button82"));  // Insert TCP Option After...
    data->entry423 = GTK_WIDGET (gtk_builder_get_object (builder, "entry423"));  // Option # to insert after
    data->button83 = GTK_BUTTON (gtk_builder_get_object (builder, "button83"));  // Append TCP option
    data->textview38 = GTK_WIDGET (gtk_builder_get_object (builder, "textview38"));  // Number of TCP options in packet
    data->button84 = GTK_BUTTON (gtk_builder_get_object (builder, "button84"));  // View TCP options
    data->entry424 = GTK_WIDGET (gtk_builder_get_object (builder, "entry424"));  // Option number to remove
    data->button85 = GTK_BUTTON (gtk_builder_get_object (builder, "button85"));  // Remove option
    // Extension headers
    data->button101  = GTK_BUTTON (gtk_builder_get_object (builder, "button101"));  // Hop-by-hop extension header
    data->button113  = GTK_BUTTON (gtk_builder_get_object (builder, "button113"));  // Destination extension header
    data->button135 = GTK_BUTTON (gtk_builder_get_object (builder, "button135"));  // Routing extension header
    data->button119  = GTK_BUTTON (gtk_builder_get_object (builder, "button119"));  // Authentication extension header
    data->button129 = GTK_BUTTON (gtk_builder_get_object (builder, "button129"));  // Encapsulating security payload (ESP) extension header

    data->button37 = GTK_BUTTON (gtk_builder_get_object (builder, "button37"));  // View packet
    data->button39 = GTK_BUTTON (gtk_builder_get_object (builder, "button39"));  // Restore default values

    // Traceroute ICMP (IPv4) page (traceroute.ui)

    // Ethernet header
    data->checkbutton31 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton31"));  // Specify ethernet header`
    data->checkbutton63 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton63"));  // Pad ethernet frame to meet minimum length, if required
    data->entry200 = GTK_WIDGET (gtk_builder_get_object (builder, "entry200"));  // Destination link-layer (MAC) address
    data->entry201 = GTK_WIDGET (gtk_builder_get_object (builder, "entry201"));  // Source link-layer (MAC) address
    data->entry202 = GTK_WIDGET (gtk_builder_get_object (builder, "entry202"));  // Source interface name
    data->spinbutton12 = GTK_WIDGET (gtk_builder_get_object (builder, "spinbutton12"));  // Interface maximum transmission unit
    data->entry203 = GTK_WIDGET (gtk_builder_get_object (builder, "entry203"));  // Ethernet type code
    // IPv4 header
    data->entry204 = GTK_WIDGET (gtk_builder_get_object (builder, "entry204"));  // IP header length
    data->entry205 = GTK_WIDGET (gtk_builder_get_object (builder, "entry205"));  // Protocol version
    data->entry206 = GTK_WIDGET (gtk_builder_get_object (builder, "entry206"));  // Type of service
    data->entry207 = GTK_WIDGET (gtk_builder_get_object (builder, "entry207"));  // Total length of datagram
    data->entry208 = GTK_WIDGET (gtk_builder_get_object (builder, "entry208"));  // ID sequence number
    data->entry209 = GTK_WIDGET (gtk_builder_get_object (builder, "entry209"));  // Zero
    data->entry210 = GTK_WIDGET (gtk_builder_get_object (builder, "entry210"));  // Do not fragment flag
    data->entry211 = GTK_WIDGET (gtk_builder_get_object (builder, "entry211"));  // More fragments following flag
    data->entry212 = GTK_WIDGET (gtk_builder_get_object (builder, "entry212"));  // Fragmentation offset
    data->entry213 = GTK_WIDGET (gtk_builder_get_object (builder, "entry213"));  // Time-to-live
    data->entry214 = GTK_WIDGET (gtk_builder_get_object (builder, "entry214"));  // Transport layer protocol
    data->entry215 = GTK_WIDGET (gtk_builder_get_object (builder, "entry215"));  // Source IP address
    data->entry216 = GTK_WIDGET (gtk_builder_get_object (builder, "entry216"));  // Destination IP address
    data->entry217 = GTK_WIDGET (gtk_builder_get_object (builder, "entry217"));  // IP checksum
    // IPv4 header options
    data->radiobutton55 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton55"));  // Decimal option data entry
    data->radiobutton56 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton56"));  // Hexadecimal option data entry
    data->entry425 = GTK_WIDGET (gtk_builder_get_object (builder, "entry425"));  // IPv4 options data
    data->button86 = GTK_BUTTON (gtk_builder_get_object (builder, "button86"));  // Insert IP Option After...
    data->entry426 = GTK_WIDGET (gtk_builder_get_object (builder, "entry426"));  // Option # to insert after
    data->button87 = GTK_BUTTON (gtk_builder_get_object (builder, "button87"));  // Append IP option
    data->textview40 = GTK_WIDGET (gtk_builder_get_object (builder, "textview40"));  // Number of IP options in packet
    data->button88 = GTK_BUTTON (gtk_builder_get_object (builder, "button88"));  // View IP options
    data->entry427 = GTK_WIDGET (gtk_builder_get_object (builder, "entry427"));  // Option number to remove
    data->button89 = GTK_BUTTON (gtk_builder_get_object (builder, "button89"));  // Remove option
    // ICMP header (IPv4)
    data->entry218 = GTK_WIDGET (gtk_builder_get_object (builder, "entry218"));  // Message type
    data->entry219 = GTK_WIDGET (gtk_builder_get_object (builder, "entry219"));  // Message code
    data->entry220 = GTK_WIDGET (gtk_builder_get_object (builder, "entry220"));  // ICMP checksum
    data->entry221 = GTK_WIDGET (gtk_builder_get_object (builder, "entry221"));  // Identifier
    data->entry222 = GTK_WIDGET (gtk_builder_get_object (builder, "entry222"));  // Sequence number
    data->radiobutton31 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton31"));  // ASCII data entry
    data->radiobutton32 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton32"));  // Hexadecimal data entry
    data->entry223 = GTK_WIDGET (gtk_builder_get_object (builder, "entry223"));  // ICMP data from keyboard
    data->button32 = GTK_BUTTON (gtk_builder_get_object (builder, "button32"));  // ICMP data from file

    data->button31 = GTK_BUTTON (gtk_builder_get_object (builder, "button31"));  // View packet
    data->button33 = GTK_BUTTON (gtk_builder_get_object (builder, "button33"));  // Restore default values

    // Traceroute ICMP (IPv6) page (traceroute.ui)

    // Ethernet header
    data->entry277 = GTK_WIDGET (gtk_builder_get_object (builder, "entry277"));  // Destination link-layer (MAC) address
    data->entry278 = GTK_WIDGET (gtk_builder_get_object (builder, "entry278"));  // Source link-layer (MAC) address
    data->entry279 = GTK_WIDGET (gtk_builder_get_object (builder, "entry279"));  // Source interface name
    data->spinbutton15 = GTK_WIDGET (gtk_builder_get_object (builder, "spinbutton15"));  // Interface maximum transmission unit
    data->entry280 = GTK_WIDGET (gtk_builder_get_object (builder, "entry280"));  // Ethernet type code
    // IPv6 header
    data->entry281 = GTK_WIDGET (gtk_builder_get_object (builder, "entry281"));  // IP version
    data->entry282 = GTK_WIDGET (gtk_builder_get_object (builder, "entry282"));  // Traffic class
    data->entry283 = GTK_WIDGET (gtk_builder_get_object (builder, "entry283"));  // Flow label
    data->entry284 = GTK_WIDGET (gtk_builder_get_object (builder, "entry284"));  // Payload length
    data->entry285 = GTK_WIDGET (gtk_builder_get_object (builder, "entry285"));  // Next header
    data->entry286 = GTK_WIDGET (gtk_builder_get_object (builder, "entry286"));  // Hop limit
    data->entry287 = GTK_WIDGET (gtk_builder_get_object (builder, "entry287"));  // Source IP address
    data->entry288 = GTK_WIDGET (gtk_builder_get_object (builder, "entry288"));  // Destination IP address
    // ICMP header (IPv6)
    data->entry289 = GTK_WIDGET (gtk_builder_get_object (builder, "entry289"));  // Message type
    data->entry290 = GTK_WIDGET (gtk_builder_get_object (builder, "entry290"));  // Message code
    data->entry291 = GTK_WIDGET (gtk_builder_get_object (builder, "entry291"));  // ICMP checksum
    data->entry292 = GTK_WIDGET (gtk_builder_get_object (builder, "entry292"));  // Identifier
    data->entry293 = GTK_WIDGET (gtk_builder_get_object (builder, "entry293"));  // Sequence number
    data->radiobutton37 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton37"));  // ASCII data entry
    data->radiobutton38 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton38"));  // Hexadecimal data entry
    data->entry294 = GTK_WIDGET (gtk_builder_get_object (builder, "entry294"));  // ICMP data from keyboard
    data->button41 = GTK_BUTTON (gtk_builder_get_object (builder, "button41"));  // ICMP data from file
    // Extension headers
    data->button102  = GTK_BUTTON (gtk_builder_get_object (builder, "button102"));  // Hop-by-hop extension header
    data->button114  = GTK_BUTTON (gtk_builder_get_object (builder, "button114"));  // Destination extension header
    data->button136 = GTK_BUTTON (gtk_builder_get_object (builder, "button136"));  // Routing extension header
    data->button120  = GTK_BUTTON (gtk_builder_get_object (builder, "button120"));  // Authentication extension header
    data->button130 = GTK_BUTTON (gtk_builder_get_object (builder, "button130"));  // Encapsulating security payload (ESP) extension header

    data->button40 = GTK_BUTTON (gtk_builder_get_object (builder, "button40"));  // View packet
    data->button42 = GTK_BUTTON (gtk_builder_get_object (builder, "button42"));  // Restore default values

    // Traceroute UDP (IPv4) page (traceroute.ui)

    // Ethernet header
    data->checkbutton33 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton33"));  // Specify ethernet header
    data->checkbutton64 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton64"));  // Pad ethernet frame to meet minimum length, if required
    data->entry224 = GTK_WIDGET (gtk_builder_get_object (builder, "entry224"));  // Destination link-layer (MAC) address
    data->entry225 = GTK_WIDGET (gtk_builder_get_object (builder, "entry225"));  // Source link-layer (MAC) address
    data->entry226 = GTK_WIDGET (gtk_builder_get_object (builder, "entry226"));  // Source interface name
    data->spinbutton13 = GTK_WIDGET (gtk_builder_get_object (builder, "spinbutton13"));  // Interface maximum transmission unit
    data->entry227 = GTK_WIDGET (gtk_builder_get_object (builder, "entry227"));  // Ethernet type code
    // IPv4 header
    data->entry228 = GTK_WIDGET (gtk_builder_get_object (builder, "entry228"));  // IP header length
    data->entry229 = GTK_WIDGET (gtk_builder_get_object (builder, "entry229"));  // Protocol version
    data->entry230 = GTK_WIDGET (gtk_builder_get_object (builder, "entry230"));  // Type of service
    data->entry231 = GTK_WIDGET (gtk_builder_get_object (builder, "entry231"));  // Total length of datagram
    data->entry232 = GTK_WIDGET (gtk_builder_get_object (builder, "entry232"));  // ID sequence number
    data->entry233 = GTK_WIDGET (gtk_builder_get_object (builder, "entry233"));  // Zero
    data->entry234 = GTK_WIDGET (gtk_builder_get_object (builder, "entry234"));  // Do not fragment flag
    data->entry235 = GTK_WIDGET (gtk_builder_get_object (builder, "entry235"));  // More fragments following flag
    data->entry236 = GTK_WIDGET (gtk_builder_get_object (builder, "entry236"));  // Fragmentation offset
    data->entry237 = GTK_WIDGET (gtk_builder_get_object (builder, "entry237"));  // Time-to-live
    data->entry238 = GTK_WIDGET (gtk_builder_get_object (builder, "entry238"));  // Transport layer protocol
    data->entry239 = GTK_WIDGET (gtk_builder_get_object (builder, "entry239"));  // Source IP address
    data->entry240 = GTK_WIDGET (gtk_builder_get_object (builder, "entry240"));  // Destination IP address
    data->entry241 = GTK_WIDGET (gtk_builder_get_object (builder, "entry241"));  // IP checksum
    // IPv4 header options
    data->radiobutton57 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton57"));  // Decimal option data entry
    data->radiobutton58 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton58"));  // Hexadecimal option data entry
    data->entry428 = GTK_WIDGET (gtk_builder_get_object (builder, "entry428"));  // IPv4 options data
    data->button90 = GTK_BUTTON (gtk_builder_get_object (builder, "button90"));  // Insert IP Option After...
    data->entry429 = GTK_WIDGET (gtk_builder_get_object (builder, "entry429"));  // Option # to insert after
    data->button91 = GTK_BUTTON (gtk_builder_get_object (builder, "button91"));  // Append IP option
    data->textview42 = GTK_WIDGET (gtk_builder_get_object (builder, "textview42"));  // Number of IP options in packet
    data->button92 = GTK_BUTTON (gtk_builder_get_object (builder, "button92"));  // View IP options
    data->entry430 = GTK_WIDGET (gtk_builder_get_object (builder, "entry430"));  // Option number to remove
    data->button93 = GTK_BUTTON (gtk_builder_get_object (builder, "button93"));  // Remove option
    // UDP header (IPv4)
    data->entry242 = GTK_WIDGET (gtk_builder_get_object (builder, "entry242"));  // Source port
    data->checkbutton35 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton35"));  // Source IP "Randomize" checkbutton
    data->entry243 = GTK_WIDGET (gtk_builder_get_object (builder, "entry243"));  // Destination port
    data->entry244 = GTK_WIDGET (gtk_builder_get_object (builder, "entry244"));  // Length of UDP datagram
    data->entry245 = GTK_WIDGET (gtk_builder_get_object (builder, "entry245"));  // UDP checksum
    data->radiobutton33 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton33"));  // ASCII data entry
    data->radiobutton34 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton34"));  // Hexadecimal data entry
    data->entry246 = GTK_WIDGET (gtk_builder_get_object (builder, "entry246"));  // UDP data from keyboard
    data->button35 = GTK_BUTTON (gtk_builder_get_object (builder, "button35"));  // UDP data from file

    data->button34 = GTK_BUTTON (gtk_builder_get_object (builder, "button34"));  // View packet
    data->button36 = GTK_BUTTON (gtk_builder_get_object (builder, "button36"));  // Restore default values

    // Traceroute UDP (IPv6) page (traceroute.ui)

    // Ethernet header
    data->entry295 = GTK_WIDGET (gtk_builder_get_object (builder, "entry295"));  // Destination link-layer (MAC) address
    data->entry296 = GTK_WIDGET (gtk_builder_get_object (builder, "entry296"));  // Source link-layer (MAC) address
    data->entry297 = GTK_WIDGET (gtk_builder_get_object (builder, "entry297"));  // Source interface name
    data->spinbutton16 = GTK_WIDGET (gtk_builder_get_object (builder, "spinbutton16"));  // Interface maximum transmission unit
    data->entry298 = GTK_WIDGET (gtk_builder_get_object (builder, "entry298"));  // Ethernet type code
    // IPv6 header
    data->entry299 = GTK_WIDGET (gtk_builder_get_object (builder, "entry299"));  // IP version
    data->entry300 = GTK_WIDGET (gtk_builder_get_object (builder, "entry300"));  // Traffic class
    data->entry301 = GTK_WIDGET (gtk_builder_get_object (builder, "entry301"));  // Flow label
    data->entry302 = GTK_WIDGET (gtk_builder_get_object (builder, "entry302"));  // Payload length
    data->entry303 = GTK_WIDGET (gtk_builder_get_object (builder, "entry303"));  // Next header
    data->entry304 = GTK_WIDGET (gtk_builder_get_object (builder, "entry304"));  // Hop limit
    data->entry305 = GTK_WIDGET (gtk_builder_get_object (builder, "entry305"));  // Source IP address
    data->entry306 = GTK_WIDGET (gtk_builder_get_object (builder, "entry306"));  // Destination IP address
    // UDP header (IPv6)
    data->entry307 = GTK_WIDGET (gtk_builder_get_object (builder, "entry307"));  // Source port
    data->checkbutton40 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "checkbutton40"));  // Source IP "Randomize" checkbutton
    data->entry308 = GTK_WIDGET (gtk_builder_get_object (builder, "entry308"));  // Destination port
    data->entry309 = GTK_WIDGET (gtk_builder_get_object (builder, "entry309"));  // Length of UDP datagram
    data->entry310 = GTK_WIDGET (gtk_builder_get_object (builder, "entry310"));  // UDP checksum
    data->radiobutton39 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton39"));  // ASCII data entry
    data->radiobutton40 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton40"));  // Hexadecimal data entry
    data->entry311 = GTK_WIDGET (gtk_builder_get_object (builder, "entry311"));  // UDP data from keyboard
    data->button44 = GTK_BUTTON (gtk_builder_get_object (builder, "button44"));  // UDP data from file
    // Extension headers
    data->button103  = GTK_BUTTON (gtk_builder_get_object (builder, "button103"));  // Hop-by-hop extension header
    data->button115  = GTK_BUTTON (gtk_builder_get_object (builder, "button115"));  // Destination extension header
    data->button137 = GTK_BUTTON (gtk_builder_get_object (builder, "button137"));  // Routing extension header
    data->button121  = GTK_BUTTON (gtk_builder_get_object (builder, "button121"));  // Authentication extension header
    data->button131 = GTK_BUTTON (gtk_builder_get_object (builder, "button131"));  // Encapsulating security payload (ESP) extension header

    data->button43 = GTK_BUTTON (gtk_builder_get_object (builder, "button43"));  // View packet
    data->button45 = GTK_BUTTON (gtk_builder_get_object (builder, "button45"));  // Restore default values

    // TCP (IPv4) for traceroute
    gtk_spin_button_set_range (GTK_SPIN_BUTTON (data->spinbutton11), 0, 65536.0);  // Minimum is enforced by check_mtu().
    gtk_spin_button_set_digits (GTK_SPIN_BUTTON (data->spinbutton11), 0);
    gtk_spin_button_set_increments (GTK_SPIN_BUTTON (data->spinbutton11), 1.0, 0.0);
    gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (data->spinbutton11), TRUE);
    gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (data->spinbutton11), FALSE);
    gtk_spin_button_set_snap_to_ticks (GTK_SPIN_BUTTON (data->spinbutton11), TRUE);
    // TCP (IPv6) for traceroute
    gtk_spin_button_set_range (GTK_SPIN_BUTTON (data->spinbutton14), 0, 65536.0);  // Minimum is enforced by check_mtu().
    gtk_spin_button_set_digits (GTK_SPIN_BUTTON (data->spinbutton14), 0);
    gtk_spin_button_set_increments (GTK_SPIN_BUTTON (data->spinbutton14), 1.0, 0.0);
    gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (data->spinbutton14), TRUE);
    gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (data->spinbutton14), FALSE);
    gtk_spin_button_set_snap_to_ticks (GTK_SPIN_BUTTON (data->spinbutton14), TRUE);
    // ICMP (IPv4) for traceroute
    gtk_spin_button_set_range (GTK_SPIN_BUTTON (data->spinbutton12), 0, 65536.0);  // Minimum is enforced by check_mtu().
    gtk_spin_button_set_digits (GTK_SPIN_BUTTON (data->spinbutton12), 0);
    gtk_spin_button_set_increments (GTK_SPIN_BUTTON (data->spinbutton12), 1.0, 0.0);
    gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (data->spinbutton12), TRUE);
    gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (data->spinbutton12), FALSE);
    gtk_spin_button_set_snap_to_ticks (GTK_SPIN_BUTTON (data->spinbutton12), TRUE);
    // ICMP (IPv6) for traceroute
    gtk_spin_button_set_range (GTK_SPIN_BUTTON (data->spinbutton15), 0, 65536.0);  // Minimum is enforced by check_mtu().
    gtk_spin_button_set_digits (GTK_SPIN_BUTTON (data->spinbutton15), 0);
    gtk_spin_button_set_increments (GTK_SPIN_BUTTON (data->spinbutton15), 1.0, 0.0);
    gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (data->spinbutton15), TRUE);
    gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (data->spinbutton15), FALSE);
    gtk_spin_button_set_snap_to_ticks (GTK_SPIN_BUTTON (data->spinbutton15), TRUE);
    // UDP (IPv4) for traceroute
    gtk_spin_button_set_range (GTK_SPIN_BUTTON (data->spinbutton13), 0, 65536.0);  // Minimum is enforced by check_mtu().
    gtk_spin_button_set_digits (GTK_SPIN_BUTTON (data->spinbutton13), 0);
    gtk_spin_button_set_increments (GTK_SPIN_BUTTON (data->spinbutton13), 1.0, 0.0);
    gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (data->spinbutton13), TRUE);
    gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (data->spinbutton13), FALSE);
    gtk_spin_button_set_snap_to_ticks (GTK_SPIN_BUTTON (data->spinbutton13), TRUE);
    // UDP (IPv6) for traceroute
    gtk_spin_button_set_range (GTK_SPIN_BUTTON (data->spinbutton16), 0, 65536.0);  // Minimum is enforced by check_mtu().
    gtk_spin_button_set_digits (GTK_SPIN_BUTTON (data->spinbutton16), 0);
    gtk_spin_button_set_increments (GTK_SPIN_BUTTON (data->spinbutton16), 1.0, 0.0);
    gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (data->spinbutton16), TRUE);
    gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (data->spinbutton16), FALSE);
    gtk_spin_button_set_snap_to_ticks (GTK_SPIN_BUTTON (data->spinbutton16), TRUE);
    // IPv6 over IPv4 (6to4) for traceroute
    gtk_spin_button_set_range (GTK_SPIN_BUTTON (data->spinbutton18), 0, 65536.0);  // Minimum is enforced by check_mtu().
    gtk_spin_button_set_digits (GTK_SPIN_BUTTON (data->spinbutton18), 0);
    gtk_spin_button_set_increments (GTK_SPIN_BUTTON (data->spinbutton18), 1.0, 0.0);
    gtk_spin_button_set_numeric (GTK_SPIN_BUTTON (data->spinbutton18), TRUE);
    gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (data->spinbutton18), FALSE);
    gtk_spin_button_set_snap_to_ticks (GTK_SPIN_BUTTON (data->spinbutton18), TRUE);

    // Connect signals
    gtk_builder_connect_signals (builder, data);

    // Destroy builder, since we don't need it anymore
    g_object_unref (G_OBJECT (builder));

    // Show window. All other widgets are automatically shown by GtkBuilder
    gtk_widget_show (data->traceroute_window);

    // Populate entries in traceroute.ui window.
    sixto4_tr_show (data);
    tcp4_tr_show (data);
    tcp6_tr_show (data);
    icmp4_tr_show (data);
    icmp6_tr_show (data);
    udp4_tr_show (data);
    udp6_tr_show (data);
  }

  return (EXIT_SUCCESS);
}

// Set traceroute_flag to zero when traceroute_window is destroyed.
int
on_traceroute_window_destroy (GtkWidget *widget, SPSData *data)
{
  (void) widget;  // This statement suppresses compiler warning about unused parameter.

  data->traceroute_flag = 0;

  return (EXIT_SUCCESS);
}

// Start traceroute.
int
on_button24_clicked (GtkButton *button24, SPSData *data)
{
  (void) button24;  // This statement suppresses compiler warning about unused parameter.

  GThread *thread;

  if (!tracing) {
    tracing = 1;

    if ((data->packet_type_tr == 9) || (data->packet_type_tr == 10) ||
        (data->packet_type_tr == 11)) {

      // Spawn thread to perform traceroute.
      thread = g_thread_new ("ipv4_tr_send", (GThreadFunc) ipv4_tr_send, data);
      if (! thread) {
        fprintf (stderr, "Error: Unable to create new thread for IPv4 traceroute.\n");
        exit (EXIT_FAILURE);
      }

    } else if ((data->packet_type_tr == 12) || (data->packet_type_tr == 13) ||
               (data->packet_type_tr == 14)) {
      if (data->sixto4_tr_flag) {

        // Spawn thread to perform traceroute.
        thread = g_thread_new ("sixto4_tr_send", (GThreadFunc) sixto4_tr_send, data);
        if (! thread) {
          fprintf (stderr, "Error: Unable to create new thread for IPv6 over IPv4 (6to4) traceroute.\n");
          exit (EXIT_FAILURE);
        }
      } else {

        // Spawn thread to perform traceroute.
        thread = g_thread_new ("ipv6_tr_send", (GThreadFunc) ipv6_tr_send, data);
        if (! thread) {
          fprintf (stderr, "Error: Unable to create new thread for IPv6 over IPv4 (6to4) traceroute.\n");
          exit (EXIT_FAILURE);
        }
      }
    }
  }  // End If !tracing

  return (EXIT_SUCCESS);
}

// Set traceroute mode (0 = terminate traceroute)
int
on_button25_clicked (GtkButton *button25, SPSData *data)
{
  (void) button25;  // This statement suppresses compiler warning about unused parameter.
  (void) data;  // This statement suppresses compiler warning about unused parameter.

  tracing = 0;

  return (EXIT_SUCCESS);
}

// Toggle whether or not to show sent and received
// messages on stdout during file downloads.
int
on_checkbutton38_toggled (GtkButton *checkbutton38, SPSData *data)
{
  (void) checkbutton38;  // This statement suppresses compiler warning about unused parameter.
  (void) data;  // This statement suppresses compiler warning about unused parameter.

  if (show_dl_messages) {
    show_dl_messages = 0;
  } else {
    show_dl_messages = 1;
  }

  return (EXIT_SUCCESS);
}

// Download ARIN delegation file.
int
on_button50_clicked (GtkButton *button50, SPSData *data)
{
  (void) button50;  // This statement suppresses compiler warning about unused parameter.

  GThread *thread;

  if (!downloading) {
    downloading = 1;

    // Select ARIN.
    data->rir_index = 0;

    // Spawn thread to download file.
    thread = g_thread_new ("ftp_rir", (GThreadFunc) ftp_rir, data);
    if (! thread) {
      fprintf (stderr, "Error: Unable to create new thread for file download.\n");
      return (EXIT_FAILURE);
    }
  }

  return (EXIT_SUCCESS);
}

// Download RIPE delegation file.
int
on_button51_clicked (GtkButton *button51, SPSData *data)
{
  (void) button51;  // This statement suppresses compiler warning about unused parameter.

  GThread *thread;

  if (!downloading) {
    downloading = 1;

    // Select RIPE.
    data->rir_index = 1;

    // Spawn thread to download file.
    thread = g_thread_new ("ftp_rir", (GThreadFunc) ftp_rir, data);
    if (! thread) {
      fprintf (stderr, "Error: Unable to create new thread for file download.\n");
      return (EXIT_FAILURE);
    }
  }

  return (EXIT_SUCCESS);
}

// Download AFRINIC delegation file.
int
on_button52_clicked (GtkButton *button52, SPSData *data)
{
  (void) button52;  // This statement suppresses compiler warning about unused parameter.

  GThread *thread;

  if (!downloading) {
    downloading = 1;

    // Select AFRINIC.
    data->rir_index = 2;

    // Spawn thread to download file.
    thread = g_thread_new ("ftp_rir", (GThreadFunc) ftp_rir, data);
    if (! thread) {
      fprintf (stderr, "Error: Unable to create new thread for file download.\n");
      return (EXIT_FAILURE);
    }
  }

  return (EXIT_SUCCESS);
}

// Download APNIC delegation file.
int
on_button53_clicked (GtkButton *button53, SPSData *data)
{
  (void) button53;  // This statement suppresses compiler warning about unused parameter.

  GThread *thread;

  if (!downloading) {
    downloading = 1;

    // Select APNIC.
    data->rir_index = 3;

    // Spawn thread to download file.
    thread = g_thread_new ("ftp_rir", (GThreadFunc) ftp_rir, data);
    if (! thread) {
      fprintf (stderr, "Error: Unable to create new thread for file download.\n");
      return (EXIT_FAILURE);
    }
  }

  return (EXIT_SUCCESS);
}

// Download LACNIC delegation file.
int
on_button54_clicked (GtkButton *button54, SPSData *data)
{
  (void) button54;  // This statement suppresses compiler warning about unused parameter.

  GThread *thread;

  if (!downloading) {
    downloading = 1;

    // Select LACNIC.
    data->rir_index = 4;

    // Spawn thread to download file.
    thread = g_thread_new ("ftp_rir", (GThreadFunc) ftp_rir, data);
    if (! thread) {
      fprintf (stderr, "Error: Unable to create new thread for file download.\n");
      return (EXIT_FAILURE);
    }
  }

  return (EXIT_SUCCESS);
}

// Download all RIR ASN / IP delegation files and www.iso.org's country code file.
int
on_button57_clicked (GtkButton *button57, SPSData *data)
{
  (void) button57;  // This statement suppresses compiler warning about unused parameter.

  GThread *thread;

  if (!downloading) {
    downloading = 1;

    // Spawn thread to download file.
    thread = g_thread_new ("download_all", (GThreadFunc) download_all, data);
    if (! thread) {
      fprintf (stderr, "Error: Unable to create new thread for file download.\n");
      return (EXIT_FAILURE);
    }
  }

  return (EXIT_SUCCESS);
}

// Download www.iso.org's country code file.
// Note that www.iso.org only supports IPv4.
int
on_button55_clicked (GtkButton *button55, SPSData *data)
{
  (void) button55;  // This statement suppresses compiler warning about unused parameter.

  GThread *thread;

  if (!downloading) {
    downloading = 1;

    // Spawn thread to download file.
    thread = g_thread_new ("get_countries", (GThreadFunc) get_countries, data);
    if (! thread) {
      fprintf (stderr, "Error: Unable to create new thread for file download.\n");
      return (EXIT_FAILURE);
    }
  }

  return (EXIT_SUCCESS);
}

// View www.iso.org's ISO 3166-1 country code list file.
int
on_button56_clicked (GtkButton *button56, SPSData *data)
{
  (void) button56;  // This statement suppresses compiler warning about unused parameter.

  int i, n, nbytes;
  uint8_t *filedata;
  GtkWidget *window, *scrolled_win, *textview;
  GtkTextBuffer *textbuffer;
  FILE *fi;

  // Report error if we don't have the file.
  if (!data->countries_loaded) {
    sprintf (data->error_text, "The country code file is not available to display. Please download it first.");
    data->parent = data->main_window;
    report_error (data);
    return (EXIT_FAILURE);
  }

  // Create new window to display file contents
  window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_position (GTK_WINDOW (window), GTK_WIN_POS_CENTER);
  gtk_window_set_resizable (GTK_WINDOW (window), TRUE);
  gtk_window_set_title (GTK_WINDOW (window), "ISO 3166-1 Country Code List (www.iso.org)");
  gtk_window_set_default_size (GTK_WINDOW (window), 800, 600);
  gtk_container_set_border_width (GTK_CONTAINER (window), 1);

  // Create a textview object
  textview = gtk_text_view_new ();
  textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (textview));
  gtk_text_view_set_cursor_visible (GTK_TEXT_VIEW (textview), TRUE);

  // Open www.iso.org's country code file.
  fi = fopen (data->country_file, "rb");
  if (fi == NULL) {
    sprintf (data->error_text, "Can't open file %s in on_button56_clicked().", data->country_file);
    data->parent = data->menubar1;
    report_error (data);
    return (EXIT_FAILURE);
  }

  // Count number of bytes in file.
  nbytes = 0;
  while ((n = fgetc (fi)) != EOF) {
    nbytes++;
  }
  rewind (fi);

  if (nbytes < 1) {
    memset (data->error_text, 0, TEXT_STRINGLEN * sizeof (char));
    strncpy (data->error_text, "Country code file has 0 bytes.", TEXT_STRINGLEN - 1);  // Minus 1 for string termination.
    data->parent = data->menubar1;
    report_error (data);
    return (EXIT_FAILURE);
  } else {
    filedata = allocate_ustrmem (nbytes + 1);
  }

  // Read file into array.
  for (i=0; i<nbytes; i++) {
    filedata[i] = (uint8_t) fgetc (fi);
  }
  filedata[nbytes] = 0u;  // Ensure string termination.

  // Close file descriptor.
  fclose (fi);

  // Put the text into the buffer.
  gtk_text_buffer_set_text (textbuffer, (const char *) filedata, -1);

  // Add scrolled window and textview to new window and display.
  scrolled_win = gtk_scrolled_window_new (NULL, NULL);
  gtk_container_add (GTK_CONTAINER (scrolled_win), textview);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolled_win), GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS);

  gtk_container_add (GTK_CONTAINER (window), scrolled_win);
  gtk_widget_show_all (window);

  free (filedata);

  return (EXIT_SUCCESS);
}

// Search country names and extract country code.
int
on_entry500_activate (GtkWidget *entry500, SPSData *data)
{
  const char *entry500_text;
  char *temp, *ccode;

  // Array of chars
  ccode = allocate_strmem (TEXT_STRINGLEN);

  // Array of chars
  temp = allocate_strmem (TEXT_STRINGLEN);

  if (!data->countries_loaded) {
    sprintf (data->error_text, "Please download the country code file first.");
    data->parent = data->main_window;
    report_error (data);
    free (ccode);
    free (temp);
    return (EXIT_FAILURE);
  }

  // Grab country name from ui.
  entry500_text = gtk_entry_get_text (GTK_ENTRY (entry500));

  // Examine country name and report any non-UTF-8 characters.
  if (!is_valid_utf8 ((uint8_t *) entry500_text, strnlen (entry500_text, TEXT_STRINGLEN), data->main_window, data)) {
    sprintf (data->error_text, "Country name appears to include invalid UTF-8 characters.");
    data->parent = data->main_window;
    report_error (data);
    gtk_entry_set_text (GTK_ENTRY (data->entry501), "");
    free (ccode);
    free (temp);
    return (EXIT_FAILURE);

  } else {
    // Convert any lower case UTF-8/ASCII letters to upper case.
    memset (temp, 0, TEXT_STRINGLEN * sizeof (char));
    if (!raise_case ((uint8_t *) entry500_text, strnlen (entry500_text, TEXT_STRINGLEN), (uint8_t *) temp, data->main_window, data)) {
      free (ccode);
      free (temp);
      return (EXIT_FAILURE);
    }
  }

  if (!find_country_code (temp, ccode, data)) {
    sprintf (data->error_text, "Failed to find country name in list. Suggest viewing country code file for spelling.");
    data->parent = data->main_window;
    report_error (data);
    gtk_entry_set_text (GTK_ENTRY (data->entry501), "");
    free (ccode);
    free (temp);
    return (EXIT_FAILURE);
  } else {
    gtk_entry_set_text (GTK_ENTRY (data->entry500), temp);
    gtk_entry_set_text (GTK_ENTRY (data->entry501), ccode);
  }

  free (ccode);
  free (temp);

  return (EXIT_SUCCESS);
}

// Search country codes and extract country name.
int
on_entry501_activate (GtkWidget *entry501, SPSData *data)
{
  const char *entry501_text;
  char *temp, *cname;

  // Array of chars
  cname = allocate_strmem (TEXT_STRINGLEN);

  // Array of chars
  temp = allocate_strmem (TEXT_STRINGLEN);

  if (!data->countries_loaded) {
    sprintf (data->error_text, "Please download the country code file first.");
    data->parent = data->main_window;
    report_error (data);
    free (cname);
    free (temp);
    return (EXIT_FAILURE);
  }

  // Grab country code from ui.
  entry501_text = gtk_entry_get_text (GTK_ENTRY (entry501));

  // Examine country code and report any non-UTF-8 characters.
  if (!is_valid_utf8 ((uint8_t *) entry501_text, strnlen (entry501_text, TEXT_STRINGLEN), data->main_window, data)) {
    sprintf (data->error_text, "Country code appears to include invalid UTF-8 characters.");
    data->parent = data->main_window;
    report_error (data);
    gtk_entry_set_text (GTK_ENTRY (data->entry500), "");
    free (cname);
    free (temp);
    return (EXIT_FAILURE);

  } else {
    // Convert any lower case UTF-8/ASCII letters to upper case.
    memset (temp, 0, TEXT_STRINGLEN * sizeof (char));
    if (!raise_case ((uint8_t *) entry501_text, strnlen (entry501_text, TEXT_STRINGLEN), (uint8_t *) temp, data->main_window, data)) {
      free (cname);
      free (temp);
      return (EXIT_FAILURE);
    }
  }

  if (!find_country_name (cname, temp, data)) {
    sprintf (data->error_text, "Failed to find country code in list. Suggest viewing country code file for spelling.");
    data->parent = data->main_window;
    report_error (data);
    gtk_entry_set_text (GTK_ENTRY (data->entry500), "");
    free (cname);
    free (temp);
    return (EXIT_FAILURE);
  } else {
    gtk_entry_set_text (GTK_ENTRY (data->entry500), cname);
    gtk_entry_set_text (GTK_ENTRY (data->entry501), temp);
  }

  free (cname);
  free (temp);

  return (EXIT_SUCCESS);
}

// Search for autonomous system (AS) number delegations by country name.
int
on_entry502_activate (GtkWidget *entry502, SPSData *data)
{
  // If a search thread is already active, then do nothing and return (EXIT_FAILURE).
  if (ip_asn_searching) {
    return (EXIT_FAILURE);
  } else {
    ip_asn_searching = 1;
  }

  const char *entry502_text;
  char *temp, *ccode;
  GtkTextBuffer *textbuffer;
  GThread *thread;

  // Array of chars
  ccode = allocate_strmem (TEXT_STRINGLEN);

  // Array of chars
  temp = allocate_strmem (TEXT_STRINGLEN);

  // Clear any previous results in the textview.
  textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview16));
  gtk_text_buffer_set_text (textbuffer, "", -1);

  // If RIR files and country code file not available, return with no action.
  if (!all_files_loaded (data)) {
    sprintf (data->error_text, "You must download the RIR files and country code file before performing searches.");
    data->parent = data->main_window;
    report_error (data);
    free (ccode);
    free (temp);
    ip_asn_searching = 0;
    return (EXIT_FAILURE);
  }

  // Grab country name from ui.
  entry502_text = gtk_entry_get_text (GTK_ENTRY (entry502));

  // Examine country name and report any non-UTF-8 characters.
  if (!is_valid_utf8 ((uint8_t *) entry502_text, strnlen (entry502_text, TEXT_STRINGLEN), data->main_window, data)) {
    sprintf (data->error_text, "Country name appears to include invalid UTF-8 characters.");
    data->parent = data->main_window;
    report_error (data);
    gtk_entry_set_text (GTK_ENTRY (data->entry503), "");
    free (ccode);
    free (temp);
    return (EXIT_FAILURE);

  } else {
    // Convert any lower case UTF-8/ASCII letters to upper case.
    memset (temp, 0, TEXT_STRINGLEN * sizeof (char));
    if (!raise_case ((uint8_t *) entry502_text, strnlen (entry502_text, TEXT_STRINGLEN), (uint8_t *) temp, data->main_window, data)) {
      free (ccode);
      free (temp);
      return (EXIT_FAILURE);
    }
  }

  if (!find_country_code (temp, ccode, data)) {
    sprintf (data->error_text, "Failed to find country name in list. Suggest viewing country code file for spelling.");
    data->parent = data->main_window;
    report_error (data);
    gtk_entry_set_text (GTK_ENTRY (data->entry503), "");
    free (ccode);
    free (temp);
    ip_asn_searching = 0;
    return (EXIT_FAILURE);
  }

  memset (data->cname, 0, TEXT_STRINGLEN * sizeof (char));
  strncpy (data->cname, temp, TEXT_STRINGLEN - 1);  // Minus 1 for string termination.
  memset (data->ccode, 0, TEXT_STRINGLEN * sizeof (char));
  strncpy (data->ccode, ccode, 2);

  // Spawn thread to perform IPv4 address delegation search.
  thread = g_thread_new ("search_asn_by_ccode", (GThreadFunc) search_asn_by_ccode, data);
  if (! thread) {
    fprintf (stderr, "Error: Unable to create new thread to search ASN delegations by country name.\n");
    free (ccode);
    free (temp);
    ip_asn_searching = 0;
    gtk_text_buffer_set_text (textbuffer, "", -1);
    return (EXIT_FAILURE);
  }

  gtk_entry_set_text (GTK_ENTRY (data->entry502), data->cname);
  gtk_entry_set_text (GTK_ENTRY (data->entry503), data->ccode);

  free (ccode);
  free (temp);

  return (EXIT_SUCCESS);
}

// Search for autonomous system (AS) number delegations by country code.
int
on_entry503_activate (GtkWidget *entry503, SPSData *data)
{
  // If a search thread is already active, then do nothing and return (EXIT_FAILURE).
  if (ip_asn_searching) {
    return (EXIT_FAILURE);
  } else {
    ip_asn_searching = 1;
  }

  const char *entry503_text;
  char *temp, *cname;
  GtkTextBuffer *textbuffer;
  GThread *thread;

  // Array of chars
  cname = allocate_strmem (TEXT_STRINGLEN);

  // Array of chars
  temp = allocate_strmem (TEXT_STRINGLEN);

  // Clear any previous results in the textview.
  textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview16));
  gtk_text_buffer_set_text (textbuffer, "", -1);

  // If RIR files and country code file not available, return with no action.
  if (!all_files_loaded (data)) {
    sprintf (data->error_text, "You must download the RIR files and country code file before performing searches.");
    data->parent = data->main_window;
    report_error (data);
    free (cname);
    free (temp);
    ip_asn_searching = 0;
    return (EXIT_FAILURE);
  }

  // Grab country code from ui.
  entry503_text = gtk_entry_get_text (GTK_ENTRY (entry503));

  // Examine country code and report any non-UTF-8 characters.
  if (!is_valid_utf8 ((uint8_t *) entry503_text, strnlen (entry503_text, TEXT_STRINGLEN), data->main_window, data)) {
    sprintf (data->error_text, "Country code appears to include invalid UTF-8 characters.");
    data->parent = data->main_window;
    report_error (data);
    gtk_entry_set_text (GTK_ENTRY (data->entry502), "");
    free (cname);
    free (temp);
    return (EXIT_FAILURE);

  } else {
    // Convert any lower case UTF-8/ASCII letters to upper case.
    memset (temp, 0, TEXT_STRINGLEN * sizeof (char));
    if (!raise_case ((uint8_t *) entry503_text, strnlen (entry503_text, TEXT_STRINGLEN), (uint8_t *) temp, data->main_window, data)) {
      free (cname);
      free (temp);
      return (EXIT_FAILURE);
    }
  }

  if (!find_country_name (cname, temp, data)) {
    sprintf (data->error_text, "Failed to find country code in list. Suggest viewing country code file for spelling.");
    data->parent = data->main_window;
    report_error (data);
    gtk_entry_set_text (GTK_ENTRY (data->entry502), "");
    free (cname);
    free (temp);
    ip_asn_searching = 0;
    return (EXIT_FAILURE);
  }

  memset (data->cname, 0, TEXT_STRINGLEN * sizeof (char));
  strncpy (data->cname, cname, TEXT_STRINGLEN - 1);  // Minus 1 for string termination.
  memset (data->ccode, 0, 3 * sizeof (char));
  strncpy (data->ccode, temp, 2);

  // Spawn thread to perform ASN delegation search.
  thread = g_thread_new ("search_asn_by_ccode", (GThreadFunc) search_asn_by_ccode, data);
  if (! thread) {
    fprintf (stderr, "Error: Unable to create new thread to search ASN delegations by country name.\n");
    free (cname);
    free (temp);
    ip_asn_searching = 0;
    gtk_text_buffer_set_text (textbuffer, "", -1);
    return (EXIT_FAILURE);
  }

  gtk_entry_set_text (GTK_ENTRY (data->entry502), data->cname);
  gtk_entry_set_text (GTK_ENTRY (data->entry503), data->ccode);

  free (cname);
  free (temp);

  return (EXIT_SUCCESS);
}

// Reverse search for country by autonomous system (AS) number delegations.
int
on_entry504_activate (GtkWidget *entry504, SPSData *data)
{
  // If a search thread is already active, then do nothing and return (EXIT_FAILURE).
  if (ip_asn_searching) {
    return (EXIT_FAILURE);
  } else {
    ip_asn_searching = 1;
  }

  const char *entry504_text;
  GtkTextBuffer *textbuffer;
  GThread *thread;

  // Clear any previous results in the textview.
  textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview17));
  gtk_text_buffer_set_text (textbuffer, "", -1);

  // If RIR files and country code file not available, return with no action.
  if (!all_files_loaded (data)) {
    sprintf (data->error_text, "You must download the RIR files and country code file before performing searches.");
    data->parent = data->main_window;
    report_error (data);
    ip_asn_searching = 0;
    return (EXIT_FAILURE);
  }

  // Grab ASN from ui.
  entry504_text = gtk_entry_get_text (GTK_ENTRY (entry504));

  if (!is_ascii_uint (entry504_text)) {
    sprintf (data->error_text, "Does not appear to be a valid ASN.");
    data->parent = data->main_window;
    report_error (data);
    ip_asn_searching = 0;
    return (EXIT_FAILURE);
  } else {
    data->asn = (uint64_t) ascii_to_int64 ((char *) entry504_text);
  }

  // Spawn thread to perform ASN delegation search.
  thread = g_thread_new ("rev_search_asn", (GThreadFunc) rev_search_asn, data);
  if (! thread) {
    fprintf (stderr, "Error: Unable to create new thread to reverse-search ASN delegations by ASN.\n");
    gtk_text_buffer_set_text (textbuffer, "", -1);
    ip_asn_searching = 0;
    return (EXIT_FAILURE);
  }

  return (EXIT_SUCCESS);
}

// Search for IP address delegations by country name.
int
on_entry505_activate (GtkWidget *entry505, SPSData *data)
{
  // If a search thread is already active, then do nothing and return (EXIT_FAILURE).
  if (ip_asn_searching) {
    return (EXIT_FAILURE);
  } else {
    ip_asn_searching = 1;
  }

  const char *entry505_text;
  char *temp, *ccode;
  GtkTextBuffer *textbuffer18;
  GtkTextBuffer *textbuffer19;
  GThread *thread4, *thread6;

  // Array of chars
  ccode = allocate_strmem (TEXT_STRINGLEN);

  // Array of chars
  temp = allocate_strmem (TEXT_STRINGLEN);

  // Clear any text in the textviews.
  textbuffer18 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview18));  // IPv4
  gtk_text_buffer_set_text (textbuffer18, "", -1);
  textbuffer19 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview19));  // IPv6
  gtk_text_buffer_set_text (textbuffer19, "", -1);

  // If RIR files and country code file not available, return with no action.
  if (!all_files_loaded (data)) {
    sprintf (data->error_text, "You must download the RIR files and country code file before performing searches.");
    data->parent = data->main_window;
    report_error (data);
    free (ccode);
    free (temp);
    ip_asn_searching = 0;
    return (EXIT_FAILURE);
  }

  // Grab country name from ui.
  entry505_text = gtk_entry_get_text (GTK_ENTRY (entry505));

  // Examine country name and report any non-UTF-8 characters.
  if (!is_valid_utf8 ((uint8_t *) entry505_text, strnlen (entry505_text, TEXT_STRINGLEN), data->main_window, data)) {
    sprintf (data->error_text, "Country name appears to include invalid UTF-8 characters.");
    data->parent = data->main_window;
    report_error (data);
    gtk_entry_set_text (GTK_ENTRY (data->entry506), "");
    free (ccode);
    free (temp);
    return (EXIT_FAILURE);

  } else {
    // Convert any lower case UTF-8/ASCII letters to upper case.
    memset (temp, 0, TEXT_STRINGLEN * sizeof (char));
    if (!raise_case ((uint8_t *) entry505_text, strnlen (entry505_text, TEXT_STRINGLEN), (uint8_t *) temp, data->main_window, data)) {
      free (ccode);
      free (temp);
      return (EXIT_FAILURE);
    }
  }

  if (!find_country_code (temp, ccode, data)) {
    sprintf (data->error_text, "Failed to find country name in list. Suggest viewing country code file for spelling.");
    data->parent = data->main_window;
    report_error (data);
    gtk_entry_set_text (GTK_ENTRY (data->entry506), "");
    free (ccode);
    free (temp);
    ip_asn_searching = 0;
    return (EXIT_FAILURE);
  }

  memset (data->cname, 0, TEXT_STRINGLEN * sizeof (char));
  strncpy (data->cname, temp, TEXT_STRINGLEN - 1);  // Minus 1 for string termination.
  memset (data->ccode, 0, 3 * sizeof (char));
  strncpy (data->ccode, ccode, 2);

  // Spawn thread to perform IPv4 address delegation search.
  thread4 = g_thread_new ("search_ipv4_by_ccode", (GThreadFunc) search_ipv4_by_ccode, data);
  if (! thread4) {
    fprintf (stderr, "Error: Unable to create new thread to search IPv4 address delegations by country name.\n");
    free (ccode);
    free (temp);
    ip_asn_searching = 0;  // OK to set to zero since we'd never get to spawn IPv6 search.
    gtk_text_buffer_set_text (textbuffer18, "", -1);  // IPv4
    return (EXIT_FAILURE);
  }

  // Spawn thread to perform IPv6 address delegation search.
  thread6 = g_thread_new ("search_ipv6_by_ccode", (GThreadFunc) search_ipv6_by_ccode, data);
  if (! thread6) {
    fprintf (stderr, "Error: Unable to create new thread to search IPv6 address delegations by country name.\n");
    free (ccode);
    free (temp);
    // Can't set ip_asn_searching to zero since IPv4 is searching.
    gtk_text_buffer_set_text (textbuffer19, "", -1);  // IPv6
    return (EXIT_FAILURE);
  }

  gtk_entry_set_text (GTK_ENTRY (data->entry505), data->cname);
  gtk_entry_set_text (GTK_ENTRY (data->entry506), data->ccode);

  free (ccode);
  free (temp);

  return (EXIT_SUCCESS);
}

// Search for IP address delegations by country code.
int
on_entry506_activate (GtkWidget *entry506, SPSData *data)
{
  // If a search thread is already active, then do nothing and return (EXIT_FAILURE).
  if (ip_asn_searching) {
    return (EXIT_FAILURE);
  } else {
    ip_asn_searching = 1;
  }

  const char *entry506_text;
  char *temp, *cname;
  GtkTextBuffer *textbuffer18;
  GtkTextBuffer *textbuffer19;
  GThread *thread4, *thread6;

  // Array of chars
  cname = allocate_strmem (TEXT_STRINGLEN);

  // Array of chars
  temp = allocate_strmem (TEXT_STRINGLEN);

  // Clear any text in the textviews.
  textbuffer18 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview18));  // IPv4
  gtk_text_buffer_set_text (textbuffer18, "", -1);
  textbuffer19 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview19));  // IPv6
  gtk_text_buffer_set_text (textbuffer19, "", -1);

  // If RIR files and country code file not available, return with no action.
  if (!all_files_loaded (data)) {
    sprintf (data->error_text, "You must download the RIR files and country code file before performing searches.");
    data->parent = data->main_window;
    report_error (data);
    free (cname);
    free (temp);
    ip_asn_searching = 0;
    return (EXIT_FAILURE);
  }

  // Grab country code from ui.
  entry506_text = gtk_entry_get_text (GTK_ENTRY (entry506));

  // Examine country code and report any non-UTF-8 characters.
  if (!is_valid_utf8 ((uint8_t *) entry506_text, strnlen (entry506_text, TEXT_STRINGLEN), data->main_window, data)) {
    sprintf (data->error_text, "Country code appears to include invalid UTF-8 characters.");
    data->parent = data->main_window;
    report_error (data);
    gtk_entry_set_text (GTK_ENTRY (data->entry505), "");
    free (cname);
    free (temp);
    return (EXIT_FAILURE);

  } else {
    // Convert any lower case UTF-8/ASCII letters to upper case.
    memset (temp, 0, TEXT_STRINGLEN * sizeof (char));
    if (!raise_case ((uint8_t *) entry506_text, strnlen (entry506_text, TEXT_STRINGLEN), (uint8_t *) temp, data->main_window, data)) {
      free (cname);
      free (temp);
      return (EXIT_FAILURE);
    }
  }

  if (!find_country_name (cname, temp, data)) {
    sprintf (data->error_text, "Failed to find country code in list. Suggest viewing country code file for spelling.");
    data->parent = data->main_window;
    report_error (data);
    gtk_entry_set_text (GTK_ENTRY (data->entry505), "");
    free (cname);
    free (temp);
    ip_asn_searching = 0;
    return (EXIT_FAILURE);
  }

  memset (data->cname, 0, TEXT_STRINGLEN * sizeof (char));
  strncpy (data->cname, cname, TEXT_STRINGLEN - 1);  // Minus 1 for string termination.
  memset (data->ccode, 0, 3 * sizeof (char));
  strncpy (data->ccode, temp, 2);

  // Spawn thread to perform IPv4 address delegation search.
  thread4 = g_thread_new ("search_ipv4_by_ccode", (GThreadFunc) search_ipv4_by_ccode, data);
  if (! thread4) {
    fprintf (stderr, "Error: Unable to create new thread to search IPv4 address delegations by country name.\n");
    free (cname);
    free (temp);
    ip_asn_searching = 0;  // OK to set to zero since we'd never get to spawn IPv6 search.
    gtk_text_buffer_set_text (textbuffer18, "", -1);  // IPv4
    return (EXIT_FAILURE);
  }

  // Spawn thread to perform IPv6 address delegation search.
  thread6 = g_thread_new ("search_ipv6_by_ccode", (GThreadFunc) search_ipv6_by_ccode, data);
  if (! thread6) {
    fprintf (stderr, "Error: Unable to create new thread to search IPv6 address delegations by country name.\n");
    free (cname);
    free (temp);
    // Can't set ip_asn_searching to zero since IPv4 is searching.
    gtk_text_buffer_set_text (textbuffer19, "", -1);  // IPv6
    return (EXIT_FAILURE);
  }

  gtk_entry_set_text (GTK_ENTRY (data->entry505), data->cname);
  gtk_entry_set_text (GTK_ENTRY (data->entry506), data->ccode);

  free (cname);
  free (temp);

  return (EXIT_SUCCESS);
}

// Reverse-search for IPv4 address delegations by IPv4 address.
int
on_entry507_activate (GtkWidget *entry507, SPSData *data)
{
  // If a search thread is already active, then do nothing and return (EXIT_FAILURE).
  if (ip_asn_searching) {
    return (EXIT_FAILURE);
  } else {
    ip_asn_searching = 1;
  }

  // Clear IPv6 text entry.
  gtk_entry_set_text (GTK_ENTRY (data->entry508), "");

  const char *entry507_text;
  GtkTextBuffer *textbuffer20;
  GThread *thread;

  // Clear any previous results in the textview.
  textbuffer20 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview20));
  gtk_text_buffer_set_text (textbuffer20, "", -1);

  // If RIR files and country code file not available, return with no action.
  if (!all_files_loaded (data)) {
    sprintf (data->error_text, "You must download the RIR files and country code file before performing searches.");
    data->parent = data->main_window;
    report_error (data);
    ip_asn_searching = 0;
    return (EXIT_FAILURE);
  }

  // Grab IPv4 address from ui.
  entry507_text = gtk_entry_get_text (GTK_ENTRY (entry507));

  // Check to see if address is a valid IPv4 address.
  if (!is_valid_ip4 (entry507_text)) {
    sprintf (data->error_text, "In callbacks.c: is_valid_ip4() failed in on_entry507_activate().\nAppears to be an invalid IPv4 address..");
    data->parent = data->main_window;
    report_error (data);
    ip_asn_searching = 0;
    return (EXIT_FAILURE);
  }

  memset (data->ip4string, 0, INET_ADDRSTRLEN * sizeof (char));
  strncpy (data->ip4string, entry507_text, INET_ADDRSTRLEN - 1);  // Minus 1 for string termination.

  // Spawn thread to perform IPv4 address delegation search.
  thread = g_thread_new ("rev_search_ipv4", (GThreadFunc) rev_search_ipv4, data);
  if (! thread) {
    fprintf (stderr, "Error: Unable to create new thread to reverse-search IPv4 address delegations by IPv4 address.\n");
    gtk_text_buffer_set_text (textbuffer20, "", -1);
    ip_asn_searching = 0;
    return (EXIT_FAILURE);
  }

  return (EXIT_SUCCESS);
}

// Reverse-search for IPv6 address delegations by IPv6 address.
int
on_entry508_activate (GtkWidget *entry508, SPSData *data)
{
  // If a search thread is already active, then do nothing and return (EXIT_FAILURE).
  if (ip_asn_searching) {
    return (EXIT_FAILURE);
  } else {
    ip_asn_searching = 1;
  }

  // Clear IPv4 text entry.
  gtk_entry_set_text (GTK_ENTRY (data->entry507), "");

  const char *entry508_text;
  GtkTextBuffer *textbuffer20;
  struct sockaddr_in6 sa;
  GThread *thread;

  // Clear any previous results in the textview.
  textbuffer20 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview20));
  gtk_text_buffer_set_text (textbuffer20, "", -1);

  // If RIR files and country code file not available, return with no action.
  if (!all_files_loaded (data)) {
    sprintf (data->error_text, "You must download the RIR files and country code file before performing searches.");
    data->parent = data->main_window;
    report_error (data);
    ip_asn_searching = 0;
    return (EXIT_FAILURE);
  }

  // Grab IPv6 address from ui.
  entry508_text = gtk_entry_get_text (GTK_ENTRY (entry508));

  // Check to see if address is a valid IPv6 address.
  if (inet_pton (AF_INET6, entry508_text, &sa.sin6_addr) < 1) {
    sprintf (data->error_text, "In callbacks.c: inet_pton() failed in on_entry508_activate().\nAppears to be an invalid IPv6 address..");
    data->parent = data->main_window;
    report_error (data);
    ip_asn_searching = 0;
    return (EXIT_FAILURE);
  }

  memset (data->ip6string, 0, INET6_ADDRSTRLEN * sizeof (char));
  strncpy (data->ip6string, entry508_text, INET6_ADDRSTRLEN - 1);  // Minus 1 for string termination.

  // Spawn thread to perform IPv4 address delegation search.
  thread = g_thread_new ("rev_search_ipv6", (GThreadFunc) rev_search_ipv6, data);
  if (! thread) {
    fprintf (stderr, "Error: Unable to create new thread to reverse-search IPv6 address delegations by IPv6 address.\n");
    gtk_text_buffer_set_text (textbuffer20, "", -1);
    ip_asn_searching = 0;
    return (EXIT_FAILURE);
  }

  return (EXIT_SUCCESS);
}

// Pseudo-random number generator (PRNG) page

// Seed for PRNG
int
on_entry319_activate (GtkWidget *entry319, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry319));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) < 1ll)) {
    sprintf (value, "%" PRIu64, (uint64_t) data->RN_SEED0);
    gtk_entry_set_text (GTK_ENTRY (entry319), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->RN_SEED0 = (uint64_t) ascii_to_int64 ((char *) entry_text);  // Update with new value
    data->RN_ITER = 0ull;  // Start at beginning of sequence.

    // Update all randomized parameters (IPv4 and IPv6, including traceroute).
    update_ran_parms (data);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Stride for PRNG
int
on_entry320_activate (GtkWidget *entry320, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry320));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) < 1ll)) {
    sprintf (value, "%" PRIu64, (uint64_t) data->RN_STRIDE);
    gtk_entry_set_text (GTK_ENTRY (entry320), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->RN_STRIDE = (uint64_t) ascii_to_int64 ((char *) entry_text);  // Update with new value
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Hop-by-hop header

// Toggle: attach / detach a hop-by-hop header
int
on_button142_clicked (GtkButton *button142, SPSData *data)
{
  (void) button142;  // This statement suppresses compiler warning about unused parameter.
  GtkTextBuffer *textbuffer47;

  textbuffer47 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview47));

  // Don't attach a hop-by-hop header.
  if (data->hbh_hdr_flag[data->exthdr_type]) {
    data->hbh_hdr_flag[data->exthdr_type] = 0;
    gtk_text_buffer_set_text (textbuffer47, "Not Attached", -1);

  // Attach a hop-by-hop header.
  } else {
    // Abort if there are no hop-by-hop options.
    if (!data->hbh_nopt[data->exthdr_type]) {
      data->hbh_hdr_flag[data->exthdr_type] = 0;
      gtk_text_buffer_set_text (textbuffer47, "Not Attached", -1);
      sprintf (data->error_text, "In on_button142_clicked: Cannot attach a hop-by-hop header since no options were specified.");
      data->parent = data->hop_window;
      report_error (data);
      return (EXIT_FAILURE);
    } else {
      data->hbh_hdr_flag[data->exthdr_type] = 1;
      gtk_text_buffer_set_text (textbuffer47, "Attached", -1);
    }
  }

  // Update ethernet frame and hop_window widgets.
  ip6data_update (data->exthdr_type, data);

  return (EXIT_SUCCESS);
}

// Set hop_flag to zero when hop_window is destroyed.
int
on_hop_window_destroy (GtkWidget *widget, SPSData *data)
{
  (void) widget;  // This statement suppresses compiler warning about unused parameter.

  data->hop_flag = 0;

  return (EXIT_SUCCESS);
}

// Hop-by-hop header length
int
on_entry438_activate (GtkWidget *entry438, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry438));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 255)) {
    sprintf (value, "%" PRIu8, (uint8_t) data->hophdr[data->exthdr_type].hdr_len);
    gtk_entry_set_text (GTK_ENTRY (entry438), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->hophdr[data->exthdr_type].hdr_len = (uint8_t) ascii_to_int64 ((char *) entry_text);  // Update with new value

    // Update ethernet frame and hop_window widgets.
    ip6data_update (data->exthdr_type, data);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Decimal option data entry
int
on_radiobutton59_toggled (GtkButton *radiobutton59, SPSData *data)
{
  (void) radiobutton59;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_hbhopt = 0;

  return (EXIT_SUCCESS);
}

// Hexadecimal option data entry
int
on_radiobutton60_toggled (GtkButton *radiobutton60, SPSData *data)
{
  (void) radiobutton60;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_hbhopt = 1;

  return (EXIT_SUCCESS);
}

// Hop-by-hop option data
int
on_entry158_activate (GtkWidget *entry158, SPSData *data)
{
  data_entry (entry158, &data->hbh_optlenbuf[data->exthdr_type], MAX_HBHOPTLEN, data->hbh_optionsbuf[data->exthdr_type], data->dec_hex_hbhopt, data->hop_window, data);

  return (EXIT_SUCCESS);
}

// Hop-by-hop option alignment parameter x (of (xn + y)
int
on_entry313_activate (GtkWidget *entry313, SPSData *data)
{
  (void) data;  // This statement suppresses compiler warning about unused parameter.

  const char *entry313_text;

  // Get new value from text entry
  entry313_text = gtk_entry_get_text (GTK_ENTRY (entry313));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry313_text) || (ascii_to_int64 ((char *) entry313_text) > 255)) {
    gtk_entry_set_text (GTK_ENTRY (entry313), "");
    return (EXIT_FAILURE);
  }

  return (EXIT_SUCCESS);
}

// Hop-by-hop option alignment parameter y (of (xn + y)
int
on_entry314_activate (GtkWidget *entry314, SPSData *data)
{
  (void) data;  // This statement suppresses compiler warning about unused parameter.

  const char *entry314_text;

  // Get new value from text entry
  entry314_text = gtk_entry_get_text (GTK_ENTRY (entry314));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry314_text) || (ascii_to_int64 ((char *) entry314_text) > 255u)) {
    gtk_entry_set_text (GTK_ENTRY (entry314), "");
    return (EXIT_FAILURE);
  }

  return (EXIT_SUCCESS);
}

// Insert hop-by-hop option after another, as specified by user.
int
on_button94_clicked (GtkButton *button94, SPSData *data)
{
  (void) button94;  // This statement suppresses compiler warning about unused parameter.

  if (dsthop_option (0, data->hbhopt_after, data->textview22, NULL, data) == EXIT_SUCCESS) {

    // Update hop-by-hop header length in hop_window.
    hop_show (data->exthdr_type, data);

    // Update ethernet frame if hop-by-hop header is attached.
    if (data->hbh_hdr_flag) {
      ip6data_update (data->exthdr_type, data);
    }
  }

  return (EXIT_SUCCESS);
}

// Number of option after which to insert new hop-by-hop option.
int
on_entry159_activate (GtkWidget *entry159, SPSData *data)
{
  dsthop_opt_insert_after_entry (entry159, &data->hbhopt_after);

  return (EXIT_SUCCESS);
}

// Append an hop-by-hop option.
int
on_button95_clicked (GtkButton *button95, SPSData *data)
{
  (void) button95;  // This statement suppresses compiler warning about unused parameter.

  if (dsthop_option (2, 0, data->textview22, NULL, data) == EXIT_SUCCESS) {

    // Update hop-by-hop header length in hop_window.
    hop_show (data->exthdr_type, data);

    // Update ethernet frame if hop-by-hop header is attached.
    if (data->hbh_hdr_flag) {
      ip6data_update (data->exthdr_type, data);
    }
  }

  return (EXIT_SUCCESS);
}

// View hop-by-hop header options.
int
on_button96_clicked (GtkButton *button96, SPSData *data)
{
  (void) button96;  // This statement suppresses compiler warning about unused parameter.

  dsthop_opt_view (0, data);  // First argument (0) is meaningless for hop-by-hop.

  return (EXIT_SUCCESS);
}

// Number of hop-by-hop option to remove.
int
on_entry312_activate (GtkWidget *entry312, SPSData *data)
{
  dsthop_opt_remove_entry (entry312, &data->hbhopt_remove);

  return (EXIT_SUCCESS);
}

// Remove selected hop-by-hop option.
int
on_button97_clicked (GtkButton *button97, SPSData *data)
{
  (void) button97;  // This statement suppresses compiler warning about unused parameter.

  if (dsthop_option (1, data->hbhopt_remove, data->textview22, NULL, data) == EXIT_SUCCESS) {

    // Update ethernet header if hop-by-hop header is attached.
    if (data->hbh_hdr_flag[data->exthdr_type]) {

      // If number of options in now zero, detach header.
      if (!data->hbh_nopt[data->exthdr_type]) {
        data->hbh_hdr_flag[data->exthdr_type] = 0;
      }

      // Update ethernet header.
      ip6data_update (data->exthdr_type, data);
    }

    // Update hop-by-hop header length and attached/detached textview in hop_window.
    hop_show (data->exthdr_type, data);
  }

  return (EXIT_SUCCESS);
}

// Destination Header

// Toggle: attach / detach a "first" destination header
int
on_button143_clicked (GtkButton *button143, SPSData *data)
{
  (void) button143;  // This statement suppresses compiler warning about unused parameter.
  GtkTextBuffer *textbuffer48;

  textbuffer48 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview48));

  // Don't attach a "first" destination header.
  if (data->dstf_hdr_flag[data->exthdr_type]) {
    data->dstf_hdr_flag[data->exthdr_type] = 0;
    gtk_text_buffer_set_text (textbuffer48, "Not Attached", -1);

  // Attach a "first" destination header.
  } else {
    // Abort if there are no destination options.
    if (!data->dstf_nopt[data->exthdr_type]) {
      data->dstf_hdr_flag[data->exthdr_type] = 0;
      gtk_text_buffer_set_text (textbuffer48, "Not Attached", -1);
      sprintf (data->error_text, "In on_button143_clicked: Cannot attach a \"first\" destination header since no options were specified.");
      data->parent = data->dst_window;
      report_error (data);
      return (EXIT_FAILURE);
    } else {
      data->dstf_hdr_flag[data->exthdr_type] = 1;
      gtk_text_buffer_set_text (textbuffer48, "Attached", -1);
    }
  }

  // Update ethernet frame and dst_window widgets.
  ip6data_update (data->exthdr_type, data);

  return (EXIT_SUCCESS);
}

// Set dst_flag to zero when dst_window is destroyed.
int
on_dst_window_destroy (GtkWidget *widget, SPSData *data)
{
  (void) widget;  // This statement suppresses compiler warning about unused parameter.

  data->dst_flag = 0;

  return (EXIT_SUCCESS);
}

// Toggle: attach / detach a "last" destination header
int
on_button144_clicked (GtkButton *button144, SPSData *data)
{
  (void) button144;  // This statement suppresses compiler warning about unused parameter.
  GtkTextBuffer *textbuffer49;

  textbuffer49 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview49));

  // Don't attach a "last" destination header.
  if (data->dstl_hdr_flag[data->exthdr_type]) {
    data->dstl_hdr_flag[data->exthdr_type] = 0;
    gtk_text_buffer_set_text (textbuffer49, "Not Attached", -1);

  // Attach a "last" destination header.
  } else {
    // Abort if there are no destination options.
    if (!data->dstl_nopt[data->exthdr_type]) {
      data->dstl_hdr_flag[data->exthdr_type] = 0;
      gtk_text_buffer_set_text (textbuffer49, "Not Attached", -1);
      sprintf (data->error_text, "In on_button144_clicked: Cannot attach a \"last\" destination header since no options were specified.");
      data->parent = data->dst_window;
      report_error (data);
      return (EXIT_FAILURE);
    } else {
      data->dstl_hdr_flag[data->exthdr_type] = 1;
      gtk_text_buffer_set_text (textbuffer49, "Attached", -1);
    }
  }

  // Update ethernet frame and dst_window widgets.
  ip6data_update (data->exthdr_type, data);

  return (EXIT_SUCCESS);
}

// Destination header length (first)
int
on_entry439_activate (GtkWidget *entry439, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry439));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 255)) {
    sprintf (value, "%" PRIu8, (uint8_t) data->dstfhdr[data->exthdr_type].hdr_len);
    gtk_entry_set_text (GTK_ENTRY (entry439), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->dstfhdr[data->exthdr_type].hdr_len = (uint8_t) ascii_to_int64 ((char *) entry_text);  // Update with new value

    // Update ethernet frame and dst_window widgets.
    ip6data_update (data->exthdr_type, data);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Destination header length (last)
int
on_entry440_activate (GtkWidget *entry440, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry440));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 255)) {
    sprintf (value, "%" PRIu8, (uint8_t) data->dstlhdr[data->exthdr_type].hdr_len);
    gtk_entry_set_text (GTK_ENTRY (entry440), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->dstlhdr[data->exthdr_type].hdr_len = (uint8_t ) ascii_to_int64 ((char *) entry_text);  // Update with new value

    // Update ethernet frame and dst_window widgets.
    ip6data_update (data->exthdr_type, data);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Decimal option data entry
int
on_radiobutton61_toggled (GtkButton *radiobutton61, SPSData *data)
{
  (void) radiobutton61;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_dstopt = 0;

  return (EXIT_SUCCESS);
}

// Hexadecimal option data entry
int
on_radiobutton62_toggled (GtkButton *radiobutton62, SPSData *data)
{
  (void) radiobutton62;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_dstopt = 1;

  return (EXIT_SUCCESS);
}

// Destination option data
int
on_entry315_activate (GtkWidget *entry315, SPSData *data)
{
  data_entry (entry315, &data->dst_optlenbuf[data->exthdr_type], MAX_DSTOPTLEN, data->dst_optionsbuf[data->exthdr_type], data->dec_hex_dstopt, data->dst_window, data);

  return (EXIT_SUCCESS);
}

// Destination option alignment parameter x (of (xn + y)
int
on_entry156_activate (GtkWidget *entry156, SPSData *data)
{
  (void) data;  // This statement suppresses compiler warning about unused parameter.

  const char *entry156_text;

  // Get new value from text entry
  entry156_text = gtk_entry_get_text (GTK_ENTRY (entry156));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry156_text) || (ascii_to_int64 ((char *) entry156_text) > 255)) {
    gtk_entry_set_text (GTK_ENTRY (entry156), "");
    return (EXIT_FAILURE);
  }

  return (EXIT_SUCCESS);
}

// Destination option alignment parameter y (of (xn + y)
int
on_entry157_activate (GtkWidget *entry157, SPSData *data)
{
  (void) data;  // This statement suppresses compiler warning about unused parameter.

  const char *entry157_text;

  // Get new value from text entry
  entry157_text = gtk_entry_get_text (GTK_ENTRY (entry157));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry157_text) || (ascii_to_int64 ((char *) entry157_text) > 255)) {
    gtk_entry_set_text (GTK_ENTRY (entry157), "");
    return (EXIT_FAILURE);
  }

  return (EXIT_SUCCESS);
}

// Designate as first destination header
int
on_radiobutton63_toggled (GtkButton *radiobutton63, SPSData *data)
{
  (void) radiobutton63;  // This statement suppresses compiler warning about unused parameter.

  data->dst_fl_flag = 0;

  return (EXIT_SUCCESS);
}

// Designate as last destination header
int
on_radiobutton64_toggled (GtkButton *radiobutton64, SPSData *data)
{
  (void) radiobutton64;  // This statement suppresses compiler warning about unused parameter.

  data->dst_fl_flag = 1;

  return (EXIT_SUCCESS);
}

// Insert destination option after another, as specified by user.
int
on_button104_clicked (GtkButton *button104, SPSData *data)
{
  (void) button104;  // This statement suppresses compiler warning about unused parameter.

  if (dsthop_option (0, data->dstopt_after, data->textview25, data->textview27, data) == EXIT_SUCCESS) {

    // Update destination header length in dst_window.
    dst_show (data->exthdr_type, data);

    // Update ethernet frame if destination header is attached.
    if ((data->dstf_hdr_flag && !data->dst_fl_flag) || (data->dstl_hdr_flag && data->dst_fl_flag)) {
      ip6data_update (data->exthdr_type, data);
    }
  }

  return (EXIT_SUCCESS);
}

// Number of option after which to insert new destination option.
int
on_entry431_activate (GtkWidget *entry431, SPSData *data)
{
  dsthop_opt_insert_after_entry (entry431, &data->dstopt_after);

  return (EXIT_SUCCESS);
}

// Append an destination option.
int
on_button105_clicked (GtkButton *button105, SPSData *data)
{
  (void) button105;  // This statement suppresses compiler warning about unused parameter.

  if (dsthop_option (2, 0, data->textview25, data->textview27, data) == EXIT_SUCCESS) {

    // Update destination header length in dst_window.
    dst_show (data->exthdr_type, data);

    // Update ethernet frame if destination header is attached.
    if ((data->dstf_hdr_flag && !data->dst_fl_flag) || (data->dstl_hdr_flag && data->dst_fl_flag)) {
      ip6data_update (data->exthdr_type, data);
    }
  }

  return (EXIT_SUCCESS);
}

// View destination header (first) options.
int
on_button106_clicked (GtkButton *button106, SPSData *data)
{
  (void) button106;  // This statement suppresses compiler warning about unused parameter.

  dsthop_opt_view (0, data);

  return (EXIT_SUCCESS);
}

// View destination header (last) options.
int
on_button109_clicked (GtkButton *button109, SPSData *data)
{
  (void) button109;  // This statement suppresses compiler warning about unused parameter.

  dsthop_opt_view (1, data);

  return (EXIT_SUCCESS);
}

// Number of destination option to remove.
int
on_entry432_activate (GtkWidget *entry432, SPSData *data)
{
  dsthop_opt_remove_entry (entry432, &data->dstopt_remove);

  return (EXIT_SUCCESS);
}

// Remove selected destination option.
int
on_button107_clicked (GtkButton *button107, SPSData *data)
{
  (void) button107;  // This statement suppresses compiler warning about unused parameter.

  if (dsthop_option (1, data->dstopt_remove, data->textview25, data->textview27, data) == EXIT_SUCCESS) {

    // Update ethernet frame if destination header is attached.
    if ((data->dstf_hdr_flag && !data->dst_fl_flag) || (data->dstl_hdr_flag && data->dst_fl_flag)) {

      // If number of options in now zero, detach header.

      // First header
      if (!data->dst_fl_flag && !data->dstf_nopt[data->exthdr_type]) {
        data->dstf_hdr_flag[data->exthdr_type] = 0;

      // Last header
      } else if (data->dst_fl_flag && !data->dstl_nopt[data->exthdr_type]) {
        data->dstl_hdr_flag[data->exthdr_type] = 0;
      }

      ip6data_update (data->exthdr_type, data);
    }

    // Update destination header length in dst_window.
    dst_show (data->exthdr_type, data);
  }

  return (EXIT_SUCCESS);
}

// Routing header

// Toggle: attach / detach a routing header
int
on_button145_clicked (GtkButton *button145, SPSData *data)
{
  (void) button145;  // This statement suppresses compiler warning about unused parameter.
  GtkTextBuffer *textbuffer50;

  textbuffer50 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview50));

  // Don't attach a routing header.
  if (data->route_hdr_flag[data->exthdr_type]) {
    data->route_hdr_flag[data->exthdr_type] = 0;
    gtk_text_buffer_set_text (textbuffer50, "Not Attached", -1);

  // Attach a routing header.
  } else {
    // Abort if there is no routing data.
    if (!data->route_datlen[data->exthdr_type]) {
      data->route_hdr_flag[data->exthdr_type] = 0;
      gtk_text_buffer_set_text (textbuffer50, "Not Attached", -1);
      sprintf (data->error_text, "In on_button145_clicked: Cannot attach a routing header since no routing data was specified.");
      data->parent = data->route_window;
      report_error (data);
      return (EXIT_FAILURE);
    } else {
      data->route_hdr_flag[data->exthdr_type] = 1;
      gtk_text_buffer_set_text (textbuffer50, "Attached", -1);
    }
  }

  // Update ethernet frame and route_window widgets.
  ip6data_update (data->exthdr_type, data);

  return (EXIT_SUCCESS);
}

// Set route_flag to zero when route_window is destroyed.
int
on_route_window_destroy (GtkWidget *widget, SPSData *data)
{
  (void) widget;  // This statement suppresses compiler warning about unused parameter.

  data->route_flag = 0;

  return (EXIT_SUCCESS);
}

// Header length (8 bits)
int
on_entry446_activate (GtkWidget *entry446, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry446));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 255)) {
    sprintf (value, "%" PRIu8, (uint8_t) data->routehdr[data->exthdr_type].hdr_len);
    gtk_entry_set_text (GTK_ENTRY (entry446), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->routehdr[data->exthdr_type].hdr_len = (uint8_t) ascii_to_int64 ((char *) entry_text);  // Update with new value

    // Update ethernet frame and route_window widgets.
    ip6data_update (data->exthdr_type, data);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Routing type (8 bits)
int
on_entry447_activate (GtkWidget *entry447, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry447));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 255)) {
    sprintf (value, "%" PRIu8, (uint8_t) data->routehdr[data->exthdr_type].routing_type);
    gtk_entry_set_text (GTK_ENTRY (entry447), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->routehdr[data->exthdr_type].routing_type = (uint8_t) ascii_to_int64 ((char *) entry_text);  // Update with new value

    // Update ethernet frame and route_window widgets.
    ip6data_update (data->exthdr_type, data);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Segments left (8 bits)
int
on_entry448_activate (GtkWidget *entry448, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry448));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 255)) {
    sprintf (value, "%" PRIu8, (uint8_t) data->routehdr[data->exthdr_type].segs_left);
    gtk_entry_set_text (GTK_ENTRY (entry448), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->routehdr[data->exthdr_type].segs_left = (uint8_t) ascii_to_int64 ((char *) entry_text);  // Update with new value

    // Update ethernet frame and route_window widgets.
    ip6data_update (data->exthdr_type, data);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Decimal routing data entry
int
on_radiobutton73_toggled (GtkButton *radiobutton73, SPSData *data)
{
  (void) radiobutton73;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_route = 0;

  return (EXIT_SUCCESS);
}

// Hexadecimal routing data entry
int
on_radiobutton74_toggled (GtkButton *radiobutton74, SPSData *data)
{
  (void) radiobutton74;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_route = 1;

  return (EXIT_SUCCESS);
}

// Routing data (variable length)
int
on_entry449_activate (GtkWidget *entry449, SPSData *data)
{
  if (data_entry (entry449, &data->route_datlen[data->exthdr_type], MAX_ROUTEDATA, data->route_data[data->exthdr_type], data->dec_hex_route, data->route_window, data) == EXIT_SUCCESS) {

    // Update routing header length.
    update_route_len (data->exthdr_type, data);

    // If routing header is attached, update IPv6 parameters, routing header editing window, and ethernet frames.
    data->dec_hex_route = 0;  // Set to decimal entry since contents will be displayed as decimal by route_show().
    if (data->route_hdr_flag[data->exthdr_type]) {
      ip6data_update (data->exthdr_type, data);

    // Otherwise, just update widgets in routing header editing window.
    } else {
      route_show (data->exthdr_type, data);
    }
  }

  return (EXIT_SUCCESS);
}

// Load routing data from file (variable length)
int
on_button125_clicked (GtkButton *button125, SPSData *data)
{
  (void) button125;  // This statement suppresses compiler warning about unused parameter.

  if (file_data (data->entry449, &data->route_datlen[data->exthdr_type], MAX_ROUTEDATA, data->route_data[data->exthdr_type], data->exthdr_type, data->route_window, data) == EXIT_SUCCESS) {

    // Update routing header length.
    update_route_len (data->exthdr_type, data);

    // If routing header is attached, update IPv6 parameters, routing header editing window, and ethernet frames.
    data->dec_hex_route = 0;  // Set to decimal entry since contents will be displayed as decimal by route_show().
    if (data->route_hdr_flag[data->exthdr_type]) {
      ip6data_update (data->exthdr_type, data);

    // Otherwise, just update widgets in routing header editing window.
    } else {
      route_show (data->exthdr_type, data);
    }
  }

  return (EXIT_SUCCESS);
}

// Authentication header

// Toggle: attach / detach an authentication header
int
on_button138_clicked (GtkButton *button138, SPSData *data)
{
  (void) button138;  // This statement suppresses compiler warning about unused parameter.
  GtkTextBuffer *textbuffer43, *textbuffer45;

  // *****************************************************************
  // NOTE: Here we choose not to allow both AH and ESP on same packet.
  //       ESP alone is generally considered sufficient since it
  //       provides both authentication and encryption.
  // *****************************************************************

  textbuffer43 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview43));

  if (data->esp_flag) {  // If ESP editing window is open, update status textview.
    textbuffer45 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview45));
    gtk_text_buffer_set_text (textbuffer45, "Not Attached", -1);
  }
  data->esp_hdr_flag[data->exthdr_type] = 0;  // Detach ESP header from packet.

  // Don't attach an authentication header.
  if (data->auth_hdr_flag[data->exthdr_type]) {
    data->auth_hdr_flag[data->exthdr_type] = 0;
    gtk_text_buffer_set_text (textbuffer43, "Not Attached", -1);

  // Attach an authentication header.
  } else {
    // Abort if there is no authentication data.
    if (!data->auth_len[data->exthdr_type]) {
      data->auth_hdr_flag[data->exthdr_type] = 0;
      gtk_text_buffer_set_text (textbuffer43, "Not Attached", -1);
      sprintf (data->error_text, "In on_button138_clicked: Cannot attach an authentication header since none was specified.");
      data->parent = data->auth_window;
      report_error (data);
      return (EXIT_FAILURE);
    } else {
      data->auth_hdr_flag[data->exthdr_type] = 1;
      gtk_text_buffer_set_text (textbuffer43, "Attached", -1);
    }
  }

  // Update ethernet frame and auth_window widgets.
  ip6data_update (data->exthdr_type, data);

  return (EXIT_SUCCESS);
}

// Set auth_flag to zero when auth_window is destroyed.
int
on_auth_window_destroy (GtkWidget *widget, SPSData *data)
{
  (void) widget;  // This statement suppresses compiler warning about unused parameter.

  data->auth_flag = 0;

  return (EXIT_SUCCESS);
}

// Toggle: transport / tunnel mode
int
on_button139_clicked (GtkButton *button139, SPSData *data)
{
  (void) button139;  // This statement suppresses compiler warning about unused parameter.
  GtkTextBuffer *textbuffer44;

  textbuffer44 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview44));
  if (data->auth_tr_tun_flag[data->exthdr_type]) {
    data->auth_tr_tun_flag[data->exthdr_type] = 0;
    gtk_text_buffer_set_text (textbuffer44, "Transport mode", -1);
  } else {
    data->auth_tr_tun_flag[data->exthdr_type] = 1;
    gtk_text_buffer_set_text (textbuffer44, "Tunnel mode", -1);
  }

  // If an authentication header is attached, update ethernet frames.
  if (data->auth_hdr_flag[data->exthdr_type]) {
    ip6data_update (data->exthdr_type, data);
  }

  return (EXIT_SUCCESS);
}

// Payload length (8 bits)
int
on_entry433_activate (GtkWidget *entry433, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry433));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 255)) {
    sprintf (value, "%" PRIu8, (uint8_t) data->authhdr[data->exthdr_type].pay_len);
    gtk_entry_set_text (GTK_ENTRY (entry433), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->authhdr[data->exthdr_type].pay_len = (uint8_t) ascii_to_int64 ((char *) entry_text);  // Update with new value

    // Update ethernet frame and auth_window widgets.
    ip6data_update (data->exthdr_type, data);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Reserved (16 bits)
int
on_entry434_activate (GtkWidget *entry434, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry434));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 65535)) {
    sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->authhdr[data->exthdr_type].reserved));
    gtk_entry_set_text (GTK_ENTRY (entry434), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->authhdr[data->exthdr_type].reserved = htons ((uint16_t) ascii_to_int64 ((char *) entry_text));  // Update with new value

    // Update ethernet frame and auth_window widgets.
    ip6data_update (data->exthdr_type, data);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Security parameters index (SPI) (32 bits)
int
on_entry435_activate (GtkWidget *entry435, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry435));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) >= 0xffffffffl)) {
    sprintf (value, "%" PRIu32, (uint32_t) ntohl (data->authhdr[data->exthdr_type].spi));
    gtk_entry_set_text (GTK_ENTRY (entry435), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->authhdr[data->exthdr_type].spi = htonl ((uint32_t) ascii_to_int64 ((char *) entry_text));  // Update with new value

    // Update ethernet frame and auth_window widgets.
    ip6data_update (data->exthdr_type, data);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Sequence number (32 bits)
int
on_entry436_activate (GtkWidget *entry436, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry436));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) >= 0xffffffffl)) {
    sprintf (value, "%" PRIu32, (uint32_t) ntohl (data->authhdr[data->exthdr_type].seq));
    gtk_entry_set_text (GTK_ENTRY (entry436), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->authhdr[data->exthdr_type].seq = htonl ((uint32_t) ascii_to_int64 ((char *) entry_text));  // Update with new value

    // Update ethernet frame and auth_window widgets.
    ip6data_update (data->exthdr_type, data);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Decimal integrity check value (ICV) entry
int
on_radiobutton67_toggled (GtkButton *radiobutton67, SPSData *data)
{
  (void) radiobutton67;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_auth = 0;

  return (EXIT_SUCCESS);
}

// Hexadecimal integrity check value (ICV) entry
int
on_radiobutton68_toggled (GtkButton *radiobutton68, SPSData *data)
{
  (void) radiobutton68;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_auth = 1;

  return (EXIT_SUCCESS);
}

// Integrity check value (ICV) (variable length)
int
on_entry437_activate (GtkWidget *entry437, SPSData *data)
{
  data_entry (entry437, &data->auth_len[data->exthdr_type], MAX_AUTHICVLEN, data->auth_data[data->exthdr_type], data->dec_hex_auth, data->auth_window, data);

  // Update authentication header payload and padding length.
  update_auth_pad (data->exthdr_type, data);

  // If authentication header is attached, update IPv6 parameters and ethernet frames.
  if (data->auth_hdr_flag[data->exthdr_type]) {
    ip6data_update (data->exthdr_type, data);

  // Otherwise, just update widgets in authentication header editing window.
  } else {
    auth_show (data->exthdr_type, data);
  }

  return (EXIT_SUCCESS);
}

// Load ICV from file ...
int
on_button108_clicked (GtkButton *button108, SPSData *data)
{
  (void) button108;  // This statement suppresses compiler warning about unused parameter.

  file_data (data->entry437, &data->auth_len[data->exthdr_type], MAX_AUTHICVLEN, data->auth_data[data->exthdr_type], data->exthdr_type, data->auth_window, data);

  // Update authentication header payload and padding length.
  update_auth_pad (data->exthdr_type, data);

  // If authentication header is attached, update IPv6 parameters and ethernet frames.
  if (data->auth_hdr_flag[data->exthdr_type]) {
    ip6data_update (data->exthdr_type, data);

  // Otherwise, just update widgets in authentication header editing window.
  } else {
    auth_show (data->exthdr_type, data);
  }

  return (EXIT_SUCCESS);
}

// Save data for ICV calculation
int
on_button122_clicked (GtkButton *button122, SPSData *data)
{
  (void) button122;  // This statement suppresses compiler warning about unused parameter.

  int i, j, result;
  struct ip6_hdr ip6hdr, newip6hdr;
  GtkWidget *dialog;
  char *filename, *text;
  uint8_t *buffer;
  FILE *fo;

  // Array for error messages.
  text = allocate_strmem (TEXT_STRINGLEN);

  // Create filechooser dialog.
  dialog = gtk_file_chooser_dialog_new ("Save File ...", (GtkWindow *) data->main_window, GTK_FILE_CHOOSER_ACTION_SAVE,
             "_Cancel", GTK_RESPONSE_CANCEL, "_Save", GTK_RESPONSE_ACCEPT, NULL);
  gtk_file_chooser_set_do_overwrite_confirmation (GTK_FILE_CHOOSER (dialog), TRUE);

  // Run the filechooser dialog.
  result = gtk_dialog_run (GTK_DIALOG (dialog));

  // Interpret result returned from filechooser dialog.
  if (result == GTK_RESPONSE_ACCEPT)
  {
    filename = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (dialog));
    gtk_widget_destroy (dialog);
  } else {
    free (text);
    gtk_widget_destroy (dialog);
    return (EXIT_SUCCESS);
  }

  // Open output file.
  if ((fo = fopen (filename, "wb")) == NULL) {
    sprintf (data->error_text, "In callbacks.c: fopen() failed in on_button122_clicked().");
    data->parent = data->main_window;
    report_error (data);
    free (text);
    return (EXIT_FAILURE);
  }

  // Save entire packet with mutable fields and authentication data field (ICV) set to zero.
  // Section 3.3.3.1 of RFC 2402.

  // Copy IPv6 headers so we don't corrupt originals.
  memcpy (&ip6hdr, &data->ip6hdr[data->exthdr_type], IP6_HDRLEN * sizeof (uint8_t));
  memcpy (&newip6hdr, &data->ip6hdr[data->exthdr_type+20], IP6_HDRLEN * sizeof (uint8_t));

  // If in tunnel mode, include "new" IPv6 header and place AH header immediately after it.
  if (data->auth_tr_tun_flag[data->exthdr_type]) {

    // "New" IPv6 header
    newip6hdr.ip6_flow = htonl ((ntohl (newip6hdr.ip6_flow) >> 28) << 28);  // Set mutable fields to zero.
    buffer = (uint8_t *) &newip6hdr;
    for (i=0; i<IP6_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Authentication header, excluding authentication data
    buffer = (uint8_t *) &data->authhdr[data->exthdr_type];
    for (i=0; i<ATH_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Authentication header data: set to zero for ICV calculation
    for (i=0; i<data->auth_len[data->exthdr_type]; i++) {
      fputc (0, fo);
    }

  }  // End if tunnel mode

  // IPv6 header
  ip6hdr.ip6_flow = htonl ((ntohl (ip6hdr.ip6_flow) >> 28) << 28);  // Set mutable fields to zero.
  buffer = (uint8_t *) &ip6hdr;
  for (i=0; i<IP6_HDRLEN; i++) {
    fputc (buffer[i], fo);
  }

  // Hop-by-hop header
  if (data->hbh_hdr_flag[data->exthdr_type]) {

    // Hop-by-hop header, excluding options and padding
    buffer = (uint8_t *) &data->hophdr[data->exthdr_type];
    for (i=0; i<HOP_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Hop-by-hop options
    for (i=0; i<data->hbh_nopt[data->exthdr_type]; i++) {

      // Alignment padding
      for (j=0; j<data->hbh_optleadpadlen[data->exthdr_type][i]; j++) {
        fputc (data->hbh_optleadpad[data->exthdr_type][i][j], fo);
      }

      // Option
      for (j=0; j<data->hbh_optlen[data->exthdr_type][i]; j++) {
        fputc (data->hbh_options[data->exthdr_type][i][j], fo);
      }

      // Trailing padding
      for (j=0; j<data->hbh_opttailpadlen[data->exthdr_type]; j++) {
        fputc (data->hbh_opttailpad[data->exthdr_type][j], fo);
      }
    }
  }  // End if hop-by-hop header

  // Destination header (first)
  if (data->dstf_hdr_flag[data->exthdr_type]) {

    // Destination header
    buffer = (uint8_t *) &data->dstfhdr[data->exthdr_type];
    for (i=0; i<DST_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Destination header options
    for (i=0; i<data->dstf_nopt[data->exthdr_type]; i++) {

      // Alignment padding
      for (j=0; j<data->dstf_optleadpadlen[data->exthdr_type][i]; j++) {
        fputc (data->dstf_optleadpad[data->exthdr_type][i][j], fo);
      }

      // Destination option
      for (j=0; j<data->dstf_optlen[data->exthdr_type][i]; j++) {
        fputc (data->dstf_options[data->exthdr_type][i][j], fo);
      }
    }

    // Trailing padding
    for (j=0; j<data->dstf_opttailpadlen[data->exthdr_type]; j++) {
      fputc (data->dstf_opttailpad[data->exthdr_type][j], fo);
    }
  }  // End if destination header (first)

  // Routing header
  if (data->route_hdr_flag[data->exthdr_type]) {

    // Routing header, excluding routing data
    buffer = (uint8_t *) &data->routehdr[data->exthdr_type];
    for (i=0; i<RTE_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Routing header data
    for (i=0; i<data->route_datlen[data->exthdr_type]; i++) {
      fputc (data->route_data[data->exthdr_type][i], fo);
    }
  }  // End if routing header

  // If not in tunnel mode, place AH header here.
  if (!data->auth_tr_tun_flag[data->exthdr_type]) {

    // Authentication header, excluding authentication data
    buffer = (uint8_t *) &data->authhdr[data->exthdr_type];
    for (i=0; i<ATH_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Authentication header data: set to zero for ICV calculation
    for (i=0; i<data->auth_len[data->exthdr_type]; i++) {
      fputc (0, fo);
    }

  }  // End if tunnel mode

  // Destination header (last)
  if (data->dstl_hdr_flag[data->exthdr_type]) {

    // Destination header
    buffer = (uint8_t *) &data->dstlhdr[data->exthdr_type];
    for (i=0; i<DST_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Destination header options
    for (i=0; i<data->dstl_nopt[data->exthdr_type]; i++) {

      // Alignment padding
      for (j=0; j<data->dstl_optleadpadlen[data->exthdr_type][i]; j++) {
        fputc (data->dstl_optleadpad[data->exthdr_type][i][j], fo);
      }

      // Destination option
      for (j=0; j<data->dstl_optlen[data->exthdr_type][i]; j++) {
        fputc (data->dstl_options[data->exthdr_type][i][j], fo);
      }
    }

    // Trailing padding
    for (j=0; j<data->dstl_opttailpadlen[data->exthdr_type]; j++) {
      fputc (data->dstl_opttailpad[data->exthdr_type][j], fo);
    }
  }  // End if destination header (last)

  // TCP header, options, and padding
  if ((data->exthdr_type == 3) || (data->exthdr_type == 9)) {

    // TCP header
    buffer = (uint8_t *) &data->tcphdr[data->exthdr_type];
    for (i=0; i<TCP_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // TCP options
    for (i=0; i<data->tcp_nopt[data->exthdr_type]; i++) {
      for (j=0; j<data->tcp_optlen[data->exthdr_type][i]; j++) {
        fputc (data->tcp_options[data->exthdr_type][i][j], fo);
      }
    }

    // TCP options padding
    for (i=0; i<data->tcp_optpadlen[data->exthdr_type]; i++) {
      fputc (0, fo);
    }

  // ICMP header
  } else if ((data->exthdr_type == 4) || (data->exthdr_type == 10)) {
    buffer = (uint8_t *) &data->icmp6hdr[data->exthdr_type];
    for (i=0; i<ICMP_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }


  // UDP header
  } else if ((data->exthdr_type == 5) || (data->exthdr_type == 1)) {
    buffer = (uint8_t *) &data->udphdr[data->exthdr_type];
    for (i=0; i<UDP_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }
  }

  // Upper layer protocol payload data
  for (i=0; i<data->payloadlen[data->exthdr_type]; i++) {
    fputc (data->payload[data->exthdr_type][i], fo);
  }

  // Close file descriptor.
  fclose (fo);

  // Free allocated memory.
  free (text);

  return (EXIT_SUCCESS);
}

// Encapsulating security payload (ESP) header

// Toggle: attach / detach an ESP header
int
on_button140_clicked (GtkButton *button140, SPSData *data)
{
  (void) button140;  // This statement suppresses compiler warning about unused parameter.
  GtkTextBuffer *textbuffer45, *textbuffer43;

  // *****************************************************************
  // NOTE: Here we choose not to allow both AH and ESP on same packet.
  //       ESP alone is generally considered sufficient since it
  //       provides both authentication and encryption.
  // *****************************************************************

  textbuffer45 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview45));

  if (data->auth_flag) {  // If authentication editing window is open, update status textview.
    textbuffer43 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview43));
    gtk_text_buffer_set_text (textbuffer43, "Not Attached", -1);
  }
  data->auth_hdr_flag[data->exthdr_type] = 0;  // Detach authentication header from packet.

  // Don't attach an ESP header.
  if (data->esp_hdr_flag[data->exthdr_type]) {
    data->esp_hdr_flag[data->exthdr_type] = 0;
    gtk_text_buffer_set_text (textbuffer45, "Not Attached", -1);

  // Attach an ESP header.
  } else {
    // Abort if there is no ESP data.
    if (!data->esp_auth_len[data->exthdr_type]) {
      data->esp_hdr_flag[data->exthdr_type] = 0;
      gtk_text_buffer_set_text (textbuffer45, "Not Attached", -1);
      sprintf (data->error_text, "In on_button140_clicked: Cannot attach an ESP header since none was specified.");
      data->parent = data->esp_window;
      report_error (data);
      return (EXIT_FAILURE);
    } else {
      data->esp_hdr_flag[data->exthdr_type] = 1;
      gtk_text_buffer_set_text (textbuffer45, "Attached", -1);
    }
  }

  // Update ethernet frame and esp_window widgets.
  ip6data_update (data->exthdr_type, data);

  return (EXIT_SUCCESS);
}

// Set esp_flag to zero when esp_window is destroyed.
int
on_esp_window_destroy (GtkWidget *widget, SPSData *data)
{
  (void) widget;  // This statement suppresses compiler warning about unused parameter.

  data->esp_flag = 0;

  return (EXIT_SUCCESS);
}

// Toggle: transport / tunnel mode
int
on_button141_clicked (GtkButton *button141, SPSData *data)
{
  (void) button141;  // This statement suppresses compiler warning about unused parameter.
  GtkTextBuffer *textbuffer46;

  textbuffer46 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview46));
  if (data->esp_tr_tun_flag[data->exthdr_type]) {
    data->esp_tr_tun_flag[data->exthdr_type] = 0;
    gtk_text_buffer_set_text (textbuffer46, "Transport mode", -1);
  } else {
    data->esp_tr_tun_flag[data->exthdr_type] = 1;
    gtk_text_buffer_set_text (textbuffer46, "Tunnel mode", -1);
  }

  // If an ESP header is attached, update ethernet frames.
  if (data->esp_hdr_flag[data->exthdr_type]) {
    ip6data_update (data->exthdr_type, data);
  }

  return (EXIT_SUCCESS);
}

// Security parameters index (SPI) (32 bits)
int
on_entry441_activate (GtkWidget *entry441, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry441));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) >= 0xffffffffl)) {
    sprintf (value, "%" PRIu32, (uint32_t) ntohl (data->esphdr[data->exthdr_type].spi));
    gtk_entry_set_text (GTK_ENTRY (entry441), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->esphdr[data->exthdr_type].spi = htonl ((uint32_t) ascii_to_int64 ((char *) entry_text));  // Update with new value

    // Update ethernet frame and esp_window widgets.
    ip6data_update (data->exthdr_type, data);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Sequence number (32 bits)
int
on_entry442_activate (GtkWidget *entry442, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry442));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) >= 0xffffffffl)) {
    sprintf (value, "%" PRIu32, (uint32_t) ntohl (data->esphdr[data->exthdr_type].seq));
    gtk_entry_set_text (GTK_ENTRY (entry442), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->esphdr[data->exthdr_type].seq = htonl ((uint32_t) ascii_to_int64 ((char *) entry_text));  // Update with new value

    // Update ethernet frame and esp_window widgets.
    ip6data_update (data->exthdr_type, data);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Save data for ICV calculation
int
on_button123_clicked (GtkButton *button123, SPSData *data)
{
  (void) button123;  // This statement suppresses compiler warning about unused parameter.

  int i, j, result;
  GtkWidget *dialog;
  char *filename, *text;
  uint8_t *buffer;
  FILE *fo;

  // Array for error messages.
  text = allocate_strmem (TEXT_STRINGLEN);

  // Create filechooser dialog.
  dialog = gtk_file_chooser_dialog_new ("Save File ...", (GtkWindow *) data->main_window, GTK_FILE_CHOOSER_ACTION_SAVE,
             "_Cancel", GTK_RESPONSE_CANCEL, "_Save", GTK_RESPONSE_ACCEPT, NULL);
  gtk_file_chooser_set_do_overwrite_confirmation (GTK_FILE_CHOOSER (dialog), TRUE);

  // Run the filechooser dialog.
  result = gtk_dialog_run (GTK_DIALOG (dialog));

  // Interpret result returned from filechooser dialog.
  if (result == GTK_RESPONSE_ACCEPT)
  {
    filename = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (dialog));
    gtk_widget_destroy (dialog);
  } else {
    free (text);
    gtk_widget_destroy (dialog);
    return (EXIT_SUCCESS);
  }

  // Open output file.
  if ((fo = fopen (filename, "wb")) == NULL) {
    sprintf (data->error_text, "In callbacks.c: fopen() failed in on_button123_clicked().");
    data->parent = data->main_window;
    report_error (data);
    free (text);
    return (EXIT_FAILURE);
  }

  // Save ESP packet minus authentication data.
  // Section 3.3.4 of RFC 2406.

  // ESP header, excluding payload data, ESP tail, and auth. data
  buffer = (uint8_t *) &data->esphdr[data->exthdr_type];
  for (i=0; i<ESP_HDRLEN; i++) {
    fputc (buffer[i], fo);
  }

  // If in tunnel mode, write IPv6 header and all extension headers present.
  if (data->esp_tr_tun_flag[data->exthdr_type]) {

    // IPv6 header
    buffer = (uint8_t *) &data->ip6hdr[data->exthdr_type];
    for (i=0; i<IP6_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Hop-by-hop header
    if (data->hbh_hdr_flag[data->exthdr_type]) {

      // Hop-by-hop header, excluding options and padding
      buffer = (uint8_t *) &data->hophdr[data->exthdr_type];
      for (i=0; i<HOP_HDRLEN; i++) {
        fputc (buffer[i], fo);
      }

      // Hop-by-hop options
      for (i=0; i<data->hbh_nopt[data->exthdr_type]; i++) {

        // Alignment padding
        for (j=0; j<data->hbh_optleadpadlen[data->exthdr_type][i]; j++) {
          fputc (data->hbh_optleadpad[data->exthdr_type][i][j], fo);
        }

        // Option
        for (j=0; j<data->hbh_optlen[data->exthdr_type][i]; j++) {
          fputc (data->hbh_options[data->exthdr_type][i][j], fo);
        }

        // Trailing padding
        for (j=0; j<data->hbh_opttailpadlen[data->exthdr_type]; j++) {
          fputc (data->hbh_opttailpad[data->exthdr_type][j], fo);
        }
      }
    }  // End if hop-by-hop header

    // Destination header (first)
    if (data->dstf_hdr_flag[data->exthdr_type]) {

      // Destination header
      buffer = (uint8_t *) &data->dstfhdr[data->exthdr_type];
      for (i=0; i<DST_HDRLEN; i++) {
        fputc (buffer[i], fo);
      }

      // Destination header options
      for (i=0; i<data->dstf_nopt[data->exthdr_type]; i++) {

        // Alignment padding
        for (j=0; j<data->dstf_optleadpadlen[data->exthdr_type][i]; j++) {
          fputc (data->dstf_optleadpad[data->exthdr_type][i][j], fo);
        }

        // Destination option
        for (j=0; j<data->dstf_optlen[data->exthdr_type][i]; j++) {
          fputc (data->dstf_options[data->exthdr_type][i][j], fo);
        }
      }

      // Trailing padding
      for (j=0; j<data->dstf_opttailpadlen[data->exthdr_type]; j++) {
        fputc (data->dstf_opttailpad[data->exthdr_type][j], fo);
      }
    }  // End if destination header (first)

    // Routing header
    if (data->route_hdr_flag[data->exthdr_type]) {

      // Routing header, excluding routing data
      buffer = (uint8_t *) &data->routehdr[data->exthdr_type];
      for (i=0; i<RTE_HDRLEN; i++) {
        fputc (buffer[i], fo);
      }

      // Routing header data
      for (i=0; i<data->route_datlen[data->exthdr_type]; i++) {
        fputc (data->route_data[data->exthdr_type][i], fo);
      }
    }  // End if routing header

  }  // End if tunnel mode

  // Destination header (last)
  if (data->dstl_hdr_flag[data->exthdr_type]) {

    // Destination header
    buffer = (uint8_t *) &data->dstlhdr[data->exthdr_type];
    for (i=0; i<DST_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // Destination header options
    for (i=0; i<data->dstl_nopt[data->exthdr_type]; i++) {

      // Alignment padding
      for (j=0; j<data->dstl_optleadpadlen[data->exthdr_type][i]; j++) {
        fputc (data->dstl_optleadpad[data->exthdr_type][i][j], fo);
      }

      // Destination option
      for (j=0; j<data->dstl_optlen[data->exthdr_type][i]; j++) {
        fputc (data->dstl_options[data->exthdr_type][i][j], fo);
      }
    }

    // Trailing padding
    for (j=0; j<data->dstl_opttailpadlen[data->exthdr_type]; j++) {
      fputc (data->dstl_opttailpad[data->exthdr_type][j], fo);
    }
  }  // End if destination header (last)

  // TCP header, options, and padding
  if ((data->exthdr_type == 3) || (data->exthdr_type == 9)) {

    // TCP header
    buffer = (uint8_t *) &data->tcphdr[data->exthdr_type];
    for (i=0; i<TCP_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }

    // TCP options
    for (i=0; i<data->tcp_nopt[data->exthdr_type]; i++) {
      for (j=0; j<data->tcp_optlen[data->exthdr_type][i]; j++) {
        fputc (data->tcp_options[data->exthdr_type][i][j], fo);
      }
    }

    // TCP options padding
    for (i=0; i<data->tcp_optpadlen[data->exthdr_type]; i++) {
      fputc (0, fo);
    }

  // ICMP header
  } else if ((data->exthdr_type == 4) || (data->exthdr_type == 10)) {
    buffer = (uint8_t *) &data->icmp6hdr[data->exthdr_type];
    for (i=0; i<ICMP_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }


  // UDP header
  } else if ((data->exthdr_type == 5) || (data->exthdr_type == 1)) {
    buffer = (uint8_t *) &data->udphdr[data->exthdr_type];
    for (i=0; i<UDP_HDRLEN; i++) {
      fputc (buffer[i], fo);
    }
  }

  // Upper layer protocol payload data
  for (i=0; i<data->payloadlen[data->exthdr_type]; i++) {
    fputc (data->payload[data->exthdr_type][i], fo);
  }

  // Encapsulating security payload trailer (transport and tunnel mode)
  // Here we need to insert the ESP payload padding as well.

  // ESP payload padding
  for (i=0; i<data->esptail[data->exthdr_type].pad_len; i++) {
    fputc (data->esp_pad[data->exthdr_type][i], fo);
  }

  // ESP trailer
  buffer = (uint8_t *) &data->esptail[data->exthdr_type];
  for (i=0; i<ESP_TAILLEN; i++) {
    fputc (buffer[i], fo);
  }

  // Close file descriptor.
  fclose (fo);

  // Free allocated memory.
  free (text);

  return (EXIT_SUCCESS);
}

// Padding length (8 bits)
int
on_entry443_activate (GtkWidget *entry443, SPSData *data)
{
  int i;
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry443));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 255)) {
    sprintf (value, "%" PRIu8, (uint8_t) data->esptail[data->exthdr_type].pad_len);
    gtk_entry_set_text (GTK_ENTRY (entry443), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->esptail[data->exthdr_type].pad_len = (uint8_t) ascii_to_int64 ((char *) entry_text);  // Revise ESP trailer with new value
    for (i=0; i<data->esptail[data->exthdr_type].pad_len; i++) {
      data->esp_pad[data->exthdr_type][i] = (unsigned char) (i + 1u);  // Add padding (Section 2.4 of RFC 2406).
    }

    // Update ethernet frame and esp_window widgets.
    ip6data_update (data->exthdr_type, data);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Next header (8 bits)
int
on_entry444_activate (GtkWidget *entry444, SPSData *data)
{
  const char *entry_text;
  char *value;
  
  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);
  
  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry444));
  
  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 255)) {
    sprintf (value, "%" PRIu8, (uint8_t) data->esptail[data->exthdr_type].nxt_hdr);
    gtk_entry_set_text (GTK_ENTRY (entry444), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);
    
  // Value is in acceptable range.
  } else {
    data->esptail[data->exthdr_type].nxt_hdr = (uint8_t) ascii_to_int64 ((char *) entry_text);  // Update with new value

    // Update ethernet frame and esp_window widgets.
    ip6data_update (data->exthdr_type, data);
  } 
    
  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Decimal integrity check value (ICV) entry
int
on_radiobutton71_toggled (GtkButton *radiobutton71, SPSData *data)
{
  (void) radiobutton71;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_esp = 0;

  return (EXIT_SUCCESS);
}

// Hexadecimal integrity check value (ICV) entry
int
on_radiobutton72_toggled (GtkButton *radiobutton72, SPSData *data)
{
  (void) radiobutton72;  // This statement suppresses compiler warning about unused parameter.

  data->dec_hex_esp = 1;

  return (EXIT_SUCCESS);
}

// Integrity check value (ICV) (variable length)
int
on_entry445_activate (GtkWidget *entry445, SPSData *data)
{
  data_entry (entry445, &data->esp_auth_len[data->exthdr_type], MAX_ESPICVLEN, data->esp_auth_data[data->exthdr_type], data->dec_hex_esp, data->esp_window, data);

  // Update ESP header payload and padding length.
  update_esp_pad (data->exthdr_type, data);

  // If ESP header is attached, update IPv6 parameters and ethernet frames.
  if (data->esp_hdr_flag[data->exthdr_type]) {
    ip6data_update (data->exthdr_type, data);

  // Otherwise, just update widgets in ESP header editing window.
  } else {
    esp_show (data->exthdr_type, data);
  }

  return (EXIT_SUCCESS);
}

// Load ICV from file ...
int
on_button124_clicked (GtkButton *button124, SPSData *data)
{
  (void) button124;  // This statement suppresses compiler warning about unused parameter.

  file_data (data->entry445, &data->esp_auth_len[data->exthdr_type], MAX_ESPICVLEN, data->esp_auth_data[data->exthdr_type], data->exthdr_type, data->esp_window, data);

  // Update ESP header payload and padding length.
  update_esp_pad (data->exthdr_type, data);

  // If ESP header is attached, update IPv6 parameters and ethernet frames.
  if (data->esp_hdr_flag[data->exthdr_type]) {
    ip6data_update (data->exthdr_type, data);

  // Otherwise, just update widgets in ESP header editing window.
  } else {
    esp_show (data->exthdr_type, data);
  }

  return (EXIT_SUCCESS);
}
