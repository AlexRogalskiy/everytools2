package com.iluwatar.testdomain.family;

public class Husband {
    Wife wife;
}
