/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// IPv4 header length (4 bits)
int
ip4_hdrlen_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 15)) {
    sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[type].ip_hl);
    gtk_entry_set_text (GTK_ENTRY (entry), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->ip4hdr[type].ip_hl = (uint8_t) ascii_to_int64 ((char *) entry_text);  // Update IPv4 header with new value

    // IPv4 header checksum (16 bits)
    ip4_chksum (type, data);

    // Update ethernet frame.
    create_ip4_frame (type, data);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// IP version (4 bits)
int
ip4_ver_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 15)) {
    sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[type].ip_v);
    gtk_entry_set_text (GTK_ENTRY (entry), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->ip4hdr[type].ip_v = (uint8_t) ascii_to_int64 ((char *) entry_text);  // Update IPv4 header with new value

    // IPv4 header checksum (16 bits)
    ip4_chksum (type, data);

    // Update ethernet frame.
    create_ip4_frame (type, data);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Type of service (8 bits)
int
ip4_tos_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 255)) {
    sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[type].ip_tos);
    gtk_entry_set_text (GTK_ENTRY (entry), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->ip4hdr[type].ip_tos = (uint8_t) ascii_to_int64 ((char *) entry_text);  // Update IPv4 header with new value

    // IPv4 header checksum (16 bits)
    ip4_chksum (type, data);

    // Update ethernet frame.
    create_ip4_frame (type, data);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Total length of datagram (16 bits)
int
ip4_tld_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 65535)) {
    sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[type].ip_len));
    gtk_entry_set_text (GTK_ENTRY (entry), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->ip4hdr[type].ip_len = htons ((uint16_t) ascii_to_int64 ((char *) entry_text));  // Update IPv4 header with new value

    // IPv4 header checksum (16 bits)
    ip4_chksum (type, data);

    // Update ethernet frame.
    create_ip4_frame (type, data);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// ID sequence number (16 bits)
int
ip4_seq_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 65535)) {
    sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[type].ip_id));
    gtk_entry_set_text (GTK_ENTRY (entry), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->ip4hdr[type].ip_id = htons ((uint16_t) ascii_to_int64 ((char *) entry_text));  // Update IPv4 header with new value

    // IPv4 header checksum (16 bits)
    ip4_chksum (type, data);

    // Update ethernet frame.
    create_ip4_frame (type, data);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Zero (1 bit)
int
ip4_zero_entry (GtkWidget *entry0, GtkWidget *entry1, GtkWidget *entry2, GtkWidget *entry3, int type, SPSData *data)
{
  const char *entry0_text, *entry1_text, *entry2_text, *entry3_text;
  uint16_t *ip_flags;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // IP header fragmentation flags and offset
  ip_flags = allocate_u2strmem (4);

  // Get new value from text entry
  entry0_text = gtk_entry_get_text (GTK_ENTRY (entry0));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry0_text) || (ascii_to_int64 ((char *) entry0_text) > 1)) {
    sprintf (value, "%" PRIu8, (uint8_t) (ntohs (data->ip4hdr[type].ip_off) >> 15));
    gtk_entry_set_text (GTK_ENTRY (entry0), value);  // Put old value back into text entry since new one was bad.
    free (value);
    free (ip_flags);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    ip_flags[0] = (uint16_t) ascii_to_int64 ((char *) entry0_text);  // Zero (1 bit)

    entry1_text = gtk_entry_get_text (GTK_ENTRY (entry1));
    ip_flags[1] = (uint16_t) ascii_to_int64 ((char *) entry1_text);  // Do not fragment flag (1 bit)

    entry2_text = gtk_entry_get_text (GTK_ENTRY (entry2));
    ip_flags[2] = (uint16_t) ascii_to_int64 ((char *) entry2_text);  // More fragments following flag (1 bit)

    entry3_text = gtk_entry_get_text (GTK_ENTRY (entry3));
    ip_flags[3] = (uint16_t) ascii_to_int64 ((char *) entry3_text);  // Fragmentation offset (13 bits)

    data->ip4hdr[type].ip_off = htons ((ip_flags[0] << 15) +
                           (ip_flags[1] << 14) +
                           (ip_flags[2] << 13) +
                            ip_flags[3]);

    // IPv4 header checksum (16 bits)
    ip4_chksum (type, data);

    // Update ethernet frame.
    create_ip4_frame (type, data);
  }

  // Free allocated memory.
  free (value);
  free (ip_flags);

  return (EXIT_SUCCESS);
}

// Do not fragment flag (1 bit)
int
ip4_dnf_entry (GtkWidget *entry0, GtkWidget *entry1, GtkWidget *entry2, GtkWidget *entry3, int type, SPSData *data)
{
  const char *entry0_text, *entry1_text, *entry2_text, *entry3_text;
  uint16_t *ip_flags;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // IP header fragmentation flags and offset
  ip_flags = allocate_u2strmem (4);

  // Get new value from text entry
  entry1_text = gtk_entry_get_text (GTK_ENTRY (entry1));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry1_text) || (ascii_to_int64 ((char *) entry1_text) > 1)) {
    sprintf (value, "%" PRIu8, (uint8_t) ((ntohs (data->ip4hdr[type].ip_off) >> 14) & 1u));
    gtk_entry_set_text (GTK_ENTRY (entry1), value);  // Put old value back into text entry since new one was bad.
    free (value);
    free (ip_flags);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    entry0_text = gtk_entry_get_text (GTK_ENTRY (entry0));
    ip_flags[0] = (uint16_t) ascii_to_int64 ((char *) entry0_text);  // Zero (1 bit)

    ip_flags[1] = (uint16_t) ascii_to_int64 ((char *) entry1_text);  // Do not fragment flag (1 bit)

    entry2_text = gtk_entry_get_text (GTK_ENTRY (entry2));
    ip_flags[2] = (uint16_t) ascii_to_int64 ((char *) entry2_text);  // More fragments following flag (1 bit)

    entry3_text = gtk_entry_get_text (GTK_ENTRY (entry3));
    ip_flags[3] = (uint16_t) ascii_to_int64 ((char *) entry3_text);  // Fragmentation offset (13 bits)

    data->ip4hdr[type].ip_off = htons ((ip_flags[0] << 15) +
                           (ip_flags[1] << 14) +
                           (ip_flags[2] << 13) +
                            ip_flags[3]);

    // IPv4 header checksum (16 bits)
    ip4_chksum (type, data);

    // Update ethernet frame.
    create_ip4_frame (type, data);
  }

  // Free allocated memory.
  free (value);
  free (ip_flags);

  return (EXIT_SUCCESS);
}

// More fragments following flag (1 bit)
int
ip4_mff_entry (GtkWidget *entry0, GtkWidget *entry1, GtkWidget *entry2, GtkWidget *entry3, int type, SPSData *data)
{
  const char *entry0_text, *entry1_text, *entry2_text, *entry3_text;
  uint16_t *ip_flags;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // IP header fragmentation flags and offset
  ip_flags = allocate_u2strmem (4);

  // Get new value from text entry
  entry2_text = gtk_entry_get_text (GTK_ENTRY (entry2));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry2_text) || (ascii_to_int64 ((char *) entry2_text) > 1)) {
    sprintf (value, "%" PRIu8, (uint8_t) ((ntohs (data->ip4hdr[type].ip_off) >> 13) & 1u));
    gtk_entry_set_text (GTK_ENTRY (entry2), value);  // Put old value back into text entry since new one was bad.
    free (value);
    free (ip_flags);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    entry0_text = gtk_entry_get_text (GTK_ENTRY (entry0));
    ip_flags[0] = (uint16_t) ascii_to_int64 ((char *) entry0_text);  // Zero (1 bit)

    entry1_text = gtk_entry_get_text (GTK_ENTRY (entry1));
    ip_flags[1] = (uint16_t) ascii_to_int64 ((char *) entry1_text);  // Do not fragment flag (1 bit)

    ip_flags[2] = (uint16_t) ascii_to_int64 ((char *) entry2_text);  // More fragments following flag (1 bit)

    entry3_text = gtk_entry_get_text (GTK_ENTRY (entry3));
    ip_flags[3] = (uint16_t) ascii_to_int64 ((char *) entry3_text);  // Fragmentation offset (13 bits)

    data->ip4hdr[type].ip_off = htons ((ip_flags[0] << 15) +
                           (ip_flags[1] << 14) +
                           (ip_flags[2] << 13) +
                            ip_flags[3]);

    // IPv4 header checksum (16 bits)
    ip4_chksum (type, data);

    // Update ethernet frame.
    create_ip4_frame (type, data);
  }

  // Free allocated memory.
  free (value);
  free (ip_flags);

  return (EXIT_SUCCESS);
}

// Fragmentation offset (13 bits)
int
ip4_fo_entry (GtkWidget *entry0, GtkWidget *entry1, GtkWidget *entry2, GtkWidget *entry3, int type, SPSData *data)
{
  const char *entry0_text, *entry1_text, *entry2_text, *entry3_text;
  uint16_t *ip_flags;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // IP header fragmentation flags and offset
  ip_flags = allocate_u2strmem (4);

  // Get new value from text entry
  entry3_text = gtk_entry_get_text (GTK_ENTRY (entry3));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry3_text) || (ascii_to_int64 ((char *) entry3_text) > 0x1fff)) {
    sprintf (value, "%" PRIu16, (uint16_t) (ntohs (data->ip4hdr[type].ip_off) & 0x1fffu));
    gtk_entry_set_text (GTK_ENTRY (entry3), value);  // Put old value back into text entry since new one was bad.
    free (value);
    free (ip_flags);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    entry0_text = gtk_entry_get_text (GTK_ENTRY (entry0));
    ip_flags[0] = (uint16_t) ascii_to_int64 ((char *) entry0_text);  // Zero (1 bit)

    entry1_text = gtk_entry_get_text (GTK_ENTRY (entry1));
    ip_flags[1] = (uint16_t) ascii_to_int64 ((char *) entry1_text);  // Do not fragment flag (1 bit)

    entry2_text = gtk_entry_get_text (GTK_ENTRY (entry2));
    ip_flags[2] = (uint16_t) ascii_to_int64 ((char *) entry2_text);  // More fragments following flag (1 bit)

    ip_flags[3] = (uint16_t) ascii_to_int64 ((char *) entry3_text);  // Fragmentation offset (13 bits)

    data->ip4hdr[type].ip_off = htons ((ip_flags[0] << 15) +
                           (ip_flags[1] << 14) +
                           (ip_flags[2] << 13) +
                            ip_flags[3]);

    // IPv4 header checksum (16 bits)
    ip4_chksum (type, data);

    // Update ethernet frame.
    create_ip4_frame (type, data);
  }

  // Free allocated memory.
  free (value);
  free (ip_flags);

  return (EXIT_SUCCESS);
}

// Time-to-Live (8 bits)
int
ip4_ttl_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 255)) {
    sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[type].ip_ttl);
    gtk_entry_set_text (GTK_ENTRY (entry), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->ip4hdr[type].ip_ttl = (uint8_t) ascii_to_int64 ((char *) entry_text);  // Update IPv4 header with new value

    // IPv4 header checksum (16 bits)
    ip4_chksum (type, data);

    // Update ethernet frame.
    create_ip4_frame (type, data);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Transport layer protocol (8 bits)
int
ip4_tlp_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 255)) {
    sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[type].ip_p);
    gtk_entry_set_text (GTK_ENTRY (entry), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->ip4hdr[type].ip_p = (uint8_t) ascii_to_int64 ((char *) entry_text);  // Update IPv4 header with new value

    // IPv4 header checksum (16 bits)
    ip4_chksum (type, data);

    // Update ethernet frame.
    switch (type) {
      case 0:  // IPv4 TCP
        tcp_chksum (type, data);  // TCP checksum (16 bits)
        create_ip4_frame (type, data);
        break;
      case 1:  // IPv4 ICMP
        create_ip4_frame (type, data);
        break;
      case 2:  // IPv4 UDP
        udp_chksum (type, data);  // UDP checksum (16 bits)
        create_ip4_frame (type, data);
        break;
      case 9:  // IPv4 TCP for traceroute
        tcp_chksum (type, data);  // TCP checksum (16 bits)
        create_ip4_frame (type, data);
        break;
      case 10:  // IPv4 ICMP for traceroute
        create_ip4_frame (type, data);
        break;
      case 11:  // IPv4 UDP for traceroute
        udp_chksum (type, data);  // UDP checksum (16 bits)
        create_ip4_frame (type, data);
        break;
      default:
        fprintf (stderr, "ERROR: Invalid upper layer protocol type %i in ip4_tlp_entry().\n", type);
        free (value);
        exit (EXIT_FAILURE);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Source IPv4 address (32 bits)
int
ip4_sip_entry (GtkWidget *entry, int type, SPSData *data)
{
  int status;
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is it a valid IPv4 address?
  if (!is_valid_ip4 (entry_text)) {
    // Invalid IP
    if (inet_ntop (AF_INET, &(data->ip4hdr[type].ip_src.s_addr), value, INET_ADDRSTRLEN) == NULL) {
      status = errno;
      sprintf (data->error_text, "ip4_sip_entry(): inet_ntop() failed.\nError message: %s", strerror (status));
      if (type > 8) {
        data->parent = data->traceroute_window;
      } else {
        data->parent = data->main_window;
      }
      report_error (data);
      free (value);
      return (EXIT_FAILURE);
    }
    gtk_entry_set_text (GTK_ENTRY (entry), value);
    sprintf (data->error_text, "ip4_sip_entry(): is_valid_ip4() failed.\nAppears to be an invalid IPv4 address.");
    if (type > 8) {
      data->parent = data->traceroute_window;
    } else {
      data->parent = data->main_window;
    }
    report_error (data);
    free (value);
    return (EXIT_FAILURE);

  } else {
    // Valid IP
    if ((status = inet_pton (AF_INET, entry_text, &data->ip4hdr[type].ip_src)) != 1) {
      sprintf (data->error_text, "ip4_sip_entry(): inet_pton() failed.\nError message: %s", strerror (status));
      if (type > 8) {
        data->parent = data->traceroute_window;
      } else {
        data->parent = data->main_window;
      }
      report_error (data);
      free (value);
      return (EXIT_FAILURE);
    }

    // IPv4 header checksum (16 bits)
    ip4_chksum (type, data);

    // Update ethernet frames.
    switch (type) {
      case 0:  // IPv4 TCP
        tcp_chksum (type, data);
        create_ip4_frame (type, data);
        break;
      case 1:  // IPv4 ICMP
        create_ip4_frame (type, data);
        break;
      case 2:  // IPv4 UDP
        udp_chksum (type, data);
        create_ip4_frame (type, data);
        break;
      case 6:  // 6to4 IPv6 TCP
        // We don't update TCP checksum since the IP addresses for TCP checksum are from IPv6 header.
        create_6to4_frame (type, data);
        break;
      case 7:  // 6to4 IPv6 ICMP
        // We don't update ICMP checksum since the IP addresses for ICMP checksum are from IPv6 header.
        create_6to4_frame (type, data);
        break;
      case 8:  // 6to4 IPv6 UDP
        // We don't update UDP checksum since the IP addresses for UDP checksum are from IPv6 header.
        create_6to4_frame (type, data);
        break;
      case 9:  // IPv4 TCP for traceroute
        tcp_chksum (type, data);
        create_ip4_frame (type, data);
        break;
      case 10:  // IPv4 ICMP for traceroute
        create_ip4_frame (type, data);
        break;
      case 11:  // IPv4 UDP for traceroute
        udp_chksum (type, data);
        create_ip4_frame (type, data);
        break;
      case 15:  // 6to4 IPv6 TCP for traceroute
        // We don't update TCP checksum since the IP addresses for TCP checksum are from IPv6 header.
        create_6to4_frame (type, data);
        break;
      case 16:  // 6to4 IPv6 ICMP for traceroute
        // We don't update ICMP6 checksum since the IP addresses for ICMP6 checksum are from IPv6 header.
        create_6to4_frame (type, data);
        break;
      case 17:  // 6to4 IPv6 UDP for traceroute
        // We don't update UDP checksum since the IP addresses for UDP checksum are from IPv6 header.
        create_6to4_frame (type, data);
        break;
      default:
        fprintf (stderr, "ERROR: Invalid upper layer protocol type %i in ip4_sip_entry().\n", type);
        free (value);
        exit (EXIT_FAILURE);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Randomize source IPv4 address
int
ip4_ransip_checkbutton (int *ran_sourceip, GtkWidget *entry, int type, SPSData *data)
{
  int status;
  char *value, *ipaddress;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Array to hold an IPv4 address + '\0'
  ipaddress = allocate_strmem (INET_ADDRSTRLEN);

  if (!(*ran_sourceip)) {
    *ran_sourceip = 1;
    if ((status = inet_pton (AF_INET, ran4_addr (ipaddress, data), &(data->ip4hdr[type].ip_src))) != 1) {
      sprintf (data->error_text, "ip4_ransip_checkbutton(): inet_pton() failed.\nError message: %s", strerror (status));
      if (type > 8) {
        data->parent = data->traceroute_window;
      } else {
        data->parent = data->main_window;
      }
      report_error (data);
      free (value);
      free (ipaddress);
      return (EXIT_FAILURE);
    }
    if (inet_ntop (AF_INET, &(data->ip4hdr[type].ip_src), value, INET_ADDRSTRLEN) == NULL) {
      status = errno;
      sprintf (data->error_text, "ip4_ransip_checkbutton(): inet_ntop() failed.\nError message: %s", strerror (status));
      if (type > 8) {
        data->parent = data->traceroute_window;
      } else {
        data->parent = data->main_window;
      }
      report_error (data);
      free (value);
      free (ipaddress);
      return (EXIT_FAILURE);
    }
    gtk_entry_set_text (GTK_ENTRY (entry), value);

    // IPv4 header checksum (16 bits)
    ip4_chksum (type, data);

    // Update ethernet frames.
    switch (type) {
      case 0:  // IPv4 TCP
        tcp_chksum (type, data);
        create_ip4_frame (type, data);
        break;
      case 1:  // IPv4 ICMP
        create_ip4_frame (type, data);
        break;
      case 2:  // IPv4 UDP
        udp_chksum (type, data);
        create_ip4_frame (type, data);
        break;
      case 6:  // 6to4 IPv6 TCP
        // We don't update TCP checksum since the IP addresses for TCP checksum are from IPv6 header.
        create_6to4_frame (type, data);
        break;
      case 7:  // 6to4 IPv6 ICMP
        // We don't update ICMP checksum since the IP addresses for ICMP checksum are from IPv6 header.
        create_6to4_frame (type, data);
        break;
      case 8:  // 6to4 IPv6 UDP
        // We don't update UDP checksum since the IP addresses for UDP checksum are from IPv6 header.
        create_6to4_frame (type, data);
        break;
      case 9:  // IPv4 TCP for traceroute
        tcp_chksum (type, data);
        create_ip4_frame (type, data);
        break;
      case 10:  // IPv4 ICMP for traceroute
        create_ip4_frame (type, data);
        break;
      case 11:  // IPv4 UDP for traceroute
        udp_chksum (type, data);
        create_ip4_frame (type, data);
        break;
      case 15:  // 6to4 IPv6 TCP for traceroute
        // We don't update TCP checksum since the IP addresses for TCP checksum are from IPv6 header.
        create_6to4_frame (type, data);
        break;
      case 16:  // 6to4 IPv6 ICMP for traceroute
        // We don't update ICMP6 checksum since the IP addresses for ICMP6 checksum are from IPv6 header.
        create_6to4_frame (type, data);
        break;
      case 17:  // 6to4 IPv6 UDP for traceroute
        // We don't update UDP checksum since the IP addresses for UDP checksum are from IPv6 header.
        create_6to4_frame (type, data);
        break;
      default:
        fprintf (stderr, "ERROR: Invalid upper layer protocol type %i in ip4_ransip_checkbutton().\n", type);
        free (value);
        free (ipaddress);
        exit (EXIT_FAILURE);
    }

  } else {
    *ran_sourceip = 0;
  }

  // Free allocated memory.
  free (value);
  free (ipaddress);

  return (EXIT_SUCCESS);
}

// Destination IP address (32 bits)
int
ip4_dip_entry (GtkWidget *entry, int type, SPSData *data)
{
  int status;
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is it a valid IPv4 address?
  if (!is_valid_ip4 (entry_text)) {
    // Invalid IP
    if (inet_ntop (AF_INET, &(data->ip4hdr[type].ip_dst.s_addr), value, INET_ADDRSTRLEN) == NULL) {
      status = errno;
      sprintf (data->error_text, "ip4_dip_entry(): inet_ntop() failed.\nError message: %s", strerror (status));
      if (type > 8) {
        data->parent = data->traceroute_window;
      } else {
        data->parent = data->main_window;
      }
      report_error (data);
      free (value);
      return (EXIT_FAILURE);
    }
    gtk_entry_set_text (GTK_ENTRY (entry), value);
    sprintf (data->error_text, "ip4_dip_entry(): is_valid_ip4() failed.\nAppears to be an invalid IPv4 address.");
    data->parent = data->main_window;
    report_error (data);
    free (value);
    return (EXIT_FAILURE);

  } else {
    // Valid IP
    if ((status = inet_pton (AF_INET, entry_text, &data->ip4hdr[type].ip_dst)) != 1) {
      sprintf (data->error_text, "ip4_dip_entry(): inet_pton() failed.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      report_error (data);
      free (value);
      return (EXIT_FAILURE);
    }

    // IPv4 header checksum (16 bits)
    ip4_chksum (type, data);

    // Update ethernet frames.
    switch (type) {
      case 0:  // IPv4 TCP
        tcp_chksum (type, data);
        create_ip4_frame (type, data);
        break;
      case 1:  // IPv4 ICMP
        create_ip4_frame (type, data);
        break;
      case 2:  // IPv4 UDP
        udp_chksum (type, data);
        create_ip4_frame (type, data);
        break;
      case 9:  // IPv4 TCP for traceroute
        tcp_chksum (type, data);
        create_ip4_frame (type, data);
        break;
      case 10:  // IPv4 ICMP for traceroute
        create_ip4_frame (type, data);
        break;
      case 11:  // IPv4 UDP for traceroute
        udp_chksum (type, data);
        create_ip4_frame (type, data);
        break;
      default:
        fprintf (stderr, "ERROR: Invalid upper layer protocol type %i in ip4_dip_entry().\n", type);
        free (value);
        exit (EXIT_FAILURE);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// IPv4 checksum (16 bits)
int
ip4_chksum_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 65535)) {
    sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[type].ip_sum));
    gtk_entry_set_text (GTK_ENTRY (entry), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->ip4hdr[type].ip_sum = htons ((uint16_t) ascii_to_int64 ((char *) entry_text));  // Update IPv4 header with new value

    // Update ethernet frame.
    create_ip4_frame (type, data);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Re-calculate IPv4 header length and update text entry.
int
ip4_hlen (int type, SPSData *data)
{
  GtkWidget *hdrlen_entry;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Update IP header length (4 bits): IP header + IP options + IP options padding
  data->ip4hdr[type].ip_hl = (IP4_HDRLEN + data->ip_opt_totlen[type] + data->ip_optpadlen[type]) / sizeof (uint32_t);
  sprintf (value, "%" PRIu8, (uint8_t) data->ip4hdr[type].ip_hl);

  switch (type) {
    case 0:  // IPv4 TCP
      hdrlen_entry = data->entry29;
      break;
    case 1:  // IPv4 ICMP
      hdrlen_entry = data->entry57;
      break;
    case 2:  // IPv4 UDP
      hdrlen_entry = data->entry1;
      break;
    case 9:  // IPv4 TCP for traceroute
      hdrlen_entry = data->entry168;
      break;
    case 10:  // IPv4 ICMP for traceroute
      hdrlen_entry = data->entry204;
      break;
    case 11:  // IPv4 UDP for traceroute
      hdrlen_entry = data->entry228;
      break;
    default:
      fprintf (stderr, "ERROR: Invalid upper layer protocol type %i in ip4_hlen().\n", type);
      free (value);
      exit (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (hdrlen_entry), value);

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Re-calculate total length of IPv4 datagram and update text entry.
int
ip4_tld (int type, SPSData *data)
{
  GtkWidget *tld_entry;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Total length of datagram (16 bits): IP header + IP options + IP options padding + Upper layer protocol
  // Upper layer protocol is:
  //   TCP header + TCP options + TCP options padding + TCP payload, or
  //   ICMP header + ICMP payload, or
  //   UDP header + UDP payload
  if ((type == 0) || (type == 9)) {
    data->ip4hdr[type].ip_len = htons (IP4_HDRLEN + data->ip_opt_totlen[type] + data->ip_optpadlen[type] + TCP_HDRLEN + data->tcp_opt_totlen[type] + data->tcp_optpadlen[type] + data->payloadlen[type]);

  } else if ((type == 1) || (type == 10)) {
    data->ip4hdr[type].ip_len = htons (IP4_HDRLEN + data->ip_opt_totlen[type] + data->ip_optpadlen[type] + ICMP_HDRLEN + data->payloadlen[type]);

  } else if ((type == 2) || (type == 11)) {
    data->ip4hdr[type].ip_len = htons (IP4_HDRLEN + data->ip_opt_totlen[type] + data->ip_optpadlen[type] + UDP_HDRLEN + data->payloadlen[type]);
  }

  // Update IPv4 header total length of datagram entry.
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[type].ip_len));

  switch (type) {
    case 0:  // IPv4 TCP
      tld_entry = data->entry32;
      break;
    case 1:  // IPv4 ICMP
      tld_entry = data->entry60;
      break;
    case 2:  // IPv4 UDP
      tld_entry = data->entry4;
      break;
    case 9:  // IPv4 TCP for traceroute
      tld_entry = data->entry171;
      break;
    case 10:  // IPv4 ICMP for traceroute
      tld_entry = data->entry207;
      break;
    case 11:  // IPv4 UDP for traceroute
      tld_entry = data->entry231;
      break;
    default:
      fprintf (stderr, "ERROR: Invalid upper layer protocol type %i in ip4_tld().\n", type);
      free (value);
      exit (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (tld_entry), value);

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Truncate IPv4 payload length as necessary to accomodate the
// variable lengths of IPv4 header options and TCP options.
int
truncate_ip4 (int type, SPSData *data)
{
  int unfraglen, fraglen_nopayload;

  // Find length of unfragmentable portion.
  unfraglen = IP4_HDRLEN + data->ip_opt_totlen[type] + data->ip_optpadlen[type];

  // Find length of fragmentable portion, excluding payload data.
  if ((type == 0) || (type == 9)) {
    fraglen_nopayload = TCP_HDRLEN + data->tcp_opt_totlen[type] + data->tcp_optpadlen[type];
  } else if ((type == 1) || (type == 10)) {
    fraglen_nopayload = ICMP_HDRLEN;
  } else if ((type == 2) || (type == 11)) {
    fraglen_nopayload = UDP_HDRLEN;
  } else {
    fprintf (stderr, "ERROR: Invalid upper layer protocol type %i in truncate_ip4() in ipv4_header.c.\n", type);
    exit (EXIT_FAILURE);
  }

  if ((unfraglen + fraglen_nopayload + data->payloadlen[type]) > IP_MAXPACKET) {
    data->payloadlen[type] = IP_MAXPACKET - unfraglen - fraglen_nopayload;
    return (1);  // Truncation occurred.
  }

  return (0);  // Truncation did not occur.
}

// Re-calculate IPv4 checksum and update text entry.
int
ip4_chksum (int type, SPSData *data)
{
  GtkWidget *chksum_entry;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // IPv4 header checksum (16 bits): set to 0 when calculating checksum
  data->ip4hdr[type].ip_sum = 0;
  data->ip4hdr[type].ip_sum = ip4_checksum (data->ip4hdr[type], data->ip_nopt[type], data->ip_optlen[type], data->ip_options[type], data->ip_optpadlen[type]);

  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip4hdr[type].ip_sum));

  switch (type) {
    case 0:  // IPv4 TCP
      chksum_entry = data->entry34;
      break;
    case 1:  // IPv4 ICMP
      chksum_entry = data->entry62;
      break;
    case 2:  // IPv4 UDP
      chksum_entry = data->entry6;
      break;
    case 9:  // IPv4 TCP for traceroute
      chksum_entry = data->entry181;
      break;
    case 10:  // IPv4 ICMP for traceroute
      chksum_entry = data->entry217;
      break;
    case 11:  // IPv4 UDP for traceroute
      chksum_entry = data->entry241;
      break;
    default:  // If not 6to4 IPv4 checksum either, then we have an unknown upper layer protocol.
      if ((type != 6) && (type != 7) && (type != 8) &&
        (type != 15) && (type != 16) && (type != 17)) {
        fprintf (stderr, "ERROR: Invalid upper layer protocol type %i in ip4_chksum().\n", type);
        free (value);
        exit (EXIT_FAILURE);
      }
      break;
  }

  // Update checksum entry if not 6to4 IPv4 checksum (which has no entry to be updated in the user interface).
  if ((type != 6) && (type != 7) && (type != 8) && 
      (type != 15) && (type != 16) && (type != 17)) {
    gtk_entry_set_text (GTK_ENTRY (chksum_entry), value);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Update IPv4: total length of datagram and checksum, Upper layer protocol: length, offset, and checksum.
int
ip4data_update (int type, SPSData *data)
{
  // Total length of datagram (16 bits)
  ip4_tld (type, data);

  // IPv4 header checksum (16 bits)
  ip4_chksum (type, data);

  // Update TCP stuff, if appropriate.
  if ((type == 0) || (type == 9)) {
    // TCP data offset (4 bits)
    tcp_dataoffset (type, data);

    // TCP header checksum (16 bits)
    tcp_chksum (type, data);
  }

  // Update ICMP stuff, if appropriate.
  if ((type == 1) || (type == 10)) {
    // ICMP header checksum (16 bits)
    icmp_chksum (type, data);
  }

  // Update UDP stuff, if appropriate.
  if ((type == 2) || (type == 11)) {
    // Length of UDP datagram (16 bits)
    udp_len (type, data);

    // UDP header checksum (16 bits)
    udp_chksum (type, data);
  }

  return (EXIT_SUCCESS);
}
