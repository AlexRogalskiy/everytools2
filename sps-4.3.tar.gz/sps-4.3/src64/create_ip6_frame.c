/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Create an IPv6 ethernet frame.
int
create_ip6_frame (int type, SPSData *data)
{
  int i, c, len[MAX_FRAGS], offset[MAX_FRAGS], *frag_flags, old_nframes;
  int unfraglen, fraglen;
  struct ip6_hdr iphdr;
  struct ip6_frag fraghdr;
  uint8_t *unfragbuffer, *fragbuffer;

  // Allocate memory for a buffer for unfragmentable portion.
  unfragbuffer = allocate_ustrmem (IP_MAXPACKET + ETH_HDRLEN);

  // Allocate memory for a buffer for fragmentable portion.
  fragbuffer = allocate_ustrmem (IP_MAXPACKET + ETH_HDRLEN);

  frag_flags = allocate_intmem (2);

  // Copy IPv6 header so we don't corrupt original during fragmentation.
  memcpy (&iphdr, &data->ip6hdr[type], IP6_HDRLEN * sizeof (uint8_t));

  // Find length of unfragmentable portion (excludes ethernet header).
  unfraglen = find6_unfraglen (type, data);

  // Find length of fragmentable portion.
  fraglen = find6_fraglen (type, data);

  // Determine required number of IPv6 ethernet frames, frame lengths, and data offsets.
  old_nframes = data->nframes[type];
  find_nframes (type, data->ifmtu[type], unfraglen, fraglen, &data->nframes[type], len, offset);

  // Check if number of frames has changed and re-allocate memory as necessary.
  nframes_change (old_nframes, type, data);

  // Setup chain of header, extension headers, and data by setting Next Header fields.
  // Assume no fragmentation here.
  ip6_chain (type, &iphdr, data);

  // Build fragmentable portion of ethernet frame.
  build_frag (type, &iphdr, fragbuffer, data);

  // Now build complete ethernet frames.

  // Loop through fragments.
  for (i=0; i<data->nframes[type]; i++) {

    // Set ethernet frame contents to zero initially.
    memset (data->ether_frame[type][i], 0, (IP_MAXPACKET + ETH_HDRLEN) * sizeof (uint8_t));

    // Index of ethernet frame.
    c = 0;

    // Fill out ethernet frame header.

    // Copy destination and source MAC addresses to ethernet frame.
    memcpy (data->ether_frame[type][i], data->ethhdr[type].dst_mac, 6 * sizeof (uint8_t));
    memcpy (data->ether_frame[type][i] + 6, data->ethhdr[type].src_mac, 6 * sizeof (uint8_t));

    // Copy ethernet type code to ethernet frame.
    memcpy (data->ether_frame[type][i] + 12, &data->ethhdr[type].type_code, 2 * sizeof (uint8_t));
    c += ETH_HDRLEN;

    // Next is ethernet frame data.

    // Payload length (16 bits): See Section 4.5 of RFC 2460.
    // Subtract IPv6 header from unfraglen, since not part of payload length.
    // No new IPv6 header if not AH and not ESP tunneling.
    if (data->nframes[type] == 1) {
      iphdr.ip6_plen = htons (unfraglen - IP6_HDRLEN + len[i]);
    } else {
      iphdr.ip6_plen = htons (unfraglen - IP6_HDRLEN + FRG_HDRLEN + len[i]);
    }

    // Set Next Header field to IPPROTO_FRAGMENT in last link of unfragmentable portion, if appropriate.
    if (data->nframes[type] > 1) {
      next_hdr_to_frag (type, &iphdr, data);
    }

    // Copy unfragmentable portion to ethernet frame.
    build_unfrag (type, &iphdr, &c, data->ether_frame[type][i], data);

    // Fill out and copy fragmentation extension header to ethernet frame.
    if (data->nframes[type] > 1) {
      fraghdr.ip6f_nxt = set_proto(data->order[type][data->first_frag[type]]);  // Upper layer protocol
      fraghdr.ip6f_reserved = 0;  // Reserved
      frag_flags[1] = 0;  // Reserved
      if (i < (data->nframes[type] - 1)) {
        frag_flags[0] = 1;  // More fragments to follow
      } else {
        frag_flags[0] = 0;  // This is the last fragment
      }
      fraghdr.ip6f_offlg = htons ((offset[i] << 3) + frag_flags[0] + (frag_flags[1] << 1));
      fraghdr.ip6f_ident = htonl (31415);
      memcpy (data->ether_frame[type][i] + c, &fraghdr, FRG_HDRLEN * sizeof (uint8_t));
      c += FRG_HDRLEN;
    }

    // Copy fragmentable portion of packet to ethernet frame.
    memcpy (data->ether_frame[type][i] + c, fragbuffer + (offset[i] * 8), len[i] * sizeof (uint8_t));
    c += len[i];

    // Ethernet frame length
    data->frame_length[type][i] = c;
  }

  // Now build the unfragmented packet (for packet display purposes with show_packet()).

  // Set packet contents to zero initially.
  memset (data->packet[type], 0, (IP_MAXPACKET + ETH_HDRLEN) * sizeof (uint8_t));

  // Index of packet.
  c = 0;

  // Copy destination and source MAC addresses to packet.
  memcpy (data->packet[type], data->ethhdr[type].dst_mac, 6 * sizeof (uint8_t));
  memcpy (data->packet[type] + 6, data->ethhdr[type].src_mac, 6 * sizeof (uint8_t));

  // Copy ethernet type code to packet.
  memcpy (data->packet[type] + 12, &data->ethhdr[type].type_code, 2 * sizeof (uint8_t));
  c += ETH_HDRLEN;

  // Next is ethernet frame data.

  // Copy unfragmentable portion to packet.
  build_unfrag (type, &data->ip6hdr[type], &c, data->packet[type], data);

  // Copy fragmentable portion to packet.
  memcpy (data->packet[type] + c, fragbuffer, fraglen * sizeof (uint8_t));
  c += fraglen;

  // Packet length
  data->packet_length[type] = c;

  // Free allocated memory.
  free (unfragbuffer);
  free (fragbuffer);
  free (frag_flags);

  return (EXIT_SUCCESS);
}
