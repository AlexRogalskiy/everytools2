package com.iluwatar.testdomain;

public class TestPojo {
}
