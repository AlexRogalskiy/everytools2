/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Send a neighbor solicitation to obtain link-layer address.
int
neighbor_discovery (uint8_t *dst_mac, const char *entry138_text, const char *entry140_text, SPSData *data)
{
  int NS_HDRLEN = sizeof (struct nd_neighbor_solicit);  // Length of NS message header
  int optlen = 8; // Option Type (1 byte) + Length (1 byte) + Length of MAC address (6 bytes)

  int i, nbytes, sd, on, status, ifindex, cmsglen, psdhdrlen;
  struct addrinfo hints;
  struct addrinfo *res;
  struct sockaddr_in6 *ipv6, src, dst, dstsnmc;
  struct nd_neighbor_solicit *ns;
  struct nd_neighbor_advert *na;
  uint8_t *outpack, *options, *psdhdr, *inpack, *pkt, hoplimit;
  struct msghdr msghdr;
  struct ifreq ifr;
  struct cmsghdr *cmsghdr1, *cmsghdr2;
  Pktinfo6 *pktinfo;
  struct iovec iov[2];
  char *target, *source, *interface;
  struct timeval tv;
  void *tmp;

  // Allocate memory for various arrays.
  interface = allocate_strmem (TMP_STRINGLEN);
  target = allocate_strmem (INET6_ADDRSTRLEN);
  source = allocate_strmem (INET6_ADDRSTRLEN);
  outpack = allocate_ustrmem (IP_MAXPACKET);
  options = allocate_ustrmem (optlen);
  psdhdr = allocate_ustrmem (IP_MAXPACKET);
  inpack = allocate_ustrmem (IP_MAXPACKET);

  // Is an interface name specified?
  if (strnlen (entry140_text, TMP_STRINGLEN) < 2) {
    sprintf (data->error_text, "neighbor_discovery(): Please specify an interface name.");
    data->parent = data->main_window;
    report_error (data);
    free (interface);
    free (target);
    free (source);
    free (outpack);
    free (options);
    free (psdhdr);
    free (inpack);
    return (EXIT_FAILURE);
  }

  // Interface to send packet through.
  memset (interface, 0, TMP_STRINGLEN * sizeof (char));
  strncpy (interface, entry140_text, TMP_STRINGLEN - 1);  // Minus 1 for string termination.

  // Clear IPv4 textentry so there's no confusion about which IP belongs to the MAC address.
  gtk_entry_set_text (GTK_ENTRY (data->entry137), "");

  // Submit request for a socket descriptor.
  if ((sd = socket (AF_INET6, SOCK_RAW, IPPROTO_ICMPV6)) < 0) {
    status = errno;
    sprintf (data->error_text, "neighbor_discovery(): socket() failed to get socket descriptor for ioctl().\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (interface);
    free (target);
    free (source);
    free (outpack);
    free (options);
    free (psdhdr);
    free (inpack);
    return (EXIT_FAILURE);
  }

  // Use ioctl() to lookup interface and get MAC address.
  memset (&ifr, 0, sizeof (ifr));
  snprintf (ifr.ifr_name, sizeof (ifr.ifr_name), "%s", interface);
  if (ioctl (sd, SIOCGIFHWADDR, &ifr) < 0) {
    status = errno;
    sprintf (data->error_text, "neighbor_discovery(): ioctl() failed to get interface hardware address (MAC).\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (interface);
    free (target);
    free (source);
    free (outpack);
    free (options);
    free (psdhdr);
    free (inpack);
    return (EXIT_FAILURE);
  }

  // Copy source MAC address into options buffer.
  options[0] = 1;           // Option Type - "source link layer address" (Section 4.6 of RFC 4861)
  options[1] = optlen / 8;  // Option Length - units of 8 octets (RFC 4861)
  for (i=0; i<6; i++) {
    options[i+2] = (uint8_t) ifr.ifr_addr.sa_data[i];
  }

  // Retrieve source interface index.
  if ((ifindex = if_nametoindex (interface)) == 0) {
    status = errno;
    sprintf (data->error_text, "neighbor_discovery(): if_nametoindex() failed to obtain interface index.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (interface);
    free (target);
    free (source);
    free (outpack);
    free (options);
    free (psdhdr);
    free (inpack);
    return (EXIT_FAILURE);
  }

  // Source IPv6 address: the IPv6 unspecified address
  memset (source, 0, INET6_ADDRSTRLEN * sizeof (char));
  strncpy (source, "::", 2);

  // Target URL or IPv6 address (node we're requesting an advertisement from).
  memset (target, 0, INET6_ADDRSTRLEN * sizeof (char));
  strncpy (target, entry138_text, INET6_ADDRSTRLEN - 1);  // Minus 1 for string termination.

  // Fill out hints for getaddrinfo().
  memset (&hints, 0, sizeof (struct addrinfo));
  hints.ai_family = AF_INET6;
  hints.ai_socktype = SOCK_STREAM;
  hints.ai_flags = hints.ai_flags | AI_CANONNAME;

  // Resolve source using getaddrinfo().
  if ((status = getaddrinfo (source, NULL, &hints, &res)) != 0) {
    sprintf (data->error_text, "neighbor_discovery(): getaddrinfo() failed to resolve the IPv6 unspecified address (::).\nError message: %s", gai_strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (interface);
    free (target);
    free (source);
    free (outpack);
    free (options);
    free (psdhdr);
    free (inpack);
    return (EXIT_FAILURE);
  }
  memset (&src, 0, sizeof (src));
  memcpy (&src, res->ai_addr, res->ai_addrlen * sizeof (uint8_t));
  memcpy (psdhdr, src.sin6_addr.s6_addr, 16 * sizeof (uint8_t));  // Copy to checksum pseudo-header
  freeaddrinfo (res);

  // Resolve target using getaddrinfo().
  if ((status = getaddrinfo (target, NULL, &hints, &res)) != 0) {
    sprintf (data->error_text, "neighbor_discovery(): getaddrinfo() failed to resolve target hostname/IPv6 address.\nError message: %s", gai_strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (interface);
    free (target);
    free (source);
    free (outpack);
    free (options);
    free (psdhdr);
    free (inpack);
    return (EXIT_FAILURE);
  }
  memset (&dst, 0, sizeof (dst));
  memcpy (&dst, res->ai_addr, res->ai_addrlen * sizeof (uint8_t));
  memset (&dstsnmc, 0, sizeof (dstsnmc));
  memcpy (&dstsnmc, res->ai_addr, res->ai_addrlen * sizeof (uint8_t)); 

  // Report target's unicast address.
  ipv6 = (struct sockaddr_in6 *) res->ai_addr;
  tmp = &(ipv6->sin6_addr);
  memset (target, 0, INET6_ADDRSTRLEN * sizeof (char));
  if (inet_ntop (AF_INET6, tmp, target, INET6_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "neighbor_discovery(): inet_ntop() failed.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (interface);
    free (target);
    free (source);
    free (outpack);
    free (options);
    free (psdhdr);
    free (inpack);
    freeaddrinfo (res);
    return (EXIT_FAILURE);
  }
  freeaddrinfo (res);

  // Convert target's IPv6 unicast address to solicited-node multicast address.
  // Section 2.7.1 of RFC 4291.
  dstsnmc.sin6_addr.s6_addr[0]= 255;
  dstsnmc.sin6_addr.s6_addr[1]=2;
  for (i=2; i<11; i++) {
    dstsnmc.sin6_addr.s6_addr[i] = 0;
  }
  dstsnmc.sin6_addr.s6_addr[11]=1;
  dstsnmc.sin6_addr.s6_addr[12]=255;
  memcpy (psdhdr + 16, dstsnmc.sin6_addr.s6_addr, 16 * sizeof (uint8_t));  // Solicited-node multicast address goes into pseudo-header

  // Define first part of buffer outpack to be a neighbor solicit struct.
  ns = (struct nd_neighbor_solicit *) outpack;
  memset (ns, 0, sizeof (*ns));

  // Populate icmp6_hdr portion of neighbor solicit struct.
  ns->nd_ns_hdr.icmp6_type = ND_NEIGHBOR_SOLICIT;  // 135 (RFC 4861)
  ns->nd_ns_hdr.icmp6_code = 0;  // zero for neighbor solicitation (RFC 4861)
  ns->nd_ns_hdr.icmp6_cksum = htons(0);  // zero when calculating checksum
  ns->nd_ns_reserved = htonl(0);  // Reserved - must be set to zero (RFC 4861)
  ns->nd_ns_target = dst.sin6_addr;  // Target address (NOT MULTICAST) (as type in6_addr)

  // Append options to end of neighbor solicit struct.
  memcpy (outpack + NS_HDRLEN, options, optlen * sizeof (uint8_t));

  // Need a pseudo-header for checksum calculation. Define length. (RFC 2460)
  // Length = source IP (16 bytes) + destination IP (16 bytes)
  //        + upper layer packet length (4 bytes) + zero (3 bytes)
  //        + next header (1 byte)
  psdhdrlen = 16 + 16 + 4 + 3 + 1 + NS_HDRLEN + optlen;

  // Prepare msghdr for sendmsg().
  memset (&msghdr, 0, sizeof (msghdr));
  msghdr.msg_name = &dstsnmc;  // Destination IPv6 address (solicited node multicast) (as struct sockaddr_in6)
  msghdr.msg_namelen = sizeof (dstsnmc);
  memset (&iov, 0, sizeof (iov));
  iov[0].iov_base = (uint8_t *) outpack;  // Point msghdr to buffer outpack
  iov[0].iov_len = NS_HDRLEN + optlen;
  msghdr.msg_iov = iov;  // scatter/gather array
  msghdr.msg_iovlen = 1;  // number of elements in scatter/gather array

  // Tell msghdr we're adding cmsghdr data to change hop limit and specify interface.
  // Allocate some memory for our cmsghdr data.
  cmsglen = CMSG_SPACE (sizeof (int)) + CMSG_SPACE (sizeof (Pktinfo6));
  msghdr.msg_control = allocate_ustrmem (cmsglen);  // Array of unsigned chars
  msghdr.msg_controllen = cmsglen;

  // Change hop limit to 255 as required for neighbor solicitation (RFC 4861).
  hoplimit = 255u;
  cmsghdr1 = CMSG_FIRSTHDR (&msghdr);
  cmsghdr1->cmsg_level = IPPROTO_IPV6;
  cmsghdr1->cmsg_type = IPV6_HOPLIMIT;  // We want to change hop limit
  cmsghdr1->cmsg_len = CMSG_LEN (sizeof (int));
  *(CMSG_DATA (cmsghdr1)) = hoplimit;

  // Specify source interface index for this packet via cmsghdr data.
  cmsghdr2 = CMSG_NXTHDR (&msghdr, cmsghdr1);
  cmsghdr2->cmsg_level = IPPROTO_IPV6;
  cmsghdr2->cmsg_type = IPV6_PKTINFO;  // We want to specify interface here
  cmsghdr2->cmsg_len = CMSG_LEN (sizeof (Pktinfo6));
  pktinfo = (Pktinfo6 *) CMSG_DATA (cmsghdr2);
  pktinfo->ipi6_ifindex = ifindex;

  // Compute ICMPv6 checksum (RFC 2460).
  // psdhdr[0 to 15] = source IPv6 address, set earlier.
  // psdhdr[16 to 31] = destination IPv6 address, set earlier.
  psdhdr[32] = 0;  // Length should not be greater than 65535 (i.e., 2 bytes)
  psdhdr[33] = 0;  // Length should not be greater than 65535 (i.e., 2 bytes)
  psdhdr[34] = (NS_HDRLEN + optlen)  / 256;  // Upper layer packet length
  psdhdr[35] = (NS_HDRLEN + optlen)  % 256;  // Upper layer packet length
  psdhdr[36] = 0;  // Must be zero
  psdhdr[37] = 0;  // Must be zero
  psdhdr[38] = 0;  // Must be zero
  psdhdr[39] = IPPROTO_ICMPV6;
  memcpy (psdhdr + 40, outpack, (NS_HDRLEN + optlen) * sizeof (uint8_t));
  ns->nd_ns_hdr.icmp6_cksum = checksum ((uint16_t *) psdhdr, psdhdrlen);

  // Send packet.
  if (sendmsg (sd, &msghdr, 0) < 0) {
    status = errno;
    sprintf (data->error_text, "neighbor_discovery(): sendmsg() failed.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (interface);
    free (target);
    free (source);
    free (outpack);
    free (options);
    free (psdhdr);
    free (inpack);
    free (msghdr.msg_control);
    return (EXIT_FAILURE);
  }

  // Prepare msghdr for recvmsg().
  memset (&msghdr, 0, sizeof (msghdr));
  msghdr.msg_name = NULL;
  msghdr.msg_namelen = 0;
  memset (&iov, 0, sizeof (iov));
  iov[0].iov_base = (uint8_t *) inpack;
  iov[0].iov_len = IP_MAXPACKET;
  msghdr.msg_iov = iov;
  msghdr.msg_iovlen = 1;

  msghdr.msg_controllen = IP_MAXPACKET * sizeof (uint8_t);

  // Set flag so we receive hop limit from recvmsg.
  on = 1;
  if ((status = setsockopt (sd, IPPROTO_IPV6, IPV6_RECVHOPLIMIT, &on, sizeof (on))) < 0) {
    sprintf (data->error_text, "neighbor_discovery(): setsockopt() failed to set IPV6_RECVHOPLIMIT.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (interface);
    free (target);
    free (source);
    free (outpack);
    free (options);
    free (psdhdr);
    free (inpack);
    free (msghdr.msg_control);
    return (EXIT_FAILURE);
  }

  // Set flag so we receive destination address from recvmsg.
  on = 1;
  if ((status = setsockopt (sd, IPPROTO_IPV6, IPV6_RECVPKTINFO, &on, sizeof (on))) < 0) {
    sprintf (data->error_text, "neighbor_discovery(): setsockopt() failed to set IPV6_RECVPKTINFO.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (interface);
    free (target);
    free (source);
    free (outpack);
    free (options);
    free (psdhdr);
    free (inpack);
    free (msghdr.msg_control);
    return (EXIT_FAILURE);
  }

  // Bind socket to interface of this node.
  if ((status = setsockopt (sd, SOL_SOCKET, SO_BINDTODEVICE, (void *) &ifr, sizeof (ifr))) < 0) {
    sprintf (data->error_text, "neighbor_discovery(): setsockopt() failed to bind socket to interface().\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (interface);
    free (target);
    free (source);
    free (outpack);
    free (options);
    free (psdhdr);
    free (inpack);
    free (msghdr.msg_control);
    return (EXIT_FAILURE);
  }

  // Set time for the socket to timeout and give up waiting for a neighbor advertisement.
  tv.tv_sec  = data->timeout;
  tv.tv_usec = 0;
  setsockopt (sd, SOL_SOCKET, SO_RCVTIMEO, (char *) &tv, sizeof (struct timeval));

  // Listen for incoming message from socket sd.
  // Keep at it until we get a neighbor advertisement.
  na = (struct nd_neighbor_advert *) inpack;
  while (na->nd_na_hdr.icmp6_type != ND_NEIGHBOR_ADVERT) {
    if ((nbytes = recvmsg (sd, &msghdr, 0)) < 0) {
      status = errno;
      if (status == EAGAIN) {  // EAGAIN = 11
        sprintf (data->error_text, "neighbor_discovery(): recvmsg() failed.\nNo reply from that node within %i seconds.", data->timeout);
        data->parent = data->main_window;
        report_error (data);
        free (interface);
        free (target);
        free (source);
        free (outpack);
        free (options);
        free (psdhdr);
        free (inpack);
        free (msghdr.msg_control);
        return (EXIT_FAILURE);
      } else if (status == EINTR) {  // EINTR = 4
        continue;  // Something weird happened, but let's try again.
      } else {
        sprintf (data->error_text, "neighbor_discovery(): recvmsg() failed.\nError message: %s", strerror (status));
        data->parent = data->main_window;
        report_error (data);
        free (interface);
        free (target);
        free (source);
        free (outpack);
        free (options);
        free (psdhdr);
        free (inpack);
        free (msghdr.msg_control);
        return (EXIT_FAILURE);
      }
    }
  }

  // Close socket descriptor.
  close (sd);

  // Extract MAC address from received ethernet frame.
  pkt = (uint8_t *) inpack;
  for (i=2; i<8; i++) {
    dst_mac[i-2] = pkt[sizeof (struct nd_neighbor_advert) + i];
  }

  // Free allocated memory.
  free (interface);
  free (target);
  free (source);
  free (outpack);
  free (options);
  free (psdhdr);
  free (inpack);
  free (msghdr.msg_control);

  return (EXIT_SUCCESS);
}
