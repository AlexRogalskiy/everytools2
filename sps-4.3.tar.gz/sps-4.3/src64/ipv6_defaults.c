/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Apply IPv6 TCP default settings
int
tcp6_default (SPSData *data)
{
  int status, i, *tcp6_flags;
  char *ipaddress, *value;
  GtkTextBuffer *textbuffer32;

  // TCP flags
  tcp6_flags = allocate_intmem (8);

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Array to hold an IPv4 or IPv6 address + '\0'
  ipaddress = allocate_strmem (INET6_ADDRSTRLEN);

  // Number of ethernet frames
  data->nframes[3] = 1;

  // Ethernet header

  // Set flag for user to specify ethernet header. This will never change for IPv6.
  data->specify_ether[3] = 1;

  // Destination link-layer (MAC) address (48 bits): default to zero; user needs to fill out
  memset (data->ethhdr[3].dst_mac, 0, 6 * sizeof (uint8_t));
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  mac_bin2string (data->ethhdr[3].dst_mac, value);
  gtk_entry_set_text (GTK_ENTRY (data->entry131), value);

  // Source Interface Name: defaults to blank
  memset (data->ifname[3], 0, TMP_STRINGLEN * sizeof (char));
  gtk_entry_set_text (GTK_ENTRY (data->entry154), "");

  // Default interface MTU
  data->ifmtu[3] = 1500;

  // Set spinbutton value to interface MTU.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton8), data->ifmtu[3]);

  // Source link-layer (MAC) address (48 bits): default to zero; user needs to fill out
  memset (data->ethhdr[3].src_mac, 0, 6 * sizeof (uint8_t));
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  mac_bin2string (data->ethhdr[3].src_mac, value);
  gtk_entry_set_text (GTK_ENTRY (data->entry132), value);

  // Ethernet type code (16 bits): default to IPv6
  // http://www.iana.org/assignments/ethernet-numbers
  data->ethhdr[3].type_code = htons (ETH_P_IPV6);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ethhdr[3].type_code));
  gtk_entry_set_text (GTK_ENTRY (data->entry133), value);

  // Deal with TCP header options and TCP data first so that 
  // lengths and offsets are correct for updating IP and TCP headers.

  // TCP header options

  // TCP option data entry format: default to hexadecimal input
  data->dec_hex_tcpopt_tcp6 = 1;

  // TCP option entry format
  if (data->dec_hex_tcpopt_tcp6 == 1) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton48), TRUE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton48), FALSE);
  }

  // No TCP options
  data->tcp_nopt[3] = 0;
  textbuffer32 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview32));
  sprintf (value, "%i", data->tcp_nopt[3]);
  gtk_text_buffer_set_text (textbuffer32, value, -1);

  // Clear TCP option buffer entry.
  gtk_entry_set_text (GTK_ENTRY (data->entry413), "");

  // Set all option data to zero.
  for (i=0; i<MAX_TCPOPTIONS; i++) {
    data->tcp_optlen[3][i] = 0;
    memset (data->tcp_options[3][i], 0, MAX_TCPOPTLEN * sizeof (uint8_t));
  }
  memset (data->tcp_optionsbuf[3], 0, MAX_TCPOPTLEN * sizeof (uint8_t));

  // Set total length of options to zero.
  data->tcp_opt_totlen[3] = 0;

  // Length of option in buffer is zero.
  data->tcp_optlenbuf[3] = 0;

  // Default option number after which to insert a new option
  data->tcpopt_tcp6_after = 0;
  gtk_entry_set_text (GTK_ENTRY (data->entry414), "");

  // Number of TCP option to remove (0 = none)
  data->tcpopt_tcp6_remove = 0;
  gtk_entry_set_text (GTK_ENTRY (data->entry415), "");

  // TCP data

  // Clear TCP data buffer.
  memset (data->payload[3], 0, IP_MAXPACKET * sizeof (uint8_t));
  data->payloadlen[3] = 0;
  gtk_entry_set_text (GTK_ENTRY (data->entry163), "");

  // TCP data entry format: default to hexadecimal input
  data->ascii_hex_tcp6 = 1;
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton20), TRUE);

  // Hop-by-hop options

  // No hop-by-hop options
  data->hbh_hdr_flag[3] = 0;
  data->hbh_nopt[3] = 0;

  // Clear all hop-by-hop option lengths.
  memset (data->hbh_optlen[3], 0, MAX_HBHOPTIONS * sizeof (int));

  // Clear all hop-by-hop options.
  for (i=0; i<MAX_HBHOPTIONS; i++) {
    memset (data->hbh_options[3][i], 0, MAX_HBHOPTLEN * sizeof (uint8_t));
  }

  // Total length of hop-by-hop options is zero.
  data->hbh_opt_totlen[3] = 0;
  data->hophdr[3].hdr_len = 0;

  // Option alignment parameter x (of xN + y)
  memset (data->hbh_x[3], 0, MAX_HBHOPTIONS * sizeof (int));

  // Option alignment parameter y (of xN + y)
  memset (data->hbh_y[3], 0, MAX_HBHOPTIONS * sizeof (int));

  // Hop-by-hop header options padding length (includes alignment padding)
  data->hbh_optpadlen[3] = 0;  // Hop-by-hop options padding: hbh_optpadlen[type] = int

  // Destination options

  // No destination options
  data->dstf_hdr_flag[3] = 0;
  data->dstf_nopt[3] = 0;
  data->dstl_hdr_flag[3] = 0;
  data->dstl_nopt[3] = 0;

  // Clear all destination option lengths.
  memset (data->dstf_optlen[3], 0, MAX_DSTOPTIONS * sizeof (int));
  memset (data->dstl_optlen[3], 0, MAX_DSTOPTIONS * sizeof (int));

  // Clear all destination options.
  for (i=0; i<MAX_DSTOPTIONS; i++) {
    memset (data->dstf_options[3][i], 0, MAX_DSTOPTLEN * sizeof (uint8_t));
    memset (data->dstl_options[3][i], 0, MAX_DSTOPTLEN * sizeof (uint8_t));
  }

  // Total length of destination options is zero.
  data->dstf_opt_totlen[3] = 0;
  data->dstfhdr[3].hdr_len = 0;
  data->dstl_opt_totlen[3] = 0;
  data->dstlhdr[3].hdr_len = 0;

  // Option alignment parameter x (of xN + y)
  memset (data->dstf_x[3], 0, MAX_DSTOPTIONS * sizeof (int));
  memset (data->dstl_x[3], 0, MAX_DSTOPTIONS * sizeof (int));

  // Option alignment parameter y (of xN + y)
  memset (data->dstf_y[3], 0, MAX_DSTOPTIONS * sizeof (int));
  memset (data->dstl_y[3], 0, MAX_DSTOPTIONS * sizeof (int));

  // Destination header options padding length (includes alignment padding)
  data->dstf_optpadlen[3] = 0;  // Destination options padding: dstf_optpadlen[type] = int
  data->dstl_optpadlen[3] = 0;  // Destination options padding: dstl_optpadlen[type] = int

  // Routing header

  // No routing header
  data->route_hdr_flag[3] = 0;
  data->route_datlen[3] = 0;
  data->routehdr[3].hdr_len = 0;
  data->routehdr[3].routing_type = 0;
  data->routehdr[3].segs_left = 0;
  memset (data->route_data[3], 0, MAX_ROUTEDATA * sizeof (uint8_t));

  // Authentication header

  // No authentication header
  data->auth_hdr_flag[3] = 0;
  data->auth_len[3] = 0;
  data->authhdr[3].pay_len = 0;
  data->authhdr[3].reserved = 0;
  data->authhdr[3].spi = 0;
  data->authhdr[3].seq = 0;
  memset (data->auth_data[3], 0, MAX_AUTHICVLEN * sizeof (uint8_t));

  // Encapsulating security payload (ESP)

  // No ESP header and no ESP tail
  data->esp_hdr_flag[3] = 0;
  data->esp_auth_len[3] = 0;
  data->esphdr[3].spi = 0;
  data->esphdr[3].seq = 0;
  data->esptail[3].pad_len = 0;
  memset (data->esp_auth_data[3], 0, MAX_ESPICVLEN * sizeof (uint8_t));
  data->esptail[3].pad_len = 0;  // Padding length
  memset (data->esp_pad[3], 0, 255 * sizeof (uint8_t));

  // ESP trailer Next Header field
  data->esptail[3].nxt_hdr = IPPROTO_TCP;

  // IPv6 header

  // IPv6 version (4 bits), Traffic class (8 bits), Flow label (20 bits)
  data->ip6hdr[3].ip6_flow = htonl ((6 << 28) | (0 << 20) | 0);

  // Version (4 bits)
  sprintf (value, "%" PRIu32, (uint32_t) (ntohl (data->ip6hdr[3].ip6_flow) >> 28));
  gtk_entry_set_text (GTK_ENTRY (data->entry22), value);

  // Traffic Class (8 bits)
  sprintf (value, "%" PRIu32, (uint32_t) ((ntohl (data->ip6hdr[3].ip6_flow) >> 20) & 0xfful));
  gtk_entry_set_text (GTK_ENTRY (data->entry23), value);

  // Flow Label (20 bits)
  sprintf (value, "%" PRIu32, (uint32_t) (ntohl (data->ip6hdr[3].ip6_flow) & 0xffffful));
  gtk_entry_set_text (GTK_ENTRY (data->entry24), value);

  // Payload length (16 bits): TCP header + TCP data
  data->ip6hdr[3].ip6_plen = htons (TCP_HDRLEN + data->payloadlen[3]);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip6hdr[3].ip6_plen));
  gtk_entry_set_text (GTK_ENTRY (data->entry25), value);

  // Next header (8 bits): 6 for TCP
  data->ip6hdr[3].ip6_nxt = IPPROTO_TCP;
  sprintf (value, "%" PRIu8, (uint8_t) data->ip6hdr[3].ip6_nxt);
  gtk_entry_set_text (GTK_ENTRY (data->entry26), value);

  // Hop limit (8 bits): default to maximum value
  data->ip6hdr[3].ip6_hops = 255u;
  sprintf (value, "%" PRIu8, (uint8_t) data->ip6hdr[3].ip6_hops);
  gtk_entry_set_text (GTK_ENTRY (data->entry27), value);

  // Source IPv6 address (128 bits): default to random
  data->ran_tcp6_sourceip = 1;
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton2), TRUE);
  if ((status = inet_pton (AF_INET6, ran6_addr (ipaddress, data), &(data->ip6hdr[3].ip6_src))) != 1) {
    sprintf (data->error_text, "tcp6_default().c: inet_pton() failed for randomized source IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (tcp6_flags);
    free (value);
    free (ipaddress);
    return (EXIT_FAILURE);
  }
  if (inet_ntop (AF_INET6, &(data->ip6hdr[3].ip6_src), value, INET6_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "tcp6_default(): inet_ntop() failed for source IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (tcp6_flags);
    free (value);
    free (ipaddress);
    return (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry28), value);

  // Destination IPv6 address (128 bits): default to loopback IP address to be safe
  memset (ipaddress, 0, INET6_ADDRSTRLEN * sizeof (char));
  strncpy (ipaddress, "::1", 3);
  if ((status = inet_pton (AF_INET6, ipaddress, &(data->ip6hdr[3].ip6_dst))) != 1) {
    sprintf (data->error_text, "tcp6_default(): inet_pton() failed for destination IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (tcp6_flags);
    free (value);
    free (ipaddress);
    return (EXIT_FAILURE);
  }
  if (inet_ntop (AF_INET6, &(data->ip6hdr[3].ip6_dst), value, INET6_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "tcp6_default(): inet_ntop() failed for destination IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (tcp6_flags);
    free (value);
    free (ipaddress);
    return (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry78), value);

  // TCP header (IPv6)

  // Source port number (16 bits): default to random
  data->ran_tcp6_sourceport = 1;
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton4), TRUE);
  data->tcphdr[3].th_sport = htons (ran16_0to65535 (data));
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[3].th_sport));
  gtk_entry_set_text (GTK_ENTRY (data->entry79), value);

  // Destination port number (16 bits)
  data->tcphdr[3].th_dport = htons (80u);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[3].th_dport));
  gtk_entry_set_text (GTK_ENTRY (data->entry80), value);

  // Sequence number (32 bits)
  data->tcphdr[3].th_seq = htonl (0);
  sprintf (value, "%" PRIu32, (uint32_t) ntohl (data->tcphdr[3].th_seq));
  gtk_entry_set_text (GTK_ENTRY (data->entry81), value);

  // Acknowledgement number (32 bits): 0 in first packet
  data->tcphdr[3].th_ack = htonl (0);
  sprintf (value, "%" PRIu32, (uint32_t) ntohl (data->tcphdr[3].th_ack));
  gtk_entry_set_text (GTK_ENTRY (data->entry82), value);

  // Reserved (4 bits): should be 0
  data->tcphdr[3].th_x2 = 0;
  sprintf (value, "%" PRIu8, (uint8_t) data->tcphdr[3].th_x2);
  gtk_entry_set_text (GTK_ENTRY (data->entry83), value);

  // Data offset (4 bits): size of TCP header + length of TCP options, in 32-bit words
  // Default is no TCP options.
  data->tcphdr[3].th_off = TCP_HDRLEN / sizeof (uint32_t);
  sprintf (value, "%" PRIu8, (uint8_t) data->tcphdr[3].th_off);
  gtk_entry_set_text (GTK_ENTRY (data->entry84), value);

  // FIN flag (1 bit)
  tcp6_flags[0] = 0;
  sprintf (value, "%i", tcp6_flags[0]);
  gtk_entry_set_text (GTK_ENTRY (data->entry85), value);

  // SYN flag (1 bit): set to 1
  tcp6_flags[1] = 1;
  sprintf (value, "%i", tcp6_flags[1]);
  gtk_entry_set_text (GTK_ENTRY (data->entry86), value);

  // RST flag (1 bit)
  tcp6_flags[2] = 0;
  sprintf (value, "%i", tcp6_flags[2]);
  gtk_entry_set_text (GTK_ENTRY (data->entry87), value);

  // PSH flag (1 bit)
  tcp6_flags[3] = 0;
  sprintf (value, "%i", tcp6_flags[3]);
  gtk_entry_set_text (GTK_ENTRY (data->entry88), value);

  // ACK flag (1 bit)
  tcp6_flags[4] = 0;
  sprintf (value, "%i", tcp6_flags[4]);
  gtk_entry_set_text (GTK_ENTRY (data->entry89), value);

  // URG flag (1 bit)
  tcp6_flags[5] = 0;
  sprintf (value, "%i", tcp6_flags[5]);
  gtk_entry_set_text (GTK_ENTRY (data->entry90), value);

  // ECE flag (1 bit)
  tcp6_flags[6] = 0;
  sprintf (value, "%i", tcp6_flags[6]);
  gtk_entry_set_text (GTK_ENTRY (data->entry91), value);

  // CWR flag (1 bit)
  tcp6_flags[7] = 0;
  sprintf (value, "%i", tcp6_flags[7]);
  gtk_entry_set_text (GTK_ENTRY (data->entry92), value);

  // Flags (8 bits): 2 for SYN
  data->tcphdr[3].th_flags = bin8_to_dec (tcp6_flags);

  // Window size (16 bits): default to maximum value
  data->tcphdr[3].th_win = htons (0xffffu);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[3].th_win));
  gtk_entry_set_text (GTK_ENTRY (data->entry93), value);

  // Urgent pointer (16 bits): 0 (only valid if URG flag is set)
  data->tcphdr[3].th_urp = htons (0);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[3].th_urp));
  gtk_entry_set_text (GTK_ENTRY (data->entry95), value);

  // TCP checksum (16 bits)
  data->tcphdr[3].th_sum = tcp6_checksum (data->ip6hdr[3], data->tcphdr[3], data->tcp_nopt[3], data->tcp_opt_totlen[3], data->tcp_optlen[3], data->tcp_options[3], data->tcp_optpadlen[3], data->payload[3], data->payloadlen[3]);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[3].th_sum));
  gtk_entry_set_text (GTK_ENTRY (data->entry94), value);

  // Free allocated memory.
  free (tcp6_flags);
  free (value);
  free (ipaddress);

  // Update ethernet frame.
  create_ip6_frame (3, data);

  // Apply default 6to4 settings.
  sixto4_tcp6_default (data);

  return (EXIT_SUCCESS);
}

// Apply IPv6 ICMP default settings
int
icmp6_default (SPSData *data)
{
  int status, i;
  char *ipaddress, *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Array to hold an IPv4 or IPv6 address + '\0'
  ipaddress = allocate_strmem (INET6_ADDRSTRLEN);

  // Number of ethernet frames
  data->nframes[4] = 1;

  // Ethernet header

  // Set flag for user to specify ethernet header. This will never change for IPv6.
  data->specify_ether[4] = 1;

  // Destination link-layer (MAC) address (48 bits): default to zero; user needs to fill out
  memset (data->ethhdr[4].dst_mac, 0, 6 * sizeof (uint8_t));
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  mac_bin2string (data->ethhdr[4].dst_mac, value);
  gtk_entry_set_text (GTK_ENTRY (data->entry128), value);

  // Source Interface Name: defaults to blank
  memset (data->ifname[4], 0, TMP_STRINGLEN * sizeof (char));
  gtk_entry_set_text (GTK_ENTRY (data->entry153), "");

  // Default interface MTU
  data->ifmtu[4] = 1500;

  // Set spinbutton value to interface MTU.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton9), data->ifmtu[4]);

  // Source link-layer (MAC) address (48 bits): default to zero; user needs to fill out
  memset (data->ethhdr[4].src_mac, 0, 6 * sizeof (uint8_t));
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  mac_bin2string (data->ethhdr[4].src_mac, value);
  gtk_entry_set_text (GTK_ENTRY (data->entry129), value);
  
  // Ethernet type code (16 bits): default to IPv6
  // http://www.iana.org/assignments/ethernet-numbers
  data->ethhdr[4].type_code = htons (ETH_P_IPV6);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ethhdr[4].type_code));
  gtk_entry_set_text (GTK_ENTRY (data->entry130), value);

  // Deal with ICMP data first so that lengths and offsets
  // are correct for updating IP and ICMP headers.

  // ICMP data

  // Clear ICMP data buffer.
  memset (data->payload[4], 0, IP_MAXPACKET * sizeof (uint8_t));
  data->payloadlen[4] = 0;
  gtk_entry_set_text (GTK_ENTRY (data->entry127), "");

  // ICMP data entry format: default to hexadecimal input
  data->ascii_hex_icmp6 = 1;
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton12), TRUE);

  // Hop-by-hop options

  // No hop-by-hop options
  data->hbh_hdr_flag[4] = 0;
  data->hbh_nopt[4] = 0;

  // Clear all hop-by-hop option lengths.
  memset (data->hbh_optlen[4], 0, MAX_HBHOPTIONS * sizeof (int));

  // Clear all hop-by-hop options.
  for (i=0; i<MAX_HBHOPTIONS; i++) {
    memset (data->hbh_options[4][i], 0, MAX_HBHOPTLEN * sizeof (uint8_t));
  }

  // Total length of hop-by-hop options is zero.
  data->hbh_opt_totlen[4] = 0;
  data->hophdr[4].hdr_len = 0;

  // Option alignment parameter x (of xN + y)
  memset (data->hbh_x[4], 0, MAX_HBHOPTIONS * sizeof (int));

  // Option alignment parameter y (of xN + y)
  memset (data->hbh_y[4], 0, MAX_HBHOPTIONS * sizeof (int));

  // Hop-by-hop header options padding length (includes alignment padding)
  data->hbh_optpadlen[4] = 0;  // Hop-by-hop options padding: hbh_optpadlen[type] = int

  // Destination options

  // No destination options
  data->dstf_hdr_flag[4] = 0;
  data->dstf_nopt[4] = 0;
  data->dstl_hdr_flag[4] = 0;
  data->dstl_nopt[4] = 0;
  
  // Clear all destination option lengths.
  memset (data->dstf_optlen[4], 0, MAX_DSTOPTIONS * sizeof (int));
  memset (data->dstl_optlen[4], 0, MAX_DSTOPTIONS * sizeof (int));
  
  // Clear all destination options.
  for (i=0; i<MAX_DSTOPTIONS; i++) {
    memset (data->dstf_options[4][i], 0, MAX_DSTOPTLEN * sizeof (uint8_t));
    memset (data->dstl_options[4][i], 0, MAX_DSTOPTLEN * sizeof (uint8_t));
  }

  // Total length of destination options is zero.
  data->dstf_opt_totlen[4] = 0;
  data->dstfhdr[4].hdr_len = 0;
  data->dstl_opt_totlen[4] = 0;
  data->dstlhdr[4].hdr_len = 0;

  // Option alignment parameter x (of xN + y)
  memset (data->dstf_x[4], 0, MAX_DSTOPTIONS * sizeof (int));
  memset (data->dstl_x[4], 0, MAX_DSTOPTIONS * sizeof (int));

  // Option alignment parameter y (of xN + y)
  memset (data->dstf_y[4], 0, MAX_DSTOPTIONS * sizeof (int));
  memset (data->dstl_y[4], 0, MAX_DSTOPTIONS * sizeof (int));

  // Destination header options padding length (includes alignment padding)
  data->dstf_optpadlen[4] = 0;  // Destination options padding: dstf_optpadlen[type] = int
  data->dstl_optpadlen[4] = 0;  // Destination options padding: dstl_optpadlen[type] = int

  // Routing header

  // No routing header
  data->route_hdr_flag[4] = 0;
  data->route_datlen[4] = 0;
  data->routehdr[4].hdr_len = 0;
  data->routehdr[4].routing_type = 0;
  data->routehdr[4].segs_left = 0;
  memset (data->route_data[4], 0, MAX_ROUTEDATA * sizeof (uint8_t));

  // Authentication header

  // No authentication header
  data->auth_hdr_flag[4] = 0;
  data->auth_len[4] = 0;
  data->authhdr[4].pay_len = 0;
  data->authhdr[4].reserved = 0;
  data->authhdr[4].spi = 0;
  data->authhdr[4].seq = 0;
  memset (data->auth_data[4], 0, MAX_AUTHICVLEN * sizeof (uint8_t));

  // Encapsulating security payload (ESP)

  // No ESP header and no ESP tail
  data->esp_hdr_flag[4] = 0;
  data->esp_auth_len[4] = 0;
  data->esphdr[4].spi = 0;
  data->esphdr[4].seq = 0;
  data->esptail[4].pad_len = 0;
  memset (data->esp_auth_data[4], 0, MAX_ESPICVLEN * sizeof (uint8_t));
  data->esptail[4].pad_len = 0;  // Padding length
  memset (data->esp_pad[4], 0, 255 * sizeof (uint8_t));

  // ESP trailer Next Header field
  data->esptail[4].nxt_hdr = IPPROTO_ICMPV6;

  // IPv6 header

  // IPv6 version (4 bits), Traffic class (8 bits), Flow label (20 bits)
  data->ip6hdr[4].ip6_flow = htonl ((6 << 28) | (0 << 20) | 0);

  // Version (4 bits)
  sprintf (value, "%" PRIu32, (uint32_t) (ntohl (data->ip6hdr[4].ip6_flow) >> 28));
  gtk_entry_set_text (GTK_ENTRY (data->entry110), value);

  // Traffic Class (8 bits)
  sprintf (value, "%" PRIu32, (uint32_t) ((ntohl (data->ip6hdr[4].ip6_flow) >> 20) & 0xfful));
  gtk_entry_set_text (GTK_ENTRY (data->entry111), value);

  // Flow Label (20 bits)
  sprintf (value, "%" PRIu32, (uint32_t) (ntohl (data->ip6hdr[4].ip6_flow) & 0xffffful));
  gtk_entry_set_text (GTK_ENTRY (data->entry112), value);

  // Payload length (16 bits): ICMP header + ICMP data
  data->ip6hdr[4].ip6_plen = htons (ICMP_HDRLEN + data->payloadlen[4]);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip6hdr[4].ip6_plen));
  gtk_entry_set_text (GTK_ENTRY (data->entry113), value);

  // Next header (8 bits): 58 for ICMP
  data->ip6hdr[4].ip6_nxt = IPPROTO_ICMPV6;
  sprintf (value, "%" PRIu8, (uint8_t) data->ip6hdr[4].ip6_nxt);
  gtk_entry_set_text (GTK_ENTRY (data->entry114), value);

  // Hop limit (8 bits): default to maximum value
  data->ip6hdr[4].ip6_hops = 255u;
  sprintf (value, "%" PRIu8, (uint8_t) data->ip6hdr[4].ip6_hops);
  gtk_entry_set_text (GTK_ENTRY (data->entry115), value);

  // Source IPv6 address (128 bits): default to random
  data->ran_icmp6_sourceip = 1;
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton10), TRUE);
  if ((status = inet_pton (AF_INET6, ran6_addr (ipaddress, data), &(data->ip6hdr[4].ip6_src))) != 1) {
    sprintf (data->error_text, "icmp6_default(): inet_pton() failed for randomized source IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ipaddress);
    free (value);
    return (EXIT_FAILURE);
  }
  if (inet_ntop (AF_INET6, &(data->ip6hdr[4].ip6_src), value, INET6_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "icmp6_default(): inet_ntop() failed for source IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ipaddress);
    free (value);
    return (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry109), value);

  // Destination IPv6 address (128 bits): default to loopback IP address to be safe
  memset (ipaddress, 0, INET6_ADDRSTRLEN * sizeof (char));
  strncpy (ipaddress, "::1", 3);
  if ((status = inet_pton (AF_INET6, ipaddress, &(data->ip6hdr[4].ip6_dst))) != 1) {
    sprintf (data->error_text, "icmp6_default(): inet_pton() failed for destination IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ipaddress);
    free (value);
    return (EXIT_FAILURE);
  }
  if (inet_ntop (AF_INET6, &(data->ip6hdr[4].ip6_dst), value, INET6_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "icmp6_default(): inet_ntop() failed for destination IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ipaddress);
    free (value);
    return (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry116), value);

  // ICMP header (IPv6)

  // Message Type (8 bits): 128 is echo request
  data->icmp6hdr[4].icmp6_type = ICMP6_ECHO_REQUEST;
  sprintf (value, "%" PRIu8, (uint8_t) data->icmp6hdr[4].icmp6_type);
  gtk_entry_set_text (GTK_ENTRY (data->entry117), value);

  // Message Code (8 bits): echo request
  data->icmp6hdr[4].icmp6_code = 0;
  sprintf (value, "%" PRIu8, (uint8_t) data->icmp6hdr[4].icmp6_code);
  gtk_entry_set_text (GTK_ENTRY (data->entry118), value);

  // Identifier (16 bits): usually pid of sending process - we'll arbitrarily use 1000
  data->icmp6hdr[4].icmp6_id = htons (1000u);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->icmp6hdr[4].icmp6_id));
  gtk_entry_set_text (GTK_ENTRY (data->entry120), value);

  // Sequence Number (16 bits): starts at 0
  data->icmp6hdr[4].icmp6_seq = htons (0);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->icmp6hdr[4].icmp6_seq));
  gtk_entry_set_text (GTK_ENTRY (data->entry121), value);

  // ICMP header checksum (16 bits)
  data->icmp6hdr[4].icmp6_cksum = icmp6_checksum (data->ip6hdr[4], data->icmp6hdr[4], data->payload[4], data->payloadlen[4]);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->icmp6hdr[4].icmp6_cksum));
  gtk_entry_set_text (GTK_ENTRY (data->entry119), value);

  // Free allocated memory.
  free (value);
  free (ipaddress);

  // Update ethernet frame.
  create_ip6_frame (4, data);

  // Apply default 6to4 settings.
  sixto4_icmp6_default (data);

  return (EXIT_SUCCESS);
}

// Apply IPv6 UDP default settings
int
udp6_default (SPSData *data)
{
  int status, i;
  char *ipaddress, *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Array to hold an IPv4 or IPv6 address + '\0'
  ipaddress = allocate_strmem (INET6_ADDRSTRLEN);

  // Number of ethernet frames
  data->nframes[5] = 1;

  // Ethernet header

  // Set flag for user to specify ethernet header. This will never change for IPv6.
  data->specify_ether[5] = 1;

  // Destination link-layer (MAC) address (48 bits): default to zero; user needs to fill out
  memset (data->ethhdr[5].dst_mac, 0, 6 * sizeof (uint8_t));
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  mac_bin2string (data->ethhdr[5].dst_mac, value);
  gtk_entry_set_text (GTK_ENTRY (data->entry134), value);

  // Source Interface Name: defaults to blank
  memset (data->ifname[5], 0, TMP_STRINGLEN * sizeof (char));
  gtk_entry_set_text (GTK_ENTRY (data->entry155), "");

  // Default interface MTU
  data->ifmtu[5] = 1500;

  // Set spinbutton value to interface MTU.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (data->spinbutton10), data->ifmtu[5]);

  // Source link-layer (MAC) address (48 bits): default to zero; user needs to fill out
  memset (data->ethhdr[5].src_mac, 0, 6 * sizeof (uint8_t));
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  mac_bin2string (data->ethhdr[5].src_mac, value);
  gtk_entry_set_text (GTK_ENTRY (data->entry135), value);
  
  // Ethernet type code (16 bits): default to IPv6
  // http://www.iana.org/assignments/ethernet-numbers
  data->ethhdr[5].type_code = htons (ETH_P_IPV6);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ethhdr[5].type_code));
  gtk_entry_set_text (GTK_ENTRY (data->entry136), value);

  // Deal with UDP data first so that lengths and offsets
  // are correct for updating IP and UDP headers.

  // UDP data

  // Clear UDP data buffer.
  memset (data->payload[5], 0, IP_MAXPACKET * sizeof (uint8_t));
  data->payloadlen[5] = 0;
  gtk_entry_set_text (GTK_ENTRY (data->entry108), "");

  // UDP data entry format: default to hexadecimal input
  data->ascii_hex_udp6 = 1;
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton16), TRUE);

  // Hop-by-hop options

  // No hop-by-hop options
  data->hbh_hdr_flag[5] = 0;
  data->hbh_nopt[5] = 0;

  // Clear all hop-by-hop option lengths.
  memset (data->hbh_optlen[5], 0, MAX_HBHOPTIONS * sizeof (int));

  // Clear all hop-by-hop options.
  for (i=0; i<MAX_HBHOPTIONS; i++) {
    memset (data->hbh_options[5][i], 0, MAX_HBHOPTLEN * sizeof (uint8_t));
  }

  // Total length of hop-by-hop options is zero.
  data->hbh_opt_totlen[5] = 0;
  data->hophdr[5].hdr_len = 0;

  // Option alignment parameter x (of xN + y)
  memset (data->hbh_x[5], 0, MAX_HBHOPTIONS * sizeof (int));

  // Option alignment parameter y (of xN + y)
  memset (data->hbh_y[5], 0, MAX_HBHOPTIONS * sizeof (int));

  // Hop-by-hop header options padding length (includes alignment padding)
  data->hbh_optpadlen[5] = 0;  // Hop-by-hop options padding: hbh_optpadlen[type] = int

  // Destination options

  // No destination options
  data->dstf_hdr_flag[5] = 0;
  data->dstf_nopt[5] = 0;
  data->dstl_hdr_flag[5] = 0;
  data->dstl_nopt[5] = 0;
  
  // Clear all destination option lengths.
  memset (data->dstf_optlen[5], 0, MAX_DSTOPTIONS * sizeof (int));
  memset (data->dstl_optlen[5], 0, MAX_DSTOPTIONS * sizeof (int));
  
  // Clear all destination options.
  for (i=0; i<MAX_DSTOPTIONS; i++) {
    memset (data->dstf_options[5][i], 0, MAX_DSTOPTLEN * sizeof (uint8_t));
    memset (data->dstl_options[5][i], 0, MAX_DSTOPTLEN * sizeof (uint8_t));
  }

  // Total length of destination options is zero.
  data->dstf_opt_totlen[5] = 0;
  data->dstfhdr[5].hdr_len = 0;
  data->dstl_opt_totlen[5] = 0;
  data->dstlhdr[5].hdr_len = 0;

  // Option alignment parameter x (of xN + y)
  memset (data->dstf_x[5], 0, MAX_DSTOPTIONS * sizeof (int));
  memset (data->dstl_x[5], 0, MAX_DSTOPTIONS * sizeof (int));

  // Option alignment parameter y (of xN + y)
  memset (data->dstf_y[5], 0, MAX_DSTOPTIONS * sizeof (int));
  memset (data->dstl_y[5], 0, MAX_DSTOPTIONS * sizeof (int));

  // Destination header options padding length (includes alignment padding)
  data->dstf_optpadlen[5] = 0;  // Destination options padding: dstf_optpadlen[type] = int
  data->dstl_optpadlen[5] = 0;  // Destination options padding: dstl_optpadlen[type] = int

  // Routing header

  // No routing header
  data->route_hdr_flag[5] = 0;
  data->route_datlen[5] = 0;
  data->routehdr[5].hdr_len = 0;
  data->routehdr[5].routing_type = 0;
  data->routehdr[5].segs_left = 0;
  memset (data->route_data[5], 0, MAX_ROUTEDATA * sizeof (uint8_t));

  // Authentication header

  // No authentication header
  data->auth_hdr_flag[5] = 0;
  data->auth_len[5] = 0;
  data->authhdr[5].pay_len = 0;
  data->authhdr[5].reserved = 0;
  data->authhdr[5].spi = 0;
  data->authhdr[5].seq = 0;
  memset (data->auth_data[5], 0, MAX_AUTHICVLEN * sizeof (uint8_t));

  // Encapsulating security payload (ESP)

  // No ESP header and no ESP tail
  data->esp_hdr_flag[5] = 0;
  data->esp_auth_len[5] = 0;
  data->esphdr[5].spi = 0;
  data->esphdr[5].seq = 0;
  data->esptail[5].pad_len = 0;
  memset (data->esp_auth_data[5], 0, MAX_ESPICVLEN * sizeof (uint8_t));
  data->esptail[5].pad_len = 0;  // Padding length
  memset (data->esp_pad[5], 0, 255 * sizeof (uint8_t));

  // ESP trailer Next Header field
  data->esptail[5].nxt_hdr = IPPROTO_UDP;

  // IPv6 header

  // IPv6 version (4 bits), Traffic class (8 bits), Flow label (20 bits)
  data->ip6hdr[5].ip6_flow = htonl ((6 << 28) | (0 << 20) | 0);

  // Version (4 bits)
  sprintf (value, "%" PRIu32, (uint32_t) (ntohl (data->ip6hdr[5].ip6_flow) >> 28));
  gtk_entry_set_text (GTK_ENTRY (data->entry97), value);

  // Traffic Class (8 bits)
  sprintf (value, "%" PRIu32, (uint32_t) ((ntohl (data->ip6hdr[5].ip6_flow) >> 20) & 0xfful));
  gtk_entry_set_text (GTK_ENTRY (data->entry98), value);

  // Flow Label (20 bits)
  sprintf (value, "%" PRIu32, (uint32_t) (ntohl (data->ip6hdr[5].ip6_flow) & 0xffffful));
  gtk_entry_set_text (GTK_ENTRY (data->entry99), value);

  // Payload length (16 bits): UDP header + UDP payload
  data->ip6hdr[5].ip6_plen = htons (UDP_HDRLEN + data->payloadlen[5]);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->ip6hdr[5].ip6_plen));
  gtk_entry_set_text (GTK_ENTRY (data->entry100), value);

  // Next header (8 bits): 17 for UDP
  data->ip6hdr[5].ip6_nxt = IPPROTO_UDP;
  sprintf (value, "%" PRIu8, (uint8_t) data->ip6hdr[5].ip6_nxt);
  gtk_entry_set_text (GTK_ENTRY (data->entry101), value);

  // Hop limit (8 bits): default to maximum value
  data->ip6hdr[5].ip6_hops = 255u;
  sprintf (value, "%" PRIu8, (uint8_t) data->ip6hdr[5].ip6_hops);
  gtk_entry_set_text (GTK_ENTRY (data->entry102), value);

  // Source IPv6 address (128 bits): default to random
  data->ran_udp6_sourceip = 1;
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton6), TRUE);
  if ((status = inet_pton (AF_INET6, ran6_addr (ipaddress, data), &(data->ip6hdr[5].ip6_src))) != 1) {
    sprintf (data->error_text, "udp6_default(): inet_pton() failed for randomized source IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ipaddress);
    free (value);
    return (EXIT_FAILURE);
  }
  if (inet_ntop (AF_INET6, &(data->ip6hdr[5].ip6_src), value, INET6_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "udp6_default(): inet_ntop() failed for source IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ipaddress);
    free (value);
    return (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry96), value);

  // Destination IPv6 address (128 bits): default to loopback IP address to be safe
  memset (ipaddress, 0, INET6_ADDRSTRLEN * sizeof (char));
  strncpy (ipaddress, "::1", 3);
  if ((status = inet_pton (AF_INET6, ipaddress, &(data->ip6hdr[5].ip6_dst))) != 1) {
    sprintf (data->error_text, "udp6_default(): inet_pton() failed for destination IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ipaddress);
    free (value);
    return (EXIT_FAILURE);
  }
  if (inet_ntop (AF_INET6, &(data->ip6hdr[5].ip6_dst), value, INET6_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "udp6_default(): inet_ntop() failed for destination IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (ipaddress);
    free (value);
    return (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry103), value);

  // UDP header (IPv6)

  // Source port number (16 bits): default to random
  data->ran_udp6_sourceport = 1;
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->checkbutton8), TRUE);
  data->udphdr[5].uh_sport = htons (ran16_0to65535 (data));
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->udphdr[5].uh_sport));
  gtk_entry_set_text (GTK_ENTRY (data->entry104), value);

  // Destination port number (16 bits): we'll arbitrarily use 4950
  data->udphdr[5].uh_dport = htons (4950u);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->udphdr[5].uh_dport));
  gtk_entry_set_text (GTK_ENTRY (data->entry105), value);

  // Length of UDP datagram (16 bits): UDP header + UDP payload
  data->udphdr[5].uh_ulen = htons (UDP_HDRLEN + data->payloadlen[5]);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->udphdr[5].uh_ulen));
  gtk_entry_set_text (GTK_ENTRY (data->entry106), value);

  // UDP header checksum (16 bits)
  data->udphdr[5].uh_sum = udp6_checksum (data->ip6hdr[5], data->udphdr[5], data->payload[5], data->payloadlen[5]);
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->udphdr[5].uh_sum));
  gtk_entry_set_text (GTK_ENTRY (data->entry107), value);

  // Free allocated memory.
  free (value);
  free (ipaddress);

  // Update ethernet frame.
  create_ip6_frame (5, data);

  // Apply default 6to4 settings.
  sixto4_udp6_default (data);

  return (EXIT_SUCCESS);
}
