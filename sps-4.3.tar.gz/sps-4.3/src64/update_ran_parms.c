/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Update all randomized parameters (IPv4 and IPv6, including traceroute).
int
update_ran_parms (SPSData *data)
{
  int status;
  char *ipaddress;

  // Allocate memory for various arrays.
  ipaddress = allocate_strmem (INET6_ADDRSTRLEN);

  // IPv4 non-traceroute

  // TCP source IPv4 address
  if (data->ran_tcp4_sourceip) {
    if ((status = inet_pton (AF_INET, ran4_addr (ipaddress, data), &data->ip4hdr[0].ip_src)) != 1) {
      sprintf (data->error_text, "ipv4_send(): inet_pton() failed for randomized TCP source IP address.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      report_error (data);
      free (ipaddress);
      return (EXIT_FAILURE);
    }
    data->ip4hdr[0].ip_sum = 0;
    data->ip4hdr[0].ip_sum = ip4_checksum (data->ip4hdr[0], data->ip_nopt[0], data->ip_optlen[0], data->ip_options[0], data->ip_optpadlen[0]);
  }

  // ICMP source IPv4 address
  if (data->ran_icmp4_sourceip) {
    if ((status = inet_pton (AF_INET, ran4_addr (ipaddress, data), &data->ip4hdr[1].ip_src)) != 1) {
      sprintf (data->error_text, "ipv4_send(): inet_pton() failed for randomized ICMP source IP address.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      report_error (data);
      free (ipaddress);
      return (EXIT_FAILURE);
    }
    data->ip4hdr[1].ip_sum = 0;
    data->ip4hdr[1].ip_sum = ip4_checksum (data->ip4hdr[1], data->ip_nopt[1], data->ip_optlen[1], data->ip_options[1], data->ip_optpadlen[1]);
  }

  // UDP source IPv4 address
  if (data->ran_udp4_sourceip) {
    if ((status = inet_pton (AF_INET, ran4_addr (ipaddress, data), &data->ip4hdr[2].ip_src)) != 1) {
      sprintf (data->error_text, "ipv4_send(): inet_pton() failed for randomized UDP source IP address.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      report_error (data);
      free (ipaddress);
      return (EXIT_FAILURE);
    }
    data->ip4hdr[2].ip_sum = 0;
    data->ip4hdr[2].ip_sum = ip4_checksum (data->ip4hdr[2], data->ip_nopt[2], data->ip_optlen[2], data->ip_options[2], data->ip_optpadlen[2]);
  }

  // TCP source port (IPv4)
  if (data->ran_tcp4_sourceport) {
    data->tcphdr[0].th_sport = htons (ran16_0to65535 (data));
  }

  // UDP source port (IPv4)
  if (data->ran_udp4_sourceport) {
    data->udphdr[2].uh_sport = htons (ran16_0to65535 (data));
  }

  // Update upper layer protocol checksums and ethernet frames.

  // TCP (IPv4)
  if ((data->ran_tcp4_sourceip) || (data->ran_tcp4_sourceport)) {
    data->tcphdr[0].th_sum = tcp4_checksum (data->ip4hdr[0], data->tcphdr[0], data->tcp_nopt[0], data->tcp_opt_totlen[0], data->tcp_optlen[0], data->tcp_options[0], data->tcp_optpadlen[0], data->payload[0], data->payloadlen[0]);
    create_ip4_frame (0, data);
  }

  // ICMP (IPv4)
  if (data->ran_icmp4_sourceip) {
    create_ip4_frame (1, data);
  }

  // UDP (IPv4)
  if ((data->ran_udp4_sourceip) || (data->ran_udp4_sourceport)) {
    data->udphdr[2].uh_sum = udp4_checksum (data->ip4hdr[2], data->udphdr[2], data->payload[2], data->payloadlen[2]);
    create_ip4_frame (2, data);
  }

  // Update user interface.
  update_ip4_sources (data);

  // IPv4 traceroute

  // TCP source port (IPv4) for traceroute
  if (data->ran_tcp4_tr_sourceport) {
    data->tcphdr[9].th_sport = htons (ran16_0to65535 (data));
    data->tcphdr[9].th_sum = tcp4_checksum (data->ip4hdr[9], data->tcphdr[9], data->tcp_nopt[9], data->tcp_opt_totlen[9], data->tcp_optlen[9], data->tcp_options[9], data->tcp_optpadlen[9], data->payload[9], data->payloadlen[9]);
    create_ip4_frame (9, data);
  }

  // UDP source port (IPv4) for traceroute
  if (data->ran_udp4_tr_sourceport) {
    data->udphdr[11].uh_sport = htons (ran16_0to65535 (data));
    data->udphdr[11].uh_sum = udp4_checksum (data->ip4hdr[11], data->udphdr[11], data->payload[11], data->payloadlen[11]);
    create_ip4_frame (11, data);
  }

  // Update user interface.
  if (data->traceroute_flag) {
    update_tr_ip4_sources (data);
  }

  // IPv6 non-traceroute

  // TCP source IPv6 address
  if (data->ran_tcp6_sourceip) {
    if ((status = inet_pton (AF_INET6, ran6_addr (ipaddress, data), &data->ip6hdr[3].ip6_src)) != 1) {
      sprintf (data->error_text, "ipv6_send(): inet_pton() failed for randomized TCP source IP address.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      report_error (data);
      free (ipaddress);
      return (EXIT_FAILURE);
    }
    memcpy (&data->ip6hdr[6], &data->ip6hdr[3], IP6_HDRLEN * sizeof (uint8_t));
  }

  // ICMP source IPv6 address
  if (data->ran_icmp6_sourceip) {
    if ((status = inet_pton (AF_INET6, ran6_addr (ipaddress, data), &data->ip6hdr[4].ip6_src)) != 1) {
      sprintf (data->error_text, "ipv6_send(): inet_pton() failed for randomized ICMP source IP address.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      report_error (data);
      free (ipaddress);
      return (EXIT_FAILURE);
    }
    memcpy (&data->ip6hdr[7], &data->ip6hdr[4], IP6_HDRLEN * sizeof (uint8_t));
  }

  // UDP source IPv6 address
  if (data->ran_udp6_sourceip) {
    if ((status = inet_pton (AF_INET6, ran6_addr (ipaddress, data), &data->ip6hdr[5].ip6_src)) != 1) {
      sprintf (data->error_text, "ipv6_send(): inet_pton() failed randomized UDP source IP address.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      report_error (data);
      free (ipaddress);
      return (EXIT_FAILURE);
    }
    memcpy (&data->ip6hdr[8], &data->ip6hdr[5], IP6_HDRLEN * sizeof (uint8_t));
  }

  // TCP source port (IPv6)
  if (data->ran_tcp6_sourceport) {
    data->tcphdr[3].th_sport = htons (ran16_0to65535 (data));
  }

  // UDP source port (IPv6)
  if (data->ran_udp6_sourceport) {
    data->udphdr[5].uh_sport = htons (ran16_0to65535 (data));
  }

  // Update upper layer protocol checksums and ethernet frames.

  // TCP checksum (IPv6)
  if ((data->ran_tcp6_sourceip) || (data->ran_tcp6_sourceport)) {
    data->tcphdr[3].th_sum = tcp6_checksum (data->ip6hdr[3], data->tcphdr[3], data->tcp_nopt[3], data->tcp_opt_totlen[3], data->tcp_optlen[3], data->tcp_options[3], data->tcp_optpadlen[3], data->payload[3], data->payloadlen[3]);
    create_ip6_frame (3, data);
    create_6to4_frame (6, data);
  }

  // ICMP checksum (IPv6)
  if (data->ran_icmp6_sourceip) {
    data->icmp6hdr[4].icmp6_cksum = icmp6_checksum (data->ip6hdr[4], data->icmp6hdr[4], data->payload[4], data->payloadlen[4]);
    create_ip6_frame (4, data);
    create_6to4_frame (7, data);
  }

  // UDP checksum (IPv6)
  if ((data->ran_udp6_sourceip) || (data->ran_udp6_sourceport)) {
    data->udphdr[5].uh_sum = udp6_checksum (data->ip6hdr[5], data->udphdr[5], data->payload[5], data->payloadlen[5]);
    create_ip6_frame (5, data);
    create_6to4_frame (8, data);
  }

  // Update user interface.
  update_ip6_sources (data);

  // IPv6 traceroute

  // TCP source port (IPv6) for traceroute
  if (data->ran_tcp6_tr_sourceport) {
    data->tcphdr[12].th_sport = htons (ran16_0to65535 (data));
    data->tcphdr[12].th_sum = tcp6_checksum (data->ip6hdr[12], data->tcphdr[12], data->tcp_nopt[12], data->tcp_opt_totlen[12], data->tcp_optlen[12], data->tcp_options[12], data->tcp_optpadlen[12], data->payload[12], data->payloadlen[12]);
    create_ip6_frame (12, data);
    create_6to4_frame (15, data);
  }

  // UDP source port (IPv6) for traceroute
  if (data->ran_udp6_tr_sourceport) {
    data->udphdr[14].uh_sport = htons (ran16_0to65535 (data));
    data->udphdr[14].uh_sum = udp6_checksum (data->ip6hdr[14], data->udphdr[14], data->payload[14], data->payloadlen[14]);
    create_ip6_frame (14, data);
    create_6to4_frame (17, data);
  }

  // Update user interface.
  if (data->traceroute_flag) {
    update_tr_ip6_sources (data);
  }

  // 6to4 non-traceroute

  // TCP source IPv4 address for 6to4
  if (data->ran_tcp6to4_sourceip) {
    if ((status = inet_pton (AF_INET, ran4_addr (ipaddress, data), &data->ip4hdr[6].ip_src)) != 1) {
      sprintf (data->error_text, "sixto4_send(): inet_pton() failed for randomized TCP source IPv4 address.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      report_error (data);
      free (ipaddress);
      return (EXIT_FAILURE);
    }
    data->ip4hdr[6].ip_sum = 0;
    data->ip4hdr[6].ip_sum = checksum ((uint16_t *) &data->ip4hdr[6], IP4_HDRLEN);
    create_6to4_frame (6, data);
  }

  // ICMP source IPv4 address for 6to4
  if (data->ran_icmp6to4_sourceip) {
    if ((status = inet_pton (AF_INET, ran4_addr (ipaddress, data), &data->ip4hdr[7].ip_src)) != 1) {
      sprintf (data->error_text, "sixto4_send(): inet_pton() failed for randomized ICMP source IPv4 address.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      report_error (data);
      free (ipaddress);
      return (EXIT_FAILURE);
    }
    data->ip4hdr[7].ip_sum = 0;
    data->ip4hdr[7].ip_sum = checksum ((uint16_t *) &data->ip4hdr[7], IP4_HDRLEN);
    create_6to4_frame (7, data);
  }

  // UDP source IPv4 address for 6to4
  if (data->ran_udp6to4_sourceip) {
    if ((status = inet_pton (AF_INET, ran4_addr (ipaddress, data), &data->ip4hdr[8].ip_src)) != 1) {
      sprintf (data->error_text, "sixto4_send(): inet_pton() failed for randomized UDP source IPv4 address.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      report_error (data);
      free (ipaddress);
      return (EXIT_FAILURE);
    }
    data->ip4hdr[8].ip_sum = 0;
    data->ip4hdr[8].ip_sum = checksum ((uint16_t *) &data->ip4hdr[8], IP4_HDRLEN);
    create_6to4_frame (8, data);
  }

  // Update user interface.
  update_6to4_sources (data);

  // 6to4 traceroute

  // Source IPv4 addresses for 6to4 are never randomized because otherwise the traceroute
  // would fail to receive the probe reponses.

  // Free allocated memory.
  free (ipaddress);

  return (EXIT_SUCCESS);
}
