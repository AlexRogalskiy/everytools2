/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

extern int message_available;  // A message is available to be displayed in a dialog by thread_listen()
extern int sending;  // Sending flag indicating SPS is sending finite number of packets
extern int stop_thread_listen;  // Flag to cause timeout function thread_listen() to stop

G_LOCK_EXTERN (message_available);  // MUTEX for flag indicating a message from a download or traceroute thread is available to be displayed in a dialog by thread_listen()
G_LOCK_EXTERN (sending);  // MUTEX for flag indicating packets are being sent

// Timeout function to monitor for error/finished messages from child threads.
// This timeout function returns 0 in order to stop.
int
thread_listen (SPSData *data)
{
  if (message_available) {
    GtkWidget *dialog, *content_area, *image, *label, *hbox;

    // data->parent is a pointer to the widget whence the error originated.
    // It can point to things like data->main_window, data->menubar1, or data->traceroute_window
    dialog = gtk_dialog_new_with_buttons ("Error", GTK_WINDOW (data->parent), GTK_DIALOG_MODAL, "OK", GTK_RESPONSE_OK, NULL);

    gtk_dialog_set_has_separator (GTK_DIALOG (dialog), FALSE);  // No separater

    g_signal_connect_swapped (dialog, "response", G_CALLBACK (gtk_widget_destroy), dialog);

    content_area = gtk_dialog_get_content_area (GTK_DIALOG (dialog));

    label = gtk_label_new (data->error_text);
    image = gtk_image_new_from_icon_name ("dialog-error", GTK_ICON_SIZE_DIALOG);

    hbox = gtk_hbox_new (FALSE, 5);  // Don't require homogeneous, 5 px spacing
    gtk_container_set_border_width (GTK_CONTAINER (hbox), 10);  // 10 px
    gtk_box_pack_start_defaults (GTK_BOX (hbox), image);  // Add error symbol to hbox
    gtk_box_pack_start_defaults (GTK_BOX (hbox), label);  // Add our text to hbox

    // Pack the dialog content into the dialog's GtkVBox.
    gtk_box_pack_start_defaults (GTK_BOX (GTK_DIALOG (dialog)->vbox), hbox);

    gtk_widget_show_all (dialog);

    gtk_dialog_run (GTK_DIALOG (dialog));

    // Clear the Message Available flag since we've displayed it.
    // Timeout functions are outside of the main GTK+ lock, so we must
    // lock this flag manually.
    G_LOCK (message_available);
    message_available = 0;
    G_UNLOCK (message_available);

    return (1);  // This timeout function will continue because we returned a non-zero value.
  }

  // This timeout will continue if no errors occur.
  // So stop it if it isn't needed for monitoring a thread anymore.
  if (stop_thread_listen) {
    stop_thread_listen = 0;
    return (0);  // This timeout function will be stopped by returning a value of zero.
  }

  return (1);  // This timeout function will continue because we returned a non-zero value.
}

// Report a warning condition to a GtkDialog
int
report_warning (SPSData *data)
{
  GtkWidget *dialog, *content_area, *image, *label, *hbox;

  // data->parent is a pointer to the widget whence the warning originated.
  // It can point to things like data->main_window or data->menubar1
  dialog = gtk_dialog_new_with_buttons ("Warning", GTK_WINDOW (data->parent), GTK_DIALOG_MODAL, "OK", GTK_RESPONSE_OK, NULL);

  gtk_dialog_set_has_separator (GTK_DIALOG (dialog), FALSE);  // No separater

  g_signal_connect_swapped (dialog, "response", G_CALLBACK (gtk_widget_destroy), dialog);

  content_area = gtk_dialog_get_content_area (GTK_DIALOG (dialog));

  label = gtk_label_new (data->warning_text);
  image = gtk_image_new_from_icon_name ("dialog-warning", GTK_ICON_SIZE_DIALOG);

  hbox = gtk_hbox_new (FALSE, 5);  // Don't require homogeneous, 5 px spacing
  gtk_container_set_border_width (GTK_CONTAINER (hbox), 10);  // 10 px
  gtk_box_pack_start_defaults (GTK_BOX (hbox), image);  // Add warning symbol to hbox
  gtk_box_pack_start_defaults (GTK_BOX (hbox), label);  // Add our text to hbox

  // Pack the dialog content into the dialog's GtkVBox.
  gtk_box_pack_start_defaults (GTK_BOX (GTK_DIALOG (dialog)->vbox), hbox);

  gtk_widget_show_all (dialog);

  gtk_dialog_run (GTK_DIALOG (dialog));

  return (EXIT_SUCCESS);
}

// Report an error condition to a GtkDialog
int
report_error (SPSData *data)
{
  GtkWidget *dialog, *content_area, *image, *label, *hbox;

  // data->parent is a pointer to the widget whence the error originated.
  // It can point to things like data->main_window or data->menubar1
  dialog = gtk_dialog_new_with_buttons ("Error", GTK_WINDOW (data->parent), GTK_DIALOG_MODAL, "OK", GTK_RESPONSE_OK, NULL);

  gtk_dialog_set_has_separator (GTK_DIALOG (dialog), FALSE);  // No separater

  g_signal_connect_swapped (dialog, "response", G_CALLBACK (gtk_widget_destroy), dialog);

  content_area = gtk_dialog_get_content_area (GTK_DIALOG (dialog));

  label = gtk_label_new (data->error_text);
  image = gtk_image_new_from_icon_name ("dialog-error", GTK_ICON_SIZE_DIALOG);

  hbox = gtk_hbox_new (FALSE, 5);  // Don't require homogeneous, 5 px spacing
  gtk_container_set_border_width (GTK_CONTAINER (hbox), 10);  // 10 px
  gtk_box_pack_start_defaults (GTK_BOX (hbox), image);  // Add error symbol to hbox
  gtk_box_pack_start_defaults (GTK_BOX (hbox), label);  // Add our text to hbox

  // Pack the dialog content into the dialog's GtkVBox.
  gtk_box_pack_start_defaults (GTK_BOX (GTK_DIALOG (dialog)->vbox), hbox);

  gtk_widget_show_all (dialog);

  gtk_dialog_run (GTK_DIALOG (dialog));

  return (EXIT_SUCCESS);
}

// Function to tell message listener thread_listen() that a
// a send error message is waiting.
void
send_error ()
{
  G_LOCK (message_available);
  message_available = 1;
  G_UNLOCK (message_available);
  G_LOCK (sending);
  sending = 0;
  G_UNLOCK (sending);
}
