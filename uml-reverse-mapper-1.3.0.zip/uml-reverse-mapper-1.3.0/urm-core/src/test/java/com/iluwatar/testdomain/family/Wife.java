package com.iluwatar.testdomain.family;

public class Wife {
    private Husband husband;
}
