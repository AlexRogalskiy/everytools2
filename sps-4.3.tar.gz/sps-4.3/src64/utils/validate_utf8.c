/*  validate_utf8 - a tool to check a file for valid UTF-8 characters

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

// Compile with gcc -Wall validate_utf8.c -o validate_utf8

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>

// Function prototypes
int is_valid_utf8 (uint8_t *, int);
int one_byte (int, int, uint8_t *);
int two_byte (int, int, uint8_t *);
int three_byte (int, int, uint8_t *);
int four_byte (int, int, uint8_t *);
int five_byte (int, int, uint8_t *);
int six_byte (int, int, uint8_t *);
char *allocate_strmem (int);
uint8_t *allocate_ustrmem (int);

int
main (int argc, char **argv)
{
  int i, n, nbytes;
  char *filename;
  uint8_t *data;
  FILE *fi;

  // Allocate memory for various arrays.
  filename = allocate_strmem (1024);

  if (argc == 2) {
    strncpy (filename, argv[1], 1024);
  } else {
    fprintf (stderr, "Usage: validate_utf8 filename\n");
    exit (EXIT_SUCCESS);
  }

  // Open input file.
  fi = fopen (filename, "r");
  if (fi == NULL) {
    fprintf (stderr, "ERROR: Cannot open input file \"%s\".\n", filename);
    exit (EXIT_FAILURE);
  }

  // Load bytes of input file into array data.
  if (fgetc (fi) == EOF) {
    fprintf (stderr, "ERROR: Input file \"%s\" is empty.\n", filename);
    exit (EXIT_FAILURE);
  } else {
    rewind (fi);
    nbytes = 0;
    while ((n = fgetc (fi)) != EOF) {
      nbytes++;
    }
    rewind (fi);
  }

  // Allocate memory for various arrays.
  data = allocate_ustrmem (nbytes);
  for (i=0; i<nbytes; i++) {
    data[i] = (uint8_t) fgetc (fi);
  }

  // Close file descriptor.
  fclose (fi);

  // Check for invalid UTF-8 characters.
  if (!is_valid_utf8 (data, nbytes)) {
    exit (EXIT_FAILURE);
  }

  printf ("Success! File \"%s\" appears to contain only valid UTF-8 characters.\n", filename);

  // Free allocated memory.
  free (filename);
  free (data);

  return (EXIT_SUCCESS);
}

// Examine an array and report any non-UTF-8 characters.
int
is_valid_utf8 (uint8_t *testdata, int nbytes)
{
  int i, j;

  i = 0;
  while (i < nbytes) {
    if (one_byte (nbytes, i, testdata)) {
      i++;
    } else if (two_byte (nbytes, i, testdata)) {
      i += 2;
    } else if (three_byte (nbytes, i, testdata)) {
      i += 3;
    } else if (four_byte (nbytes, i, testdata)) {
      i += 4;
    } else if (five_byte (nbytes, i, testdata)) {
      i += 5;
    } else if (six_byte (nbytes, i, testdata)) {
      i += 6;
    } else {
      fprintf (stderr, "Failure: Non-UTF-8 character appears at byte %08x\n", i);
      fprintf (stderr, "Here are 40 characters starting with problem character (ignore quotes): \"");
      if ((nbytes - (i+1)) >= 40) {
        for (j=i; j<(i+40); j++) {
           fprintf (stderr, "%c", testdata[j]);
        }
      } else {
        for (j=i; j<nbytes; j++) {
           fprintf (stderr, "%c", testdata[j]);
        }
      }
      fprintf (stderr, "\"\n");
      return (0);
    }
  }  // End while i < nbytes

  return (1);  // Success: data contains no invalid UTF-8 characters.
}

// Check for 1-byte UTF-8 character
int
one_byte (int nbytes, int i, uint8_t *data)
{
  // Check for valid index.
  if (i >= nbytes) {
    return (0);  // Not a valid 1-byte UTF-8 character
  }

  if (data[i] >> 7) {
    return (0);  // Not a valid 1-byte UTF-8 character
  }

  return (1);  // Is a valid 1-byte UTF-8 character
}

// Check for 2-byte UTF-8 character
int
two_byte (int nbytes, int i, uint8_t *data)
{
  // Check for valid index.
  if ((i + 1) >= nbytes) {
    return (0);  // Not a valid 2-byte UTF-8 character
  }

  if ((data[i] >> 5) == 0x6) {  // 0x6 = 110b
    if ((data[i+1] >> 6) == 0x2) {  // 0x2 = 10b
      return (1);
    }
  }

  return (0);  // Not a valid 2-byte UTF-8 character
}

// Check for 3-byte UTF-8 character
int
three_byte (int nbytes, int i, uint8_t *data)
{
  // Check for valid index.
  if ((i + 2) >= nbytes) {
    return (0);  // Not a valid 3-byte UTF-8 character
  }
    
 if ((data[i] >> 4) == 0xe) {  // 0xe = 1110b
   if ((data[i+1] >> 6) == 0x2) {  // 0x2 = 10b
     if ((data[i+2] >> 6) == 0x2) {  // 0x2 = 10b
       return (1); 
     }
   }
 }
  
  return (0);  // Not a valid 3-byte UTF-8 character
}

// Check for 4-byte UTF-8 character
int
four_byte (int nbytes, int i, uint8_t *data)
{
  // Check for valid index.
  if ((i + 3) >= nbytes) {
    return (0);  // Not a valid 4-byte UTF-8 character
  }
    
 if ((data[i] >> 3) == 0x1e) {  // 0x1e = 11110b
   if ((data[i+1] >> 6) == 0x2) {  // 0x2 = 10b
     if ((data[i+2] >> 6) == 0x2) {  // 0x2 = 10b
       if ((data[i+3] >> 6) == 0x2) {  // ox2 = 10b
         return (1);
       }
     }
   }
 }

  return (0);  // Not a valid 4-byte UTF-8 character
}

// Check for 5-byte UTF-8 character
int
five_byte (int nbytes, int i, uint8_t *data)
{
  // Check for valid index.
  if ((i + 4) >= nbytes) {
    return (0);  // Not a valid 5-byte UTF-8 character
  }
    
 if ((data[i] >> 2) == 0x3e) {  // 0x3e = 111110b
   if ((data[i+1] >> 6) == 0x2) {  // 0x2 = 10b
     if ((data[i+2] >> 6) == 0x2) {  // 0x2 = 10b
       if ((data[i+3] >> 6) == 0x2) {  // 0x2 = 10b
         if ((data[i+4] >> 6) == 0x2) {  // 0x2 = 10b
           return (1);
         }
       }
     }
   }
 }

  return (0);  // Not a valid 5-byte UTF-8 character
}

// Check for 6-byte UTF-8 character
int
six_byte (int nbytes, int i, uint8_t *data)
{
  // Check for valid index.
  if ((i + 5) >= nbytes) {
    return (0);  // Not a valid 6-byte UTF-8 character
  }
    
 if ((data[i] >> 1) == 0x7e) {  // 0x7e = 1111110b
   if ((data[i+1] >> 6) == 0x2) {  // 0x2 = 10b
     if ((data[i+2] >> 6) == 0x2) {  // 0x2 = 10b
       if ((data[i+3] >> 6) == 0x2) {  // 0x2 = 10b
         if ((data[i+4] >> 6) == 0x2) {  // 0x2 = 10b
           if ((data[i+5] >> 6) == 0x2) {  // 0x2 = 10b
             return (1);
           }
         }
       }
     }
   }
 }  
    
  return (0);  // Not a valid 6-byte UTF-8 character
}

// Allocate memory for an array of chars.
char *
allocate_strmem (int len)
{
  void *tmp;

  if (len <= 0) {
    fprintf (stderr, "ERROR: Cannot allocate memory because len = %i in allocate_strmem().\n", len);
    exit (EXIT_FAILURE);
  }

  tmp = (char *) malloc (len * sizeof (char));
  if (tmp != NULL) {
    memset (tmp, 0, len * sizeof (char));
    return (tmp);
  } else {
    fprintf (stderr, "ERROR: Cannot allocate memory for array in allocate_strmem().\n");
    exit (EXIT_FAILURE);
  }
}

// Allocate memory for an array of unsigned chars.
uint8_t *
allocate_ustrmem (int len)
{
  void *tmp;

  if (len <= 0) {
    fprintf (stderr, "ERROR: Cannot allocate memory because len = %i in allocate_ustrmem().\n", len);
    exit (EXIT_FAILURE);
  }

  tmp = (uint8_t *) malloc (len * sizeof (uint8_t));
  if (tmp != NULL) {
    memset (tmp, 0, len * sizeof (uint8_t));
    return (tmp);
  } else {
    fprintf (stderr, "ERROR: Cannot allocate memory for array in allocate_ustrmem().\n");
    exit (EXIT_FAILURE);
  }
}
