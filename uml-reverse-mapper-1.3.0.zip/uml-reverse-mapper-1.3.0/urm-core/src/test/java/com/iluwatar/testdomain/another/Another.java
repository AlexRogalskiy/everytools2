package com.iluwatar.testdomain.another;

public class Another {
}
