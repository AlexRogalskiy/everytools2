package com.iluwatar.testdomain.weirdos;

public class Outer {

    public class Inner {
    }
}
