/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Encapsulating security payload (ESP) extension header editing window
int
esp_win (SPSData *data)
{
  GtkBuilder *builder;
  GError *error = NULL;

  // If ESP window is already open, return with no action.
  if (data->esp_flag) {
    return (EXIT_FAILURE);
  } else {
    data->esp_flag = 1;
  }

  // Create new GtkBuilder object.
  builder = gtk_builder_new();
  if (!gtk_builder_add_from_file (builder, "esp.ui", &error)) {
    g_warning ("%s", error->message);
    g_free (error);
    exit (EXIT_FAILURE);
  }

  // Get objects from UI file
  data->esp_window = GTK_WIDGET (gtk_builder_get_object (builder, "esp_window"));

  data->button140 = GTK_BUTTON (gtk_builder_get_object (builder, "checkbutton140"));  // Toggle: attach / detach an ESP header
  data->textview45 = GTK_WIDGET (gtk_builder_get_object (builder, "textview45"));  // Status: attached / detached
  data->button141 = GTK_BUTTON (gtk_builder_get_object (builder, "button141"));  // Toggle: transport / tunnel mode
  data->textview46 = GTK_WIDGET (gtk_builder_get_object (builder, "textview46"));  // Status: transport / tunnel mode
  data->entry441 = GTK_WIDGET (gtk_builder_get_object (builder, "entry441"));  // Security parameters index (SPI)
  data->entry442 = GTK_WIDGET (gtk_builder_get_object (builder, "entry442"));  // Sequence number
  data->button123 = GTK_BUTTON (gtk_builder_get_object (builder, "button123"));  // Save data for ICV calculation
  data->entry443 = GTK_WIDGET (gtk_builder_get_object (builder, "entry443"));  // Padding length
  data->entry444 = GTK_WIDGET (gtk_builder_get_object (builder, "entry444"));  // Next header
  data->radiobutton71 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton71"));  // Decimal integrity check value (ICV) entry
  data->radiobutton72 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton72"));  // Hexadecimal integrity check value (ICV) entry
  data->entry445 = GTK_WIDGET (gtk_builder_get_object (builder, "entry445"));  // Integrity check value (ICV)
  data->button124 = GTK_BUTTON (gtk_builder_get_object (builder, "button124"));  // Load ICV from file ...

  // Connect signals.
  gtk_builder_connect_signals (builder, data);

  // Destroy builder, since we don't need it anymore.
  g_object_unref (G_OBJECT (builder));

  // Show window. All other widgets are automatically shown by GtkBuilder.
  gtk_widget_show (data->esp_window);

  // Populate/set widgets in ESP header editing window.
  esp_show (data->exthdr_type, data);

  return (EXIT_SUCCESS);
}

// Populate esp_window with contents of selected ESP header.
int
esp_show (int type, SPSData *data)
{
  int i, c, val;
  char *temp, *value;
  GtkTextBuffer *textbuffer45, *textbuffer46;

  // Strings to hold miscellaneous calculated values
  temp = allocate_strmem (TMP_STRINGLEN);
  value = allocate_strmem (IP_MAXPACKET);

  // Flag indicating an ESP header
  textbuffer45 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview45));
  if (data->esp_hdr_flag[data->exthdr_type]) {
    gtk_text_buffer_set_text (textbuffer45, "Attached", -1);
  } else {
    gtk_text_buffer_set_text (textbuffer45, "Not Attached", -1);
  }

  // Transport or tunnel mode
  textbuffer46 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview46));
  if (data->esp_tr_tun_flag[data->exthdr_type]) {
    gtk_text_buffer_set_text (textbuffer46, "Tunnel mode", -1);
  } else {
    gtk_text_buffer_set_text (textbuffer46, "Transport mode", -1);
  }

  // Decimal or hexadecimal ICV data entry
  val = data->dec_hex_esp;
  if (val) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton71), FALSE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton71), TRUE);
  }
  // Variable data->dec_hex_esp will be changed by on_radiobutton71_toggled(), so set it now.
  data->dec_hex_esp = val;

  // Security parameters index (SPI)
  sprintf (value, "%" PRIu32, (uint32_t) ntohl (data->esphdr[type].spi));
  gtk_entry_set_text (GTK_ENTRY (data->entry441), value);

  // Sequence number
  sprintf (value, "%" PRIu32, (uint32_t) ntohl (data->esphdr[type].seq));
  gtk_entry_set_text (GTK_ENTRY (data->entry442), value);

  // Padding length
  sprintf (value, "%" PRIu8, (uint8_t) data->esptail[type].pad_len);
  gtk_entry_set_text (GTK_ENTRY (data->entry443), value);

  // Next header
  sprintf (value, "%" PRIu8, (uint8_t) data->esptail[type].nxt_hdr);
  gtk_entry_set_text (GTK_ENTRY (data->entry444), value);

  // Integrity check value (ICV)
  // NOTE: Always displays in decimal.
  memset (value, 0, IP_MAXPACKET * sizeof (char));
  c = 0;
  for (i=0; i<data->esp_auth_len[type]; i++) {
    sprintf (temp, "%" PRIu8, (uint8_t) data->esp_auth_data[type][i]);
    strncpy (value + c, temp, IP_MAXPACKET - c - 1);  // Minus 1 for string termination.
    c += strnlen (temp, TMP_STRINGLEN);
    if (i != (data->esp_auth_len[type] - 1)) {  // There's more values to come.
      sprintf (value, "%s, ", value);  // Add a comma and space.
      c += 2;
    }
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry445), value);

  // Free allocated memory.
  free (temp);
  free (value);

  return (EXIT_SUCCESS);
}

// Update encapsulating security payload (ESP) header payload and padding length.
int
update_esp_pad (int type, SPSData *data)
{
  int payloadlen;
  char *value;

  value = allocate_strmem (TMP_STRINGLEN);

  payloadlen = 0;

  // IPv6 header (when in tunnel mode)
  if (data->esp_tr_tun_flag[type]) {
    payloadlen += IP6_HDRLEN;
  }

  // Hop-by-hop header
  if (data->hbh_hdr_flag[type]) {
    payloadlen += HOP_HDRLEN + data->hbh_opt_totlen[type] + data->hbh_optpadlen[type];
  }

  // Destination header (first)
  if (data->dstf_hdr_flag[type]) {
    payloadlen += DST_HDRLEN + data->dstf_opt_totlen[type] + data->dstf_optpadlen[type];
  }

  // Routing header (when in tunnel mode)
  if (data->esp_tr_tun_flag[type] && data->route_hdr_flag[type]) {
    payloadlen += RTE_HDRLEN + data->route_datlen[type];
  }

  // Authentication header
  if (data->auth_hdr_flag[type]) {
    payloadlen += ATH_HDRLEN + data->auth_len[type];
  }

  // ESP header, excluding payload data, ESP tail, and auth. data
  if (data->esp_hdr_flag[type]) {
    payloadlen += ESP_HDRLEN;
  }

  // Destination header (last)
  if (data->dstl_hdr_flag[type]) {
    payloadlen += DST_HDRLEN + data->dstl_opt_totlen[type] + data->dstl_optpadlen[type];
  }

  // Upper layer protocol header
  if ((type == 3) || (type == 12)) {
    payloadlen += TCP_HDRLEN + data->tcp_opt_totlen[type] + data->tcp_optpadlen[type];
  } else if ((type == 4) || (type == 13)) {
    payloadlen += ICMP_HDRLEN;
  } else if ((type == 5) || (type == 14)) {
    payloadlen += UDP_HDRLEN;
  }

  // Upper layer protocol payload data
  payloadlen += data->payloadlen[type];

  // Update ESP payload padding length.
  // The ESP header Pad Length and Next Header must be right-aligned to nearest 4-byte block so
  // that authentication ICV begins at start of a 4-byte boundary.
  // See Section 2.4 of RFC 2406.
  data->esptail[type].pad_len = 0;
  while (((payloadlen + data->esptail[type].pad_len + ESP_TAILLEN) % 4) != 0) {
    data->esp_pad[type][data->esptail[type].pad_len] = (unsigned char) (data->esptail[type].pad_len + 1u);
    data->esptail[type].pad_len++;
  }

  // Update ESP header editing window if open.
  if (data->esp_flag) {
    sprintf (value, "%" PRIu8, (uint8_t) data->esptail[type].pad_len);
    gtk_entry_set_text (GTK_ENTRY (data->entry443), value);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}
