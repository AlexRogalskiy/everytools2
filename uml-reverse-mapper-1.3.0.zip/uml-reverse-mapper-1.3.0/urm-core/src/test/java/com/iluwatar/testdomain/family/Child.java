package com.iluwatar.testdomain.family;

public class Child {
    Mother mommy;
}
