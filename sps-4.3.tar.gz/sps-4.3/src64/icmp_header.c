/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// ICMP message type (8 bits)
int
icmp_mt_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 255)) {
    if ((type == 1) || (type == 10)) {
      sprintf (value, "%" PRIu8, (uint8_t) data->icmp4hdr[type].icmp_type);

    } else if ((type == 4) || (type == 13)) {
      sprintf (value, "%" PRIu8, (uint8_t) data->icmp6hdr[type].icmp6_type);
    }
    gtk_entry_set_text (GTK_ENTRY (entry), value);
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    if ((type == 1) || (type == 10)) {
      data->icmp4hdr[type].icmp_type = (uint8_t) ascii_to_int64 ((char *) entry_text);  // Update ICMP header with new value

    } else if ((type == 4) || (type == 13)) {
      data->icmp6hdr[type].icmp6_type = (uint8_t) ascii_to_int64 ((char *) entry_text);  // Update ICMP header with new value
    }

    // ICMP header checksum (16 bits)
    icmp_chksum (type, data);

    // Update ethernet frames.
    if ((type == 1) || (type == 10)) {
      create_ip4_frame (type, data);

    } else if ((type == 4) || (type == 13)) {
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// ICMP Message Code (8 bits)
int
icmp_mc_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 255)) {
    if ((type == 1) || (type == 10)) {
      sprintf (value, "%" PRIu8, (uint8_t) data->icmp4hdr[type].icmp_code);

    } else if ((type == 4) || (type == 13)) {
      sprintf (value, "%" PRIu8, (uint8_t) data->icmp6hdr[type].icmp6_code);
    }
    gtk_entry_set_text (GTK_ENTRY (entry), value);
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    if ((type == 1) || (type == 10)) {
      data->icmp4hdr[type].icmp_code = (uint8_t) ascii_to_int64 ((char *) entry_text);  // Update ICMP header with new value

    } else if ((type == 4) || (type == 13)) {
      data->icmp6hdr[type].icmp6_code = (uint8_t) ascii_to_int64 ((char *) entry_text);  // Update ICMP header with new value
    }

    // ICMP header checksum (16 bits)
    icmp_chksum (type, data);

    // Update ethernet frames.
    if ((type == 1) || (type == 10)) {
      create_ip4_frame (type, data);

    } else if ((type == 4) || (type == 13)) {
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// ICMP checksum (16 bits)
int
icmp_chksum_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 65535)) {
    if ((type == 1) || (type == 10)) {
      sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->icmp4hdr[type].icmp_cksum));

    } else if ((type == 4) || (type == 13)) {
      sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->icmp6hdr[type].icmp6_cksum));
    }
    gtk_entry_set_text (GTK_ENTRY (entry), value);
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    if ((type == 1) || (type == 10)) {
      data->icmp4hdr[type].icmp_cksum = htons ((uint16_t) ascii_to_int64 ((char *) entry_text));  // Update ICMP header with new value

    } else if ((type == 4) || (type == 13)) {
      data->icmp6hdr[type].icmp6_cksum = htons ((uint16_t) ascii_to_int64 ((char *) entry_text));  // Update ICMP header with new value
    }

    // Update ethernet frames.
    if ((type == 1) || (type == 10)) {
      create_ip4_frame (type, data);

    } else if ((type == 4) || (type == 13)) {
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// ICMP ID (16 bits)
int
icmp_id_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 65535)) {
    if ((type == 1) || (type == 10)) {
      sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->icmp4hdr[type].icmp_id));

    } else if ((type == 4) || (type == 13)) {
      sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->icmp6hdr[type].icmp6_id));
    }
    gtk_entry_set_text (GTK_ENTRY (entry), value);
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    if ((type == 1) || (type == 10)) {
      data->icmp4hdr[type].icmp_id = htons ((uint16_t) ascii_to_int64 ((char *) entry_text));  // Update ICMP header with new value

    } else if ((type == 4) || (type == 13)) {
      data->icmp6hdr[type].icmp6_id = htons ((uint16_t) ascii_to_int64 ((char *) entry_text));  // Update ICMP header with new value
    }

    // ICMP header checksum (16 bits)
    icmp_chksum (type, data);

    // Update ethernet frames.
    if ((type == 1) || (type == 10)) {
      create_ip4_frame (type, data);

    } else if ((type == 4) || (type == 13)) {
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// ICMP sequence number (16 bits)
int
icmp_seq_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 65535)) {
    if ((type == 1) || (type == 10)) {
      sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->icmp4hdr[type].icmp_seq));

    } else if ((type == 4) || (type == 13)) {
      sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->icmp6hdr[type].icmp6_seq));
    }
    gtk_entry_set_text (GTK_ENTRY (entry), value);
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    if ((type == 1) || (type == 10)) {
      data->icmp4hdr[type].icmp_seq = htons ((uint16_t) ascii_to_int64 ((char *) entry_text));  // Update ICMP header with new value

    } else if ((type == 4) || (type == 13)) {
      data->icmp6hdr[type].icmp6_seq = htons ((uint16_t) ascii_to_int64 ((char *) entry_text));  // Update ICMP header with new value
    }

    // ICMP header checksum (16 bits)
    icmp_chksum (type, data);

    // Update ethernet frames.
    if ((type == 1) || (type == 10)) {
      create_ip4_frame (type, data);

    } else if ((type == 4) || (type == 13)) {
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Re-calculate ICMP checksum and update text entry (IPv4 or IPv6).
int
icmp_chksum (int type, SPSData *data)
{
  GtkWidget *chksum_entry;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // ICMP header checksum (16 bits)
  if ((type == 1) || (type == 10)) {
    data->icmp4hdr[type].icmp_cksum = icmp4_checksum (data->icmp4hdr[type], data->payload[type], data->payloadlen[type]);
    sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->icmp4hdr[type].icmp_cksum));

  } else if ((type == 4) || (type == 13)) {
    data->icmp6hdr[type].icmp6_cksum = icmp6_checksum (data->ip6hdr[type], data->icmp6hdr[type], data->payload[type], data->payloadlen[type]);
    sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->icmp6hdr[type].icmp6_cksum));
  }

  switch (type) {
    case 1:  // IPv4 ICMP
      chksum_entry = data->entry71;
      break;
    case 4:  // IPv6 ICMP
      chksum_entry = data->entry119;
      break;
    case 10:  // IPv4 ICMP for traceroute
      chksum_entry = data->entry220;
      break;
    case 13:  // IPv6 ICMP for traceroute
      chksum_entry = data->entry291;
      break;
    default:
      fprintf (stderr, "ERROR: Invalid upper layer protocol type %i in icmp_chksum().\n", type);
      free (value);
      exit (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (chksum_entry), value);

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}
