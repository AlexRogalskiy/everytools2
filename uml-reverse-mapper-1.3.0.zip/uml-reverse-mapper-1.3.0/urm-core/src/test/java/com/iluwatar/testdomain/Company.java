package com.iluwatar.testdomain;

import com.iluwatar.testdomain.person.Person;

import java.util.List;

public class Company {
    private List<Person> employees;
}
