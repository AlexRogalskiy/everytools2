/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Upper layer protocol data from keyboard (IPv4 or IPv6)
int
key_data (GtkWidget *entry, int type, int ascii_hex, SPSData *data)
{
  int i, j, c, flag;
  const char *entry_text;
  char *value;
  char **endptr;

  if (type < 9) {
    data->parent = data->main_window;
  } else {
    data->parent = data->traceroute_window;
  }

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // If user asked for no payload then zero it out.
  if (strnlen (entry_text, 2) == 0) {
    data->payloadlen[type] = 0;
    memset (data->payload[type], 0, IP_MAXPACKET * sizeof (uint8_t));
  
  // ASCII data entry radiobutton was selected.
  } else if ((strnlen (entry_text, 2) != 0) && (ascii_hex == 0)) {

    data->payloadlen[type] = strnlen (entry_text, IP_MAXPACKET);
    memset (data->payload[type], 0, IP_MAXPACKET * sizeof (uint8_t));
    memcpy (data->payload[type], entry_text, data->payloadlen[type] * sizeof (uint8_t));

  // Hexadecimal data entry radiobutton was selected.
  } else if ((strnlen (entry_text, IP_MAXPACKET) != 0) && (ascii_hex == 1)) {

    // Check for invalid hexadecimal data.
    if (!is_valid_hexdata (entry_text, data)) {
      sprintf (data->error_text, "There seems to be invalid hexadecimal data.\nHere's an example of acceptable data: 23, 4e,a,cd    ,7");
      report_error (data);
      free (value);
      return (EXIT_FAILURE);

    // Data is in acceptable format.
    } else {
      data->payloadlen[type] = 0;
      memset (data->payload[type], 0, IP_MAXPACKET * sizeof (uint8_t));
      // Store values as payload data.
      c = 0;  // index for payload array
      i = 0;  // index for entry array
      while (i < (int) strnlen (entry_text, IP_MAXPACKET)) {

        // Grab next hexadecimal value.
        memset (value, 0, TMP_STRINGLEN * sizeof (char));
        j = 0;
        while ((entry_text[i+j] != ' ') && (entry_text[i+j] != ',') && ((i + j) < (int) strnlen (entry_text, IP_MAXPACKET))) {
          value[j] = entry_text[i+j];
          j++;
        }
        i += j;
        // Convert to base-10 chars and store as payload data.
        endptr = NULL;
        data->payload[type][c] = (uint8_t) strtol (value, endptr, 16);
        if (endptr != NULL) {
          sprintf (data->error_text, "key_data(): strtol() failed.\n");
          report_error (data);
          free (value);
          return (EXIT_FAILURE);
        }
        c++;
        data->payloadlen[type]++;

        // Increment i until we find more hex or hit end of string.
        while (((entry_text[i] == ' ') || (entry_text[i] == ',')) && (i < (int) strnlen (entry_text, IP_MAXPACKET))) {
          i++;
        }
      }  // Looping through entry_text
    }  // else data is in acceptable format
  }  // else data is hex

  // Truncate upper layer protocol payload if necessary to accomodate packet size limit.
  flag = 0;
  if ((type == 0) || (type == 9) || (type == 1) || (type == 10) || (type == 2) || (type == 11)) {
    if (truncate_ip4 (type, data)) {
      flag = 1;
    }
  } else {
    if (truncate_ip6 (type, data)) {
      flag = 1;
    }
  }
  if (flag) {
    sprintf (data->warning_text, "Upper layer protocol payload data was truncated\nto accomodate maximum packet size of %i bytes.", IP_MAXPACKET);
    report_warning (data);
  }

  // Update lengths, offsets, and checksums.
  if ((type == 0) || (type == 1) || (type == 2) ||
      (type == 9) || (type == 10) || (type == 11)) {
    ip4data_update (type, data);

  } else if ((type == 3) || (type == 4) || (type == 5) ||
      (type == 12) || (type == 13) || (type == 14)) {
    ip6data_update (type, data);
  }

  // Check if MTU is sufficiently large to accomodate packet. Revise if necessary.
  check_mtu (type, data);

  // Update ethernet frame.
  if ((type == 0) || (type == 1) || (type == 2) || (type == 9) || (type == 10) || (type == 11)) {
    create_ip4_frame (type, data);

  } else if ((type == 3) || (type == 4) || (type == 5) || (type == 12) || (type == 13) || (type == 14)) {
    create_ip6_frame (type, data);
    create_6to4_frame (type + 3, data);
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}
