/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Send an ARP request to obtain link-layer address.
int
arp (uint8_t *dst_mac, const char *entry137_text, const char *entry140_text, SPSData *data)
{
  int nbytes, status;
  char *hostname;
  int i, frame_length, sd;
  char *interface, *target, *src_ip;
  Arp_hdr *arphdr;
  uint8_t *src_mac, *ether_frame;
  struct addrinfo hints, *res;
  struct sockaddr_in *ipv4;
  struct sockaddr_ll device;
  struct ifreq ifr;
  struct timeval tv;

  // Array of chars
  hostname = allocate_strmem (TEXT_STRINGLEN);

  // Array of unsigned chars
  src_mac = allocate_ustrmem (6);

  // Array of unsigned chars
  ether_frame = allocate_ustrmem (IP_MAXPACKET);

  // Array of chars
  interface = allocate_strmem (TMP_STRINGLEN);

  // Array of chars
  target = allocate_strmem (TEXT_STRINGLEN);

  // Array of chars
  src_ip = allocate_strmem (INET_ADDRSTRLEN);

  arphdr = (Arp_hdr *) (ether_frame + ETH_HDRLEN);

  // Is an interface name specified in text entry 140?
  if (strnlen (entry140_text, TMP_STRINGLEN - 1) < 2) {  // Minus 1 for string termination
    sprintf (data->error_text, "arp(): Please specify an interface name.");
    data->parent = data->main_window;
    report_error (data);
    free (hostname);
    free (src_mac);
    free (ether_frame);
    free (interface);
    free (target);
    free (src_ip);
    return (EXIT_FAILURE);
  }

  // Interface to send packet through.
  memset (interface, 0, TMP_STRINGLEN * sizeof (char));
  strncpy (interface, entry140_text, TMP_STRINGLEN - 1);  // Minus 1 to allow for string termination.

  // Clear IPv6 text entry so there's no confusion about which IP belongs to the MAC address.
  gtk_entry_set_text (GTK_ENTRY (data->entry138), "");

  // Submit request for a socket descriptor to lookup interface.
  if ((sd = socket (PF_PACKET, SOCK_RAW, htons (ETH_P_ALL))) < 0) {
    status = errno;
    sprintf (data->error_text, "arp(): socket() failed to get socket descriptor for ioctl().\nError Message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (hostname);
    free (src_mac);
    free (ether_frame);
    free (interface);
    free (target);
    free (src_ip);
    return (EXIT_FAILURE);
  }

  // Use ioctl() to lookup interface and get MAC address.
  memset (&ifr, 0, sizeof (ifr));
  snprintf (ifr.ifr_name, sizeof (ifr.ifr_name), "%s", interface);
  if (ioctl (sd, SIOCGIFHWADDR, &ifr) < 0) {
    status = errno;
    sprintf (data->error_text, "arp(): ioctl() failed to get interface hardware address (MAC).\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (hostname);
    free (src_mac);
    free (ether_frame);
    free (interface);
    free (target);
    free (src_ip);
    return (EXIT_FAILURE);
  }
  close (sd);

  // Copy source MAC address.
  memcpy (src_mac, ifr.ifr_hwaddr.sa_data, 6 * sizeof (uint8_t));

  // Resolve interface index.
  memset (&device, 0, sizeof (device));
  if ((device.sll_ifindex = if_nametoindex (interface)) == 0) {
    status = errno;
    sprintf (data->error_text, "arp(): if_nametoindex() failed to obtain interface index.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (hostname);
    free (src_mac);
    free (ether_frame);
    free (interface);
    free (target);
    free (src_ip);
    return (EXIT_FAILURE);
  }

  // Set destination MAC address: broadcast address
  memset (dst_mac, 0xff, 6 * sizeof (uint8_t));

  // Source IPv4 address (this host)
  gethostname (hostname, 1023);
  strncat (hostname, ".local", 6);
  memset (src_ip, 0, INET_ADDRSTRLEN * sizeof (char));
  strncpy (src_ip, thishost_ipv4 (hostname), INET_ADDRSTRLEN - 1);  // Minus 1 for string termination.
  if ((status = inet_pton (AF_INET, src_ip, &arphdr->sender_ip)) != 1) {
    sprintf (data->error_text, "arp(): inet_pton() failed for source IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (hostname);
    free (src_mac);
    free (ether_frame);
    free (interface);
    free (target);
    free (src_ip);
    return (EXIT_FAILURE);
  }

  // Destination IPv4 address
  memset (target, 0, TEXT_STRINGLEN * sizeof (char));  // Use TEXT_STRINGLEN because this may hold target hostname temporarily.
  strncpy (target, entry137_text, TEXT_STRINGLEN - 1);  // Minus 1 for string termination.

  // Fill out hints for getaddrinfo().
  memset (&hints, 0, sizeof (struct addrinfo));
  hints.ai_family = AF_INET;
  hints.ai_socktype = SOCK_STREAM;
  hints.ai_flags = hints.ai_flags | AI_CANONNAME;

  // Resolve target using getaddrinfo().
  if ((status = getaddrinfo (target, NULL, &hints, &res)) != 0) {
    sprintf (data->error_text, "arp(): getaddrinfo() failed for target host.\nError message: %s", gai_strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (hostname);
    free (src_mac);
    free (ether_frame);
    free (interface);
    free (target);
    free (src_ip);
    return (EXIT_FAILURE);
  }
  ipv4 = (struct sockaddr_in *) res->ai_addr;
  memcpy (&arphdr->target_ip, &ipv4->sin_addr, 4 * sizeof (uint8_t));
  freeaddrinfo (res);

  // Fill out sockaddr_ll.
  device.sll_family = AF_PACKET;
  memcpy (device.sll_addr, src_mac, 6 * sizeof (uint8_t));
  device.sll_halen = 6u;

  // ARP header
  // NOTE: ether_frame is updated as arp header is populated because of cast done previously.

  // Hardware type (16 bits): 1 for ethernet
  arphdr->htype = htons (1u);

  // Protocol type (16 bits): 2048 for IP
  arphdr->ptype = htons (ETH_P_IP);

  // Hardware address length (8 bits): 6 bytes for MAC address
  arphdr->hlen = 6;

  // Protocol address length (8 bits): 4 bytes for IPv4 address
  arphdr->plen = 4;

  // OpCode: 1 for ARP request
  arphdr->opcode = htons (ARPOP_REQUEST);

  // Sender hardware address (48 bits): MAC address
  memcpy (&arphdr->sender_mac, src_mac, 6 * sizeof (uint8_t));

  // Sender protocol address (32 bits)
  // See getaddrinfo() resolution of src_ip.

  // Target hardware address (48 bits): zero, since we don't know it yet.
  memset (&arphdr->target_mac, 0, 6 * sizeof (uint8_t));

  // Target protocol address (32 bits)
  // See getaddrinfo() resolution of target.

  // Fill out ethernet frame header.

  // Ethernet frame length = ethernet header (MAC + MAC + ethernet type) + ethernet data (ARP header)
  frame_length = ETH_HDRLEN + ARP_HDRLEN;

  // Destination and Source MAC addresses
  memcpy (ether_frame, dst_mac, 6 * sizeof (uint8_t));
  memcpy (ether_frame + 6, src_mac, 6 * sizeof (uint8_t));

  // Next is ethernet type code (ETH_P_ARP for ARP).
  // http://www.iana.org/assignments/ethernet-numbers
  ether_frame[12] = ETH_P_ARP / 256;
  ether_frame[13] = ETH_P_ARP % 256;

  // Submit request for a raw socket descriptor.
  if ((sd = socket (PF_PACKET, SOCK_RAW, htons (ETH_P_ALL))) < 0) {
    status = errno;
    sprintf (data->error_text, "arp(): socket() failed to obtain a socket descriptor.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (hostname);
    free (src_mac);
    free (ether_frame);
    free (interface);
    free (target);
    free (src_ip);
    return (EXIT_FAILURE);
  }

  // Send ethernet frame to socket.
  if (sendto (sd, ether_frame, frame_length, 0, (struct sockaddr *) &device, sizeof (device)) <= 0) {
    status = errno;
    sprintf (data->error_text, "arp(): sendto() failed.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (hostname);
    free (src_mac);
    free (ether_frame);
    free (interface);
    free (target);
    free (src_ip);
    return (EXIT_FAILURE);
  }

  // Set time for the socket to timeout and give up waiting for an ARP reply.
  tv.tv_sec  = data->timeout;  
  tv.tv_usec = 0;
  setsockopt (sd, SOL_SOCKET, SO_RCVTIMEO, (char *) &tv, sizeof (struct timeval));

  // Listen for incoming ethernet frame from socket sd.
  // We expect an ARP ethernet frame of the form:
  //     MAC (6 bytes) + MAC (6 bytes) + ethernet type (2 bytes)
  //     + ethernet data (ARP header) (28 bytes)
  // Keep at it for data->timeout seconds, or until we get an ARP reply.
  memset (ether_frame, 0, IP_MAXPACKET * sizeof (uint8_t));
  arphdr = (Arp_hdr *) (ether_frame + ETH_HDRLEN);
  while (((((ether_frame[12]) << 8) + ether_frame[13]) != ETH_P_ARP) || (ntohs (arphdr->opcode) != ARPOP_REPLY)) {
    if ((nbytes = recv (sd, ether_frame, IP_MAXPACKET, 0)) < 0) {
      status = errno;
      if (status == EAGAIN) {  // EAGAIN = 11
        sprintf (data->error_text, "arp(): recv() failed.\nNo reply from that node within %i seconds.", data->timeout);
        data->parent = data->main_window;
        report_error (data);
        free (hostname);
        free (src_mac);
        free (ether_frame);
        free (interface);
        free (target);
        free (src_ip);
        return (EXIT_FAILURE);
      } else if (status == EINTR) {  // EINTR = 4
        memset (ether_frame, 0, IP_MAXPACKET * sizeof (uint8_t));
        continue;  // Something weird happened, but let's try again.
      } else {
        sprintf (data->error_text, "arp(): recv() failed.\nError message: %s", strerror (status));
        data->parent = data->main_window;
        report_error (data);
        free (hostname);
        free (src_mac);
        free (ether_frame);
        free (interface);
        free (target);
        free (src_ip);
        return (EXIT_FAILURE);
      }
    }
  }

  // Close socket descriptor.
  close (sd);

  // Extract MAC address from received ethernet frame.
  for (i=0; i<6; i++) {
    dst_mac[i] = ether_frame[i+6];
  }

  // Free allocated memory.
  free (hostname);
  free (src_mac);
  free (ether_frame);
  free (interface);
  free (target);
  free (src_ip);
  return (EXIT_SUCCESS);
}
