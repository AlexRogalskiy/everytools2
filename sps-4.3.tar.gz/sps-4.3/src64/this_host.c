/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Function to get this hostname and IP addresses.
int
this_host (SPSData *data)
{
  int status;
  char *hostname, *text;
  GtkTextIter end;
  GtkTextBuffer *textbuffer4, *textbuffer5, *textbuffer23;
  struct ifaddrs *myaddrs, *ifa;
  struct sockaddr_in *s4;
  struct sockaddr_in6 *s6;
  char buf[64];

  // Array of chars
  hostname = allocate_strmem (TEXT_STRINGLEN);

  // Array for error messages.
  text = allocate_strmem (TEXT_STRINGLEN);

  gethostname (hostname, 1023);

  // Show hostname of localhost in textview.
  textbuffer4 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview4));
  gtk_text_buffer_set_text (textbuffer4, hostname, -1);

  // Obtain all interface names and IP addresses for localhost.
  if ((status = getifaddrs (&myaddrs)) != 0) {
    sprintf (data->error_text, "this_host(): getifaddrs() failed.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (hostname);
    free (text);
    freeifaddrs (myaddrs);
    return (EXIT_FAILURE);
  }

  // Loop through all the results.
  for (ifa = myaddrs; ifa != NULL; ifa = ifa->ifa_next){
    if (ifa->ifa_addr == NULL) {
      continue;
    }
    if ((ifa->ifa_flags & IFF_UP) == 0) {
      continue;
    }

    // IPv4 results
    if (ifa->ifa_addr->sa_family == AF_INET) {
      s4 = (struct sockaddr_in *)(ifa->ifa_addr);
      if (inet_ntop (ifa->ifa_addr->sa_family, (void *)&(s4->sin_addr), buf, sizeof (buf)) == NULL) {
        sprintf (data->error_text, "this_host(): inet_ntop() failed for IPv4 results while processing %s.", ifa->ifa_name);
        data->parent = data->main_window;
        report_error (data);
        free (hostname);
        free (text);
        freeifaddrs (myaddrs);
        return (EXIT_FAILURE);
      } else {
        sprintf (text, "%s  %s\n", ifa->ifa_name, buf);
      }
      textbuffer23 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview23));
      gtk_text_buffer_get_end_iter (textbuffer23, &end);
      gtk_text_buffer_insert (textbuffer23, &end, text, -1);
      gtk_text_view_scroll_to_iter (GTK_TEXT_VIEW (data->textview23), &end, 0.0, FALSE, 0, 0);

    // IPv6 results
    } else if (ifa->ifa_addr->sa_family == AF_INET6) {
      s6 = (struct sockaddr_in6 *)(ifa->ifa_addr);
      if (inet_ntop (ifa->ifa_addr->sa_family, (void *)&(s6->sin6_addr), buf, sizeof (buf)) == NULL) {
        sprintf (data->error_text, "this_host(): inet_ntop() failed for IPv6 results while processing %s.", ifa->ifa_name);
        data->parent = data->main_window;
        report_error (data);
        free (hostname);
        free (text);
        freeifaddrs (myaddrs);
        return (EXIT_FAILURE);
      } else {
        sprintf (text, "%s  %s\n", ifa->ifa_name, buf);
      }
      textbuffer5 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview5));
      gtk_text_buffer_get_end_iter (textbuffer5, &end);
      gtk_text_buffer_insert (textbuffer5, &end, text, -1);
      gtk_text_view_scroll_to_iter (GTK_TEXT_VIEW (data->textview5), &end, 0.0, FALSE, 0, 0);
    } 
  }

  // Free alloacted memory.
  free (hostname);
  free (text);
  freeifaddrs (myaddrs);

  return (EXIT_SUCCESS);
}

// Find this host's IPv4 address - only used in arp()
char *
thishost_ipv4 (char *host)
{
  int status;
  struct addrinfo hints, *res, *p;
  void *tmp;

  gethostname (host, 1023);

  strncat (host, ".local", 6);

  memset (&hints, 0, sizeof (struct addrinfo));
  hints.ai_family = AF_INET;
  hints.ai_socktype = SOCK_STREAM;
  hints.ai_flags = hints.ai_flags | AI_CANONNAME;

  if ((status = getaddrinfo (host, NULL, &hints, &res)) != 0) {
    host[0] = 0;
    return (host);
  }

  for (p = res; p != NULL; p = p->ai_next) {

    switch (p->ai_family) {
      case AF_INET:
        tmp = &((struct sockaddr_in *) p->ai_addr)->sin_addr;
        break;
      case AF_INET6:
        continue;
      default:
        tmp = NULL;
        break;
    }
    if (tmp == NULL) {
      fprintf (stderr, "Unable to find anything in results from getaddrinfo() in thishost_ipv4().\n");
      exit (EXIT_FAILURE);
    }

    if (inet_ntop (AF_INET, tmp, host, INET_ADDRSTRLEN) == NULL) {
      status = errno;
      fprintf (stderr, "thishost_ipv4(): inet_ntop() failed.\nError message: %s", strerror (status));
      exit (EXIT_FAILURE);
    }
  }

  freeaddrinfo (res);

  return (host);
}

// Find link-layer (MAC) address given interface name.
uint8_t *
interface_getmac (char *interface, uint8_t *mac, GtkWidget *parent, SPSData *data)
{
  int sd, status;
  struct ifreq ifr;

  // Submit request for a socket descriptor to lookup interface.
  if ((sd = socket (PF_PACKET, SOCK_RAW, htons (ETH_P_ALL))) < 0) {
    status = errno;
    sprintf (data->error_text, "interface_getmac(): socket() failed to get a socket descriptor for ioctl().\nAppears to be an invalid interface name.\nError message: %s", strerror (status));
    data->parent = parent;
    report_error (data);
    return (NULL);
  }

  // Use ioctl() to lookup interface and get MAC address.
  memset (&ifr, 0, sizeof (ifr));
  snprintf (ifr.ifr_name, sizeof (ifr.ifr_name), "%s", interface);
  if (ioctl (sd, SIOCGIFHWADDR, &ifr) < 0) {
    status = errno;
    sprintf (data->error_text, "interface_getmac(): ioctl() failed to get interface hardware address (MAC).\nAppears to be an invalid interface name.\nError message: %s", strerror (status));
    data->parent = parent;
    report_error (data);
    return (NULL);
  }
  close (sd);

  memcpy (mac, ifr.ifr_hwaddr.sa_data, 6 * sizeof (unsigned char));

  return (mac);
}
