/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

extern int downloading;  // Flag to indicate a file download thread is active.
extern int show_dl_messages;  // Flag to show sent and received messages on stdout as files download.
extern int message_available;  // A message is available to be displayed in a dialog by thread_listen()

G_LOCK_EXTERN (downloading);  // MUTEX for flag indicating a download thread is active.
G_LOCK_EXTERN (show_dl_messages);  // MUTEX for flag indicating messages from file download threads should be sent to stdout
G_LOCK_EXTERN (message_available);  // MUTEX for flag indicating a message from a download or traceroute thread is available to be displayed in a dialog by thread_listen()

// Retrieve the Regional Internet Registry (RIR) IP delegation files
// using FTP protocol.
// This function will be executed as a separate thread.
int
ftp_rir (SPSData *data)
{
  int sd_cntl, data_port;
  char *cntl_ip, *data_ip, *text;

  // Array to hold various strings of text
  text = allocate_strmem (TEXT_STRINGLEN);

  // Array of chars
  cntl_ip = allocate_strmem (INET6_ADDRSTRLEN);

  // Array of chars
  data_ip = allocate_strmem (INET6_ADDRSTRLEN);

  // Array of chars
  data->ftp_data = allocate_strmem (IP_MAXPACKET);

  // Set RIR delegation file status to "Loading".
  g_idle_add ((GSourceFunc) rir_loading, data);

  // Set up control connection.
  if ((sd_cntl = cntl_sock (data->rir_ftp[data->rir_index], cntl_ip, data)) == EXIT_FAILURE) {
    free_rir_mem (text, cntl_ip, data_ip, data);
    g_idle_add ((GSourceFunc) rir_not_available, data);
    G_LOCK (downloading);
    downloading = 0;
    G_UNLOCK (downloading);
    return (EXIT_FAILURE);
  }

  G_LOCK (show_dl_messages);
  if (show_dl_messages) {
    printf ("\nConnected to Regional Internet Registry (RIR): %s (%s)\n", data->rir_name[data->rir_index], cntl_ip);
  }
  G_UNLOCK (show_dl_messages);

  // Authenticate with target node.
  if (cntl_send (sd_cntl, "USER anonymous\r\n", data) == EXIT_FAILURE) {
    free_rir_mem (text, cntl_ip, data_ip, data);
    g_idle_add ((GSourceFunc) rir_not_available, data);
    G_LOCK (downloading);
    downloading = 0;
    G_UNLOCK (downloading);
    return (EXIT_FAILURE);
  }
  if (cntl_recv (sd_cntl, data) == EXIT_FAILURE) {
    free_rir_mem (text, cntl_ip, data_ip, data);
    g_idle_add ((GSourceFunc) rir_not_available, data);
    G_LOCK (downloading);
    downloading = 0;
    G_UNLOCK (downloading);
    return (EXIT_FAILURE);
  }

  if (cntl_send (sd_cntl, "PASS password\r\n", data) == EXIT_FAILURE) {  // Anything is acceptable for anonymous user.
    free_rir_mem (text, cntl_ip, data_ip, data);
    g_idle_add ((GSourceFunc) rir_not_available, data);
    G_LOCK (downloading);
    downloading = 0;
    G_UNLOCK (downloading);
    return (EXIT_FAILURE);
  }
  if (cntl_recv (sd_cntl, data) == EXIT_FAILURE) {
    free_rir_mem (text, cntl_ip, data_ip, data);
    g_idle_add ((GSourceFunc) rir_not_available, data);
    G_LOCK (downloading);
    downloading = 0;
    G_UNLOCK (downloading);
    return (EXIT_FAILURE);
  }

  // Request type of operating system
  if (cntl_send (sd_cntl, "SYST\r\n", data) == EXIT_FAILURE) {
    free_rir_mem (text, cntl_ip, data_ip, data);
    g_idle_add ((GSourceFunc) rir_not_available, data);
    G_LOCK (downloading);
    downloading = 0;
    G_UNLOCK (downloading);
    return (EXIT_FAILURE);
  }
  if (cntl_recv (sd_cntl, data) == EXIT_FAILURE) {
    free_rir_mem (text, cntl_ip, data_ip, data);
    g_idle_add ((GSourceFunc) rir_not_available, data);
    G_LOCK (downloading);
    downloading = 0;
    G_UNLOCK (downloading);
    return (EXIT_FAILURE);
  }

  // Set to passive mode.
  if (data->ftp_family == AF_INET) {
    if (cntl_send (sd_cntl, "PASV\r\n", data) == EXIT_FAILURE) { // Tell target node we need it to provide IP and port to us.
      free_rir_mem (text, cntl_ip, data_ip, data);
      g_idle_add ((GSourceFunc) rir_not_available, data);
      G_LOCK (downloading);
      downloading = 0;
      G_UNLOCK (downloading);
      return (EXIT_FAILURE);
    }
    if (cntl_recv (sd_cntl, data) == EXIT_FAILURE) {
      free_rir_mem (text, cntl_ip, data_ip, data);
      g_idle_add ((GSourceFunc) rir_not_available, data);
      G_LOCK (downloading);
      downloading = 0;
      G_UNLOCK (downloading);
      return (EXIT_FAILURE);
    }

    if (data->ftp_data[0] == '2') {
      if (parse_ip4_port (data_ip, &data_port, data) == EXIT_FAILURE) {
        free_rir_mem (text, cntl_ip, data_ip, data);
        g_idle_add ((GSourceFunc) rir_not_available, data);
        G_LOCK (downloading);
        downloading = 0;
        G_UNLOCK (downloading);
        return (EXIT_FAILURE);
      }
    }

    // Set up data connection.
    if ((data->sd_data = data_sock (data_ip, data_port, data)) == EXIT_FAILURE) {
      free_rir_mem (text, cntl_ip, data_ip, data);
      g_idle_add ((GSourceFunc) rir_not_available, data);
      G_LOCK (downloading);
      downloading = 0;
      G_UNLOCK (downloading);
      return (EXIT_FAILURE);
    }
  } else if (data->ftp_family == AF_INET6) {
    if (cntl_send (sd_cntl, "EPSV\r\n", data) == EXIT_FAILURE) { // Tell target node we need it to provide IP and port to us.
      free_rir_mem (text, cntl_ip, data_ip, data);
      g_idle_add ((GSourceFunc) rir_not_available, data);
      G_LOCK (downloading);
      downloading = 0;
      G_UNLOCK (downloading);
      return (EXIT_FAILURE);
    }
    if (cntl_recv (sd_cntl, data) == EXIT_FAILURE) {
      free_rir_mem (text, cntl_ip, data_ip, data);
      g_idle_add ((GSourceFunc) rir_not_available, data);
      G_LOCK (downloading);
      downloading = 0;
      G_UNLOCK (downloading);
      return (EXIT_FAILURE);
    }

    if (data->ftp_data[0] == '2') {
      if (parse_ip6_port (&data_port, data) == EXIT_FAILURE) {
        free_rir_mem (text, cntl_ip, data_ip, data);
        g_idle_add ((GSourceFunc) rir_not_available, data);
        G_LOCK (downloading);
        downloading = 0;
        G_UNLOCK (downloading);
        return (EXIT_FAILURE);
      }
    }
    memset (data_ip, 0, INET6_ADDRSTRLEN * sizeof (char));
    // For IPv6, we use the same IP address as the control connection.
    strncpy (data_ip, cntl_ip, INET6_ADDRSTRLEN - 1);  // Minus 1 for string termination.

    // Set up data connection.
    if ((data->sd_data = data_sock (data_ip, data_port, data)) == EXIT_FAILURE) {
      free_rir_mem (text, cntl_ip, data_ip, data);
      g_idle_add ((GSourceFunc) rir_not_available, data);
      G_LOCK (downloading);
      downloading = 0;
      G_UNLOCK (downloading);
      return (EXIT_FAILURE);
    }
  }
  G_LOCK (show_dl_messages);
  if (show_dl_messages) {
    printf ("\nData connection established.\n");
  }
  G_UNLOCK (show_dl_messages);

  // Set to binary transfer mode.
  if (cntl_send (sd_cntl, "TYPE I\r\n", data) == EXIT_FAILURE) {
    free_rir_mem (text, cntl_ip, data_ip, data);
    g_idle_add ((GSourceFunc) rir_not_available, data);
    G_LOCK (downloading);
    downloading = 0;
    G_UNLOCK (downloading);
    return (EXIT_FAILURE);
  }
  if (cntl_recv (sd_cntl, data) == EXIT_FAILURE) {
    free_rir_mem (text, cntl_ip, data_ip, data);
    g_idle_add ((GSourceFunc) rir_not_available, data);
    G_LOCK (downloading);
    downloading = 0;
    G_UNLOCK (downloading);
    return (EXIT_FAILURE);
  }

  // Change directory.
  memset (text, 0, TEXT_STRINGLEN * sizeof (char));
  sprintf (text, "CWD %s\r\n", data->rir_dir[data->rir_index]);
  if (cntl_send (sd_cntl, text, data) == EXIT_FAILURE) {
    free_rir_mem (text, cntl_ip, data_ip, data);
    g_idle_add ((GSourceFunc) rir_not_available, data);
    G_LOCK (downloading);
    downloading = 0;
    G_UNLOCK (downloading);
    return (EXIT_FAILURE);
  }
  if (cntl_recv (sd_cntl, data) == EXIT_FAILURE) {
    free_rir_mem (text, cntl_ip, data_ip, data);
    g_idle_add ((GSourceFunc) rir_not_available, data);
    G_LOCK (downloading);
    downloading = 0;
    G_UNLOCK (downloading);
    return (EXIT_FAILURE);
  }

  // Retrieve delegation file.
  memset (text, 0, TEXT_STRINGLEN * sizeof (char));
  sprintf (text, "RETR %s\r\n", data->rir_file[data->rir_index]);
  if (cntl_send (sd_cntl, text, data) == EXIT_FAILURE) {
    free_rir_mem (text, cntl_ip, data_ip, data);
    g_idle_add ((GSourceFunc) rir_not_available, data);
    G_LOCK (downloading);
    downloading = 0;
    G_UNLOCK (downloading);
    return (EXIT_FAILURE);
  }
  if (data_recv (data) == EXIT_FAILURE) {
    free_rir_mem (text, cntl_ip, data_ip, data);
    g_idle_add ((GSourceFunc) rir_not_available, data);
    G_LOCK (downloading);
    downloading = 0;
    G_UNLOCK (downloading);
    return (EXIT_FAILURE);
  }

  // Close control and data connections.
  if (cntl_send (sd_cntl, "QUIT\r\n", data) == EXIT_FAILURE) {
    free_rir_mem (text, cntl_ip, data_ip, data);
    g_idle_add ((GSourceFunc) rir_not_available, data);
    G_LOCK (downloading);
    downloading = 0;
    G_UNLOCK (downloading);
    return (EXIT_FAILURE);
  }
  if (cntl_recv (sd_cntl, data) == EXIT_FAILURE) {  // Expect "221 Goodbye."
    free_rir_mem (text, cntl_ip, data_ip, data);
    g_idle_add ((GSourceFunc) rir_not_available, data);
    G_LOCK (downloading);
    downloading = 0;
    G_UNLOCK (downloading);
    return (EXIT_FAILURE);
  }

  // Close control and data sockets.
  close (sd_cntl);
  close (data->sd_data);

  G_LOCK (show_dl_messages);
  if (show_dl_messages) {
    printf ("DONE!\n");
  }
  G_UNLOCK (show_dl_messages);

  // Free allocated memory.
  free_rir_mem (text, cntl_ip, data_ip, data);

  G_LOCK (downloading);
  downloading = 0;
  G_UNLOCK (downloading);

  // Load RIR files into memory.
  read_delegation (data->rir_index, data);

  // Update RIR delegation file status.
  g_idle_add ((GSourceFunc) rir_available, data);

  return (EXIT_SUCCESS);
}

// Free allocated memory used in ftp_rir().
int
free_rir_mem (char *text, char *cntl_ip, char *data_ip, SPSData *data)
{
  free (text);
  free (cntl_ip);
  free (data_ip);
  free (data->ftp_data);

  return (EXIT_SUCCESS);
}

// Download all RIR ASN / IP delegation files and www.iso.org's country code file.
// This function is executed as a separate thread.
int
download_all (SPSData *data)
{
  int i;

  // Download all RIR ASN / IP delegation files.
  for (i=0; i<5; i++) {
    data->rir_index = i;
    ftp_rir (data);
  }

  // Download www.iso.org's country code file.
  get_countries (data);

  return (EXIT_SUCCESS);
}

// Request a socket descriptor for FTP control socket.
int
cntl_sock (char *host, char *cntl_ip, SPSData *data)
{
  int sd, status;
  struct addrinfo hints, *servinfo, *p;
  struct timeval ts;
  char s[INET6_ADDRSTRLEN];

  // Populate struct hints for getaddrinfo().
  memset (&hints, 0, sizeof hints);
  hints.ai_family = AF_UNSPEC;
  hints.ai_socktype = SOCK_STREAM;

  // Resolve RIR URL to IP address.
  if ((status = getaddrinfo (host, FTP_PORT, &hints, &servinfo)) != 0) {
    sprintf (data->error_text, "cntl_sock(): getaddrinfo() failed.\nError message: %s", gai_strerror (status));
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    return (EXIT_FAILURE);
  }

  // Loop through all the results and connect to the first we can.
  // Request socket descriptor.
  for (p = servinfo; p != NULL; p = p->ai_next) {
    if ((sd = socket (p->ai_family, p->ai_socktype, p->ai_protocol)) < 0) {
      status = errno;
      continue;
    }

    // Set socket timeout option for control connection.
    memset (&ts, 0, sizeof (struct timeval));
    ts.tv_sec = FTP_TIMEOUT;
    if ((setsockopt (sd, SOL_SOCKET, SO_RCVTIMEO, &ts, sizeof (ts))) != 0) {
      status = errno;
      close (sd);
      continue;
    }

    // Establish connection to remote host.
    if (connect (sd, p->ai_addr, p->ai_addrlen) < 0) {
      status = errno;
      close (sd);
      continue;
    }
    break;
  }

  if (p == NULL) {
    sprintf (data->error_text, "cntl_sock(): Failed to establish a connection with remote host.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    freeaddrinfo (servinfo);
    return (EXIT_FAILURE);
  }

  // Save family for calling function to use.
  data->ftp_family = p->ai_family;

  // Get IP address so calling function can report it.
  if (inet_ntop (p->ai_family, get_in_addr ((struct sockaddr *)p->ai_addr), s, INET6_ADDRSTRLEN) == NULL) {
    status = errno;
    sprintf (data->error_text, "cntl_sock(): inet_ntop() failed.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    freeaddrinfo (servinfo);
    return (EXIT_FAILURE);
  }
  memset (cntl_ip, 0, INET6_ADDRSTRLEN * sizeof (char));
  strncpy (cntl_ip, s, INET6_ADDRSTRLEN - 1);  // Minus 1 for string termination.
  freeaddrinfo (servinfo);

  return (sd);
}

// Request a socket descriptor for FTP data socket.
int
data_sock (char *data_ip, int data_port, SPSData *data)
{
  int sd, status;
  struct addrinfo hints, *servinfo, *p;
  struct timeval ts;
  char buf[6];
  const char *port;

  sprintf (buf, "%d", data_port);
  port = (const char *) buf;

  // Populate struct hints for getaddrinfo().
  memset (&hints, 0, sizeof hints);
  hints.ai_family = AF_UNSPEC;
  hints.ai_socktype = SOCK_STREAM;

  // Populate struct servinfo.
  if ((status = getaddrinfo (data_ip, port, &hints, &servinfo)) != 0) {
    sprintf (data->error_text, "data_sock(): getaddrinfo() failed.\nError message: %s", gai_strerror (status));
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    return (EXIT_FAILURE);
  }

  // Loop through all the results and connect to the first we can.
  // Request socket descriptor.
  for (p = servinfo; p != NULL; p = p->ai_next) {

    if ((sd = socket (p->ai_family, p->ai_socktype, p->ai_protocol)) < 0) {
      status = errno;
      continue;
    }

    // Set socket timeout option for control connection.
    memset (&ts, 0, sizeof (struct timeval));
    ts.tv_sec = FTP_TIMEOUT;
    if ((setsockopt (sd, SOL_SOCKET, SO_RCVTIMEO, &ts, sizeof (ts))) != 0) {
      status = errno;
      close (sd);
      continue;
    }

    // Establish connection to remote host.
    if (connect (sd, p->ai_addr, p->ai_addrlen) < 0) {
      status = errno;
      close (sd);
      continue;
    }
    break;
  }

  if (p == NULL) {
    sprintf (data->error_text, "data_sock(): Failed to establish a connection with remote host.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    return (EXIT_FAILURE);
  }

  freeaddrinfo (servinfo);

  return (sd);
}

// Send a command to FTP control socket.
int
cntl_send (int sd_cntl, char *command, SPSData *data)
{
  int status;

  G_LOCK (show_dl_messages);
  if (show_dl_messages) {
    printf ("Sending command: %s\n", command);
  }
  G_UNLOCK (show_dl_messages);

  if (write (sd_cntl, command, strnlen (command, 80)) < 1) {  // 80 is arbitrary since we receive string literal as argument.
    status = errno;
    sprintf (data->error_text, "cntl_send(): write() failed to write bytes to socket.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    return (EXIT_FAILURE);
  }
  sleep (1);  // Allow 1 second for remote hsot to respond.

  return (EXIT_SUCCESS);
}

// Receive FTP command responses from remote host on the control socket.
int
cntl_recv (int sd_cntl, SPSData *data)
{
  int nbytes, status;

  // Note: we expect to get entire response in cntl-data in one recv() call, so we don't loop it.
  memset (data->ftp_data, 0, IP_MAXPACKET * sizeof (char));
  if ((nbytes = recv (sd_cntl, data->ftp_data, IP_MAXPACKET, 0)) < 0) {
    status = errno;
    if (status == EAGAIN) {  // No response within TIMEOUT seconds. EAGAIN = 11
      sprintf (data->error_text,"cntl_recv(): recv() failed to receive a response within timeout.\nSuggest you try again.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      G_LOCK (message_available);
      message_available = 1;
      G_UNLOCK (message_available);
      return (EXIT_FAILURE);
    } else {
      sprintf (data->error_text, "cntl_recv(): recv() failed.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      G_LOCK (message_available);
      message_available = 1;
      G_UNLOCK (message_available);
      return (EXIT_FAILURE);
    }
  }

  G_LOCK (show_dl_messages);
  if (show_dl_messages) {
    printf ("Received message: %s\n", data->ftp_data);
  }
  G_UNLOCK (show_dl_messages);

  // If a command isn't accepted/fails, then the response code starts with a 4 or 5 like HTTP.
  // If it starts with 2 it's ok.
  if ((data->ftp_data[0] == '4') || (data->ftp_data[0] == '5')) {
    sprintf (data->error_text, "cntl_recv(): FTP command wasn't accepted/failed.\nSuggest you try again.");
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    return (EXIT_FAILURE);
  }

  return (EXIT_SUCCESS);
}

// Extract IPv4 address and port number for creating FTP data socket in passive mode.
int
parse_ip4_port (char *data_ip, int *data_port, SPSData *data)
{
  int i, j, k, p1, p2;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Find first bracket enclosing IP and port information.
  i = 1;
  while ((data->ftp_data[i] != '(') && (i < TEXT_STRINGLEN)) {
    i++;
  }
  if (i == TEXT_STRINGLEN) {
    sprintf (data->error_text, "parse_ip4_port(): Can't find data connection IP address in server's reply.\nSuggest you try again.\n");
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    free (value);
    return (EXIT_FAILURE);
  }
  i++;

  // Extract data connection IP address.
  memset (data_ip, 0, INET6_ADDRSTRLEN * sizeof (char));
  j = 0;
  k = 0;
  while (j < 4) {
    data_ip[k] = data->ftp_data[i];
    if (data_ip[k] == ',') {
      data_ip[k] = '.';
      j++;
    }
    i++;
    k++;
  }
  data_ip[strnlen (data_ip, INET6_ADDRSTRLEN) - 1] = 0;
  G_LOCK (show_dl_messages);
  if (show_dl_messages) {
    printf ("Data connection IP address: %s\n", data_ip);
  }
  G_UNLOCK (show_dl_messages);

  // Extract data connection port number.
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  k = 0;
  while ((data->ftp_data[i] != ',') && (i < TEXT_STRINGLEN)) {
    value[k] = data->ftp_data[i];
    i++;
    k++;
  }
  if (i == TEXT_STRINGLEN) {
    sprintf (data->error_text, "parse_ip4_port(): Can't find data connection port number in server's reply.\nSuggest you try again.\n");
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    free (value);
    return (EXIT_FAILURE);
  }
  if (!is_ascii_uint (value)) {
    sprintf (data->error_text, "Does not appear to be a valid port number: %s", value);
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    free (value);
    return (EXIT_FAILURE);
  } else {
    p1 = (int) ascii_to_int64 (value);
  }
  i++;
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  k = 0;
  while ((data->ftp_data[i] != ')') && (i < TEXT_STRINGLEN)) {
    value[k] = data->ftp_data[i];
    i++;
    k++;
  }
  if (i == TEXT_STRINGLEN) {
    sprintf (data->error_text, "parse_ip4_port(): Can't find data connection port number in server's reply.\nSuggest you try again.\n");
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    free (value);
    return (EXIT_FAILURE);
  }
  if (!is_ascii_uint (value)) {
    sprintf (data->error_text, "Does not appear to be a valid port number: %s", value);
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    free (value);
    return (EXIT_FAILURE);
  } else {
    p2 = (int) ascii_to_int64 (value);
  }
  *data_port = (p1 * 256) + p2;
  if (*data_port > 65535) {
    sprintf (data->error_text, "parse_ip4_port(): Data connection port number in server's reply appears to be too large.\nSuggest you try again.\n");
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    free (value);
    return (EXIT_FAILURE);
  }
  G_LOCK (show_dl_messages);
  if (show_dl_messages) {
    printf ("Data connection port: %i\n", *data_port);
  }
  G_UNLOCK (show_dl_messages);

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Extract port number for creating an IPv6 FTP data socket in passive mode.
// For IPv6 FTP, data IP address is the same as the control IP address.
int
parse_ip6_port (int *data_port, SPSData *data)
{
  int i, k;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Find first bracket enclosing port information.
  i = 1;
  while ((data->ftp_data[i] != '(') && (i < TEXT_STRINGLEN)) {
    i++;
  }
  if (i == TEXT_STRINGLEN) {
    sprintf (data->error_text, "parse_ip6_port(): Can't find data connection IP address in server's reply.\nSuggest you try again.\n");
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    free (value);
    return (EXIT_FAILURE);
  }
  i++;

  // Find a digit. i.e., where port number starts
  while ((data->ftp_data[i] < 48) && (data->ftp_data[i] > 57) && (i < TEXT_STRINGLEN)) {
    i++;
  }

  // Extract data connection port number.
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  k = 0;
  while ((data->ftp_data[i] > 47) && (data->ftp_data[i] < 58) && (i < TEXT_STRINGLEN)) {
    value[k] = data->ftp_data[i];
    i++;
    k++;
  }
  if (i == TEXT_STRINGLEN) {
    sprintf (data->error_text, "parse_ip6_port(): Can't find data connection port number in server's reply.\nSuggest you try again.\n");
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    free (value);
    return (EXIT_FAILURE);
  }
  if (!is_ascii_uint (value)) {
    sprintf (data->error_text, "Does not appear to be a valid port number: %s", value);
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    free (value);
    return (EXIT_FAILURE);
  } else {
    *data_port = (int) ascii_to_int64 (value);
  }
  if (*data_port > 65535) {
    sprintf (data->error_text, "parse_ip6_port(): Data connection port number in server's reply appears to be too large.\nSuggest you try again.\n");
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    free (value);
    return (EXIT_FAILURE);
  }
  G_LOCK (show_dl_messages);
  if (show_dl_messages) {
    printf ("Data connection port: %i\n", *data_port);
  }
  G_UNLOCK (show_dl_messages);

  free (value);

  return (EXIT_SUCCESS);
}

// Receive and save data on the FTP data socket.
int
data_recv (SPSData *data)
{
  int i, nbytes, status;
  FILE *fo;

  // Open file to cache the IP delegation data.
  fo = fopen (data->rir_file[data->rir_index], "wb");
  if (fo == NULL) {
    sprintf (data->error_text, "data_recv(): Can't open a file for saving the IP delegation data.");
    data->parent = data->main_window;
    G_LOCK (message_available);
    message_available = 1;
    G_UNLOCK (message_available);
    return (EXIT_FAILURE);
  }

  nbytes = 1;
  while (nbytes) {
    memset (data->ftp_data, 0, IP_MAXPACKET * sizeof (char));
    if ((nbytes = recv (data->sd_data, data->ftp_data, IP_MAXPACKET, 0)) < 0) {
      status = errno;
      if (status == EAGAIN) {  // No response within TIMEOUT seconds. EAGAIN = 11
        sprintf (data->error_text, "data_recv(): recv() failed to receive a response within timeout.\nSuggest you try again.\nError message: %s", strerror (status));
        data->parent = data->main_window;
        G_LOCK (message_available);
        message_available = 1;
        G_UNLOCK (message_available);
        return (EXIT_FAILURE);
      } else if (status == EINTR) {  // EINTR = 4
          continue;  // Something weird happened, but let's keep listening.
      } else {
        sprintf (data->error_text, "data_recv(): recvfrom() failed.\nError message: %s", strerror (status));
        data->parent = data->main_window;
        G_LOCK (message_available);
        message_available = 1;
        G_UNLOCK (message_available);
        return (EXIT_FAILURE);
      }
    }
    // Write this batch of data to file.
    for (i=0; i<nbytes; i++) {
      fputc (data->ftp_data[i], fo);
    }
  }

  fclose (fo);

  return (EXIT_SUCCESS);
}

// Set RIR delegation file status to "Loading".
// This idle function returns 0 in order to stop.
int
rir_loading (SPSData *data)
{
  // File is currently loading.
  gtk_text_buffer_set_text (rir_textview (data->rir_index, data), "Loading", -1);

  return (0);  // This idle function stops when it returns a value of zero.
}

// Set RIR delegation file status to "Not Available" because an error occurred.
// This idle function returns 0 in order to stop.
int
rir_not_available (SPSData *data)
{
  // File is not available to be loaded.
  gtk_text_buffer_set_text (rir_textview (data->rir_index, data), "Not Available", -1);

  return (0);  // This idle function stops when it returns a value of zero.
}

// Update RIR delegation file status.
// This idle function returns 0 in order to stop.
int
rir_available (SPSData *data)
{
  // File is loaded.
  if (data->rir_file_loaded[data->rir_index]) {
    gtk_text_buffer_set_text (rir_textview (data->rir_index, data), "Loaded", -1);

  // File not available to be loaded.
  } else {
    gtk_text_buffer_set_text (rir_textview (data->rir_index, data), "Not Available", -1);
  }

  return (0);  // This idle function stops when it returns a value of zero.
}

// Return pointer to RIR file status textbuffer based on RIR index.
GtkTextBuffer *
rir_textview (int index, SPSData *data)
{
  switch (index) {

  case 0:
    return (gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview8)));

  case 1:
    return (gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview9)));

  case 2:
    return (gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview12)));

  case 3:
    return (gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview13)));

  case 4:
    return (gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview14)));

  default:
    fprintf (stderr, "ERROR: Invalid value %i of RIR index in rir_textview().\n", index);
    exit (EXIT_FAILURE);
  }
}
