/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>           // close(), sleep(), usleep(), gethostname(), write()
#include <string.h>           // strncpy(), strncmp(), strnlen(), strncat(), memset(), and memcpy()
#include <time.h>             // localtime(), time()
#include <inttypes.h>         // uint8_t, uint16_t, uint32_t, uint64_t, int32_t, int64_t, PRIu8, PRIu16, PRIu32, PRIu64

#include <netdb.h>            // struct addrinfo
#include <sys/types.h>        // needed for socket()
#include <sys/socket.h>       // needed for socket()
#include <netinet/in_systm.h>
#include <netinet/in.h>       // IPPROTO_IP, IPPROTO_ICMP, IPPROTO_TCP, IPPROTO_UDP, IPPROTO_IPV6, IPPROTO_ICMPV6, INET_ADDRSTRLEN, INET6_ADDRSTRLEN
#include <netinet/ip.h>       // struct ip and IP_MAXPACKET (which is 65535), IPPROTO_IPV6, IPPROTO_ICMPV6
#include <netinet/ip6.h>      // struct ip6_hdr
#define __FAVOR_BSD           // Use BSD format of TCP and UDP header. Must appear here BEFORE #include <netinet/tcp.h>.
#include <netinet/tcp.h>      // struct tcphdr
#include <netinet/ip_icmp.h>  // struct icmp, ICMP_ECHO
#include <netinet/icmp6.h>    // struct icmp6_hdr, ICMP6_ECHO_REQUEST, ICMP6_TIME_EXCEEDED, struct nd_neighbor_solicit, ND_NEIGHBOR_SOLICIT
#include <netinet/udp.h>      // struct udphdr
#include <arpa/inet.h>        // inet_pton(), inet_ntop(), htons(), ntohs(), htonl(), ntohl()
#include <sys/ioctl.h>        // macro ioctl is defined
#include <bits/ioctls.h>      // defines values for argument "request" of ioctl. Here, we need SIOCGIFHWADDR
#include <net/if.h>           // struct ifreq
#include <ifaddrs.h>          // ifaddrs()
#include <bits/socket.h>      // structs msghdr and cmsghdr
#include <linux/if_ether.h>   // ETH_P_IP = 0x0800, ETH_P_IPV6 = 0x86DDD
#include <linux/if_packet.h>  // struct sockaddr_ll (see man 7 packet)
#include <net/ethernet.h>
#include <sys/time.h>         // gettimeofday()

#include <errno.h>            // errno, perror(), EAGAIN, EINTR, ECONNREFUSED

// Define some constants
#define UTF8_FILENAME "UTF-8.csv"  // Small-capital UTF-8 cross-reference filename
#define ETH_HDRLEN 14      // Ethernet header length (bytes)
#define IP4_HDRLEN 20      // IPv4 header length (bytes)
#define IP6_HDRLEN 40      // IPv6 header length (bytes)
#define MAX_IP6LINKS 1000  // Maximum number of links in an IPv6 chain of headers, options, payloads, etc.
#define TCP_HDRLEN 20      // TCP header length, excludes options data (bytes)
#define ICMP_HDRLEN 8      // ICMP header length for echo request, excludes data (bytes)
#define UDP_HDRLEN 8       // UDP header length, excludes data (bytes)
#define FRG_HDRLEN 8       // IPv6 fragment header (bytes)
#define HOP_HDRLEN 2       // Hop-by-hop header length (bytes), excluding options
#define DST_HDRLEN 2       // Destination header length (bytes), excluding options
#define RTE_HDRLEN 4       // Routing header length, excluding data
#define ATH_HDRLEN 12      // Authentication header length (bytes), excludes authentication data
#define ESP_HDRLEN 8       // ESP header length (bytes), excluding payload data, padding, ESP trailer, and authentication data
#define ESP_TAILLEN 2      // ESP tail length (bytes), excluding ESP header (above), payload data, padding, and auth. data
#define ARP_HDRLEN 28      // ARP header length (bytes)
#define ARPOP_REQUEST 1    // Taken from <linux/if_arp.h>
#define ARPOP_REPLY 2      // Taken from <linux/if_arp.h>
#define FTP_TIMEOUT 10     // FTP listening timeout
#define FTP_PORT "21"      // FTP port number
#define HTTP_TIMEOUT 10    // HTTP listening timeout
#define HTTP_PORT "80"     // HTTP port number
#define MAX_FRAGS 65536    // Maximum number of fragments for one packet (some big number)
#define MAX_IP4OPTLEN 40   // Maximum length (bytes) of IPv4 options
#define MAX_IP4OPTIONS 20  // Maximum number of IPv4 options (60 - IP4_HDRLEN) / 2 bytes)
#define MAX_TCPOPTLEN 40   // Maximum length (bytes) of TCP options
#define MAX_TCPOPTIONS 20  // Maximum number of TCP options (40 / 2 bytes)
#define MAX_HBHOPTIONS 20  // Maximum number of hop-by-hop extension header options
#define MAX_HBHOPTLEN 256  // Maximum length (bytes) of a hop-by-hop option (some large value)
#define MAX_DSTOPTIONS 20  // Maximum number of destination extension header options
#define MAX_DSTOPTLEN 256  // Maximum length (bytes) of a destination option (some large value)
#define MAX_ROUTEDATA 2044  // Maximum length (bytes) of routing header data (255 * 8 bytes) + 4
#define MAX_AUTHICVLEN 1024  // Maximum length (bytes) of authentication header ICV
#define MAX_ESPICVLEN 1024  // Maximum length (bytes) of ESP header ICV
#define TMP_STRINGLEN 80  // Length of array to hold temporary values as strings
#define TEXT_STRINGLEN 1024  // Length of array to hold various strings of text
#define RIR_MEM_BLOCK 1000000  // Size of each memory chunk allocated for IP/ASN RIR search results
#define SMALL 0  // Value indicating lower case UTF-8 letter
#define CAPITAL 1  // Value indicating upper case UTF-8 letter

// Definition of pktinfo6 created from definition of in6_pktinfo in netinet/in.h.
// This should remove "redefinition of in6_pktinfo" errors in some linux variants.
typedef struct _pktinfo6 Pktinfo6;
struct _pktinfo6 {
  struct in6_addr ipi6_addr;
  int ipi6_ifindex;
};

// Struct to hold ethernet header values
typedef struct _ethhdr Ethhdr;
struct _ethhdr {
  uint8_t dst_mac[6];
  uint8_t src_mac[6];
  uint16_t type_code;
};

// Define a struct for hop-by-hop and destination headers, excluding options.
typedef struct _hopdst_hdr Hopdst_hdr;
struct _hopdst_hdr {
  uint8_t nxt_hdr;
  uint8_t hdr_len;
};

// Define a struct for routing header, excluding data.
typedef struct _route_hdr Route_hdr;
struct _route_hdr {
  uint8_t nxt_hdr;
  uint8_t hdr_len;
  uint8_t routing_type;
  uint8_t segs_left;
};

// Define a struct for authentication header, excluding authentication data.
typedef struct _auth_hdr Auth_hdr;
struct _auth_hdr {
  uint8_t nxt_hdr;
  uint8_t pay_len;
  uint16_t reserved;
  uint32_t spi;
  uint32_t seq;
};

// Define a struct for head of ESP header, excluding payload and authentication data.
typedef struct _esp_hdr Esp_hdr;
struct _esp_hdr {
  uint32_t spi;
  uint32_t seq;
};

// Define a struct for tail of ESP header, excluding payload and authentication data.
typedef struct _esp_tail Esp_tail;
struct _esp_tail {
  uint8_t pad_len;
  uint8_t nxt_hdr;
};

// Define a struct for ARP header.
typedef struct _arp_hdr Arp_hdr;
struct _arp_hdr {
  uint16_t htype;
  uint16_t ptype;
  uint8_t hlen;
  uint8_t plen;
  uint16_t opcode;
  uint8_t sender_mac[6];
  uint8_t sender_ip[4];
  uint8_t target_mac[6];
  uint8_t target_ip[4];
};

// Define a struct to contain pointers to a textview and message for post_message().
typedef struct _msgdata Msgdata;
struct _msgdata {
  char *message;
  GtkWidget *textview;
};

// Main data structure definition
typedef struct _SPSData SPSData;
struct _SPSData {
  GtkWidget *main_window;
  GtkWidget *menubar1;
  GtkWidget *view;
  GtkWidget *parent;  // Pointer to parent that spawned an error. e.g., data->menubar1, data->main_window, or data->traceroute_window

  char *error_text;  // String to hold error messages.
  char *warning_text;  // String to hold warning messages.

  // UTF-8 small-capital cross-reference array
  uint8_t ***utf8;  // Array holding contents of file UTF8_FILENAME: utf8[record][SMALL/CAP] = uint8_t * of size 6
  int nutf8;  // Number of lines in file UTF8_FILENAME

  // Pseudo-random number parameters
  // LA-UR-07-7961
  uint64_t RN_MULT;
  uint64_t RN_STRIDE;
  uint64_t RN_SEED;
  uint64_t RN_SEED0;
  uint64_t RN_ADD;
  uint64_t RN_MOD;
  double RN_NORM;
  uint64_t RN_PERIOD;
  uint64_t RN_MASK;
  int RN_BITS;
  uint64_t RN_ITER;

  /* The following are the definitions for variable 'type':
     Type: 0 = IPv4 TCP, 1 = IPv4 ICMP, 2 = IPv4 UDP
     Type: 3 = IPv6 TCP, 4 = IPv6 ICMP, 5 = IPv6 UDP
     6to4:
     Type: 6 = IPv6 TCP, 7 = IPv6 ICMP, 8 = IPv6 UDP

     Traceroute:
     Type: 9 = IPv4 TCP, 10 = IPv4 ICMP, 11 = IPv4 UDP
     Type: 12 = IPv6 TCP, 13 = IPv6 ICMP, 14 = IPv6 UDP
     Traceroute (6to4):
     Type: 15 = IPv6 TCP, 16 = IPv6 ICMP, 17 = IPv6 UDP

     New IPv6 headers for Auth. and ESP tunnel modes
     Type: 23 = IPv6 TCP, 24 = IPv6 ICMP, 25 = IPv6 UDP
     Type: 32 = IPv6 TCP, 33 = IPv6 ICMP, 34 = IPv6 UDP

     Special type for sending all (cycling through) IPv4 or IPv6 packets.
     Used only for data->packet_type, which is for the ipv4_send() and ipv6_send() functions.
     Type: 100 = all IPv4, 101 = all IPv6
  */

  int *protocol_type;  // Table of type values from above matched to protocol type values: protocol_type[type] = int

  // Number of packet types, as listed above
  int ntypes;  // Number of types of packet - currently 18

  // Ethernet header and interface
  int *specify_ether;  // Flag to indicate if ethernet header is specified by user: specify_ether[type] = int
  Ethhdr *ethhdr;  // Struct to hold ethernet header values: ethhdr[type] = Ethhdr
  char **ifname;  // Interface name: ifname[type] = char *
  int *ifmtu;  // Interface MTU: ifmtu[type] = int;

  // IP and upper layer protocol Headers
  struct ip *ip4hdr;  // IPv4 header: ip4hdr[type] = struct ip
  struct ip6_hdr *ip6hdr;  // IPv6 header: ip6hdr[type] = struct ip6_hdr
  struct tcphdr *tcphdr;  // TCP header: tcphdr[type] = struct tcphdr
  struct icmp *icmp4hdr;  // IPv4 ICMP header: icmp4hdr[type] = struct icmp
  struct icmp6_hdr *icmp6hdr;  // IPv6 ICMP header: icmp6hdr[type] = struct icmp6_hdr
  struct udphdr *udphdr;  // UDP header: udphdr[type] = struct udphdr

  // Ethernet frames (can be a fragment). This is what gets sent to socket.
  // packet holds unfragmented ethernet frames. Used only for displaying packet.
  uint8_t ***ether_frame;  // Ethernet frame buffers: ether_frame[type][frame #] = uint8_t *
  uint8_t **packet;  // Entire unfragmented packet: packet[type] = uint8_t *
  int **frame_length;  // Length of ethernet frame: frame_length[type][frame] = int
  int *packet_length;  // Length of unfragmented packet: packet_length[type] = int
  int *nframes;  // Number of frames: nframes[type] = int

  // IPv4 options. Type definitions as above.
  int *ip_nopt;  // Number of IP options: ip_nopt[type] = int
  int *ip_opt_totlen;  // Total length of IP options: ip_opt_totlen[type] = int
  int **ip_optlen;  // IPv4 option length: ip_optlen[type][option #] = int
  uint8_t ***ip_options;  // IPv4 options data: ip_options[type][option #] = uint8_t *
  int *ip_optpadlen;  // IPv4 options padding length: ip_optpad[type] = int
  int *ip_optlenbuf;  // IPv4 option length buffer: ip_optlenbuf[type] = int
  uint8_t **ip_optionsbuf;  // IPv4 options data buffer: ip_optionsbuf[type] = uint8_t *

  // Order array for chain of IPv6 headers, extension headers, payloads, etc.
  int **order;  // Array giving order of links in IPv6 chain: order[type][link #] = int
  int *first_frag;  // Link in chain at which fragmentable portion begins: first_frag[type] = int

  // Hop-by-Hop header options. Type definitions as above.
  int *hbh_hdr_flag;  // Flag indicating hop-by-hop header: hbh_hdr_flag[type] = int
  Hopdst_hdr *hophdr;  // Hop-by-hop header (Next header and Length): hophdr[type] = struct Hopdst_hdr
  int *hbh_nopt;  // Number of hop-by-hop options: hbh_nopt[type] = int
  int **hbh_x;  // Alignment factor x (of xN + y): hbh_x[type][option #] = int
  int **hbh_y;  // Alignment factor y (of xN + y): hbh_y[type][option #] = int
  int *hbh_opt_totlen;  // Total length of hop-by-hop options: hbh_opt_totlen[type] = int
  int **hbh_optlen;  // Hop-by-hop option length: hbh_optlen[type][option #] = int
  uint8_t ***hbh_options;  // Hop-by-hop options data: hbh_options[type][option #] = uint8_t *
  int *hbh_optpadlen;  // Hop-by-hop options padding length: hbh_optpad[type] = int
  int **hbh_optleadpadlen;  // Hop-by-hop options alignment padding length: hbh_optleadpadlen[type][option #] = int
  uint8_t ***hbh_optleadpad;  // Hop-by-hop options alignment padding: hbh_optleadpad[type][option #] = uint8_t *
  int *hbh_opttailpadlen;  // Hop-by-hop options trailing padding length: hbh_opttailpadlen[type] = int
  uint8_t **hbh_opttailpad;  // Hop-by-hop options trailing padding: hbh_opttailpad[type] = uint8_t *
  int *hbh_optlenbuf;  // Hop-by-hop option length buffer: hbh_optlenbuf[type] = int
  uint8_t **hbh_optionsbuf;  // Hop-by-hop options data buffer: hbh_optionsbuf[type] = uint8_t *

  // Destination header (first) options. Type definitions as above.
  int *dstf_hdr_flag;  // Flag indicating destination header (first): dstf_hdr_flag[type] = int
  Hopdst_hdr *dstfhdr;  // Destination header (first) (Next header and Length): dstfhdr[type] = struct Hopdst_hdr
  int *dstf_nopt;  // Number of "first" destination options: dstf_nopt[type] = int
  int **dstf_x;  // Alignment factor x (of xN + y): dstf_x[type][option #] = int
  int **dstf_y;  // Alignment factor y (of xN + y): dstf_y[type][option #] = int
  int *dstf_opt_totlen;  // Total length of destination header (first) options: dstf_opt_totlen[type] = int
  int **dstf_optlen;  // Destination header (first) option length: dstf_optlen[type][option #] = int
  uint8_t ***dstf_options;  // Destination header (first) options data: dstf_options[type][option #] = uint8_t *
  int *dstf_optpadlen;  // Destination header (first) options padding length: dstf_optpad[type] = int
  int **dstf_optleadpadlen;  // Destination options alignment padding length: dstf_optleadpadlen[type][option #] = int
  uint8_t ***dstf_optleadpad;  // Destination options alignment padding: dstf_optleadpad[type][option #] = uint8_t *
  int *dstf_opttailpadlen;  // Destination options trailing padding length: dstf_opttailpadlen[type] = int
  uint8_t **dstf_opttailpad;  // Destination options trailing padding: dstf_opttailpad[type] = uint8_t *

  // Destination header (last) options. Type definitions as above.
  int *dstl_hdr_flag;  // Flag indicating destination header (last): dstl_hdr_flag[type] = int
  Hopdst_hdr *dstlhdr;  // Destination header (last) (Next header and Length): dstlhdr[type] = struct Hopdst_hdr
  int *dstl_nopt;  // Number of "last" destination options: dstl_nopt[type] = int
  int **dstl_x;  // Alignment factor x (of xN + y): dstl_x[type][option #] = int
  int **dstl_y;  // Alignment factor y (of xN + y): dstl_y[type][option #] = int
  int *dstl_opt_totlen;  // Total length of destination header (last) options: dstl_opt_totlen[type] = int
  int **dstl_optlen;  // Destination header (last) option length: dstl_optlen[type][option #] = int
  uint8_t ***dstl_options;  // Destination header (last) options data: dstl_options[type][option #] = uint8_t *
  int *dstl_optpadlen;  // Destination header (last) options padding length: dstl_optpad[type] = int
  int **dstl_optleadpadlen;  // Destination options alignment padding length: dstf_optleadpadlen[type][option #] = int
  uint8_t ***dstl_optleadpad;  // Destination options alignment padding: dstf_optleadpad[type][option #] = uint8_t *
  int *dstl_opttailpadlen;  // Destination options trailing padding length: dstf_opttailpadlen[type] = int
  uint8_t **dstl_opttailpad;  // Destination options trailing padding: dstf_opttailpad[type] = uint8_t *

  // Routing header. Type definitions as above.
  int *route_hdr_flag;  // Flag indicating routing header: route[type] = int
  Route_hdr *routehdr;  // Routing header, excluding data: routehdr[type] = struct Route_hdr
  int *route_datlen;  // Routing header data length: route_datlen[type] = int
  uint8_t **route_data;  // Routing header data: route_data[type] = uint8_t *

  // Authentication header. Type definitions as above.
  int *auth_hdr_flag;  // Flag indicating authentication header: auth_hdr_flag[type] = int
  int *auth_tr_tun_flag;  // Flag indicating transport or tunnel mode: auth_tr_tun_flag[type] = int
  Auth_hdr *authhdr;  // Authentication header: authhdr[type] = struct Auth_hdr
  int *auth_len;  // Authentication data length: auth_len[type] = int
  uint8_t **auth_data;  // Authentication data (integrity check value (ICV)): auth_data[type] = uint8_t *

  // Encapsulating security payload (ESP) header. Type definitions as above.
  int *esp_hdr_flag;  // Flag indicating ESP header: esp_hdr_flag[type] = int
  int *esp_tr_tun_flag;  // Flag indicating transport or tunnel mode: esp_tr_tun_flag[type] = int
  Esp_hdr *esphdr;  // Encapsulating security payload header: esphdr[type] = struct Esp_hdr
  uint8_t **esp_pad;  // ESP payload padding: esp_pad[type] = uint8_t *
  Esp_tail *esptail;  // Encapsulating security payload trailer: esptail[type] = struct Esp_tail
  int *esp_auth_len;  // ESP authentication header data length: esp_auth_len[type] = int
  uint8_t **esp_auth_data;  // ESP auth. data (integrity check value (ICV)): esp_auth_data[type] = uint8_t *

  // TCP options for IPv4 and IPv6. Type definitions as above.
  int *tcp_nopt;  // Number of TCP options: tcp_nopt[type] = int
  int *tcp_opt_totlen;  // Total length of TCP options: tcp_opt_totlen[type] = int
  int **tcp_optlen;  // TCP option length: tcp_optlen[type][option #] = int
  uint8_t ***tcp_options;  // TCP options data: tcp_options[type][option #] = uint8_t *
  int *tcp_optpadlen;  // TCP options padding length: tcp_optpad[type] = int
  int *tcp_optlenbuf;  // TCP option length buffer: tcp_optlenbuf[type] = int
  uint8_t **tcp_optionsbuf;  // TCP option data buffer: tcp_optionsbuf[type] = uint8_t *

  // Upper layer protocol data for IPv4 and IPv6. Type definitions as above.
  uint8_t **payload;  // Upper layer protocol data: payload[type] = uint8_t *
  int *payloadlen;  // Upper layer protocol data length: payloadlen[type] = int

  // Regional Internet Registry (RIR) names, URLs, directories, and filenames.
  // RIR index values: 0 = arin, 1 = ripe, 2 = afrinic, 3 = apnic, 4 = lacnic
  char **rir_name;  // Regional Internet Registry (RIR) names: rir_name[RIR index] = char *
  char **rir_www;  // Regional Internet Registry (RIR) HTTP URLs: rir_www[RIR index] = char *
  char **rir_ftp;  // Regional Internet Registry (RIR) FTP URLs: rir_ftp[RIR index] = char *
  char **rir_dir;  // RIR directory location of IP delegation files: rir_dir[RIR index] = char *
  char **rir_file;  // RIR IP delegation filenames: rir_file[RIR index] = char *

  // International Organization for Standardization (ISO)'s country code URL, directory, and filename.
  char *country_www;  // ISO's HTTP URL: country_www = char *
  char *country_dir;  // ISO's directory location of country code file: country_dir = char *
  char *country_file;  // ISO's filename for country code file: country_file = char *

// Send page

  // Select Packet Type
  GtkToggleButton *radiobutton1;  // TCP (IPv4) packet type, packet_type = 1
  GtkToggleButton *radiobutton2;  // ICMP (IPv4) packet type, packet_type = 2
  GtkToggleButton *radiobutton3;  // UDP (IPv4) packet type, packet_type = 3
  GtkToggleButton *radiobutton4;  // All (IPv4) packet types (i.e., cycle), packet_type = 4
  GtkToggleButton *radiobutton5;  // TCP (IPv6) packet type, packet_type = 5
  GtkToggleButton *radiobutton6;  // ICMP (IPv6) packet type, packet_type = 6
  GtkToggleButton *radiobutton7;  // UDP (IPv6) packet type, packet_type = 7
  GtkToggleButton *radiobutton8;  // All (IPv6) packet types (i.e., cycle), packet_type = 8
  int packet_type;  // Packet type

  // Number of Packets to Send
  GtkWidget *entry18;  // Number of packets to send
  int64_t npackets;  // Number of packets to send
  GtkToggleButton *checkbutton11;  // Flood

  // Activity Log
  GtkWidget *textview1;  // Activity log

  // IPv6 over IPv4 (6to4)
  GtkToggleButton *checkbutton12;  // Tunnel IPv6 over IPv4
  int sixto4_flag;  // Flag for state of Tunnel IPv6 over IPv4 checkbutton
  GtkWidget *spinbutton17;  // Interface maximum transmission unit
  GtkToggleButton *checkbutton57;  // Pad ethernet frame to meet minimum length, if required
  GtkToggleButton *checkbutton14;  // TCP - Use ethernet header specified on IPv6 page
  GtkWidget *entry125;  // TCP source IPv4 address for 6to4 packets
  GtkToggleButton *checkbutton47;  // ICMP - Use ethernet header specified on IPv6 page
  GtkWidget *entry160;  // ICMP source IPv4 address for 6to4 packets
  GtkToggleButton *checkbutton32;  // UDP - Use ethernet header specified on IPv6 page
  GtkWidget *entry161;  // UDP source IPv4 address for 6to4 packets
  GtkToggleButton *checkbutton13;  // TCP source IPv4 "Randomize" for 6to4 packets
  GtkToggleButton *checkbutton26;  // ICMP source IPv4 "Randomize" for 6to4 packets
  GtkToggleButton *checkbutton27;  // UDP source IPv4 "Randomize" for 6to4 packets
  int ran_tcp6to4_sourceip;  // Flag for state of TCP source IPv4 "Randomize" for 6to4 packets
  int ran_icmp6to4_sourceip;  // Flag for state of ICMP source IPv4 "Randomize" for 6to4 packets
  int ran_udp6to4_sourceip;  // Flag for state of UDP source IPv4 "Randomize" for 6to4 packets

  // Send / Stop
  GtkButton *button1;  // Send
  GtkButton *button5;  // Stop Flood

// TCP page (IPv4)

  // Ethernet header for IPv4 TCP
  GtkToggleButton *checkbutton18;  // Specify ethernet header
  GtkToggleButton *checkbutton58;  // Pad ethernet frame to meet minimum length, if required
  GtkWidget *entry144;  // Destination link-layer (MAC) address
  GtkWidget *entry145;  // Source link-layer (MAC) address
  GtkWidget *entry150;  // Source interface name
  GtkWidget *spinbutton5;  // Interface maximum transmission unit
  GtkWidget *entry146;  // Ethernet type code;

  // IPv4 header for IPv4 TCP
  GtkWidget *entry29;  // IP header length
  GtkWidget *entry30;  // Protocol version
  GtkWidget *entry31;  // Type of service
  GtkWidget *entry32;  // Total length of datagram
  GtkWidget *entry33;  // ID sequence number
  GtkWidget *entry122;  // Zero
  GtkWidget *entry37;  // Do not fragment flag
  GtkWidget *entry38;  // More fragments following flag
  GtkWidget *entry39;  // Fragmentation offset
  GtkWidget *entry40;  // Time-to-live
  GtkWidget *entry74;  // Transport layer protocol
  GtkWidget *entry35;  // Source IP address
  GtkToggleButton *checkbutton5;  // Source IP "Randomize"
  int ran_tcp4_sourceip;  // Flag for state of source IPv4 "Randomize" checkbutton
  GtkWidget *entry36;  // Destination IP address
  GtkWidget *entry34;  // IP checksum

  // IPv4 header options for IPv4 TCP
  GtkToggleButton *radiobutton24;  // Decimal option data entry
  GtkToggleButton *radiobutton25;  // Hexadecimal option data entry
  int dec_hex_ipopt_tcp4;  // Flag to indicate decimal (0) or hexadecimal (1) data entry
  GtkWidget *entry400;  // Option data
  GtkButton *button26;  // Insert IP option after...
  GtkWidget *entry401;  // Option number after which to insert new option
  int ipopt_tcp4_after;  // Option number after which to insert new option
  GtkButton *button60;  // Append IP option
  GtkWidget *textview30;  // Number of IP options in packet
  GtkButton *button61;  // View IP options
  GtkWidget *entry403;  // Option number to remove
  int ipopt_tcp4_remove;  // Option number to remove
  GtkButton *button62;  // Remove option

  // TCP header for IPv4 TCP
  GtkWidget *entry41;  // Source port number
  GtkToggleButton *checkbutton7;  // Source port "Randomize"
  int ran_tcp4_sourceport;  // Flag for state of source port "Randomize" checkbutton (IPv4)
  GtkWidget *entry42;  // Destination port number
  GtkWidget *entry43;  // Sequence number
  GtkWidget *entry44;  // Ack number
  GtkWidget *entry45;  // Reserved
  GtkWidget *entry46;  // Data offset
  GtkWidget *entry47;  // FIN flag
  GtkWidget *entry48;  // SYN flag
  GtkWidget *entry49;  // RST flag
  GtkWidget *entry50;  // PSH flag
  GtkWidget *entry51;  // ACK flag
  GtkWidget *entry52;  // URG flag
  GtkWidget *entry53;  // ECE flag
  GtkWidget *entry54;  // CWR flag
  GtkWidget *entry55;  // Window size
  GtkWidget *entry56;  // TCP checksum
  GtkWidget *entry77;  // Urgent pointer
  GtkToggleButton *radiobutton17;  // ASCII data entry
  GtkToggleButton *radiobutton18;  // Hexadecimal data entry
  int ascii_hex_tcp4;  // Flag to indicate ASCII (0) or hexadecimal (1) data entry
  GtkWidget *entry162;  // TCP payload data from keyboard
  GtkButton *button20;  // TCP payload data from file

  // TCP header options for IPv4 TCP
  GtkToggleButton *radiobutton41;  // Decimal option data entry
  GtkToggleButton *radiobutton42;  // Hexadecimal option data entry
  int dec_hex_tcpopt_tcp4;  // Flag to indicate decimal (0) or hexadecimal (1) data entry
  GtkWidget *entry404;  // Option data
  GtkButton *button47;  // Insert IP option after...
  GtkWidget *entry405;  // Option number after which to insert new option
  int tcpopt_tcp4_after;  // Option number after which to insert new option
  GtkButton *button48;  // Append TCP option
  GtkWidget *textview24;  // Number of TCP options in packet
  GtkButton *button49;  // View TCP options
  GtkWidget *entry406;  // Option number to remove
  int tcpopt_tcp4_remove;  // Option number to remove
  GtkButton *button58;  // Remove option

  GtkButton *button3;  // View Packet
  GtkButton *button11;  // Restore default settings

// TCP page (IPv6)

  // Ethernet header for IPv6 TCP
  GtkWidget *entry131;  // Destination link-layer (MAC) address
  GtkWidget *entry132;  // Source link-layer (MAC) address
  GtkWidget *entry154;  // Source interface name
  GtkWidget *spinbutton8;  // Interface maximum transmission unit
  GtkWidget *entry133;  // Ethernet type code;

  // IPv6 header for IPv6 TCP
  GtkWidget *entry22;  // IP version
  GtkWidget *entry23;  // Traffic class
  GtkWidget *entry24;  // Flow label
  GtkWidget *entry25;  // Payload length
  GtkWidget *entry26;  // Next header
  GtkWidget *entry27;  // Hop limit
  GtkWidget *entry28;  // Source IP address
  GtkToggleButton *checkbutton2;  // Source IPv6 address "Randomize"
  int ran_tcp6_sourceip;  // Flag for state of source IPv6 "Randomize" checkbutton
  GtkWidget *entry78;  // Destination IP address

  // TCP header for IPv6 TCP
  GtkWidget *entry79;  // Source port number
  GtkToggleButton *checkbutton4;  // Source port "Randomize"
  int ran_tcp6_sourceport;  // Flag for state of source port "Randomize" checkbutton (IPv6)
  GtkWidget *entry80;  // Destination port number
  GtkWidget *entry81;  // Sequence number
  GtkWidget *entry82;  // Ack number
  GtkWidget *entry83;  // Reserved
  GtkWidget *entry84;  // Data offset
  GtkWidget *entry85;  // FIN flag
  GtkWidget *entry86;  // SYN flag
  GtkWidget *entry87;  // RST flag
  GtkWidget *entry88;  // PSH flag
  GtkWidget *entry89;  // ACK flag
  GtkWidget *entry90;  // URG flag
  GtkWidget *entry91;  // ECE flag
  GtkWidget *entry92;  // CWR flag
  GtkWidget *entry93;  // Window size
  GtkWidget *entry94;  // TCP checksum
  GtkWidget *entry95;  // Urgent pointer
  GtkToggleButton *radiobutton19;  // ASCII data entry
  GtkToggleButton *radiobutton20;  // Hexadecimal data entry
  int ascii_hex_tcp6;  // Flag to indicate ASCII (0) or hexadecimal (1) data entry
  GtkWidget *entry163;  // TCP payload data from keyboard
  GtkButton *button22;  // TCP payload data from file

  // TCP options for IPv6 TCP
  GtkToggleButton *radiobutton47;  // Decimal option data entry
  GtkToggleButton *radiobutton48;  // Hexadecimal option data entry
  int dec_hex_tcpopt_tcp6;  // Flag to indicate decimal (0) or hexadecimal (1) data entry
  GtkWidget *entry413;  // Option data
  GtkButton *button70;  // Insert IP option after...
  GtkWidget *entry414;  // Option number after which to insert new option
  int tcpopt_tcp6_after;  // Option number after which to insert new option
  GtkButton *button71;  // Append TCP option
  GtkWidget *textview32;  // Number of TCP options in packet
  GtkButton *button72;  // View TCP options
  GtkWidget *entry415;  // Option number to remove
  int tcpopt_tcp6_remove;  // Option number to remove
  GtkButton *button73;  // Remove option

  // Extension headers
  GtkButton *button98;  // Hop-by-hop extension header
  GtkButton *button110;  // Destination extension header
  GtkButton *button132;  // Routing extension header
  GtkButton *button116;  // Authentication extension header
  GtkButton *button126;  // Encapsulating security payload (ESP) extension header

  GtkButton *button6;  // View Packet
  GtkButton *button16;  // Restore default settings

// ICMP page (IPv4)

  // Ethernet header for IPv4 ICMP
  GtkToggleButton *checkbutton17;  // Specify ethernet header
  GtkToggleButton *checkbutton59;  // Pad ethernet frame to meet minimum length, if required
  GtkWidget *entry141;  // Destination link-layer (MAC) address
  GtkWidget *entry142;  // Source link-layer (MAC) address
  GtkWidget *entry151;  // Source interface name
  GtkWidget *spinbutton6;  // Interface maximum transmission unit
  GtkWidget *entry143;  // Ethernet type code;

  // IPv4 header for IPv4 ICMP
  GtkWidget *entry57;  // IP header length
  GtkWidget *entry58;  // Protocol version
  GtkWidget *entry59;  // Type of service
  GtkWidget *entry60;  // Total length of datagram
  GtkWidget *entry61;  // ID sequence number
  GtkWidget *entry123;  // Zero
  GtkWidget *entry65;  // Do not fragment flag
  GtkWidget *entry66;  // More fragments following flag
  GtkWidget *entry67;  // Fragmentation offset
  GtkWidget *entry68;  // Time-to-live
  GtkWidget *entry75;  // Transport layer protocol
  GtkWidget *entry63;  // Source IP address
  GtkToggleButton *checkbutton9;  // Source IP "Randomize"
  int ran_icmp4_sourceip;  // Flag for state of source IPv4 "Randomize" checkbutton
  GtkWidget *entry64;  // Destination IP address
  GtkWidget *entry62;  // IP checksum

  // IPv4 header options for IPv4 ICMP
  GtkToggleButton *radiobutton43;  // Decimal option data entry
  GtkToggleButton *radiobutton44;  // Hexadecimal option data entry
  int dec_hex_ipopt_icmp4;  // Flag to indicate decimal (0) or hexadecimal (1) data entry
  GtkWidget *entry407;  // Option data
  GtkButton *button59;  // Insert IP option after...
  GtkWidget *entry408;  // Option number after after which to insert new option
  int ipopt_icmp4_after;  // Option number after which to insert new option
  GtkButton *button63;  // Append IP option
  GtkWidget *textview26;  // Number of IP options in packet
  GtkButton *button64;  // View IP options
  GtkWidget *entry409;  // Option number to remove
  int ipopt_icmp4_remove;  // Option number to remove
  GtkButton *button65;  // Remove option

  // ICMP header for IPv4 ICMP
  GtkWidget *entry69;  // Message type
  GtkWidget *entry70;  // Message code
  GtkWidget *entry71;  // ICMP checksum
  GtkWidget *entry72;  // Identifier
  GtkWidget *entry73;  // Sequence number
  GtkToggleButton *radiobutton9;  // ASCII data entry
  GtkToggleButton *radiobutton10;  // Hexadecimal data entry
  int ascii_hex_icmp4;  // Flag to indicate ASCII (0) or hexadecimal (1) data entry
  GtkWidget *entry126;  // ICMP payload data from keyboard
  GtkButton *button7;  // ICMP payload data from file

  GtkButton *button2;  // View Packet
  GtkButton *button12;  // Restore default settings

// ICMP page (IPv6)

  // Ethernet header for IPv6 ICMP
  GtkWidget *entry128;  // Destination link-layer (MAC) address
  GtkWidget *entry129;  // Source link-layer (MAC) address
  GtkWidget *entry153;  // Source interface name
  GtkWidget *spinbutton9;  // Interface maximum transmission unit
  GtkWidget *entry130;  // Ethernet type code

  // IPv6 header for IPv6 ICMP
  GtkWidget *entry110;  // IP version
  GtkWidget *entry111;  // Traffic class
  GtkWidget *entry112;  // Flow label
  GtkWidget *entry113;  // Payload length
  GtkWidget *entry114;  // Next header
  GtkWidget *entry115;  // Hop limit
  GtkWidget *entry109;  // Source IP address
  GtkToggleButton *checkbutton10;  // Source IPv6 address "Randomize"
  int ran_icmp6_sourceip;  // Flag for state of source IPv6 "Randomize" checkbutton
  GtkWidget *entry116;  // Destination IP address

  // ICMP header for IPv6 ICMP
  GtkWidget *entry117;  // Message type
  GtkWidget *entry118;  // Message code
  GtkWidget *entry119;  // ICMP checksum
  GtkWidget *entry120;  // Identifier
  GtkWidget *entry121;  // Sequence number
  GtkToggleButton *radiobutton11;  // ASCII data entry
  GtkToggleButton *radiobutton12;  // Hexadecimal data entry
  int ascii_hex_icmp6;  // Flag to indicate ASCII (0) or hexadecimal (1) data entry
  GtkWidget *entry127;  // ICMP payload data from keyboard
  GtkButton *button9;  // ICMP payload data from file

  // Extension headers
  GtkButton *button99;  // Hop-by-hop extension header
  GtkButton *button111;  // Destination extension header
  GtkButton *button133;  // Routing extension header
  GtkButton *button117;  // Authentication extension header
  GtkButton *button127;  // Encapsulating security payload (ESP) extension header

  GtkButton *button17;  // View Packet
  GtkButton *button18;  // Restore default settings

// UDP page (IPv4)

  // Ethernet header for IPv4 UDP
  GtkToggleButton *checkbutton19;  // Specify ethernet header
  GtkToggleButton *checkbutton60;  // Pad ethernet frame to meet minimum length, if required
  GtkWidget *entry147;  // Destination link-layer (MAC) address
  GtkWidget *entry148;  // Source link-layer (MAC) address
  GtkWidget *entry152;  // Source interface name
  GtkWidget *spinbutton7;  // Interface maximum transmission unit
  GtkWidget *entry149;  // Ethernet type code;

  // IPv4 header for IPv4 UDP
  GtkWidget *entry1;  // IP header length
  GtkWidget *entry2;  // Protocol version
  GtkWidget *entry3;  // Type of service
  GtkWidget *entry4;  // Total length of datagram
  GtkWidget *entry5;  // ID sequence number
  GtkWidget *entry124;  // Zero
  GtkWidget *entry9;  // Do not fragment flag
  GtkWidget *entry10;  // More fragments following flag
  GtkWidget *entry11;  // Fragmentation offset
  GtkWidget *entry12;  // Time-to-live
  GtkWidget *entry76;  // Transport layer protocol
  GtkWidget *entry7;  // Source IP address
  GtkToggleButton *checkbutton1;  // Source IP "Randomize"
  int ran_udp4_sourceip;  // Flag for state of source IPv4 "Randomize" checkbutton
  GtkWidget *entry8;  // Destination IP address
  GtkWidget *entry6;  // IP checksum

  // IPv4 header options for IPv4 UDP
  GtkToggleButton *radiobutton45;  // Decimal option data entry
  GtkToggleButton *radiobutton46;  // Hexadecimal option data entry
  int dec_hex_ipopt_udp4;  // Flag to indicate decimal (0) or hexadecimal (1) data entry
  GtkWidget *entry410;  // Option data
  GtkButton *button66;  // Insert IP option after...
  GtkWidget *entry411;  // Option number after which to insert new option
  int ipopt_udp4_after;  // Option number after which to insert new option
  GtkButton *button67;  // Append IP option
  GtkWidget *textview28;  // Number of IP options in packet
  GtkButton *button68;  // View IP options
  GtkWidget *entry412;  // Option number to remove
  int ipopt_udp4_remove;  // Option number to remove
  GtkButton *button69;  // Remove option

  // UDP header for IPv4 UDP
  GtkWidget *entry13;  // Source port
  GtkToggleButton *checkbutton3;  // Source port "Randomize"
  int ran_udp4_sourceport;  // Flag for state of source port "Randomize" checkbutton (IPv4)
  GtkWidget *entry14;  // Destination port
  GtkWidget *entry15;  // Length of UDP datagram
  GtkWidget *entry16;  // UDP checksum
  GtkToggleButton *radiobutton13;  // ASCII data entry
  GtkToggleButton *radiobutton14;  // Hexadecimal data entry
  int ascii_hex_udp4;  // Flag to indicate ASCII (0) or hexadecimal (1) data entry
  GtkWidget *entry17;  // UDP payload data from keyboard
  GtkButton *button8;  // UDP payload data from file

  GtkButton *button4;  // View Packet
  GtkButton *button15;  // Restore default settings

// UDP page (IPv6)

  // Ethernet header for IPv6 UDP
  GtkWidget *entry134;  // Destination link-layer (MAC) address
  GtkWidget *entry135;  // Source link-layer (MAC) address
  GtkWidget *entry155;  // Source interface name
  GtkWidget *spinbutton10;  // Interface maximum transmission unit
  GtkWidget *entry136;  // Ethernet type code;

  // IPv6 header for IPv6 UDP
  GtkWidget *entry97;  // IP version
  GtkWidget *entry98;  // Traffic class
  GtkWidget *entry99;  // Flow label
  GtkWidget *entry100;  // Payload length
  GtkWidget *entry101;  // Next header
  GtkWidget *entry102;  // Hop limit
  GtkWidget *entry96;  // Source IP address
  GtkToggleButton *checkbutton6;  // Source IPv6 address "Randomize"
  int ran_udp6_sourceip;  // Flag for state of source IPv6 "Randomize" checkbutton
  GtkWidget *entry103;  // Destination IP address

  // UDP header for IPv6 UDP
  GtkWidget *entry104;  // Source port
  GtkToggleButton *checkbutton8;  // Source port "Randomize"
  int ran_udp6_sourceport;  // Flag for state of source port "Randomize" checkbutton (IPv6)
  GtkWidget *entry105;  // Destination port
  GtkWidget *entry106;  // Length of UDP datagram
  GtkWidget *entry107;  // UDP checksum
  GtkToggleButton *radiobutton15;  // ASCII data entry
  GtkToggleButton *radiobutton16;  // Hexadecimal data entry
  int ascii_hex_udp6;  // Flag to indicate ASCII (0) or hexadecimal (1) data entry
  GtkWidget *entry108;  // UDP payload data from keyboard
  GtkButton *button10;  // UDP payload data from file

  // Extension headers
  GtkButton *button100;  // Hop-by-hop extension header
  GtkButton *button112;  // Destination extension header
  GtkButton *button134;  // Routing extension header
  GtkButton *button118;  // Authentication extension header
  GtkButton *button128;  // Encapsulating security payload (ESP) extension header

  GtkButton *button13;  // View Packet
  GtkButton *button19;  // Restore default settings

// Host/IP page
  GtkWidget *entry19;  // Host-to-IP: hostname
  GtkWidget *textview3;  // Host-to-IPv4 results
  GtkWidget *textview6;  // Host-to-IPv6 results

  GtkWidget *entry20;  // IP-to-Host IPv4 address
  GtkWidget *entry21;  // IP-to-Host IPv6 address
  GtkWidget *textview2;  // IP-to-Host hostname result

  GtkWidget *textview4;  // This Host hostname
  GtkWidget *textview23;  // This Host interface names and IPv4 addresses
  GtkWidget *textview5;  // This Host interface names and IPv6 addresses

  GtkWidget *entry139;  // This host interface name
  GtkWidget *textview10;  // This host interface MAC address
  GtkWidget *textview21;  // This host interface current MTU

  GtkWidget *entry140;  // IP-to-MAC source interface name
  GtkWidget *spinbutton1;  // Timeout for ARP/Neighbor discovery
  int timeout;  // Timeout value (s) for ARP/Neighbor discovery
  GtkWidget *entry137;  // IP-to-MAC IPv4 address
  GtkWidget *entry138;  // IP-to-MAC IPv6 address
  GtkWidget *textview11;  // IP-to-MAC results

// Load/Save page

  // Load file
  GtkButton *button21;  // Load file ...

  // Save

  uint8_t *save_flags;  // Flags to indicate which items to save to SPS file
  int save_nitems;  // Number of possible items to save

  // Send Packet settings
  GtkToggleButton *checkbutton25;  // Packet type, Number of packets to send, Flood mode

  // IPv6 over IPv4 (6to4)
  GtkToggleButton *checkbutton15;  // IPv4 Ethernet header and IPv4 header

  // IPv4
  GtkToggleButton *checkbutton16;  // TCP packet (ethernet header, IP header, and TCP header)
  GtkToggleButton *checkbutton20;  // ICMP packet (ethernet header, IP header, ICMP header, and ICMP data)
  GtkToggleButton *checkbutton21;  // UDP packet (ethernet header, IP header, UDP header, and UDP data)

  // IPv6
  GtkToggleButton *checkbutton22;  // TCP packet (ethernet header, IP header, and TCP header)
  GtkToggleButton *checkbutton23;  // ICMP packet (ethernet header, IP header, ICMP header, and ICMP data)
  GtkToggleButton *checkbutton24;  // UDP packet (ethernet header, IP header, UDP header, and UDP data)

  // Traceroute settings
  GtkToggleButton *checkbutton36;  // Traceroute settings

  // IPv6 over IPv4 (6to4) for traceroute
  GtkToggleButton *checkbutton46;  // IPv4 Ethernet header and IPv4 header for traceroute

  // IPv4 traceroute
  GtkToggleButton *checkbutton39;  // TCP packet for traceroute
  GtkToggleButton *checkbutton41;  // ICMP packet for traceroute
  GtkToggleButton *checkbutton42;  // UDP packet for traceroute

  // IPv6 Traceroute
  GtkToggleButton *checkbutton43;  // TCP packet for traceroute
  GtkToggleButton *checkbutton44;  // ICMP packet for traceroute
  GtkToggleButton *checkbutton45;  // UDP packet for traceroute

  // Save file
  GtkButton *button14;  // Save SPS file, which contains settings selected by user

// Traceroute page (sps.ui)

  GtkWidget *traceroute_window;  // Traceroute edit packet window
  int traceroute_flag;  // Flag indicating traceroute packet-editing window is activated

  // Probe Protocol
  GtkToggleButton *radiobutton21;  // TCP (IPv4) probe packet
  GtkToggleButton *radiobutton22;  // ICMP (IPv4) probe packet
  GtkToggleButton *radiobutton23;  // UDP (IPv4) probe packet
  GtkToggleButton *radiobutton26;  // TCP (IPv6) probe packet
  GtkToggleButton *radiobutton27;  // ICMP (IPv6) probe packet
  GtkToggleButton *radiobutton28;  // UDP (IPv6) probe packet
  GtkToggleButton *checkbutton29;  // Tunnel IPv6 over IPv4
  int packet_type_tr;  // Packet type
  int sixto4_tr_flag;  // Flag for state of Tunnel IPv6 over IPv4 checkbutton

  // Number of Probes per Hop
  GtkWidget *spinbutton2;  // Number of probes per hop
  int num_probes;  // Number of probes per hop

  // Timeout for Reply
  GtkWidget *spinbutton4;  // Timeout for reply
  int timeout_tr;  // Timeout for reply

  // Maximum number of hops
  GtkWidget *spinbutton3;  // Maximum number of hops
  int maxhops;  // Maximum number of hops

  // Resolve Node Hostnames
  GtkToggleButton *checkbutton34;
  int resolve_tr;

  // Edit, Start, Stop buttons
  GtkButton *button23;  // Edit packets
  GtkButton *button24;  // Start
  GtkButton *button25;  // Stop

  // Activity Log
  GtkWidget *textview7;  // Traceroute activity log
  char *tr_message;  // String to contain traceroute results

// Traceroute IPv6 over IPv4 (6to4) (traceroute.ui)

  GtkWidget *spinbutton18;  // Interface maximum transmission unit
  GtkToggleButton *checkbutton61;  // Pad ethernet frame to meet minimum length, if required
  GtkToggleButton *checkbutton48;  // Use ethernet header specified on TCP (IPv6) page
  GtkWidget *entry316;  // TCP source IPv4 address for 6to4 packets
  GtkToggleButton *checkbutton49;  // Use ethernet header specified on ICMP (IPv6) page
  GtkWidget *entry317;  // ICMP source IPv4 address for 6to4 packets
  GtkToggleButton *checkbutton50;  // Use ethernet header specified on UDP (IPv6) page
  GtkWidget *entry318;  // UDP source IPv4 address for 6to4 packets

// Traceroute TCP page (IPv4) (traceroute.ui)

  // Ethernet header for IPv4 TCP for traceroute
  GtkToggleButton *checkbutton28;  // Specify ethernet header
  GtkToggleButton *checkbutton62;  // Pad ethernet frame to meet minimum length, if required
  GtkWidget *entry164;  // Destination link-layer (MAC) address
  GtkWidget *entry165;  // Source link-layer (MAC) address
  GtkWidget *entry166;  // Source interface name
  GtkWidget *spinbutton11;  // Interface maximum transmission unit
  GtkWidget *entry167;  // Ethernet type code;

  // IPv4 header for IPv4 TCP for traceroute
  GtkWidget *entry168;  // IP header length
  GtkWidget *entry169;  // Protocol version
  GtkWidget *entry170;  // Type of service
  GtkWidget *entry171;  // Total length of datagram
  GtkWidget *entry172;  // ID sequence number
  GtkWidget *entry173;  // Zero
  GtkWidget *entry174;  // Do not fragment flag
  GtkWidget *entry175;  // More fragments following flag
  GtkWidget *entry176;  // Fragmentation offset
  GtkWidget *entry177;  // Time-to-live
  GtkWidget *entry178;  // Transport layer protocol
  GtkWidget *entry179;  // Source IP address
  GtkWidget *entry180;  // Destination IP address
  GtkWidget *entry181;  // IP checksum

  // IPv4 header options for IPv4 TCP traceroute
  GtkToggleButton *radiobutton49;  // Decimal option data entry
  GtkToggleButton *radiobutton50;  // Hexadecimal option data entry
  int dec_hex_ipopt_tcp4_tr;  // Flag to indicate decimal (0) or hexadecimal (1) data entry
  GtkWidget *entry416;  // Option data
  GtkButton *button74;  // Insert IP option after...
  GtkWidget *entry417;  // Option number after which to insert new option
  int ipopt_tcp4_tr_after;  // Option number after which to insert new option
  GtkButton *button75;  // Append IP option
  GtkWidget *textview34;  // Number of IP options in packet
  GtkButton *button76;  // View IP options
  GtkWidget *entry418;  // Option number to remove
  int ipopt_tcp4_tr_remove;  // Option number to remove
  GtkButton *button77;  // Remove option

  // TCP header for IPv4 TCP for traceroute
  GtkWidget *entry182;  // Source port number
  GtkToggleButton *checkbutton30;  // Source port "Randomize"
  int ran_tcp4_tr_sourceport;  // Flag for state of source port "Randomize" checkbutton (IPv4)
  GtkWidget *entry183;  // Destination port number
  GtkWidget *entry184;  // Sequence number
  GtkWidget *entry185;  // Ack number
  GtkWidget *entry186;  // Reserved
  GtkWidget *entry187;  // Data offset
  GtkWidget *entry188;  // FIN flag
  GtkWidget *entry189;  // SYN flag
  GtkWidget *entry190;  // RST flag
  GtkWidget *entry191;  // PSH flag
  GtkWidget *entry192;  // ACK flag
  GtkWidget *entry193;  // URG flag
  GtkWidget *entry194;  // ECE flag
  GtkWidget *entry195;  // CWR flag
  GtkWidget *entry196;  // Window size
  GtkWidget *entry197;  // TCP checksum
  GtkWidget *entry198;  // Urgent pointer
  GtkToggleButton *radiobutton29;  // ASCII data entry
  GtkToggleButton *radiobutton30;  // Hexadecimal data entry
  int ascii_hex_tcp4_tr;  // Flag to indicate ASCII (0) or hexadecimal (1) data entry
  GtkWidget *entry199;  // TCP payload data from keyboard
  GtkButton *button29;  // TCP payload data from file

  // TCP options for IPv4 TCP for traceroute
  GtkToggleButton *radiobutton51;  // Decimal option data entry
  GtkToggleButton *radiobutton52;  // Hexadecimal option data entry
  int dec_hex_tcpopt_tcp4_tr;  // Flag to indicate decimal (0) or hexadecimal (1) data entry
  GtkWidget *entry419;  // Option data
  GtkButton *button78;  // Insert IP option after...
  GtkWidget *entry420;  // Option number after which to insert new option
  int tcpopt_tcp4_tr_after;  // Option number after which to insert new option
  GtkButton *button79;  // Append TCP option
  GtkWidget *textview36;  // Number of TCP options in packet
  GtkButton *button80;  // View TCP options
  GtkWidget *entry421;  // Option number to remove
  int tcpopt_tcp4_tr_remove;  // Option number to remove
  GtkButton *button81;  // Remove option

  GtkButton *button28;  // View Packet
  GtkButton *button30;  // Restore default settings

// Traceroute TCP page (IPv6) (traceroute.ui)

  // Ethernet header for IPv6 TCP for traceroute
  GtkWidget *entry247;  // Destination link-layer (MAC) address
  GtkWidget *entry248;  // Source link-layer (MAC) address
  GtkWidget *entry249;  // Source interface name
  GtkWidget *spinbutton14;  // Interface maximum transmission unit
  GtkWidget *entry250;  // Ethernet type code;

  // IPv6 header for IPv6 TCP for traceroute
  GtkWidget *entry251;  // IP version
  GtkWidget *entry252;  // Traffic class
  GtkWidget *entry253;  // Flow label
  GtkWidget *entry254;  // Payload length
  GtkWidget *entry255;  // Next header
  GtkWidget *entry256;  // Hop limit
  GtkWidget *entry257;  // Source IP address
  GtkWidget *entry258;  // Destination IP address

  // TCP header for IPv6 TCP for traceroute
  GtkWidget *entry259;  // Source port number
  GtkToggleButton *checkbutton37;  // Source port "Randomize"
  int ran_tcp6_tr_sourceport;  // Flag for state of source port "Randomize" checkbutton (IPv6)
  GtkWidget *entry260;  // Destination port number
  GtkWidget *entry261;  // Sequence number
  GtkWidget *entry262;  // Ack number
  GtkWidget *entry263;  // Reserved
  GtkWidget *entry264;  // Data offset
  GtkWidget *entry265;  // FIN flag
  GtkWidget *entry266;  // SYN flag
  GtkWidget *entry267;  // RST flag
  GtkWidget *entry268;  // PSH flag
  GtkWidget *entry269;  // ACK flag
  GtkWidget *entry270;  // URG flag
  GtkWidget *entry271;  // ECE flag
  GtkWidget *entry272;  // CWR flag
  GtkWidget *entry273;  // Window size
  GtkWidget *entry274;  // TCP checksum
  GtkWidget *entry275;  // Urgent pointer
  GtkToggleButton *radiobutton35;  // ASCII data entry
  GtkToggleButton *radiobutton36;  // Hexadecimal data entry
  int ascii_hex_tcp6_tr;  // Flag to indicate ASCII (0) or hexadecimal (1) data entry
  GtkWidget *entry276;  // TCP payload data from keyboard
  GtkButton *button38;  // TCP payload data from file

  // TCP options for IPv6 TCP for traceroute
  GtkToggleButton *radiobutton53;  // Decimal option data entry
  GtkToggleButton *radiobutton54;  // Hexadecimal option data entry
  int dec_hex_tcpopt_tcp6_tr;  // Flag to indicate decimal (0) or hexadecimal (1) data entry
  GtkWidget *entry422;  // Option data
  GtkButton *button82;  // Insert IP option after...
  GtkWidget *entry423;  // Option number after which to insert new option
  int tcpopt_tcp6_tr_after;  // Option number after which to insert new option
  GtkButton *button83;  // Append TCP option
  GtkWidget *textview38;  // Number of TCP options in packet
  GtkButton *button84;  // View TCP options
  GtkWidget *entry424;  // Option number to remove
  int tcpopt_tcp6_tr_remove;  // Option number to remove
  GtkButton *button85;  // Remove option

  // Extension headers
  GtkButton *button101;  // Hop-by-hop extension header
  GtkButton *button113;  // Destination extension header
  GtkButton *button135;  // Routing extension header
  GtkButton *button119;  // Authentication extension header
  GtkButton *button129;  // Encapsulating security payload (ESP) extension header

  GtkButton *button37;  // View Packet
  GtkButton *button39;  // Restore default settings

// Traceroute ICMP page (IPv4) (traceroute.ui)

  // Ethernet header for IPv4 ICMP for traceroute
  GtkToggleButton *checkbutton31;  // Specify ethernet header
  GtkToggleButton *checkbutton63;  // Pad ethernet frame to meet minimum length, if required
  GtkWidget *entry200;  // Destination link-layer (MAC) address
  GtkWidget *entry201;  // Source link-layer (MAC) address
  GtkWidget *entry202;  // Source interface name
  GtkWidget *spinbutton12;  // Interface maximum transmission unit
  GtkWidget *entry203;  // Ethernet type code;

  // IPv4 header for IPv4 ICMP for traceroute
  GtkWidget *entry204;  // IP header length
  GtkWidget *entry205;  // Protocol version
  GtkWidget *entry206;  // Type of service
  GtkWidget *entry207;  // Total length of datagram
  GtkWidget *entry208;  // ID sequence number
  GtkWidget *entry209;  // Zero
  GtkWidget *entry210;  // Do not fragment flag
  GtkWidget *entry211;  // More fragments following flag
  GtkWidget *entry212;  // Fragmentation offset
  GtkWidget *entry213;  // Time-to-live
  GtkWidget *entry214;  // Transport layer protocol
  GtkWidget *entry215;  // Source IP address
  GtkWidget *entry216;  // Destination IP address
  GtkWidget *entry217;  // IP checksum

  // IPv4 header options for IPv4 ICMP for traceroute
  GtkToggleButton *radiobutton55;  // Decimal option data entry
  GtkToggleButton *radiobutton56;  // Hexadecimal option data entry
  int dec_hex_ipopt_icmp4_tr;  // Flag to indicate decimal (0) or hexadecimal (1) data entry
  GtkWidget *entry425;  // Option data
  GtkButton *button86;  // Insert IP option after...
  GtkWidget *entry426;  // Option number after which to insert new option
  int ipopt_icmp4_tr_after;  // Option number after which to insert new option
  GtkButton *button87;  // Append IP option
  GtkWidget *textview40;  // Number of IP options in packet
  GtkButton *button88;  // View IP options
  GtkWidget *entry427;  // Option number to remove
  int ipopt_icmp4_tr_remove;  // Option number to remove
  GtkButton *button89;  // Remove option

  // ICMP header for IPv4 ICMP for traceroute
  GtkWidget *entry218;  // Message type
  GtkWidget *entry219;  // Message code
  GtkWidget *entry220;  // ICMP checksum
  GtkWidget *entry221;  // Identifier
  GtkWidget *entry222;  // Sequence number
  GtkToggleButton *radiobutton31;  // ASCII data entry
  GtkToggleButton *radiobutton32;  // Hexadecimal data entry
  int ascii_hex_icmp4_tr;  // Flag to indicate ASCII (0) or hexadecimal (1) data entry
  GtkWidget *entry223;  // ICMP payload data from keyboard
  GtkButton *button32;  // ICMP payload data from file

  GtkButton *button31;  // View Packet
  GtkButton *button33;  // Restore default settings

// Traceroute ICMP page (IPv6) (traceroute.ui)

  // Ethernet header for IPv6 ICMP for traceroute
  GtkWidget *entry277;  // Destination link-layer (MAC) address
  GtkWidget *entry278;  // Source link-layer (MAC) address
  GtkWidget *entry279;  // Source interface name
  GtkWidget *spinbutton15;  // Interface maximum transmission unit
  GtkWidget *entry280;  // Ethernet type code;

  // IPv6 header for IPv6 ICMP for traceroute
  GtkWidget *entry281;  // IP version
  GtkWidget *entry282;  // Traffic class
  GtkWidget *entry283;  // Flow label
  GtkWidget *entry284;  // Payload length
  GtkWidget *entry285;  // Next header
  GtkWidget *entry286;  // Hop limit
  GtkWidget *entry287;  // Source IP address
  GtkWidget *entry288;  // Destination IP address

  // ICMP header for IPv6 ICMP for traceroute
  GtkWidget *entry289;  // Message type
  GtkWidget *entry290;  // Message code
  GtkWidget *entry291;  // ICMP checksum
  GtkWidget *entry292;  // Identifier
  GtkWidget *entry293;  // Sequence number
  GtkToggleButton *radiobutton37;  // ASCII data entry
  GtkToggleButton *radiobutton38;  // Hexadecimal data entry
  int ascii_hex_icmp6_tr;  // Flag to indicate ASCII (0) or hexadecimal (1) data entry
  GtkWidget *entry294;  // ICMP payload data from keyboard
  GtkButton *button41;  // ICMP payload data from file

  // Extension headers
  GtkButton *button102;  // Hop-by-hop extension header
  GtkButton *button114;  // Destination extension header
  GtkButton *button136;  // Routing extension header
  GtkButton *button120;  // Authentication extension header
  GtkButton *button130;  // Encapsulating security payload (ESP) extension header

  GtkButton *button40;  // View Packet
  GtkButton *button42;  // Restore default settings

// Traceroute UDP page (IPv4) (traceroute.ui)

  // Ethernet header for IPv4 UDP for traceroute
  GtkToggleButton *checkbutton33;  // Specify ethernet header
  GtkToggleButton *checkbutton64;  // Pad ethernet frame to meet minimum length, if required
  GtkWidget *entry224;  // Destination link-layer (MAC) address
  GtkWidget *entry225;  // Source link-layer (MAC) address
  GtkWidget *entry226;  // Source interface name
  GtkWidget *spinbutton13;  // Interface maximum transmission unit
  GtkWidget *entry227;  // Ethernet type code;

  // IPv4 header for IPv4 UDP for traceroute
  GtkWidget *entry228;  // IP header length
  GtkWidget *entry229;  // Protocol version
  GtkWidget *entry230;  // Type of service
  GtkWidget *entry231;  // Total length of datagram
  GtkWidget *entry232;  // ID sequence number
  GtkWidget *entry233;  // Zero
  GtkWidget *entry234;  // Do not fragment flag
  GtkWidget *entry235;  // More fragments following flag
  GtkWidget *entry236;  // Fragmentation offset
  GtkWidget *entry237;  // Time-to-live
  GtkWidget *entry238;  // Transport layer protocol
  GtkWidget *entry239;  // Source IP address
  GtkWidget *entry240;  // Destination IP address
  GtkWidget *entry241;  // IP checksum

  // IPv4 header options for IPv4 UDP for traceroute
  GtkToggleButton *radiobutton57;  // Decimal option data entry
  GtkToggleButton *radiobutton58;  // Hexadecimal option data entry
  int dec_hex_ipopt_udp4_tr;  // Flag to indicate decimal (0) or hexadecimal (1) data entry
  GtkWidget *entry428;  // Option data
  GtkButton *button90;  // Insert IP option after...
  GtkWidget *entry429;  // Option number after which to insert new option
  int ipopt_udp4_tr_after;  // Option number after which to insert new option
  GtkButton *button91;  // Append IP option
  GtkWidget *textview42;  // Number of IP options in packet
  GtkButton *button92;  // View IP options
  GtkWidget *entry430;  // Option number to remove
  int ipopt_udp4_tr_remove;  // Option number to remove
  GtkButton *button93;  // Remove option

  // UDP header for IPv4 UDP for traceroute
  GtkWidget *entry242;  // Source port
  GtkToggleButton *checkbutton35;  // Source port "Randomize"
  int ran_udp4_tr_sourceport;  // Flag for state of source port "Randomize" checkbutton (IPv4)
  GtkWidget *entry243;  // Destination port
  GtkWidget *entry244;  // Length of UDP datagram
  GtkWidget *entry245;  // UDP checksum
  GtkToggleButton *radiobutton33;  // ASCII data entry
  GtkToggleButton *radiobutton34;  // Hexadecimal data entry
  int ascii_hex_udp4_tr;  // Flag to indicate ASCII (0) or hexadecimal (1) data entry
  GtkWidget *entry246;  // UDP payload data from keyboard
  GtkButton *button35;  // UDP payload data from file

  GtkButton *button34;  // View Packet
  GtkButton *button36;  // Restore default settings

// Traceroute UDP page (IPv6) (traceroute.ui)

  // Ethernet header for IPv6 UDP for traceroute
  GtkWidget *entry295;  // Destination link-layer (MAC) address
  GtkWidget *entry296;  // Source link-layer (MAC) address
  GtkWidget *entry297;  // Source interface name
  GtkWidget *spinbutton16;  // Interface maximum transmission unit
  GtkWidget *entry298;  // Ethernet type code;

  // IPv6 header for IPv6 UDP for traceroute
  GtkWidget *entry299;  // IP version
  GtkWidget *entry300;  // Traffic class
  GtkWidget *entry301;  // Flow label
  GtkWidget *entry302;  // Payload length
  GtkWidget *entry303;  // Next header
  GtkWidget *entry304;  // Hop limit
  GtkWidget *entry305;  // Source IP address
  GtkWidget *entry306;  // Destination IP address

  // UDP header for IPv6 UDP for traceroute
  GtkWidget *entry307;  // Source port
  GtkToggleButton *checkbutton40;  // Source port "Randomize"
  int ran_udp6_tr_sourceport;  // Flag for state of source port "Randomize" checkbutton (IPv6)
  GtkWidget *entry308;  // Destination port
  GtkWidget *entry309;  // Length of UDP datagram
  GtkWidget *entry310;  // UDP checksum
  GtkToggleButton *radiobutton39;  // ASCII data entry
  GtkToggleButton *radiobutton40;  // Hexadecimal data entry
  int ascii_hex_udp6_tr;  // Flag to indicate ASCII (0) or hexadecimal (1) data entry
  GtkWidget *entry311;  // UDP payload data from keyboard
  GtkButton *button44;  // UDP payload data from file

  // Extension headers
  GtkButton *button103;  // Hop-by-hop extension header
  GtkButton *button115;  // Destination extension header
  GtkButton *button137;  // Routing extension header
  GtkButton *button121;  // Authentication extension header
  GtkButton *button131;  // Encapsulating security payload (ESP) extension header

  GtkButton *button43;  // View Packet
  GtkButton *button45;  // Restore default settings

// IP / ASN delegation page
  int *rir_file_loaded;  // Flags indicating which RIR files are loaded.
  GtkWidget *textview8;  // Status of ARIN delegation file.
  GtkButton *button50;  // Download ARIN delegation file.
  GtkWidget *textview9;  // Status of RIPE delegation file.
  GtkButton *button51;  // Download RIPE delegation file.
  GtkWidget *textview12;  // Status of AFRINIC delegation file.
  GtkButton *button52;  // Download AFRINIC delegation file.
  GtkWidget *textview13;  // Status of APNIC delegation file.
  GtkButton *button53;  // Download APNIC delegation file.
  GtkWidget *textview14;  // Status of LACNIC delegation file.
  GtkButton *button54;  // Download LACNIC delegation file.
  GtkWidget *textview15;  // Status of ISO 3166-1 country code file.
  GtkButton *button55;  // Download ISO 3166-1 country code file.
  GtkButton *button56;  // View ISO 3166-1 country code file.
  GtkButton *button57;  // Download all RIR files and country code file.
  GtkToggleButton *checkbutton38;  // Flag to show sent and received messages during file downloads
  int countries_loaded;  // Flag indicating if country code file is loaded.
  int ftp_family;  // Address family for FTP connection to RIRs.
  int sd_data;  // Socket descriptor for FTP data connection.
  char *ftp_data;  // Array to hold FTP data received from remote host.
  int rir_index;  // Index to strings containing RIR names, URLs, directories, and file names.

  int *nrecords;  // Number of records in each RIR's delegation file: nrecords[rir] = int
  int ncountries;  // Number of countries in www.iso.org's country code list.
  uint8_t ****array;  // Array containing all RIR delegation files: array[rir][record][field] = uint8_t *
  uint8_t ***cc;  // Array containing www.iso.org's country code list: cc[record][field] = char *
  GtkWidget *entry500;  // Country name for country name/code search.
  GtkWidget *entry501;  // Country code for country name/code search.
  GtkWidget *entry502;  // Country name for ASN search.
  GtkWidget *entry503;  // Country code for ASN search.
  GtkWidget *textview16;  // ASN delegation results for ASN delegation search.
  char *asn_results;  // ASN delegation results for ASN delegation search.
  GtkWidget *entry504;  // ASN for reverse-search for delegation of ASN.
  uint64_t asn;  // ASN for reverse-search for delegation of ASN.
  GtkWidget *textview17;  // Results of reverse-search for delegation of ASN.
  GtkWidget *entry505;  // Country name for IP delegation search.
  char *cname;  // Country name for IP delegation search.
  GtkWidget *entry506;  // Country code for IP delegation search.
  char *ccode;  // Country code for IP delegation search.
  GtkWidget *textview18;  // IPv4 address delegation results for IP delegation search.
  char *ip4_results;  // IPv4 address delegation results for IP delegation search.
  GtkWidget *textview19;  // IPv6 address delegation results for IP delegation search.
  char *ip6_results;  // IPv6 address delegation results for IP delegation search.
  GtkWidget *entry507;  // IPv4 address for IP delegation reverse-search.
  char *ip4string;  // IPv4 address for IP delegation reverse_search.
  GtkWidget *entry508;  // IPv6 address for IP delegation reverse-search.
  char *ip6string;  // IPv6 address for IP delegation reverse_search.
  GtkWidget *textview20;  // IPv4 or IPv6  address delegation results for IP delegation reverse-search.

// IPv6 extension headers

  // Extension header to be edited
  int exthdr_type;  // Type of packet containing extension header to be edited

  // Hop-by-hop extension header page
  GtkWidget *hop_window;  // Hop-by-hop extension header editing window
  int hop_flag;  // Flag indicating hop-by-hop header editing window is activated

  GtkButton *button142;  // Toggle: attach / detach a hop-by-hop header
  GtkWidget *textview47;  // Status: attached / detached
  GtkWidget *entry438;  // Hop-by-hop header length
  GtkToggleButton *radiobutton59;  // Decimal data entry
  GtkToggleButton *radiobutton60;  // Hexadecimal data entry
  int dec_hex_hbhopt;  // Flag to indicate decimal (0) or hexadecimal (1) data entry
  GtkWidget *entry158;  // Hop-by-hop option data
  GtkWidget *entry313;  // Option alignment parameter x (of xN + y)
  GtkWidget *entry314;  // Option alignment parameter y (of xN + y)
  GtkButton *button94;  // Insert Option After...
  GtkWidget *entry159;  // Option # to insert after
  int hbhopt_after;  // Option number after which to insert new option
  GtkButton *button95;  // Append option
  GtkWidget *textview22;  // Number of options in hop-by-hop header
  GtkButton *button96;  // View hop-by-hop options
  GtkWidget *entry312;  // Option number to remove
  int hbhopt_remove;  // Option number to remove
  GtkButton *button97;  // Remove option

  // Destination extension header page
  GtkWidget *dst_window;  // Destination extension header editing window
  int dst_flag;  // Flag indicating destination header editing window is activated

  GtkButton *button143;  // Toggle: attach / detach a "first" destination header
  GtkWidget *textview48;  // Status: attached / detached
  GtkButton *button144;  // Toggle: attach / detach a "last" destination header
  GtkWidget *textview49;  // Status: attached / detached
  GtkWidget *entry439;  // Destination header length (first)
  GtkWidget *entry440;  // Destination header length (last)
  GtkToggleButton *radiobutton61;  // Decimal data entry
  GtkToggleButton *radiobutton62;  // Hexadecimal data entry
  int dec_hex_dstopt;  // Flag to indicate decimal (0) or hexadecimal (1) data entry
  GtkWidget *entry315;  // Destination option data
  int *dst_optlenbuf;  // Destination header (last) option length buffer: dstl_optlenbuf[type] = int
  uint8_t **dst_optionsbuf;  // Destination header (last) options data buffer: dstl_optionsbuf[type] = uint8_t *
  GtkWidget *entry156;  // Option alignment parameter x (of xN + y)
  GtkWidget *entry157;  // Option alignment parameter y (of xN + y)
  GtkToggleButton *radiobutton63;  // Designate as first destination header
  GtkToggleButton *radiobutton64;  // Designate as last destination header
  int dst_fl_flag;  // Flag indicating first or last destination header. 0 = first, 1 = last
  GtkButton *button104;  // Insert Option After...
  GtkWidget *entry431;  // Option # to insert after
  int dstopt_after;  // Option number after which to insert new option
  GtkButton *button105;  // Append option
  GtkWidget *textview25;  // Number of options in first destination header
  GtkWidget *textview27;  // Number of options in last destination header
  GtkButton *button106;  // View destination options (first)
  GtkButton *button109;  // View destination options (last)
  GtkWidget *entry432;  // Option number to remove
  int dstopt_remove;  // Option number to remove
  GtkButton *button107;  // Remove option

  // Routing extension header page
  GtkWidget *route_window;  // Routing extension header editing window
  int route_flag;  // Flag indicating routing header editing window is activated

  GtkButton *button145;  // Toggle: attach / detach a routing header
  GtkWidget *textview50;  // Status: attached / detached
  GtkWidget *entry446;  // Header length
  GtkWidget *entry447;  // Routing type
  GtkWidget *entry448;  // Segments left
  GtkToggleButton *radiobutton73;  // Decimal routing data entry
  GtkToggleButton *radiobutton74;  // Hexadecimal routing data entry
  int dec_hex_route;  // Flag to indicate decimal (0) or hexadecimal (1) routing data entry
  GtkWidget *entry449;  // Routing data
  GtkButton *button125;  // Load routing data from file ...

  // Authentication extension header page
  GtkWidget *auth_window;  // Authentication extension header editing window
  int auth_flag;  // Flag indicating authentication header editing window is activated

  GtkButton *button138;  // Toggle: attach / detach an authentication header
  GtkWidget *textview43;  // Status: attached / detached
  GtkButton *button139;  // Toggle: transport / tunnel mode
  GtkWidget *textview44;  // Status: transport / tunnel mode
  GtkWidget *entry433;  // Payload length
  GtkWidget *entry434;  // Reserved
  GtkWidget *entry435;  // Security parameters index (SPI)
  GtkWidget *entry436;  // Sequence number
  GtkToggleButton *radiobutton67;  // Decimal integrity check value (ICV) entry
  GtkToggleButton *radiobutton68;  // Hexadecimal integrity check value (ICV) entry
  int dec_hex_auth;  // Flag to indicate decimal (0) or hexadecimal (1) ICV entry
  GtkWidget *entry437;  // Integrity check value (ICV)
  GtkButton *button108;  // Load ICV from file ...
  GtkButton *button122;  // Save data for ICV calculation

  // Encapsulating security payload (ESP) extension header page
  GtkWidget *esp_window;  // ESP extension header editing window
  int esp_flag;  // Flag indicating ESP header editing window is activated

  GtkButton *button140;  // Toggle: attach / detach an ESP header
  GtkWidget *textview45;  // Status: attached / detached
  GtkButton *button141;  // Toggle: transport / tunnel mode
  GtkWidget *textview46;  // Status: transport / tunnel mode
  GtkWidget *entry441;  // Security parameters index (SPI)
  GtkWidget *entry442;  // Sequence number
  GtkButton *button123;  // Save payload data for ICV calculation
  GtkWidget *entry443;  // Padding length
  GtkWidget *entry444;  // Next header
  GtkToggleButton *radiobutton71;  // Decimal integrity check value (ICV) entry
  GtkToggleButton *radiobutton72;  // Hexadecimal integrity check value (ICV) entry
  int dec_hex_esp;  // Flag to indicate decimal (0) or hexadecimal (1) ICV entry
  GtkWidget *entry445;  // Integrity check value (ICV)
  GtkButton *button124;  // Load ICV from file ...

// Pseudo-random number generator page
  GtkWidget *entry319;  // Seed for PRNG
  GtkWidget *entry320;  // Stride for PRNG

};

// ********** CALLBACK FUNCTION PROTOTYPES **********
//                   callbacks.c

// Menubar
int on_about_requested (void);
int on_documentation_activate (SPSData *);

// Send page 

// Select Packet Type
int on_radiobutton1_toggled (GtkButton *, SPSData *);  // TCP (IPv4) packet type
int on_radiobutton2_toggled (GtkButton *, SPSData *);  // ICMP (IPv4) packet type
int on_radiobutton3_toggled (GtkButton *, SPSData *);  // UDP (IPv4) packet type
int on_radiobutton4_toggled (GtkButton *, SPSData *);  // All (IPv4) packet types (cycle)
int on_radiobutton5_toggled (GtkButton *, SPSData *);  // TCP (IPv6) packet type
int on_radiobutton6_toggled (GtkButton *, SPSData *);  // ICMP (IPv6) packet type
int on_radiobutton7_toggled (GtkButton *, SPSData *);  // UDP (IPv6) packet type
int on_radiobutton8_toggled (GtkButton *, SPSData *);  // All (IPv6) packet types (cycle)
// Number of Packets to Send
int on_entry18_activate (GtkWidget *, SPSData *);  // Number of packets to send
int on_checkbutton11_toggled (GtkButton *, SPSData *);  // Flood mode
// IPv6 over IPv4 (6to4)
int on_checkbutton12_toggled (GtkButton *, SPSData *);  // Tunnel IPv6 over IPv4
int on_spinbutton17_value_changed (GtkWidget *, SPSData *);  // Interface maximum transmission unit (MTU)
int on_checkbutton57_toggled (GtkButton *, SPSData *);  // Pad ethernet frame to meet minimum length, if required
int on_checkbutton14_toggled (GtkButton *, SPSData *);  // TCP - Specify ethernet header
int on_entry125_activate (GtkWidget *, SPSData *);  // TCP IPv4 Source Address for 6to4 tunnel
int on_checkbutton47_toggled (GtkButton *, SPSData *);  // ICMP - Specify ethernet header
int on_entry160_activate (GtkWidget *, SPSData *);  // ICMP IPv4 Source Address for 6to4 tunnel
int on_checkbutton32_toggled (GtkButton *, SPSData *);  // UDP - Specify ethernet header
int on_entry161_activate (GtkWidget *, SPSData *);  // UDP IPv4 Source Address for 6to4 tunnel
int on_checkbutton13_toggled (GtkButton *, SPSData *);  // Randomize TCP source IPv4 address for 6to4
int on_checkbutton26_toggled (GtkButton *, SPSData *);  // Randomize ICMP source IPv4 address for 6to4
int on_checkbutton27_toggled (GtkButton *, SPSData *);  // Randomize UDP source IPv4 address for 6to4
// Send / Stop
int on_button1_clicked (GtkButton *, SPSData *);  // Send packet(s)
int on_button5_clicked (GtkButton *, SPSData *);  // Stop flood

// TCP page (IPv4)

// Ethernet header
int on_checkbutton18_toggled (GtkButton *, SPSData *);  // Specify ethernet header
int on_checkbutton58_toggled (GtkButton *, SPSData *);  // Pad ethernet frame to meet minimum length, if required
int on_entry144_activate (GtkWidget *, SPSData *);  // Destination link-layer (MAC) address
int on_entry145_activate (GtkWidget *, SPSData *);  // Source link-layer (MAC) address
int on_entry150_activate (GtkWidget *, SPSData *);  // Source interface name
int on_spinbutton5_value_changed (GtkWidget *, SPSData *);  // Maximum transmission unit (MTU)
int on_entry146_activate (GtkWidget *, SPSData *);  // Ethernet type code
// IPv4 header
int on_entry29_activate (GtkWidget *, SPSData *);  // IPv4 header length
int on_entry30_activate (GtkWidget *, SPSData *);  // Protocol version
int on_entry31_activate (GtkWidget *, SPSData *);  // Type-of-service
int on_entry32_activate (GtkWidget *, SPSData *);  // Total length of datagram
int on_entry33_activate (GtkWidget *, SPSData *);  // ID sequence number
int on_entry122_activate (GtkWidget *, SPSData *);  // Zero
int on_entry37_activate (GtkWidget *, SPSData *);  // Do not fragment flag
int on_entry38_activate (GtkWidget *, SPSData *);  // More fragments following flag
int on_entry39_activate (GtkWidget *, SPSData *);  // Fragmentation offset
int on_entry40_activate (GtkWidget *, SPSData *);  // Time-to-Live
int on_entry74_activate (GtkWidget *, SPSData *);  // Transport layer protocol
int on_entry35_activate (GtkWidget *, SPSData *);  // Source IPv4 address
int on_checkbutton5_toggled (GtkButton *, SPSData *);  // Randomize source IPv4 address
int on_entry36_activate (GtkWidget *, SPSData *);  // Destination IPv4 address
int on_entry34_activate (GtkWidget *, SPSData *);  // IPv4 Checksum
// IPv4 header options
int on_radiobutton24_toggled (GtkButton *, SPSData *);  // Decimal option data entry
int on_radiobutton25_toggled (GtkButton *, SPSData *);  // Hexadecimal option data entry
int on_entry400_activate (GtkWidget *, SPSData *);  // Options data
int on_button26_clicked (GtkButton *, SPSData *);  // Insert IP option after...
int on_entry401_activate (GtkWidget *, SPSData *);  // Option number after which to insert new option
int on_button60_clicked (GtkButton *, SPSData *);  // Append IP option
int on_button61_clicked (GtkButton *, SPSData *);  // View IP options
int on_entry403_activate (GtkWidget *, SPSData *);  // Option number to remove
int on_button62_clicked (GtkButton *, SPSData *);  // Remove option

// TCP header (IPv4)
int on_entry41_activate (GtkWidget *, SPSData *);  // Source Port
int on_checkbutton7_toggled (GtkButton *, SPSData *);  // Randomize source port
int on_entry42_activate (GtkWidget *, SPSData *);  // Destination port
int on_entry43_activate (GtkWidget *, SPSData *);  // Sequence number
int on_entry44_activate (GtkWidget *, SPSData *);  // Acknowledgement number
int on_entry45_activate (GtkWidget *, SPSData *);  // Reserved 4 bits
int on_entry46_activate (GtkWidget *, SPSData *);  // Data offset
int on_entry47_activate (GtkWidget *, SPSData *);  // FIN flag
int on_entry48_activate (GtkWidget *, SPSData *);  // SYN flag
int on_entry49_activate (GtkWidget *, SPSData *);  // RST flag
int on_entry50_activate (GtkWidget *, SPSData *);  // PSH flag
int on_entry51_activate (GtkWidget *, SPSData *);  // ACK flag
int on_entry52_activate (GtkWidget *, SPSData *);  // URG flag
int on_entry53_activate (GtkWidget *, SPSData *);  // ECE flag
int on_entry54_activate (GtkWidget *, SPSData *);  // CWR flag
int on_entry55_activate (GtkWidget *, SPSData *);  // Window size
int on_entry56_activate (GtkWidget *, SPSData *);  // TCP checksum
int on_entry77_activate (GtkWidget *, SPSData *);  // Urgent pointer
int on_radiobutton17_toggled (GtkButton *, SPSData *);  // ASCII data entry
int on_radiobutton18_toggled (GtkButton *, SPSData *);  // Hexadecimal data entry
int on_entry162_activate (GtkWidget *, SPSData *);  // TCP data from keyboard
int on_button20_clicked (GtkButton *, SPSData *);  // TCP data from file
// TCP options (IPv4)
int on_radiobutton41_toggled (GtkButton *, SPSData *);  // Decimal option data entry
int on_radiobutton42_toggled (GtkButton *, SPSData *);  // Hexadecimal option data entry
int on_entry404_activate (GtkWidget *, SPSData *);  // Option data
int on_button47_clicked (GtkButton *, SPSData *);  // Insert IP option after...
int on_entry405_activate (GtkWidget *, SPSData *);  // Option number after which to insert new option
int on_button48_clicked (GtkButton *, SPSData *);  // Append TCP option
int on_button49_clicked (GtkButton *, SPSData *);  // View TCP options
int on_entry406_activate (GtkWidget *, SPSData *);  // Option number to remove
int on_button58_clicked (GtkButton *, SPSData *);  // Remove option

int on_button3_clicked (GtkButton *, SPSData *);  // View IPv4 TCP packet
int on_button11_clicked (GtkButton *, SPSData *);  // Restore IPv4 TCP default values

// TCP page (IPv6)

// Ethernet header
int on_entry131_activate (GtkWidget *, SPSData *);  // Destination link-layer (MAC) address
int on_entry132_activate (GtkWidget *, SPSData *);  // Source link-layer (MAC) address
int on_entry154_activate (GtkWidget *, SPSData *);  // Source interface name
int on_spinbutton8_value_changed (GtkWidget *, SPSData *);  // Maximum transmission unit (MTU)
int on_entry133_activate (GtkWidget *, SPSData *);  // Ethernet type code
// IPv6 header
int on_entry22_activate (GtkWidget *, SPSData *);  // IP version
int on_entry23_activate (GtkWidget *, SPSData *);  // Traffic class
int on_entry24_activate (GtkWidget *, SPSData *);  // Flow label
int on_entry25_activate (GtkWidget *, SPSData *);  // Payload length
int on_entry26_activate (GtkWidget *, SPSData *);  // Next header
int on_entry27_activate (GtkWidget *, SPSData *);  // Hop limit
int on_entry28_activate (GtkWidget *, SPSData *);  // Source IPv6 address
int on_checkbutton2_toggled (GtkButton *, SPSData *);  // Randomize Source IPv6 Address
int on_entry78_activate (GtkWidget *, SPSData *);  // Destination IPv6 address
// TCP header (IPv6)
int on_entry79_activate (GtkWidget *, SPSData *);  // Source Port
int on_checkbutton4_toggled (GtkButton *, SPSData *);  // Randomize source port
int on_entry80_activate (GtkWidget *, SPSData *);  // Destination port
int on_entry81_activate (GtkWidget *, SPSData *);  // Sequence number
int on_entry82_activate (GtkWidget *, SPSData *);  // Acknowledgement number
int on_entry83_activate (GtkWidget *, SPSData *);  // Reserved 4 bits
int on_entry84_activate (GtkWidget *, SPSData *);  // Data offset
int on_entry85_activate (GtkWidget *, SPSData *);  // FIN flag
int on_entry86_activate (GtkWidget *, SPSData *);  // SYN flag
int on_entry87_activate (GtkWidget *, SPSData *);  // RST flag
int on_entry88_activate (GtkWidget *, SPSData *);  // PSH flag
int on_entry89_activate (GtkWidget *, SPSData *);  // ACK flag
int on_entry90_activate (GtkWidget *, SPSData *);  // URG flag
int on_entry91_activate (GtkWidget *, SPSData *);  // ECE flag
int on_entry92_activate (GtkWidget *, SPSData *);  // CWR flag
int on_entry93_activate (GtkWidget *, SPSData *);  // Window size
int on_entry94_activate (GtkWidget *, SPSData *);  // TCP checksum
int on_entry95_activate (GtkWidget *, SPSData *);  // Urgent pointer
int on_radiobutton19_toggled (GtkButton *, SPSData *);  // ASCII data entry
int on_radiobutton20_toggled (GtkButton *, SPSData *);  // Hexadecimal data entry
int on_entry163_activate (GtkWidget *, SPSData *);  // TCP data from keyboard
int on_button22_clicked (GtkButton *, SPSData *);  // TCP data from file
// TCP options (IPv6)
int on_radiobutton47_toggled (GtkButton *, SPSData *);  // Decimal option data entry
int on_radiobutton48_toggled (GtkButton *, SPSData *);  // Hexadecimal option data entry
int on_entry413_activate (GtkWidget *, SPSData *);  // Option data
int on_button70_clicked (GtkButton *, SPSData *);  // Insert IP option after...
int on_entry414_activate (GtkWidget *, SPSData *);  // Option number after which to insert new option
int on_button71_clicked (GtkButton *, SPSData *);  // Append TCP option
int on_button72_clicked (GtkButton *, SPSData *);  // View TCP options
int on_entry415_activate (GtkWidget *, SPSData *);  // Option number to remove
int on_button73_clicked (GtkButton *, SPSData *);  // Remove option
// Extension headers
int on_button98_clicked (GtkWidget *, SPSData *);  // Hop-by-hop extension header
int on_button110_clicked (GtkWidget *, SPSData *);  // Destination extension header
int on_button132_clicked (GtkWidget *, SPSData *);  // Routing extension header
int on_button116_clicked (GtkWidget *, SPSData *);  // Authentication extension header
int on_button126_clicked (GtkWidget *, SPSData *);  // Encapsulating security payload (ESP) extension header

int on_button6_clicked (GtkButton *, SPSData *);  // View IPv6 TCP packet
int on_button16_clicked (GtkButton *, SPSData *);  // Restore IPv6 TCP default values

// ICMP page (IPv4)

// Ethernet header
int on_checkbutton17_toggled (GtkButton *, SPSData *);  // Specify ethernet header
int on_checkbutton59_toggled (GtkButton *, SPSData *);  // Pad ethernet frame to meet minimum length, if required
int on_entry141_activate (GtkWidget *, SPSData *);  // Destination link-layer (MAC) address
int on_entry142_activate (GtkWidget *, SPSData *);  // Source link-layer (MAC) address
int on_entry151_activate (GtkWidget *, SPSData *);  // Source interface name
int on_spinbutton6_value_changed (GtkWidget *, SPSData *);  // Maximum transmission unit (MTU)
int on_entry143_activate (GtkWidget *, SPSData *);  // Ethernet type code
// IPv4 header
int on_entry57_activate (GtkWidget *, SPSData *);  // IPv4 Header Length
int on_entry58_activate (GtkWidget *, SPSData *);  // Protocol Version
int on_entry59_activate (GtkWidget *, SPSData *);  // Type of Service
int on_entry60_activate (GtkWidget *, SPSData *);  // Total Length of Datagram
int on_entry61_activate (GtkWidget *, SPSData *);  // ID Sequence Number
int on_entry123_activate (GtkWidget *, SPSData *);  // Zero
int on_entry65_activate (GtkWidget *, SPSData *);  // Do Not Fragment Flag
int on_entry66_activate (GtkWidget *, SPSData *);  // More Fragments Following
int on_entry67_activate (GtkWidget *, SPSData *);  // Fragmentation Offset
int on_entry68_activate (GtkWidget *, SPSData *);  // Time-to-Live
int on_entry75_activate (GtkWidget *, SPSData *);  // Transport Layer Protocol
int on_entry63_activate (GtkWidget *, SPSData *);  // Source IPv4 Address
int on_checkbutton9_toggled (GtkButton *, SPSData *);  // Randomize Source IPv4 Address
int on_entry64_activate (GtkWidget *, SPSData *);  // Destination IPv4 Address
int on_entry62_activate (GtkWidget *, SPSData *);  // IPv4 Checksum
// IPv4 header options
int on_radiobutton43_toggled (GtkButton *, SPSData *);  // Decimal option data entry
int on_radiobutton44_toggled (GtkButton *, SPSData *);  // Hexadecimal option data entry
int on_entry407_activate (GtkWidget *, SPSData *);  // Options data
int on_button59_clicked (GtkButton *, SPSData *);  // Insert IP option after...
int on_entry408_activate (GtkWidget *, SPSData *);  // Option number after which to insert new option
int on_button63_clicked (GtkButton *, SPSData *);  // Append IP option
int on_button64_clicked (GtkButton *, SPSData *);  // View IP options
int on_entry409_activate (GtkWidget *, SPSData *);  // Option number to remove
int on_button65_clicked (GtkButton *, SPSData *);  // Remove option
// ICMP message (IPv4)
int on_entry69_activate (GtkWidget *, SPSData *);  // Message type
int on_entry70_activate (GtkWidget *, SPSData *);  // Message code
int on_entry71_activate (GtkWidget *, SPSData *);  // ICMP checksum
int on_entry72_activate (GtkWidget *, SPSData *);  // ID
int on_entry73_activate (GtkWidget *, SPSData *);  // Sequence number
int on_radiobutton9_toggled (GtkButton *, SPSData *);  // ASCII data entry
int on_radiobutton10_toggled (GtkButton *, SPSData *);  // Hexadecimal data entry
int on_entry126_activate (GtkWidget *, SPSData *);  // ICMP data from keyboard
int on_button7_clicked (GtkButton *, SPSData *);  // ICMP data from file

int on_button2_clicked (GtkButton *, SPSData *);  // View IPv4 ICMP packet
int on_button12_clicked (GtkButton *, SPSData *);  // Restore IPv4 ICMP default values

// ICMP page (IPv6)

// Ethernet header
int on_entry128_activate (GtkWidget *, SPSData *);  // Destination link-layer (MAC) address
int on_entry129_activate (GtkWidget *, SPSData *);  // Source link-layer (MAC) address
int on_entry153_activate (GtkWidget *, SPSData *);  // Source interface name
int on_spinbutton9_value_changed (GtkWidget *, SPSData *);  // Maximum transmission unit (MTU)
int on_entry130_activate (GtkWidget *, SPSData *);  // Ethernet type code
// IPv6 header
int on_entry110_activate (GtkWidget *, SPSData *);  // IP version
int on_entry111_activate (GtkWidget *, SPSData *);  // Traffic class
int on_entry112_activate (GtkWidget *, SPSData *);  // Flow label
int on_entry113_activate (GtkWidget *, SPSData *);  // Payload length
int on_entry114_activate (GtkWidget *, SPSData *);  // Next header
int on_entry115_activate (GtkWidget *, SPSData *);  // Hop limit
int on_entry109_activate (GtkWidget *, SPSData *);  // Source IPv6 address
int on_checkbutton10_toggled (GtkButton *, SPSData *);  // Randomize Source IPv6 Address
int on_entry116_activate (GtkWidget *, SPSData *);  // Destination IPv6 address
// ICMP message (IPv6)
int on_entry117_activate (GtkWidget *, SPSData *);  // Message type
int on_entry118_activate (GtkWidget *, SPSData *);  // Message code
int on_entry119_activate (GtkWidget *, SPSData *);  // ICMP checksum
int on_entry120_activate (GtkWidget *, SPSData *);  // ID
int on_entry121_activate (GtkWidget *, SPSData *);  // Sequence number
int on_radiobutton11_toggled (GtkButton *, SPSData *);  // ASCII data entry
int on_radiobutton12_toggled (GtkButton *, SPSData *);  // Hexadecimal data entry
int on_entry127_activate (GtkWidget *, SPSData *);  // ICMP data from keyboard
int on_button9_clicked (GtkButton *, SPSData *);  // ICMP data from file
// Extension headers
int on_button99_clicked (GtkWidget *, SPSData *);  // Hop-by-hop extension header
int on_button111_clicked (GtkWidget *, SPSData *);  // Destination extension header
int on_button133_clicked (GtkWidget *, SPSData *);  // Routing extension header
int on_button117_clicked (GtkWidget *, SPSData *);  // Authentication extension header
int on_button127_clicked (GtkWidget *, SPSData *);  // Encapsulating security payload (ESP) extension header

int on_button17_clicked (GtkButton *, SPSData *);  // View IPv6 ICMP packet
int on_button18_clicked (GtkButton *, SPSData *);  // Restore IPv6 ICMP default values

// UDP page (IPv4)

// Ethernet header
int on_checkbutton19_toggled (GtkButton *, SPSData *);  // Specify ethernet header
int on_checkbutton60_toggled (GtkButton *, SPSData *);  // Pad ethernet frame to meet minimum length, if required
int on_entry147_activate (GtkWidget *, SPSData *);  // Destination link-layer (MAC) address
int on_entry148_activate (GtkWidget *, SPSData *);  // Source link-layer (MAC) address
int on_entry152_activate (GtkWidget *, SPSData *);  // Source interface name
int on_spinbutton7_value_changed (GtkWidget *, SPSData *);  // Maximum transmission unit (MTU)
int on_entry149_activate (GtkWidget *, SPSData *);  // Ethernet type code
// IPv4 header
int on_entry1_activate (GtkWidget *, SPSData *);  // IPv4 Header Length
int on_entry2_activate (GtkWidget *, SPSData *);  // Protocol Version
int on_entry3_activate (GtkWidget *, SPSData *);  // Type of Service
int on_entry4_activate (GtkWidget *, SPSData *);  // Total Length of Datagram
int on_entry5_activate (GtkWidget *, SPSData *);  // ID Sequence Number
int on_entry124_activate (GtkWidget *, SPSData *);  // Zero
int on_entry9_activate (GtkWidget *, SPSData *);  // Do Not Fragment Flag
int on_entry10_activate (GtkWidget *, SPSData *);  // More Fragments Following
int on_entry11_activate (GtkWidget *, SPSData *);  // Fragmentation Offset
int on_entry12_activate (GtkWidget *, SPSData *);  // Time-to-Live
int on_entry76_activate (GtkWidget *, SPSData *);  // Transport Layer Protocol
int on_entry7_activate (GtkWidget *, SPSData *);  // Source IPv4 Address
int on_checkbutton1_toggled (GtkButton *, SPSData *);  // Randomize Source IPv4 Address
int on_entry8_activate (GtkWidget *, SPSData *);  // Destination IPv4 Address
int on_entry6_activate (GtkWidget *, SPSData *);  // IPv4 Checksum
// IPv4 header options
int on_radiobutton45_toggled (GtkButton *, SPSData *);  // Decimal option data entry
int on_radiobutton46_toggled (GtkButton *, SPSData *);  // Hexadecimal option data entry
int on_entry410_activate (GtkWidget *, SPSData *);  // Options data
int on_button66_clicked (GtkButton *, SPSData *);  // Insert IP option after...
int on_entry411_activate (GtkWidget *, SPSData *);  // Option number after which to insert new option
int on_button67_clicked (GtkButton *, SPSData *);  // Append IP option
int on_button68_clicked (GtkButton *, SPSData *);  // View IP options
int on_entry412_activate (GtkWidget *, SPSData *);  // Option number to remove
int on_button69_clicked (GtkButton *, SPSData *);  // Remove option
// UDP header (IPv4)
int on_entry13_activate (GtkWidget *, SPSData *);  // Source Port
int on_checkbutton3_toggled (GtkButton *, SPSData *);  // Randomize Source Port
int on_entry14_activate (GtkWidget *, SPSData *);  // Destination Port
int on_entry15_activate (GtkWidget *, SPSData *);  // Length of UDP Datagram
int on_entry16_activate (GtkWidget *, SPSData *);  // UDP Checksum
int on_radiobutton13_toggled (GtkButton *, SPSData *);  // ASCII data entry
int on_radiobutton14_toggled (GtkButton *, SPSData *);  // Hexadecimal data entry
int on_entry17_activate (GtkWidget *, SPSData *);  // UDP Data from keyboard
int on_button8_clicked (GtkButton *, SPSData *);  // UDP data from file

int on_button4_clicked (GtkButton *, SPSData *);  // View IPv4 UDP packet
int on_button15_clicked (GtkButton *, SPSData *);  // Restore IPv4 UDP default values

// UDP page (IPv6)

// Ethernet header
int on_entry134_activate (GtkWidget *, SPSData *);  // Destination link-layer (MAC) address
int on_entry135_activate (GtkWidget *, SPSData *);  // Source link-layer (MAC) address
int on_entry155_activate (GtkWidget *, SPSData *);  // Source interface name
int on_spinbutton10_value_changed (GtkWidget *, SPSData *);  // Maximum transmission unit (MTU)
int on_entry136_activate (GtkWidget *, SPSData *);  // Ethernet type code
// IPv6 header
int on_entry97_activate (GtkWidget *, SPSData *);  // IP version
int on_entry98_activate (GtkWidget *, SPSData *);  // Traffic class
int on_entry99_activate (GtkWidget *, SPSData *);  // Flow label
int on_entry100_activate (GtkWidget *, SPSData *);  // Payload length
int on_entry101_activate (GtkWidget *, SPSData *);  // Next header
int on_entry102_activate (GtkWidget *, SPSData *);  // Hop limit
int on_entry96_activate (GtkWidget *, SPSData *);  // Source IPv6 address
int on_checkbutton6_toggled (GtkButton *, SPSData *);  // Randomize Source IPv6 Address
int on_entry103_activate (GtkWidget *, SPSData *);  // Destination IPv6 address
// UDP header (IPv6)
int on_entry104_activate (GtkWidget *, SPSData *);  // Source Port
int on_checkbutton8_toggled (GtkButton *, SPSData *);  // Randomize Source Port
int on_entry105_activate (GtkWidget *, SPSData *);  // Destination Port
int on_entry106_activate (GtkWidget *, SPSData *);  // Length of UDP Datagram
int on_entry107_activate (GtkWidget *, SPSData *);  // UDP Checksum
int on_radiobutton15_toggled (GtkButton *, SPSData *);  // ASCII data entry
int on_radiobutton16_toggled (GtkButton *, SPSData *);  // Hexadecimal data entry
int on_entry108_activate (GtkWidget *, SPSData *);  // UDP Data from keyboard
int on_button10_clicked (GtkButton *, SPSData *);  // UDP data from file
// Extension headers
int on_button100_clicked (GtkWidget *, SPSData *);  // Hop-by-hop extension header
int on_button112_clicked (GtkWidget *, SPSData *);  // Destination extension header
int on_button134_clicked (GtkWidget *, SPSData *);  // Routing extension header
int on_button118_clicked (GtkWidget *, SPSData *);  // Authentication extension header
int on_button128_clicked (GtkWidget *, SPSData *);  // Encapsulating security payload (ESP) extension header

int on_button13_clicked (GtkButton *, SPSData *);  // View IPv6 UDP packet
int on_button19_clicked (GtkButton *, SPSData *);  // Restore IPv6 UDP default values

// Host/IP page
int on_entry19_activate (GtkWidget *, SPSData *);  // Hostname to IP Address
int on_entry20_activate (GtkWidget *, SPSData *);  // IPv4 Address to Hostname
int on_entry21_activate (GtkWidget *, SPSData *);  // IPv6 Address to Hostname
int on_entry139_activate (GtkWidget *, SPSData *);  // This host's interface name to be converted to link-layer (MAC) address.
int on_entry140_activate (GtkWidget *, SPSData *);  // Interface name for IP to link-layer conversion
int on_spinbutton1_value_changed (GtkWidget *, SPSData *);  // Timeout for ARP/Neighbor discovery
int on_entry137_activate (GtkWidget *, SPSData *);  // IPv4 Address to link-layer (MAC) address
int on_entry138_activate (GtkWidget *, SPSData *);  // IPv6 Address to link-layer (MAC) address

// Load/Save page

// Load SPS file, which contains settings selected by user when saved
int on_button21_clicked (GtkButton *, SPSData *);

// Save
// Send Packet settings
int on_checkbutton25_toggled (GtkButton *, SPSData *);  // Packet type, Number of packets to send, Flood mode
// IPv6 over IPv4 (6to4)
int on_checkbutton15_toggled (GtkButton *, SPSData *);  // IPv4 Ethernet header and IPv4 header
// IPv4
int on_checkbutton16_toggled (GtkButton *, SPSData *);  // TCP packet
int on_checkbutton20_toggled (GtkButton *, SPSData *);  // ICMP packet
int on_checkbutton21_toggled (GtkButton *, SPSData *);  // UDP packet
// IPv6
int on_checkbutton22_toggled (GtkButton *, SPSData *);  // TCP packet
int on_checkbutton23_toggled (GtkButton *, SPSData *);  // ICMP packet
int on_checkbutton24_toggled (GtkButton *, SPSData *);  // UDP packet
// Traceroute settings
int on_checkbutton36_toggled (GtkButton *, SPSData *);  // Traceroute settings
// IPv6 over IPv4 (6to4) for traceroute
int on_checkbutton46_toggled (GtkButton *, SPSData *);  // IPv4 Ethernet header and IPv4 header for traceroute
// IPv4 traceroute
int on_checkbutton39_toggled (GtkButton *, SPSData *);  // TCP packet for traceroute
int on_checkbutton41_toggled (GtkButton *, SPSData *);  // ICMP packet for traceroute
int on_checkbutton42_toggled (GtkButton *, SPSData *);  // UDP packet for traceroute
// IPv6 traceroute
int on_checkbutton43_toggled (GtkButton *, SPSData *);  // TCP packet for traceroute
int on_checkbutton44_toggled (GtkButton *, SPSData *);  // ICMP packet for traceroute
int on_checkbutton45_toggled (GtkButton *, SPSData *);  // UDP packet for traceroute
// Save SPS file, which contains settings selected by user
int on_button14_clicked (GtkButton *, SPSData *);

// Traceroute page (sps.ui)

// Probe Protocol
int on_radiobutton21_toggled (GtkButton *, SPSData *);  // TCP (IPv4) probe packet
int on_radiobutton22_toggled (GtkButton *, SPSData *);  // ICMP (IPv4) probe packet
int on_radiobutton23_toggled (GtkButton *, SPSData *);  // UDP (IPv4) probe packet
int on_radiobutton26_toggled (GtkButton *, SPSData *);  // TCP (IPv6) probe packet
int on_radiobutton27_toggled (GtkButton *, SPSData *);  // ICMP (IPv6) probe packet
int on_radiobutton28_toggled (GtkButton *, SPSData *);  // UDP (IPv6) probe packet
int on_checkbutton29_toggled (GtkButton *, SPSData *);  // Tunnel IPv6 over IPv4

int on_spinbutton2_value_changed (GtkWidget *, SPSData *);  // Number of probes per hop
int on_spinbutton4_value_changed (GtkWidget *, SPSData *);  // Timeout for reply
int on_spinbutton3_value_changed (GtkWidget *, SPSData *);  // Maximum number of hops
// Resolve Node Hostnames
int on_checkbutton34_toggled (GtkButton *, SPSData *);  // Yes
// Edit, Start, Stop buttons
int on_button23_clicked (GtkButton *, SPSData *);  // Edit packets
int on_traceroute_window_destroy (GtkWidget *, SPSData *);  // Set traceroute_flag to zero when traceroute_window is destroyed
int on_button24_clicked (GtkButton *, SPSData *);  // Start
int on_button25_clicked (GtkButton *, SPSData *);  // Stop

// Traceroute IPv6 over IPv4 (6to4) page (traceroute.ui)

// IPv6 over IPv4 (6to4)
int on_spinbutton18_value_changed (GtkWidget *, SPSData *);  // Maximum transmission unit (MTU)
int on_checkbutton61_toggled (GtkButton *, SPSData *);  // Pad ethernet frame to meet minimum length, if required
int on_checkbutton48_toggled (GtkButton *, SPSData *);  // TCP - Specify ethernet header
int on_entry316_activate (GtkWidget *, SPSData *);  // TCP IPv4 Source Address for 6to4 tunnel
int on_checkbutton49_toggled (GtkButton *, SPSData *);  // ICMP - Specify ethernet header
int on_entry317_activate (GtkWidget *, SPSData *);  // ICMP IPv4 Source Address for 6to4 tunnel
int on_checkbutton50_toggled (GtkButton *, SPSData *);  // UDP - Specify ethernet header
int on_entry318_activate (GtkWidget *, SPSData *);  // UDP IPv4 Source Address for 6to4 tunnel

// TCP page (IPv4) (traceroute.ui)

// Ethernet header
int on_checkbutton28_toggled (GtkButton *, SPSData *);  // Specify ethernet header
int on_checkbutton62_toggled (GtkButton *, SPSData *);  // Pad ethernet frame to meet minimum length, if required
int on_entry164_activate (GtkWidget *, SPSData *);  // Destination link-layer (MAC) address
int on_entry165_activate (GtkWidget *, SPSData *);  // Source link-layer (MAC) address
int on_entry166_activate (GtkWidget *, SPSData *);  // Source interface name
int on_spinbutton11_value_changed (GtkWidget *, SPSData *);  // Maximum transmission unit (MTU)
int on_entry167_activate (GtkWidget *, SPSData *);  // Ethernet type code

// IPv4 header
int on_entry168_activate (GtkWidget *, SPSData *);  // IPv4 header length
int on_entry169_activate (GtkWidget *, SPSData *);  // Protocol version
int on_entry170_activate (GtkWidget *, SPSData *);  // Type-of-service
int on_entry171_activate (GtkWidget *, SPSData *);  // Total length of datagram
int on_entry172_activate (GtkWidget *, SPSData *);  // ID sequence number
int on_entry173_activate (GtkWidget *, SPSData *);  // Zero
int on_entry174_activate (GtkWidget *, SPSData *);  // Do not fragment flag
int on_entry175_activate (GtkWidget *, SPSData *);  // More fragments following flag
int on_entry176_activate (GtkWidget *, SPSData *);  // Fragmentation offset
int on_entry177_activate (GtkWidget *, SPSData *);  // Time-to-Live
int on_entry178_activate (GtkWidget *, SPSData *);  // Transport layer protocol
int on_entry179_activate (GtkWidget *, SPSData *);  // Source IPv4 address
int on_entry180_activate (GtkWidget *, SPSData *);  // Destination IPv4 address
int on_entry181_activate (GtkWidget *, SPSData *);  // IPv4 Checksum
// IPv4 header options
int on_radiobutton49_toggled (GtkButton *, SPSData *);  // Decimal option data entry
int on_radiobutton50_toggled (GtkButton *, SPSData *);  // Hexadecimal option data entry
int on_entry416_activate (GtkWidget *, SPSData *);  // Options data
int on_button74_clicked (GtkButton *, SPSData *);  // Insert IP option after...
int on_entry417_activate (GtkWidget *, SPSData *);  // Option number after which to insert new option
int on_button75_clicked (GtkButton *, SPSData *);  // Append IP option
int on_button76_clicked (GtkButton *, SPSData *);  // View IP options
int on_entry418_activate (GtkWidget *, SPSData *);  // Option number to remove
int on_button77_clicked (GtkButton *, SPSData *);  // Remove option

// TCP header (IPv4)
int on_entry182_activate (GtkWidget *, SPSData *);  // Source Port
int on_checkbutton30_toggled (GtkButton *, SPSData *);  // Randomize source port
int on_entry183_activate (GtkWidget *, SPSData *);  // Destination port
int on_entry184_activate (GtkWidget *, SPSData *);  // Sequence number
int on_entry185_activate (GtkWidget *, SPSData *);  // Acknowledgement number
int on_entry186_activate (GtkWidget *, SPSData *);  // Reserved 4 bits
int on_entry187_activate (GtkWidget *, SPSData *);  // Data offset
int on_entry188_activate (GtkWidget *, SPSData *);  // FIN flag
int on_entry189_activate (GtkWidget *, SPSData *);  // SYN flag
int on_entry190_activate (GtkWidget *, SPSData *);  // RST flag
int on_entry191_activate (GtkWidget *, SPSData *);  // PSH flag
int on_entry192_activate (GtkWidget *, SPSData *);  // ACK flag
int on_entry193_activate (GtkWidget *, SPSData *);  // URG flag
int on_entry194_activate (GtkWidget *, SPSData *);  // ECE flag
int on_entry195_activate (GtkWidget *, SPSData *);  // CWR flag
int on_entry196_activate (GtkWidget *, SPSData *);  // Window size
int on_entry197_activate (GtkWidget *, SPSData *);  // TCP checksum
int on_entry198_activate (GtkWidget *, SPSData *);  // Urgent pointer
int on_radiobutton29_toggled (GtkButton *, SPSData *);  // ASCII data entry
int on_radiobutton30_toggled (GtkButton *, SPSData *);  // Hexadecimal data entry
int on_entry199_activate (GtkWidget *, SPSData *);  // TCP data from keyboard
int on_button29_clicked (GtkButton *, SPSData *);  // TCP data from file
// TCP options (IPv4)
int on_radiobutton51_toggled (GtkButton *, SPSData *);  // Decimal option data entry
int on_radiobutton52_toggled (GtkButton *, SPSData *);  // Hexadecimal option data entry
int on_entry419_activate (GtkWidget *, SPSData *);  // Option data
int on_button78_clicked (GtkButton *, SPSData *);  // Insert IP option after...
int on_entry420_activate (GtkWidget *, SPSData *);  // Option number after which to insert new option
int on_button79_clicked (GtkButton *, SPSData *);  // Append TCP option
int on_button80_clicked (GtkButton *, SPSData *);  // View TCP options
int on_entry421_activate (GtkWidget *, SPSData *);  // Option number to remove
int on_button81_clicked (GtkButton *, SPSData *);  // Remove option

int on_button28_clicked (GtkButton *, SPSData *);  // View IPv4 TCP packet
int on_button30_clicked (GtkButton *, SPSData *);  // Restore IPv4 TCP default values

// TCP page (IPv6) (traceroute.ui)

// Ethernet header
int on_entry247_activate (GtkWidget *, SPSData *);  // Destination link-layer (MAC) address
int on_entry248_activate (GtkWidget *, SPSData *);  // Source link-layer (MAC) address
int on_entry249_activate (GtkWidget *, SPSData *);  // Source interface name
int on_spinbutton14_value_changed (GtkWidget *, SPSData *);  // Maximum transmission unit (MTU)
int on_entry250_activate (GtkWidget *, SPSData *);  // Ethernet type code
// IPv6 header
int on_entry251_activate (GtkWidget *, SPSData *);  // IP version
int on_entry252_activate (GtkWidget *, SPSData *);  // Traffic class
int on_entry253_activate (GtkWidget *, SPSData *);  // Flow label
int on_entry254_activate (GtkWidget *, SPSData *);  // Payload length
int on_entry255_activate (GtkWidget *, SPSData *);  // Next header
int on_entry256_activate (GtkWidget *, SPSData *);  // Hop limit
int on_entry257_activate (GtkWidget *, SPSData *);  // Source IPv6 address
int on_entry258_activate (GtkWidget *, SPSData *);  // Destination IPv6 address
// TCP header (IPv6)
int on_entry259_activate (GtkWidget *, SPSData *);  // Source Port
int on_checkbutton37_toggled (GtkButton *, SPSData *);  // Randomize source port
int on_entry260_activate (GtkWidget *, SPSData *);  // Destination port
int on_entry261_activate (GtkWidget *, SPSData *);  // Sequence number
int on_entry262_activate (GtkWidget *, SPSData *);  // Acknowledgement number
int on_entry263_activate (GtkWidget *, SPSData *);  // Reserved 4 bits
int on_entry264_activate (GtkWidget *, SPSData *);  // Data offset
int on_entry265_activate (GtkWidget *, SPSData *);  // FIN flag
int on_entry266_activate (GtkWidget *, SPSData *);  // SYN flag
int on_entry267_activate (GtkWidget *, SPSData *);  // RST flag
int on_entry268_activate (GtkWidget *, SPSData *);  // PSH flag
int on_entry269_activate (GtkWidget *, SPSData *);  // ACK flag
int on_entry270_activate (GtkWidget *, SPSData *);  // URG flag
int on_entry271_activate (GtkWidget *, SPSData *);  // ECE flag
int on_entry272_activate (GtkWidget *, SPSData *);  // CWR flag
int on_entry273_activate (GtkWidget *, SPSData *);  // Window size
int on_entry274_activate (GtkWidget *, SPSData *);  // TCP checksum
int on_entry275_activate (GtkWidget *, SPSData *);  // Urgent pointer
int on_radiobutton35_toggled (GtkButton *, SPSData *);  // ASCII data entry
int on_radiobutton36_toggled (GtkButton *, SPSData *);  // Hexadecimal data entry
int on_entry276_activate (GtkWidget *, SPSData *);  // TCP data from keyboard
int on_button38_clicked (GtkButton *, SPSData *);  // TCP data from file
// TCP options (IPv6)
int on_radiobutton53_toggled (GtkButton *, SPSData *);  // Decimal option data entry
int on_radiobutton54_toggled (GtkButton *, SPSData *);  // Hexadecimal option data entry
int on_entry422_activate (GtkWidget *, SPSData *);  // Option data
int on_button82_clicked (GtkButton *, SPSData *);  // Insert IP option after...
int on_entry423_activate (GtkWidget *, SPSData *);  // Option number after which to insert new option
int on_button83_clicked (GtkButton *, SPSData *);  // Append TCP option
int on_button84_clicked (GtkButton *, SPSData *);  // View TCP options
int on_entry424_activate (GtkWidget *, SPSData *);  // Option number to remove
int on_button85_clicked (GtkButton *, SPSData *);  // Remove option
// Extension headers
int on_button101_clicked (GtkWidget *, SPSData *);  // Hop-by-hop extension header
int on_button113_clicked (GtkWidget *, SPSData *);  // Destination extension header
int on_button135_clicked (GtkWidget *, SPSData *);  // Routing extension header
int on_button119_clicked (GtkWidget *, SPSData *);  // Authentication extension header
int on_button129_clicked (GtkWidget *, SPSData *);  // Encapsulating security payload (ESP) extension header

int on_button37_clicked (GtkButton *, SPSData *);  // View IPv6 TCP packet
int on_button39_clicked (GtkButton *, SPSData *);  // Restore IPv6 TCP default values

// ICMP page (IPv4) (traceroute.ui)

// Ethernet header
int on_checkbutton31_toggled (GtkButton *, SPSData *);  // Specify ethernet header
int on_checkbutton63_toggled (GtkButton *, SPSData *);  // Pad ethernet frame to meet minimum length, if required
int on_entry200_activate (GtkWidget *, SPSData *);  // Destination link-layer (MAC) address
int on_entry201_activate (GtkWidget *, SPSData *);  // Source link-layer (MAC) address
int on_entry202_activate (GtkWidget *, SPSData *);  // Source interface name
int on_spinbutton12_value_changed (GtkWidget *, SPSData *);  // Maximum transmission unit (MTU)
int on_entry203_activate (GtkWidget *, SPSData *);  // Ethernet type code

// IPv4 header
int on_entry204_activate (GtkWidget *, SPSData *);  // IPv4 Header Length
int on_entry205_activate (GtkWidget *, SPSData *);  // Protocol Version
int on_entry206_activate (GtkWidget *, SPSData *);  // Type of Service
int on_entry207_activate (GtkWidget *, SPSData *);  // Total Length of Datagram
int on_entry208_activate (GtkWidget *, SPSData *);  // ID Sequence Number
int on_entry209_activate (GtkWidget *, SPSData *);  // Zero
int on_entry210_activate (GtkWidget *, SPSData *);  // Do Not Fragment Flag
int on_entry211_activate (GtkWidget *, SPSData *);  // More Fragments Following
int on_entry212_activate (GtkWidget *, SPSData *);  // Fragmentation Offset
int on_entry213_activate (GtkWidget *, SPSData *);  // Time-to-Live
int on_entry214_activate (GtkWidget *, SPSData *);  // Transport Layer Protocol
int on_entry215_activate (GtkWidget *, SPSData *);  // Source IPv4 Address
int on_entry216_activate (GtkWidget *, SPSData *);  // Destination IPv4 Address
int on_entry217_activate (GtkWidget *, SPSData *);  // IPv4 Checksum
// IPv4 header options
int on_radiobutton55_toggled (GtkButton *, SPSData *);  // Decimal option data entry
int on_radiobutton56_toggled (GtkButton *, SPSData *);  // Hexadecimal option data entry
int on_entry425_activate (GtkWidget *, SPSData *);  // Options data
int on_button86_clicked (GtkButton *, SPSData *);  // Insert IP option after...
int on_entry426_activate (GtkWidget *, SPSData *);  // Option number after which to insert new option
int on_button87_clicked (GtkButton *, SPSData *);  // Append IP option
int on_button88_clicked (GtkButton *, SPSData *);  // View IP options
int on_entry427_activate (GtkWidget *, SPSData *);  // Option number to remove
int on_button89_clicked (GtkButton *, SPSData *);  // Remove option

// ICMP message (IPv4)
int on_entry218_activate (GtkWidget *, SPSData *);  // Message type
int on_entry219_activate (GtkWidget *, SPSData *);  // Message code
int on_entry220_activate (GtkWidget *, SPSData *);  // ICMP checksum
int on_entry221_activate (GtkWidget *, SPSData *);  // ID
int on_entry222_activate (GtkWidget *, SPSData *);  // Sequence number
int on_radiobutton31_toggled (GtkButton *, SPSData *);  // ASCII data entry
int on_radiobutton32_toggled (GtkButton *, SPSData *);  // Hexadecimal data entry
int on_entry223_activate (GtkWidget *, SPSData *);  // ICMP data from keyboard
int on_button32_clicked (GtkButton *, SPSData *);  // ICMP data from file

int on_button31_clicked (GtkButton *, SPSData *);  // View IPv4 ICMP packet
int on_button33_clicked (GtkButton *, SPSData *);  // Restore IPv4 ICMP default values

// ICMP page (IPv6) (traceroute.ui)

// Ethernet header
int on_entry277_activate (GtkWidget *, SPSData *);  // Destination link-layer (MAC) address
int on_entry278_activate (GtkWidget *, SPSData *);  // Source link-layer (MAC) address
int on_entry279_activate (GtkWidget *, SPSData *);  // Source interface name
int on_spinbutton15_value_changed (GtkWidget *, SPSData *);  // Maximum transmission unit (MTU)
int on_entry280_activate (GtkWidget *, SPSData *);  // Ethernet type code
// IPv6 header
int on_entry281_activate (GtkWidget *, SPSData *);  // IP version
int on_entry282_activate (GtkWidget *, SPSData *);  // Traffic class
int on_entry283_activate (GtkWidget *, SPSData *);  // Flow label
int on_entry284_activate (GtkWidget *, SPSData *);  // Payload length
int on_entry285_activate (GtkWidget *, SPSData *);  // Next header
int on_entry286_activate (GtkWidget *, SPSData *);  // Hop limit
int on_entry287_activate (GtkWidget *, SPSData *);  // Source IPv6 address
int on_entry288_activate (GtkWidget *, SPSData *);  // Destination IPv6 address
// ICMP message (IPv6)
int on_entry289_activate (GtkWidget *, SPSData *);  // Message type
int on_entry290_activate (GtkWidget *, SPSData *);  // Message code
int on_entry291_activate (GtkWidget *, SPSData *);  // ICMP checksum
int on_entry292_activate (GtkWidget *, SPSData *);  // ID
int on_entry293_activate (GtkWidget *, SPSData *);  // Sequence number
int on_radiobutton37_toggled (GtkButton *, SPSData *);  // ASCII data entry
int on_radiobutton38_toggled (GtkButton *, SPSData *);  // Hexadecimal data entry
int on_entry294_activate (GtkWidget *, SPSData *);  // ICMP data from keyboard
int on_button41_clicked (GtkButton *, SPSData *);  // ICMP data from file
// Extension headers
int on_button102_clicked (GtkWidget *, SPSData *);  // Hop-by-hop extension header
int on_button114_clicked (GtkWidget *, SPSData *);  // Destination extension header
int on_button136_clicked (GtkWidget *, SPSData *);  // Routing extension header
int on_button120_clicked (GtkWidget *, SPSData *);  // Authentication extension header
int on_button130_clicked (GtkWidget *, SPSData *);  // Encapsulating security payload (ESP) extension header

int on_button40_clicked (GtkButton *, SPSData *);  // View IPv6 ICMP packet
int on_button42_clicked (GtkButton *, SPSData *);  // Restore IPv6 ICMP default values

// UDP page (IPv4) (traceroute.ui)

// Ethernet header
int on_checkbutton33_toggled (GtkButton *, SPSData *);  // Specify ethernet header
int on_checkbutton64_toggled (GtkButton *, SPSData *);  // Pad ethernet frame to meet minimum length, if required
int on_entry224_activate (GtkWidget *, SPSData *);  // Destination link-layer (MAC) address
int on_entry225_activate (GtkWidget *, SPSData *);  // Source link-layer (MAC) address
int on_entry226_activate (GtkWidget *, SPSData *);  // Source interface name
int on_spinbutton13_value_changed (GtkWidget *, SPSData *);  // Maximum transmission unit (MTU)
int on_entry227_activate (GtkWidget *, SPSData *);  // Ethernet type code

// IPv4 header
int on_entry228_activate (GtkWidget *, SPSData *);  // IPv4 Header Length
int on_entry229_activate (GtkWidget *, SPSData *);  // Protocol Version
int on_entry230_activate (GtkWidget *, SPSData *);  // Type of Service
int on_entry231_activate (GtkWidget *, SPSData *);  // Total Length of Datagram
int on_entry232_activate (GtkWidget *, SPSData *);  // ID Sequence Number
int on_entry233_activate (GtkWidget *, SPSData *);  // Zero
int on_entry234_activate (GtkWidget *, SPSData *);  // Do Not Fragment Flag
int on_entry235_activate (GtkWidget *, SPSData *);  // More Fragments Following
int on_entry236_activate (GtkWidget *, SPSData *);  // Fragmentation Offset
int on_entry237_activate (GtkWidget *, SPSData *);  // Time-to-Live
int on_entry238_activate (GtkWidget *, SPSData *);  // Transport Layer Protocol
int on_entry239_activate (GtkWidget *, SPSData *);  // Source IPv4 Address
int on_entry240_activate (GtkWidget *, SPSData *);  // Destination IPv4 Address
int on_entry241_activate (GtkWidget *, SPSData *);  // IPv4 Checksum
// IPv4 header options
int on_radiobutton57_toggled (GtkButton *, SPSData *);  // Decimal option data entry
int on_radiobutton58_toggled (GtkButton *, SPSData *);  // Hexadecimal option data entry
int on_entry428_activate (GtkWidget *, SPSData *);  // Options data
int on_button90_clicked (GtkButton *, SPSData *);  // Insert IP option after...
int on_entry429_activate (GtkWidget *, SPSData *);  // Option number after which to insert new option
int on_button91_clicked (GtkButton *, SPSData *);  // Append IP option
int on_button92_clicked (GtkButton *, SPSData *);  // View IP options
int on_entry430_activate (GtkWidget *, SPSData *);  // Option number to remove
int on_button93_clicked (GtkButton *, SPSData *);  // Remove option

// UDP header (IPv4)
int on_entry242_activate (GtkWidget *, SPSData *);  // Source Port
int on_checkbutton35_toggled (GtkButton *, SPSData *);  // Randomize Source Port
int on_entry243_activate (GtkWidget *, SPSData *);  // Destination Port
int on_entry244_activate (GtkWidget *, SPSData *);  // Length of UDP Datagram
int on_entry245_activate (GtkWidget *, SPSData *);  // UDP Checksum
int on_radiobutton33_toggled (GtkButton *, SPSData *);  // ASCII data entry
int on_radiobutton34_toggled (GtkButton *, SPSData *);  // Hexadecimal data entry
int on_entry246_activate (GtkWidget *, SPSData *);  // UDP Data from keyboard
int on_button35_clicked (GtkButton *, SPSData *);  // UDP data from file

int on_button34_clicked (GtkButton *, SPSData *);  // View IPv4 UDP packet
int on_button36_clicked (GtkButton *, SPSData *);  // Restore IPv4 UDP default values

// UDP page (IPv6) (traceroute.ui)

// Ethernet header
int on_entry295_activate (GtkWidget *, SPSData *);  // Destination link-layer (MAC) address
int on_entry296_activate (GtkWidget *, SPSData *);  // Source link-layer (MAC) address
int on_entry297_activate (GtkWidget *, SPSData *);  // Source interface name
int on_spinbutton16_value_changed (GtkWidget *, SPSData *);  // Maximum transmission unit (MTU)
int on_entry298_activate (GtkWidget *, SPSData *);  // Ethernet type code
// IPv6 header
int on_entry299_activate (GtkWidget *, SPSData *);  // IP version
int on_entry300_activate (GtkWidget *, SPSData *);  // Traffic class
int on_entry301_activate (GtkWidget *, SPSData *);  // Flow label
int on_entry302_activate (GtkWidget *, SPSData *);  // Payload length
int on_entry303_activate (GtkWidget *, SPSData *);  // Next header
int on_entry304_activate (GtkWidget *, SPSData *);  // Hop limit
int on_entry305_activate (GtkWidget *, SPSData *);  // Source IPv6 address
int on_entry306_activate (GtkWidget *, SPSData *);  // Destination IPv6 address
// UDP header (IPv6)
int on_entry307_activate (GtkWidget *, SPSData *);  // Source Port
int on_checkbutton40_toggled (GtkButton *, SPSData *);  // Randomize Source Port
int on_entry308_activate (GtkWidget *, SPSData *);  // Destination Port
int on_entry309_activate (GtkWidget *, SPSData *);  // Length of UDP Datagram
int on_entry310_activate (GtkWidget *, SPSData *);  // UDP Checksum
int on_radiobutton39_toggled (GtkButton *, SPSData *);  // ASCII data entry
int on_radiobutton40_toggled (GtkButton *, SPSData *);  // Hexadecimal data entry
int on_entry311_activate (GtkWidget *, SPSData *);  // UDP Data from keyboard
int on_button44_clicked (GtkButton *, SPSData *);  // UDP data from file
// Extension headers
int on_button103_clicked (GtkWidget *, SPSData *);  // Hop-by-hop extension header
int on_button115_clicked (GtkWidget *, SPSData *);  // Destination extension header
int on_button137_clicked (GtkWidget *, SPSData *);  // Routing extension header
int on_button121_clicked (GtkWidget *, SPSData *);  // Authentication extension header
int on_button131_clicked (GtkWidget *, SPSData *);  // Encapsulating security payload (ESP) extension header

int on_button43_clicked (GtkButton *, SPSData *);  // View IPv6 UDP packet
int on_button45_clicked (GtkButton *, SPSData *);  // Restore IPv6 UDP default values

// Extension header pages

// Hop-by-hop extension header callback functions
int on_hop_window_destroy (GtkWidget *, SPSData *);  // Set hop_flag to zero when hop_window is destroyed
int on_button142_clicked (GtkButton *, SPSData *);  // Toggle: attach / detach a hop-by-hop header
int on_entry438_activate (GtkWidget *, SPSData *);  // Hop-by-hop header length
int on_radiobutton59_toggled (GtkButton *, SPSData *);  // Decimal option data entry
int on_radiobutton60_toggled (GtkButton *, SPSData *);  // Hexadecimal option data entry
int on_entry158_activate (GtkWidget *, SPSData *);  // Hop-by-hop option data
int on_entry313_activate (GtkWidget *, SPSData *);  // Option alignment parameter x (of xN + y)
int on_entry314_activate (GtkWidget *, SPSData *);  // Option alignment parameter y (of xN + y)
int on_button94_clicked (GtkButton *, SPSData *);  // Insert hop-by-hop option after...
int on_entry159_activate (GtkWidget *, SPSData *);  // Option number after which to insert new option
int on_button95_clicked (GtkButton *, SPSData *);  // Append hop-by-hop option
int on_button96_clicked (GtkButton *, SPSData *);  // View hop-by-hop options
int on_entry312_activate (GtkWidget *, SPSData *);  // Option number to remove
int on_button97_clicked (GtkButton *, SPSData *);  // Remove option

// Destination extension header callback functions
int on_dst_window_destroy (GtkWidget *, SPSData *);  // Set dst_flag to zero when dst_window is destroyed
int on_button143_clicked (GtkButton *, SPSData *);  // Toggle: attach / detach a "first" destination header
int on_button144_clicked (GtkButton *, SPSData *);  // Toggle: attach / detach a "last" destination header
int on_entry439_activate (GtkWidget *, SPSData *);  // Destination header length (first)
int on_entry440_activate (GtkWidget *, SPSData *);  // Destination header length (last)
int on_radiobutton61_toggled (GtkButton *, SPSData *);  // Decimal option data entry
int on_radiobutton62_toggled (GtkButton *, SPSData *);  // Hexadecimal option data entry
int on_entry315_activate (GtkWidget *, SPSData *);  // Destination option data
int on_entry156_activate (GtkWidget *, SPSData *);  // Option alignment parameter x (of xN + y)
int on_entry157_activate (GtkWidget *, SPSData *);  // Option alignment parameter y (of xN + y)
int on_radiobutton63_toggled (GtkButton *, SPSData *);  // Designate as first destination header
int on_radiobutton64_toggled (GtkButton *, SPSData *);  // Designate as last destination header
int on_button104_clicked (GtkButton *, SPSData *);  // Insert destination option after...
int on_entry431_activate (GtkWidget *, SPSData *);  // Option number after which to insert new option
int on_button105_clicked (GtkButton *, SPSData *);  // Append destination option
int on_button106_clicked (GtkButton *, SPSData *);  // View destination options (first)
int on_button109_clicked (GtkButton *, SPSData *);  // View destination options (last)
int on_entry432_activate (GtkWidget *, SPSData *);  // Option number to remove
int on_button107_clicked (GtkButton *, SPSData *);  // Remove option

// Routing extension header callback functions
int on_route_window_destroy (GtkWidget *, SPSData *);  // Set route_flag to zero when route_window is destroyed
int on_button145_clicked (GtkButton *, SPSData *);  // Toggle: attach / detach a routing header
int on_entry446_activate (GtkWidget *, SPSData *);  // Header length
int on_entry447_activate (GtkWidget *, SPSData *);  // Routing type
int on_entry448_activate (GtkWidget *, SPSData *);  // Segments left
int on_radiobutton73_toggled (GtkButton *, SPSData *);  // Decimal routing data entry
int on_radiobutton74_toggled (GtkButton *, SPSData *);  // Hexadecimal routing data entry
int on_entry449_activate (GtkWidget *, SPSData *);  // Routing data
int on_button125_clicked (GtkButton *, SPSData *);  // Load routing data from file ...

// Authentication extension header callback functions
int on_auth_window_destroy (GtkWidget *, SPSData *);  // Set auth_flag to zero when auth_window is destroyed
int on_button138_clicked (GtkButton *, SPSData *);  // Toggle: attach / detach an authentication header
int on_button139_clicked (GtkButton *, SPSData *);  // Toggle: transport / tunnel mode
int on_entry433_activate (GtkWidget *, SPSData *);  // Payload length
int on_entry434_activate (GtkWidget *, SPSData *);  // Reserved
int on_entry435_activate (GtkWidget *, SPSData *);  // Security parameters index (SPI)
int on_entry436_activate (GtkWidget *, SPSData *);  // Sequence number
int on_radiobutton67_toggled (GtkButton *, SPSData *);  // Decimal integrity check value (ICV) entry
int on_radiobutton68_toggled (GtkButton *, SPSData *);  // Hexadecimal integrity check value (ICV) entry
int on_entry437_activate (GtkWidget *, SPSData *);  // Integrity check value (ICV)
int on_button108_clicked (GtkButton *, SPSData *);  // Load ICV from file ...
int on_button122_clicked (GtkButton *, SPSData *);  // Save data for ICV calculation

// Encapsulating security payload (ESP) extension header callback functions
int on_esp_window_destroy (GtkWidget *, SPSData *);  // Set esp_flag to zero when esp_window is destroyed
int on_button140_clicked (GtkButton *, SPSData *);  // Toggle: attach / detach an ESP header
int on_button141_clicked (GtkButton *, SPSData *);  // Toggle: transport / tunnel mode
int on_entry441_activate (GtkWidget *, SPSData *);  // Security parameters index (SPI)
int on_entry442_activate (GtkWidget *, SPSData *);  // Sequence number
int on_button123_clicked (GtkButton *, SPSData *);  // Save data for ICV calculation
int on_entry443_activate (GtkWidget *, SPSData *);  // Padding length
int on_entry444_activate (GtkWidget *, SPSData *);  // Next header
int on_radiobutton71_toggled (GtkButton *, SPSData *);  // Decimal integrity check value (ICV) entry
int on_radiobutton72_toggled (GtkButton *, SPSData *);  // Hexadecimal integrity check value (ICV) entry
int on_entry445_activate (GtkWidget *, SPSData *);  // Integrity check value (ICV)
int on_button124_clicked (GtkButton *, SPSData *);  // Load ICV from file ...

// IP / ASN delegation page
int on_checkbutton38_toggled (GtkButton *button, SPSData *);  // Change state of flag to show sent and received messages during file downloads
int on_button50_clicked (GtkButton *, SPSData *);  // Download ARIN delegation file.
int on_button51_clicked (GtkButton *, SPSData *);  // Download RIPE delegation file.
int on_button52_clicked (GtkButton *, SPSData *);  // Download AFRINIC delegation file.
int on_button53_clicked (GtkButton *, SPSData *);  // Download APNIC delegation file.
int on_button54_clicked (GtkButton *, SPSData *);  // Download LACNIC delegation file.
int on_button55_clicked (GtkButton *, SPSData *);  // Download www.iso.org's ISO 3166-1 country code list.
int on_button56_clicked (GtkButton *, SPSData *);  // View www.iso.org's ISO 3166-1 country code list.
int on_button57_clicked (GtkButton *, SPSData *);  // Download all RIR files and www.iso.org's country code list.
int on_entry500_activate (GtkWidget *, SPSData *);  // Country name (for country name/code search).
int on_entry501_activate (GtkWidget *, SPSData *);  // Country code (for country name/code search).
int on_entry502_activate (GtkWidget *, SPSData *);  // Search for autonomous system (AS) number delegations by country name.
int on_entry503_activate (GtkWidget *, SPSData *);  // Search for autonomous system (AS) number delegations by country code.
int on_entry504_activate (GtkWidget *, SPSData *);  // Reverse search for country by autonomous system (AS) number delegations.
int on_entry505_activate (GtkWidget *, SPSData *);  // Search for IP delegations by country name.
int on_entry506_activate (GtkWidget *, SPSData *);  // Search for IP delegations by country code.
int on_entry507_activate (GtkWidget *, SPSData *);  // Reverse-search for IPv4 address delegations by IPv4 address.
int on_entry508_activate (GtkWidget *, SPSData *);  // Reverse-search for IPv6 address delegations by IPv6 address.

// Pseudo-random number generator page
int on_entry319_activate (GtkWidget *, SPSData *);  // Seed for PRNG
int on_entry320_activate (GtkWidget *, SPSData *);  // Stride for PRNG

// ********** NON-CALLBACK FUNCTION PROTOTYPES **********

// Send packet functions, with respective filenames.
int ipv4_send (SPSData *);  // Send IPv4 packet(s) (ipv4_send.c).
int update_ip4_sources (SPSData *);  // (idle function) Update source IPv4 addresses and source ports, which may have changed if randomized.
int ipv6_send (SPSData *);  // Send IPv6 packet(s) (ipv6_send.c).
int update_ip6_sources (SPSData *);  // (idle function) Update source IPv6 addresses and source ports, which may have changed if randomized.
int sixto4_send (SPSData *);  // Send IPv6 packet(s) over IPv4 (6to4) (sixto4_send.c).
int update_6to4_sources (SPSData *);  // (idle function) Update source 6to4 IPv4 addresses, which may have changed if randomized.

// Maximum transmission unit (MTU) functions (mtu.c)
int interface_getmtu (char *, GtkWidget *, SPSData *);  // Obtain interface's current MTU setting.
int check_mtu (int, SPSData *);  // Check if current MTU is sufficiently large to accomodate packet.
int min4_mtu (int, SPSData *);  // Find minimum MTU for IPv4 packet.
int min6_mtu (int, SPSData *);  // Find minimum MTU for IPv6 packet.
int min6to4_mtu (int, SPSData *);  // Find minimum MTU for 6to4 packet.
int change_mtu (int, int, SPSData *);  // Change maximum transmission unit (MTU).
int report_mtu_change (int, int, SPSData *);  // Report then MTU was changed.

// Ethernet header functions (ethernet_header.c)
int mac_entry (GtkWidget *, uint8_t *, int, SPSData *);  // Process link-layer (MAC) address entry.
int ifname_entry (GtkWidget *, char *, uint8_t *, GtkWidget *, int, SPSData *);  // Find link-layer (MAC) address for given interface name entry.
int ethtype_entry (GtkWidget *, int, SPSData *);  // Process ethernet type code entry.
int mac_bin2string (uint8_t *, char *);  // Convert link-layer (MAC) address from binary to colon-separated string.
int mac_string2bin (char *, uint8_t *);  // Convert link-layer (MAC) address from colon-separated string to binary.

// IPv4 header functions (ipv4_header.c)
int ip4_hdrlen_entry (GtkWidget *, int, SPSData *);  // Process IPv4 header length entry.
int ip4_ver_entry (GtkWidget *, int, SPSData *);  // Process IPv4 header IP version entry.
int ip4_tos_entry (GtkWidget *, int, SPSData *);  // Process IPv4 type of service entry.
int ip4_tld_entry (GtkWidget *, int, SPSData *);  // Process IPv4 total length of datagram entry.
int ip4_seq_entry (GtkWidget *, int, SPSData *);  // Process IPv4 ID sequence number entry.
int ip4_zero_entry (GtkWidget *, GtkWidget *, GtkWidget *, GtkWidget *, int, SPSData *);  // Process IPv4 zero entry.
int ip4_dnf_entry (GtkWidget *, GtkWidget *, GtkWidget *, GtkWidget *, int, SPSData *);  // Process IPv4 do not fragment entry.
int ip4_mff_entry (GtkWidget *, GtkWidget *, GtkWidget *, GtkWidget *, int, SPSData *);  // Process IPv4 more fragments following entry.
int ip4_fo_entry (GtkWidget *, GtkWidget *, GtkWidget *, GtkWidget *, int, SPSData *);  // Process IPv4 fragmentation offset entry.
int ip4_ttl_entry (GtkWidget *, int, SPSData *);  // Process IPv4 time-to-live entry.
int ip4_tlp_entry (GtkWidget *, int, SPSData *);  // Process IPv4 transport layer protocol entry.
int ip4_sip_entry (GtkWidget *, int, SPSData *);  // Process IPv4 source IP address entry.
int ip4_ransip_checkbutton (int *, GtkWidget *, int, SPSData *);  // Process toggled checkbutton for randomizing IPv4 source IP address.
int ip4_dip_entry (GtkWidget *, int, SPSData *);  // Process IPv4 destination IP address entry.
int ip4_chksum_entry (GtkWidget *, int, SPSData *);  // Process IPv4 checksum entry.
int ip4_hlen (int, SPSData *);  // Re-calculate IPv4 header length and update text entry.
int ip4_tld (int, SPSData *);  // Re-calculate total length of IPv4 datagram and update text entry.
int truncate_ip4 (int, SPSData *);  // Truncate IPv4 payload length as necessary to accomodate the variable lengths of IPv4 header options and TCP options.
int ip4_chksum (int, SPSData *);  // Re-calculate IPv4 checksum and update text entry.
int ip4data_update (int, SPSData *);  // Update IPv4: total length of datagram and checksum, Upper layer protocol: length, offset, and checksum.

// IPv4 and TCP options functions (ipv4_and_tcp_options.c)
int compose_optstring (int, char *, int, int **, uint8_t ***, int);  // Prepare a string of text containing IPv4 or TCP options.
int ip4_option (int, int, int, GtkWidget *, GtkWidget *, SPSData *);  // Insert, remove, or append an IPv4 option.
int ip4_opt_insert_after_entry (GtkWidget *, int, int *, SPSData *);  // Number of option after which to insert new IPv4 option.
int opt_view (int, int, SPSData *);  // View IPv4 header options or TCP header (IPv4 or IPv6) options.
int ip4_opt_remove_entry (GtkWidget *, int, int *, SPSData *);  // Number of IPv4 option to remove.

// Data entry for IPv4 header or TCP header options, hop-by-hop header or destination header options, or other extension header data (data_entry.c).
int data_entry (GtkWidget *, int *, int, uint8_t *, int, GtkWidget *, SPSData *);

// IPv6 header functions (ipv6_header.c)
int ip6_ver_entry (GtkWidget *, int, SPSData *);  // Process IPv6 header IP version entry.
int ip6_tc_entry (GtkWidget *, int, SPSData *);  // Process IPv6 traffic class entry.
int ip6_fl_entry (GtkWidget *, int, SPSData *);  // Process IPv6 flow label entry.
int ip6_plen_entry (GtkWidget *, int, SPSData *);  // Process IPv6 payload length entry.
int ip6_nxt_entry (GtkWidget *, int, SPSData *);  // Process IPv6 next header entry.
int ip6_hops_entry (GtkWidget *, int, SPSData *);  // Process IPv6 hop limit entry.
int ip6_sip_entry (GtkWidget *, int, SPSData *);  // Process IPv6 source IP address entry.
int ip6_ransip_checkbutton (int *, GtkWidget *, int, SPSData *);  // Process toggled checkbutton for randomizing IPv6 source IP address.
int ip6_dip_entry (GtkWidget *, int, SPSData *);  // Process IPv6 destination IP address entry.
int truncate_ip6 (int, SPSData *);  // Truncate IPv6 payload length as necessary to accomodate the variable lengths of extension headers and TCP options.
int ip6_paylen (int, SPSData *);  // Re-calculate IPv6 payload length and update text entry.
int ip6data_update (int, SPSData *);  // Update IPv6: payload length, Upper layer protocol: length, offset, and checksum.

// Hop-by-hop and destination extension header functions (hop_and_dst_headers.c)
int hop_win (SPSData *);  // Create hop-by-hop extension header editing window.
int hop_show (int, SPSData *);  // Display contents of selected hop-by-hop header.
int dst_win (SPSData *);  // Create destination extension header editing window.
int dst_show (int, SPSData *);  // Display contents of selected destination header.
int compose_exoptstring (int, char *, int, int **, uint8_t ***, SPSData *);  // Prepare a string of text containing hop-by-hop or destination header options.
int dsthop_option (int, int, GtkWidget *, GtkWidget *, SPSData *);  // Insert, remove, or append a hop-by-hop or destination option.
int dsthop_opt_insert_after_entry (GtkWidget *, int *);  // Number of option after which to insert new hop-by-hop or destination option.
int dsthop_opt_view (int, SPSData *);  // View hop-by-hop or destination header options.
int dsthop_opt_remove_entry (GtkWidget *, int *);  // Number of hop-by-hop or destination option to remove.
int option_pad (int *, uint8_t *, int, int, int);  // Provide padding as needed to achieve alignment requirements of hop-by-hop or destination option.

// Routing extension header functions (routing_header.c)
int route_win (SPSData *);  // Create routing extension header editing window.
int route_show (int, SPSData *);  // Display contents of selected routing header.
int update_route_len (int, SPSData *);  // Update routing header length.

// Authentication extension header functions (auth_header.c)
int auth_win (SPSData *);  // Create authentication extenstion header editing window.
int auth_show (int, SPSData *);  // Display contents of selected authentication header.
int update_auth_pad (int, SPSData *);  // Update authentication header payload and padding length.

// Encapsulating security payload (ESP) extension header functions (esp_header.c)
int esp_win (SPSData *);  // Create ESP extenstion header editing window.
int esp_show (int, SPSData *);  // Display contents of selected ESP header.
int update_esp_pad (int, SPSData *);  // Update encapsulating security payload (ESP) header payload and padding length.

// TCP header functions (tcp_header.c)
int tcp_sport_entry (GtkWidget *, int, SPSData *);  // Process TCP source port entry.
int tcp_ran_sport (int *, int, GtkWidget *, SPSData *);  // Create a random TCP source port number (16 bits).
int tcp_dport_entry (GtkWidget *, int, SPSData *);  // Process TCP destination port entry.
int tcp_seqnum_entry (GtkWidget *, int, SPSData *);  // Process TCP sequence number entry.
int tcp_acknum_entry (GtkWidget *, int, SPSData *);  // Process TCP acknowledgement number entry.
int tcp_res_entry (GtkWidget *, int, SPSData *);  // Process TCP reserved entry.
int tcp_off_entry (GtkWidget *, int, SPSData *);  // Process TCP data offset entry.
int tcp_fin_entry (GtkWidget *, int, SPSData *);  // Process TCP FIN flag entry.
int tcp_syn_entry (GtkWidget *, int, SPSData *);  // Process TCP SYN flag entry.
int tcp_rst_entry (GtkWidget *, int, SPSData *);  // Process TCP RST flag entry.
int tcp_psh_entry (GtkWidget *, int, SPSData *);  // Process TCP PSH flag entry.
int tcp_ack_entry (GtkWidget *, int, SPSData *);  // Process TCP ACK flag entry.
int tcp_urg_entry (GtkWidget *, int, SPSData *);  // Process TCP URG flag entry.
int tcp_ece_entry (GtkWidget *, int, SPSData *);  // Process TCP ECE flag entry.
int tcp_cwr_entry (GtkWidget *, int, SPSData *);  // Process TCP CWR flag entry.
int tcp_win_entry (GtkWidget *, int, SPSData *);  // Process TCP window size entry.
int tcp_chksum_entry (GtkWidget *, int, SPSData *);  // Process TCP checksum entry.
int tcp_urgptr_entry (GtkWidget *, int, SPSData *);  // Process TCP urgent pointer entry.
int tcp4_option (int, int, int, GtkWidget *, SPSData *);  // Insert, remove, or append an IPv4 TCP option.
int tcp6_option (int, int, int, GtkWidget *, SPSData *);  // Insert, remove, or append an IPv6 TCP option.
int tcp_opt_insert_after_entry (GtkWidget *, int, int *, SPSData *);  // Number of option after which to insert new TCP option.
int tcp_opt_remove_entry (GtkWidget *, int, int *, SPSData *);  // Number of TCP option to remove.
int tcp_dataoffset (int, SPSData *);  // Re-calculate TCP data offset and update text entry (IPv4 and IPv6).
int tcp_chksum (int, SPSData *);  // Re-calculate TCP checksum and update text entry (IPv4 or IPv6).

// ICMP header functions (icmp_header.c)
int icmp_mt_entry (GtkWidget *, int, SPSData *);  // Process ICMP message type entry.
int icmp_mc_entry (GtkWidget *, int, SPSData *);  // Process ICMP message code entry.
int icmp_chksum_entry (GtkWidget *, int, SPSData *);  // Process ICMP checksum entry.
int icmp_id_entry (GtkWidget *, int, SPSData *);  // Process ICMP ID number entry.
int icmp_seq_entry (GtkWidget *, int, SPSData *);  // Process ICMP sequence number entry.
int icmp_chksum (int, SPSData *);  // Re-calculate ICMP checksum and update text entry (IPv4 or IPv6).

// UDP header functions (udp_header.c)
int udp_sport_entry (GtkWidget *, int, SPSData *);  // Process UDP source port entry.
int udp_ran_sport (int *, int, GtkWidget *, SPSData *);  // Create a random UDP source port number (16 bits).
int udp_dport_entry (GtkWidget *, int, SPSData *);  // Process UDP destination port entry.
int udp_len_entry (GtkWidget *, int, SPSData *);  // Process length of UDP datagram entry.
int udp_chksum_entry (GtkWidget *, int, SPSData *);  // Process UDP checksum entry.
int udp_len (int, SPSData *);  // Re-calculate length of UDP datagram and update text entry (IPv4 or IPv6).
int udp_chksum (int, SPSData *);  // Re-calculate UDP checksum and update text entry (IPv4 or IPv6).

// Default settings functions for IPv4 packets (ipv4_defaults.c)
int tcp4_default (SPSData *);  // IPv4 default settings.
int icmp4_default (SPSData *);  // IPv4 default settings.
int udp4_default (SPSData *);  // IPv4 default settings.

// Default settings functions for IPv6 packets (ipv6_defaults.c)
int tcp6_default (SPSData *);  // IPv6 default settings.
int icmp6_default (SPSData *);  // IPv6 default settings.
int udp6_default (SPSData *);  // IPv6 default settings.

// Default settings functions for 6to4 packets (sixto4_defaults.c)
int sixto4_tcp6_default (SPSData *);  // 6to4 default settings.
int sixto4_icmp6_default (SPSData *);  // 6to4 default settings.
int sixto4_udp6_default (SPSData *);  // 6to4 default settings.

// Functions to link IPv6 headers into appropriate order, and perform IPv4 and IPv6 fragmentation
// (header_linking_and_fragmentation.c)
int next_hdr_to_frag (int, struct ip6_hdr *, SPSData *);  // Set the Next Header field to IPPROTO_FRAGMENT in last link of unfragmentable portion.
int find4_unfraglen (int, SPSData *);  // Returns length of unfragmentable portion (IPv4).
int find6_unfraglen (int, SPSData *);  // Returns length of unfragmentable portion (IPv6).
int find4_fraglen (int, SPSData *);  // Returns length of fragmentable portion (IPv4).
int find6_fraglen (int, SPSData *);  // Returns length of fragmentable portion (IPv6).
int build_unfrag (int, struct ip6_hdr *, int *, uint8_t *, SPSData *);  // Build unfragmentable portion of ethernet frame (IPv6).
int build_frag (int, struct ip6_hdr *, uint8_t *, SPSData *);  // Build fragmentable portion of ethernet frame (IPv6).
int ip6_chain (int, struct ip6_hdr *, SPSData *);  // Setup chain of header, extension headers, and data by setting Next Header fields (IPv6).
int ip6_order (int, SPSData *);  // Set order of all headers, extension headers, and data. Determine where in chain to separate unfragmentable from fragmentable (IPv6).
int set_proto (int val);  // Return appropriate protocol type value (IPPROTO), depending upon SPS header type index (IPv6).
int find_nframes (int, int, int, int, int *, int *, int *);  // Determine required number of IPv6 ethernet frames, frame lengths, and data offsets (IPv4 or IPv6).

// Function to process keyboard entry of upper layer protocol data (IPv4 or IPv6) (keyboard_data.c).
int key_data (GtkWidget *, int, int, SPSData *);

// Functions for loading upper layer protocol data from file (file_data.c)
int file_payload_data (GtkWidget *, int, SPSData *);  // Entry from file of upper layer protocol data (IPv4 or IPv6).
int file_data (GtkWidget *, int *, int, uint8_t *, int, GtkWidget *, SPSData *);  // Extension header data entry from file (ipv6).

// Create an IPv4 ethernet frame (create_ip4_frame.c).
int create_ip4_frame (int, SPSData *);

// Create an IPv6 ethernet frame (create_ip6_frame.c).
int create_ip6_frame (int, SPSData *);

// Create an IPv6 over IPv4 (6to4) ethernet frame (create_6to4_frame.c).
int create_6to4_frame (int, SPSData *);

// Functions to show traceroute settings on Traceroute page of sps.ui (show_traceroute_settings.c).
int tr_settings_show (SPSData *);

// IPv4 traceroute functions (ipv4_traceroute.c)
int ipv4_tr_send (SPSData *);  // Perform IPv4 traceroute.
int free_ipv4_tr_mem (char *, uint8_t *, char *, char *, char *);  // Free allocated memory used in ipv4_tr_send().
int update_tr_ip4_sources (SPSData *);  // (idle function) Update IPv4 traceroute source ports, which may have changed if randomized.
int tcp4_tr_show (SPSData *);  // Populate entries in traceroute.ui window.
int icmp4_tr_show (SPSData *);  // Populate entries in traceroute.ui window.
int udp4_tr_show (SPSData *);  // Populate entries in traceroute.ui window.

// IPv6 traceroute functions (ipv6_traceroute.c)
int ipv6_tr_send (SPSData *);  // Perform IPv6 traceroute.
int free_ipv6_tr_mem (char *, uint8_t *, char *, char *, char *);  // Free allocated memory used in ipv6_tr_send().
int update_tr_ip6_sources (SPSData *);  // (idle function) Update IPv6 traceroute source ports, which may have changed if randomized.
int tcp6_tr_show (SPSData *);  // Populate entries in traceroute.ui window.
int icmp6_tr_show (SPSData *);  // Populate entries in traceroute.ui window.
int udp6_tr_show (SPSData *);  // Populate entries in traceroute.ui window.

// 6to4 traceroute functions (sixto4_traceroute.c)
int sixto4_tr_send (SPSData *);  // Perform IPv6 over IPv4 (6to4) traceroute.
int free_sixto4_tr_mem (char *, uint8_t *, char *, char *, char *, char *);  // Free allocated memory used in sixto4_tr_send()..
int sixto4_tr_show (SPSData *);  // Populate entries in traceroute.ui window.

// IPv4 traceroute default settings functions (ipv4_traceroute_defaults.c)
int tcp4_tr_default (SPSData *);  // IPv4 traceroute default settings.
int icmp4_tr_default (SPSData *);  // IPv4 traceroute default settings.
int udp4_tr_default (SPSData *);  // IPv4 traceroute default settings.

// IPv6 traceroute default settings functions (ipv6_traceroute_defaults.c)
int tcp6_tr_default (SPSData *);  // IPv6 traceroute default settings.
int icmp6_tr_default (SPSData *);  // IPv6 traceroute default settings.
int udp6_tr_default (SPSData *);  // IPv6 traceroute default settings.

// 6to4 traceroute default settings functions (sixto4_traceroute_defaults.c)
int sixto4_tcp6_tr_default (SPSData *);  // 6to4 traceroute default settings.
int sixto4_icmp6_tr_default (SPSData *);  // 6to4 traceroute default settings.
int sixto4_udp6_tr_default (SPSData *);  // 6to4 traceroute default settings.

// RIR IP / ASN delegation FTP functions (ftp.c)
int ftp_rir (SPSData *);  // FTP function to retrieve RIR delegation files.
int free_rir_mem (char *, char *, char *, SPSData *);  // Free allocated memory used in ftp_rir().
int download_all (SPSData *);  // Download all RIR delegation files and country code file.
int cntl_sock (char *, char *, SPSData *);  // Request a socket descriptor for FTP control socket.
int data_sock (char *, int, SPSData *);  // Request a socket descriptor for FTP data socket.
int cntl_send (int, char *, SPSData *);  // Send a command to FTP control socket.
int cntl_recv (int, SPSData *);  // Receive FTP command responses from remote host on the control socket.
int parse_ip4_port (char *, int *, SPSData *);  // Extract IPv4 address and port number for creating FTP data socket in passive mode.
int parse_ip6_port (int *, SPSData *);  // Extract port number for creating IPv6 FTP data socket in passive mode.
int data_recv (SPSData *);  // Receive and save data on the FTP data socket.
int rir_loading (SPSData *);  // (idle function) Change RIR delegation file status to "Loading".
int rir_not_available (SPSData *);  // (idle function) Change RIR delegation file status to "Not Available" because an error occurred while downloading.
int rir_available (SPSData *);  // (idle function) Update RIR delegation file status.
GtkTextBuffer *rir_textview (int, SPSData *);  // Return pointer to RIR file status textbuffer based on RIR index.

// HTTP functions (http.c)
int get_countries (SPSData *);  // Retrieve www.iso.org's ISO 3166-1 country code list.
int http_sock (char *, char *, const char *, SPSData *);  // Request socket descriptor for HTTP connection.
int send_get (int, char *, SPSData *);  // Send HTTP GET.
int http_recv (int, char *, int *, int *, SPSData *);  // Receive data resulting from HTTP GET.
int save_data (char *, int *, int *, char *, SPSData *);  // Save received data to file.
int cc_loading (SPSData *);  // (idle function) Change country code file status to "Loading".
int cc_not_available (SPSData *);  // (idle function) Change country code file status to "Not Available" because an error occurred while downloading.
int cc_available (SPSData *);  // (idle function) Update country code file status.

// Functions for reading and searching ASN / IP delegation files and www.iso.org's ISO 3166-1 country code list
// (rir_utils.c)
int all_files_loaded (SPSData *);  // Check to see if all RIR ASN/IP files and country code file are loaded (called prior to any delegation search).
int file_exists (char *);  // Check if a file exists. Return 1 if it exists..
int read_delegation (int, SPSData *);  // Read one Regional Internet Registry ASN / IP delegation file and place into arrays in memory..
int read_countries (SPSData *);  // Read ISO 3166-1 country code list file into an array in memory..
int find_country_code (char *, char *, SPSData *);  // Search www.iso.org's country name/code list for a country name.
int find_country_name (char *, char *, SPSData *);  // Search www.iso.org's country name/code list for a country code.
int search_asn_by_ccode (SPSData *);  // Search for ASN delegations by country code.
int rev_search_asn (SPSData *);  // Search delegation files for asn. Return country code/name.
int search_ipv4_by_ccode (SPSData *);  // Search for IPv4 address delegations by country code.
int rev_search_ipv4 (SPSData *);  // Search delegation files for IPv4 address. Return country code/name.
int search_ipv6_by_ccode (SPSData *);  // Search for IPv6 address delegations by country code.
int rev_search_ipv6 (SPSData *);  // Search delegation files for IPv6 address. Return country code/name.

// Function to update all randomized parameters (update_ran_parms.c).
int update_ran_parms (SPSData *);  // Called only if PRNG seed is changed.

// Miscellaneous functions (misc_utils.c)
int hexascii_listing (uint8_t *, int, char *, int);  // Prepare a string of text containing a hexadecimal and ASCII listing of data.
int alphanum_and_symbols (uint8_t *, int, char *);  // Copy data to ascii array but only allow alphanumerics and symbols.
int bin8_to_dec (int *);  // Convert 8-bit binary number to decimal.
int is_valid_ip4 (const char *);  // Check if valid IPv4 address.
int is_valid_hexdata (const char *, SPSData *);  // Check string for valid comma-separated hexadecimal values.
int is_valid_hex (char);  // Check for valid hexadecimal character.
int is_valid_decdata (const char *, SPSData *);  // Check string for valid comma-separated decimal values.
int is_valid_dec (char);  // Check for valid decimal. Called from is_valid_decdata().
int is_ascii_uint (const char *);  // Check for non-numeric ASCII characters.
int64_t ascii_to_int64 (char *);  // Convert an ASCII representation of a 64-bit integer into a 64-bit integer.
void *get_in_addr (struct sockaddr *);  // Get sockaddr (IPv4 or IPv6). - from Brian “Beej Jorgensen” Hall (beej@beej.us)
int carry (int, int, int *, int *);  // Recursive carry function for numerical subtraction.
int parse_ipv4 (char *, unsigned int *);  // Parse character string into 4-byte IPv4 address.
int show_cidr_or_range (unsigned int, unsigned int *, char *);  // Express IPv4 span in CIDR notation or as range.
int parse_ipv6 (char *, unsigned int *);  // Parse character string into 16-byte IPv6 address.
int interval_test_ipv4 (char *, char *, unsigned int);  // Test if an IPv4 address is within a range of IPv4 addresses.
int interval_test_ipv6 (char *, char *, unsigned int);  // Test if an IPv6 address is within a range of IPv6 addresses.
int skip_type (int, SPSData *);  // Cross-reference between "save type" index and packet type index.
int read_line (FILE *, char *, int);  // Read a single line of text from a text file.
int clear_textview (GtkWidget *);  // Clear a textview.

// UTF-8 functions (utf-8.c)
int is_valid_utf8 (uint8_t *, int, GtkWidget *, SPSData *);  // Examine an array and report any non-UTF-8 characters.
int raise_case (uint8_t *, int, uint8_t *, GtkWidget *, SPSData *);  // Convert any lower case UTF-8 letters to upper case.
int is_small_utf8_letter (uint8_t *, SPSData *);  // Determine if a character is an lower case UTF-8 letter.
int find_val (uint8_t *, int *, SPSData *);  // Find a UTF-8 character's byte sequence in cross-reference array.
uint8_t *utf8_value (uint8_t *, uint8_t *);  // Convert ascii representation of UTF-8 byte sequence to uint8_t byte sequence.
int one_byte (int, int, uint8_t *);  // Determine if input is a 1-byte UTF-8 character.
int two_byte (int, int, uint8_t *);  // Determine if input is a 2-byte UTF-8 character.
int three_byte (int, int, uint8_t *);  // Determine if input is a 3-byte UTF-8 character.
int four_byte (int, int, uint8_t *);  // Determine if input is a 4-byte UTF-8 character.
int five_byte (int, int, uint8_t *);  // Determine if input is a 5-byte UTF-8 character.
int six_byte (int, int, uint8_t *);  // Determine if input is a 6-byte UTF-8 character.
int load_utf8 (SPSData *);  // Load the UTF-8 cross-reference file UTF8_FILENAME into an array.

// Pseudo-random number generation and associated functions.
uint16_t ran16_0to65535 (SPSData *);  // Generate pseudo-random numbers from 0 to 65535, inclusive.
char *ran4_addr (char *, SPSData *);  // Generate a pseudo-random IPv4 address.
char *ran6_addr (char *, SPSData *);  // Generate pseudo-random IPv6 address.
double prng (SPSData *);  // Generate a pseudo-random number.
void prng_init (SPSData *);  // Initialize random number parameters for iterate "iter".
uint64_t RN_skip_ahead (int64_t *, SPSData *);  // Skip ahead n pseudo-random numbers.

// Functions for local host's MAC and IP addresses (this_host.c)
int this_host (SPSData *);  // Find this hostname and IP addresses.
char *thishost_ipv4 (char *);  // Find this host's IPv4 address - only used in arp().
uint8_t *interface_getmac (char *, uint8_t *, GtkWidget *, SPSData *);  // Obtain MAC address from interface name.

// Functions to display packet contents (display_packet.c)
int show_packet (int, char **, SPSData *);  // Display packet contents in a pop-up window.

// Perform ARP to obtain MAC address of a node in link-local network (arp.c).
int arp (uint8_t *, const char *, const char *, SPSData *);

// Perform ND to obtain MAC address of a node in link-local network (neighbor_discovery.c).
int neighbor_discovery (uint8_t *, const char *, const char *, SPSData *);

// Warnings and errors functions (errors_and_warnings.c)
int thread_listen (SPSData *);  // (timeout function) Create dialog pop-up for messages/errors from file download or traceroute threads.
int report_warning (SPSData *);  // Report a warning in a pop-up dialog.
int report_error (SPSData *);  // Report an error in a pop-up dialog.
void send_error (void);  // Alert thread_listen() a send error message is available, and reset sending flag.

// Save SPS file, which contains settings selected by user (save_file.c).
int save_file (SPSData *);

// Load SPS file, which contains settings selected by user when saved (load_file.c).
int load_file (SPSData *);

// Textview messaging functions (post_message.c)
Msgdata *packit (Msgdata *, char *);  // Pack Msgdata struct with pointers to a textview and a message string.
int post_message (Msgdata *);  // (idle function) Place message in a textview.

// Checksum functions with respective filenames
uint16_t checksum (uint16_t *, int);  // checksum.c
uint16_t ip4_checksum (struct ip, int, int *, uint8_t **, int);  // ip4_checksum.c
uint16_t tcp4_checksum (struct ip, struct tcphdr, int, int, int *, uint8_t **, int, uint8_t *, int);  // tcp4_checksum.c
uint16_t tcp6_checksum (struct ip6_hdr, struct tcphdr, int, int, int *, uint8_t **, int, uint8_t *, int);  // tcp6_checksum.c
uint16_t icmp4_checksum (struct icmp, uint8_t *, int);  // icmp4_checksum.c
uint16_t icmp6_checksum (struct ip6_hdr, struct icmp6_hdr, uint8_t *, int);  // icmp6_checksum.c
uint16_t udp4_checksum (struct ip, struct udphdr, uint8_t *, int);  // udp4_checksum.c
uint16_t udp6_checksum (struct ip6_hdr, struct udphdr, uint8_t *, int);  // udp6_checksum.c

// Obtain current local host date and time function (date_and_time.c).
char *date_and_time (char *, int);

// Memory allocation functions (allocate.c)
char *allocate_strmem (int);  // Allocate memory for an array chars.
char **allocate_strmemp (int);  // Allocate memory for an array of pointers to arrays of chars.
char *reallocate_strmem (char *, int);  // Reallocate memory for an array of chars. Do not clear contents.
uint8_t *allocate_ustrmem (int);  // Allocate memory for an array of unsigned chars.
uint8_t **allocate_ustrmemp (int);  // Allocate memory for an array pointers to arrays of unsigned chars.
uint8_t ***allocate_ustrmempp (int);  // Allocate memory for an array pointers to arrays of pointers to arrays of unsigned chars.
uint8_t ****allocate_ustrmemppp (int);  // Allocate memory for an array pointers to arrays of pointers to arrays of pointers to arrays of unsigned chars.
uint16_t *allocate_u2strmem (int);  // Allocate memory for an array of unsigned short ints.
int *allocate_intmem (int);  // Allocate memory for an array of ints.
int **allocate_intmemp (int);  // Allocate memory for an array of pointers to arrays of ints.
int nframes_change (int, int, SPSData *);  // Check if number of frames has changed and re-allocate memory as necessary.
Ethhdr *allocate_ethhdr (int);  // Allocate memory for an array of ethernet headers.
struct ip *allocate_ip4hdr (int);  // Allocate memory for an array of IPv4 headers.
struct ip6_hdr *allocate_ip6hdr (int);  // Allocate memory for an array of IPv6 headers.
Hopdst_hdr *allocate_hopdsthdr (int);  // Allocate memory for an array of hop-by-hop or destination extension headers, excluding options.
Route_hdr *allocate_routehdr (int);  // Allocate memory for an array of routing extension headers.
Auth_hdr *allocate_authhdr (int);  // Allocate memory for an array of authentication extension headers.
Esp_hdr *allocate_esphdr (int);  // Allocate memory for an array of encapsulating security payload (ESP) extension headers.
Esp_tail *allocate_esptail (int);  // Allocate memory for an array of encapsulating security payload (ESP) trailers.
struct tcphdr *allocate_tcphdr (int);  // Allocate memory for an array of TCP headers.
struct icmp *allocate_icmp4hdr (int);  // Allocate memory for an array of IPv4 ICMP headers.
struct icmp6_hdr *allocate_icmp6hdr (int);  // Allocate memory for an array of IPv6 ICMP headers.
struct udphdr *allocate_udphdr (int);  // Allocate memory for an array of UDP headers.
Msgdata *allocate_msgdata (int);  // Allocate memory for an array of Msgdata structs.
