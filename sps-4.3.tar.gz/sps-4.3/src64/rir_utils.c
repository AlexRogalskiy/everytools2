/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

extern int ip_asn_searching;  // Flag to indicate an IP delegation search or ASN delegation search thread is active
extern int message_available;  // A message is available to be displayed in a dialog by thread_listen()

G_LOCK_EXTERN (ip_asn_searching);  // MUTEX for flag indicating an ASN delegation search or IP address delegation search thread is active
G_LOCK_EXTERN (message_available);  // MUTEX for flag indicating a message from a download or traceroute thread is available to be displayed in a dialog by thread_listen()

// Check to see if all RIR ASN/IP files and country code file are loaded (called prior to any delegation search)
int
all_files_loaded (SPSData *data)
{
  int i, flag;

  flag = 1;  // Start with the assumption we have all files loaded.

  // Check all five RIR files.
  for (i=0; i<5; i++) {
    if (!data->rir_file_loaded[i]) {
      flag = 0;  // File is not loaded.
      break;
    }
  }

  // Check for country code file.
  if (!data->countries_loaded) {
    flag = 0;  // File is not loaded.
  }

  return (flag);
}

// Check if a file exists. Return 1 if it exists.
int
file_exists (char *filename)
{
  FILE *fp;

  // Does file exist?
  fp = fopen (filename, "r");
  if (fp == NULL) {
    return (0);  // Failed to obtain file descriptor. i.e., file does not exist.
  } else {
    fclose (fp);
  }

  return (1);  // Obtained file desccriptor. i.e., file exists.
}

// Read one Regional Internet Registry ASN / IP delegation file and place into an array in memory.
int
read_delegation (int i, SPSData *data)
{
  int j, k, m, n, p;
  uint8_t *line;
  FILE *fi;

  // Array of unsigned chars
  line = allocate_ustrmem (TEXT_STRINGLEN);

  // Only try to load file if it exists.
  if (file_exists (data->rir_file[i])) {

    // If file already loaded, free allocated memory so we can allocate it anew (data->nrecords might be different).
    // array[rir][record][field] = uint8_t *
    if (data->rir_file_loaded[i]) {
      for (j=0; j<data->nrecords[i]; j++) {  // Use current value for data->nrecords
        for (k=0; k<7; k++) {
          free (data->array[i][j][k]);
        }
        free (data->array[i][j]);
      }
      free (data->array[i]);
    }  // End if already loaded

    // Open Regional Internet Registry (RIR) IP delegation file.
    fi = fopen (data->rir_file[i], "rb");
    if (fi == NULL) {
      sprintf (data->error_text, "read_delegations(): Cannot open RIR delegation file %s.", data->rir_file[i]);
      data->parent = data->main_window;
      report_error (data);
      free (line);
      return (EXIT_FAILURE);
    }

    // Check for empty file.
    if (fgetc (fi) == EOF) {
      sprintf (data->error_text, "read_delegations(): RIR delegation file %s appears to be empty.", data->rir_file[i]);
      data->parent = data->main_window;
      report_error (data);
      free (line);
      return (EXIT_FAILURE);
    }

    // Count all lines in file (excluding comments and blank lines).
    // We will use this for allocating memory.
    rewind (fi);
    data->nrecords[i] = 0;
    for (;;) {  // Loop through all records (lines) in file.

      // Grab next line from file.
      memset (line, 0, TEXT_STRINGLEN * sizeof (uint8_t));
      n = read_line (fi, (char *) line, TEXT_STRINGLEN);

      // End-of-file was reached.
      // read_file() returns -1 when EOF is encountered.
      if (n < 0) {
        break;
      }

      // If line has zero length, then we hit a blank line.
      if (line[0] == 0) {
        continue;  // Don't count as a line in input file.
      }

      // Ignore title line, comments, or lines starting with a space.
      // i.e., ignore a line starting with anything other than a RIR name.
      if ((line[0] < 97) || (line[0] > 122)) {  // a = 97, z = 122
        continue;  // Don't count as a record.
      }

      // Ignore summary lines.
      // Don't count as a record.
      if ((line[5] == '*') || (line[6] == '*') || (line[7] == '*') || (line[8] == '*') || (line[9] == '*') ||
         (line[10] == '*')) {
        continue;
      }

      data->nrecords[i]++;
    }

    // Allocate memory for array[rir][record][field] = uint8_t *
    // It's important not to use excessively large array lengths because it uses
    // so much memory.
    // Some examples:
    //            1         2         3         4         5         6         7         8
    //   12345678901234567890123456789012345678901234567890123456789012345678901234567890
    //   arin|US|asn|393285|1|20131004|assigned|9af3c2422c15eba2fc606550796ddc32
    //   arin|US|ipv4|216.255.240.0|4096|20040528|allocated|675b66a98218436a0f2ef3dc9dfe22ba
    //   arin|US|ipv6|2620:1e0::|32|20120330|assigned|ce654d72bcc4d1861e5293872fae00c5
    data->array[i] = allocate_ustrmempp (data->nrecords[i]);
    for (j=0; j<data->nrecords[i]; j++) {
      data->array[i][j] = allocate_ustrmemp (7);
      data->array[i][j][0] = allocate_ustrmem (8);  // RIR name (longest is "afrinic")
      data->array[i][j][1] = allocate_ustrmem (3);  // Country code
      data->array[i][j][2] = allocate_ustrmem (5);  // "asn", "ipv4", or "ipv6"
      data->array[i][j][3] = allocate_ustrmem (INET6_ADDRSTRLEN);  // Start
      data->array[i][j][4] = allocate_ustrmem (10);  // Value
      data->array[i][j][5] = allocate_ustrmem (10);  // Date as YYYMMDD
      data->array[i][j][6] = allocate_ustrmem (10);  // Status ("assigned", "reserved", or "available")
    }

    // Populate array[rir][record][field][char].
    rewind (fi);
    for (j=0; j<data->nrecords[i]; j++) {  // Loop through records.

      // Grab next line from file.
      memset (line, 0, TEXT_STRINGLEN * sizeof (uint8_t));
      n = read_line (fi, (char *) line, TEXT_STRINGLEN);

      // End-of-file was reached.
      // read_line() returns -1 when EOF is encountered.
      if (n < 0) {
        break;
      }

      // If line has zero length, then we hit a blank line.
      if (line[0] == 0) {
        j--;  // Don't count as a record.
        continue;
      }

      // Ignore title line, comments, or lines starting with a space.
      // i.e., ignore a line starting with anything other than a RIR name.
      if ((line[0] < 97) || (line[0] > 122)) {  // a = 97, z = 122
        j--;  // Don't count as a record.
        continue;
      }

      // Ignore summary lines.
      if ((line[5] == '*') || (line[6] == '*') || (line[7] == '*') || (line[8] == '*') || (line[9] == '*') ||
         (line[10] == '*')) {
        j--;  // Don't count as having extracted a record.
        continue;
      }

      // Extract field data.
      p = 0;  // p is character index for current line.
      for (k=0; k<7; k++) {  // Loop through fields.
        m = 0;
        while (line[p] && (line[p] != '|') && (line[p] != ' ') && (p < TEXT_STRINGLEN)) {
          data->array[i][j][k][m] = line[p];
          m++;
          p++;
        }
        p++;
      }  // End loop fields
    }  // End loop records

    // Close file descriptor.
    fclose (fi);

    // Set flag indicating we have this RIR file in memory.
    data->rir_file_loaded[i] = 1;

  }  // End if file exists.

  // Free allocated memory.
  free (line);

  return (EXIT_SUCCESS);
}

// Read ISO 3166-1 country code list file into an array in memory.
int
read_countries (SPSData *data)
{
  int i, j, k, n, p;
  uint8_t *line;
  FILE *fi;

  // Array of unsigned chars
  line = allocate_ustrmem (TEXT_STRINGLEN);

  // Only try to load file if it exists.
  if (file_exists (data->country_file)) {

    // If file already loaded, free allocated memory so we can allocate it anew (data->ncountries might be different).
    if (data->countries_loaded) {
      for (i=0; i<data->ncountries; i++) {
        for (j=0; j<2; j++) {
          free (data->cc[i][j]);
        }
        free (data->cc[i]);
      }
      free (data->cc);
    }  // End if already loaded

    // Open ISO 3166-1 country code list file.
    fi = fopen (data->country_file, "rb");
    if (fi == NULL) {
      sprintf (data->error_text, "read_countries(): Cannot open country code file %s.", data->country_file);
      data->parent = data->main_window;
      report_error (data);
      free (line);
      return (EXIT_FAILURE);
    }

    // Check for empty file.
    if (fgetc (fi) == EOF) {
      sprintf (data->error_text, "read_countries(): Country code file %s appears to be empty.", data->country_file);
      data->parent = data->main_window;
      report_error (data);
      free (line);
      return (EXIT_FAILURE);
    }

    // Populate array with country code data.

    // Skip the first line; it's just comments.
    if (read_line (fi, (char *) line, TEXT_STRINGLEN) < 0) {
      sprintf (data->error_text, "read_countries(): Country code file %s only appears to have oen line.", data->country_file);
      data->parent = data->main_window;
      report_error (data);
      free (line);
      return (EXIT_FAILURE);
    }

    data->ncountries = 0;
    for (;;) {  // Loop through all records (lines) in file.

      // Grab next line from file.
      memset (line, 0, TEXT_STRINGLEN * sizeof (uint8_t));
      n = read_line (fi, (char *) line, TEXT_STRINGLEN);

      // End-of-file was reached.
      // read_line() returns -1 when EOF is encountered.
      if (n < 0) {
        break;
      }

      // If line has zero length, then we hit a blank line.
      if (line[0] == 0) {
        continue;  // Don't count as a line in input file.
      }

      // Ignore comments or lines starting with a space.
      // Don't count as a record.
      if ((line[0] == '#') || (line[0] == ' ')) {
        continue;
      }

      data->ncountries++;
    }  // End loop through records

    // Allocate memory for country code array cc[record][field] = char *
    data->cc = allocate_ustrmempp (data->ncountries);
    for (i=0; i<data->ncountries; i++) {
      data->cc[i] = allocate_ustrmemp (2);
      for (j=0; j<2; j++) {
        data->cc[i][j] = allocate_ustrmem (TEXT_STRINGLEN);
      }
    }

    // Populate country code array country[record][field][char].

    rewind (fi);

    // Skip the first line; it's just comments.
    if (read_line (fi, (char *) line, TEXT_STRINGLEN) < 0) {
      sprintf (data->error_text, "read_countries(): Country code file %s only appears to have oen line.", data->country_file
);
      data->parent = data->main_window;
      report_error (data);
      free (line);
      return (EXIT_FAILURE);
    }

    for (i=0; i<data->ncountries; i++) {  // Loop through records.

      // Grab next line from file.
      memset (line, 0, TEXT_STRINGLEN * sizeof (uint8_t));
      n = read_line (fi, (char *) line, TEXT_STRINGLEN);

      // End-of-file was reached.
      // read_line() returns -1 when EOF is encountered.
      if (n < 0) {
        break;
      }

      // If line has zero length, then we hit a blank line.
      if (line[0] == 0) {
        i--;  // Don't count as a record.
        continue;
      }

      // Ignore comments or lines starting with a space.
      if ((line[0] == '#') || (line[0] == ' ')) {
        i--;  // Don't count as a record.
        continue;
      }

      // Extract field data.
      p = 0;  // P is character index for current line.
      for (j=0; j<2; j++) {  // Loop through fields.
        k = 0;
        while (line[p] && (line[p] != ';') && (p < TEXT_STRINGLEN)) {
          data->cc[i][j][k] = line[p];
          k++;
          p++;
        }
        p++;
      }  // End loop fields
    }  // End loop records
    fclose (fi);
    data->countries_loaded = 1;  // Set flag indicating we have country code file in memory.
  }  // End if file exists.

  // Free allocated memory.
  free (line);

  return (EXIT_SUCCESS);
}

// Search www.iso.org's country name/code list for a country name. Return country code.
// cc[record][field] = char *
// Field 0 = country name, Field 1 = country code
// e.g., BELGIUM;BE
int
find_country_code (char *cname, char *ccode, SPSData *data)
{
  int i, len1, len2;

  len2 = strnlen (cname, TEXT_STRINGLEN);
  memset (ccode, 0, 3 * sizeof (char));
  for (i=0; i<data->ncountries; i++) {
    len1 = strnlen ((char *) data->cc[i][0], TEXT_STRINGLEN);
    if (len1 != len2) {
      continue;
    } else if (memcmp (data->cc[i][0], cname, len1) == 0) {
      strncpy (ccode, (char *) data->cc[i][1], 2);
      return (1);  // Found country name.
      break;
    }
  }

  return (0);  // Cound not find country name.
}

// Search www.iso.org's country name/code list for a country code. Return country name.
// cc[record][field] = char *
// Field 0 = country name, Field 1 = country code
// e.g., BELGIUM;BE
int
find_country_name (char *cname, char *ccode, SPSData *data)
{
  int i, len1, len2;

  len2 = strnlen (ccode, TEXT_STRINGLEN);
  memset (cname, 0, TEXT_STRINGLEN * sizeof (char));
  for (i=0; i<data->ncountries; i++) {
    len1 = strnlen ((char *) data->cc[i][1], TEXT_STRINGLEN);
    if (len1 != len2) {
      continue;
    } else if (memcmp (data->cc[i][1], ccode, len1) == 0) {
      strncpy (cname, (char *) data->cc[i][0], TEXT_STRINGLEN - 1);  // Minus 1 for string termination.
      return (1);  // Found country code.
      break;
    }
  }

  return (0);  // Could not find country code.
}

// Search for ASN delegations by country code.
// This function will be executed as a separate thread.
int
search_asn_by_ccode (SPSData *data)
{
  uint32_t value, start;
  int i, j, k, c, year, month, day, fail;
  char asns[4], temp[5], *message, *results;
  char mon_name[12][10] = {
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  };
  Msgdata *msgdata;

  // Allocate memory for message local character string.
  message = allocate_strmem (TEXT_STRINGLEN);

  // Allocate memory for string to contain all results.
  results = allocate_strmem (RIR_MEM_BLOCK);
  c = 1;  // Number of RIR_MEM_BLOCKs in use.
  k = 0;  // Index of results array.

  memset (asns, 0, 4 * sizeof (char));
  strncpy (asns, "asn", 3);

  fail = 1;
  for (i=0; i<5; i++) {
    sprintf (message, "Searching %s database...\n", data->rir_name[i]);
    msgdata = allocate_msgdata (1);  // Free'd by idle function post_message().
    msgdata->textview = data->textview16;  // Free'd by idle function post_message().
    g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
    for (j=0; j<data->nrecords[i]; j++) {
      if ((memcmp (data->array[i][j][1], data->ccode, 3) == 0) && (memcmp (data->array[i][j][2], asns, 4) == 0)) {
        message[0] = 0;  // Ensure terminated string; faster than memsetting whole string; speed counts here.
        start = (uint32_t) ascii_to_int64 ((char *) data->array[i][j][3]);
        value = (uint32_t) ascii_to_int64 ((char *) data->array[i][j][4]);
        memcpy (temp, (char *) data->array[i][j][5], 4 * sizeof (char));
        temp[4] = 0;  // Ensure terminated string; faster than memsetting whole string; speed counts here.
        year = (int) ascii_to_int64 (temp);
        memcpy (temp, (char *) (data->array[i][j][5] + 4), 2 * sizeof (char));
        temp[2] = 0;  // Ensure terminated string; faster than memsetting whole string; speed counts here.
        month = (int) ascii_to_int64 (temp) - 1;
        memcpy (temp, (char *) (data->array[i][j][5] + 6), 2 * sizeof (char));
        temp[2] = 0;  // Ensure terminated string; faster than memsetting whole string; speed counts here.
        day = (int) ascii_to_int64 (temp);
        if (year) {  // Date is known if not equal to zero.
          if (value == 1) {
           sprintf (message, "%sASN %i %s to %s (%s) by %s on %s %i, %i.\n", message, start, (char *) data->array[i][j][6], data->cname, data->ccode, data->rir_www[i], mon_name[month], day, year);
          } else {
             sprintf (message, "%sASN %i to ASN %i %s to %s (%s) by %s on %s %i, %i.\n", message, start, start + value - 1, (char *) data->array[i][j][6], data->cname, data->ccode, data->rir_www[i], mon_name[month], day, year);
          }
        } else {  // Date is 00000000, which means it is unavailable.
          if (value == 1) {
           sprintf (message, "%sASN %i %s to %s (%s) by %s (date unavailable).\n", message, start, (char *) data->array[i][j][6], data->cname, data->ccode, data->rir_www[i]);
          } else {
             sprintf (message, "%sASN %i to ASN %i %s to %s (%s) by %s (date unavailable).\n", message, start, start + value - 1, (char *) data->array[i][j][6], data->cname, data->ccode, data->rir_www[i]);
          }
        }

        fail = 0;  // Found at least one match.
        message[TEXT_STRINGLEN - 1] = 0;  // Enforce string termination.
        strncpy (results + k, message, TEXT_STRINGLEN - 1);  // Minus one to allow for string termination
        k += strnlen (message, TEXT_STRINGLEN - 1);
        if (k > ((c * RIR_MEM_BLOCK) - (2 * TEXT_STRINGLEN))) {
          c++;
          results = reallocate_strmem (results, c * RIR_MEM_BLOCK);
          memset (results + ((c - 1) * RIR_MEM_BLOCK), 0, RIR_MEM_BLOCK);
        }
      }
    }
  }

  // Clear any text in the textviews.
  g_idle_add ((GSourceFunc) clear_textview, data->textview16);

  // Found no matches. Report failure to textview.
  if (fail) {
    sprintf (message, "Failed to find any ASN delegations for %s (%s).", data->cname, data->ccode);
    msgdata = allocate_msgdata (1);  // Free'd by idle function post_message().
    msgdata->textview = data->textview16;  // Free'd by idle function post_message().
    g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));

  // Report that search is complete.
  } else {
    memset (message, 0, TEXT_STRINGLEN * sizeof (char));
    sprintf (message, "Search complete.");
    strncat (results, message, TEXT_STRINGLEN - 1);  // Minus one to allow for string termination
    msgdata = allocate_msgdata (1);  // Free'd by idle function post_message().
    msgdata->textview = data->textview16;  // Free'd by idle function post_message().
    g_idle_add ((GSourceFunc) post_message, packit (msgdata, results));
  }

  // Clear ip_asn_searching flag.
  G_LOCK (ip_asn_searching);
  ip_asn_searching = 0;
  G_UNLOCK (ip_asn_searching);

  // Free allocated memory.
  free (message);

  return (EXIT_SUCCESS);
}

// Search delegation files for asn. Return country code/name.
// This function will be executed as a separate thread.
int
rev_search_asn (SPSData *data)
{
  uint32_t value, start;
  int i, j, year, month, day, fail;
  char cname[TEXT_STRINGLEN], asns[4], temp[5], *message;
  char mon_name[12][10] = {
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  };
  Msgdata *msgdata;

  // Allocate memory for message local character string.
  message = allocate_strmem (TEXT_STRINGLEN);

  memset (asns, 0, 4 * sizeof (char));
  strncpy (asns, "asn", 3);
  memset (cname, 0, TEXT_STRINGLEN * sizeof (char));

  fail = 1;
  for (i=0; i<5; i++) {
    for (j=0; j<data->nrecords[i]; j++) {
      if (memcmp (data->array[i][j][2], asns, 4) == 0) {
        memset (message, 0, TEXT_STRINGLEN * sizeof (char));
        start = (uint32_t) ascii_to_int64 ((char *) data->array[i][j][3]);
        value = (uint32_t) ascii_to_int64 ((char *) data->array[i][j][4]);
        if ((start <= data->asn) && (data->asn <= (start + value - 1))) {
          if (!find_country_name (cname, (char *) data->array[i][j][1], data)) {
            strncpy (cname, "[no country name assigned]", TEXT_STRINGLEN - 1);  // Minus 1 for string termination.
          }
          memcpy (temp, (char *) data->array[i][j][5], 4 * sizeof (char));
          temp[4] = 0;  // Ensure terminated string; faster than memsetting whole string; speed counts here.
          year = (int) ascii_to_int64 (temp);
          memcpy (temp, (char *) (data->array[i][j][5] + 4), 2 * sizeof (char));
          temp[2] = 0;  // Ensure terminated string; faster than memsetting whole string; speed counts here.
          month = (int) ascii_to_int64 (temp) - 1;
          memcpy (temp, (char *) (data->array[i][j][5] + 6), 2 * sizeof (char));
          temp[2] = 0;  // Ensure terminated string; faster than memsetting whole string; speed counts here.
          day = (int) ascii_to_int64 (temp);
          if (year) {  // Date is known if not equal to zero.
            if (value == 1) {
              sprintf (message, "%sASN %i %s to %s (%s) by %s on %s %i, %i.\n", message, start, (char *) data->array[i][j][6], cname, (char *) data->array[i][j][1], data->rir_www[i], mon_name[month], day, year);
            } else {
              sprintf (message, "%sASN %i to ASN %i %s to %s (%s) by %s on %s %i, %i.\n", message, start, start + value - 1, (char *) data->array[i][j][6], cname, (char *) data->array[i][j][1], data->rir_www[i], mon_name[month], day, year);
            }
          } else {
            if (value == 1) {
              sprintf (message, "%sASN %i %s to %s (%s) by %s (date unavailable).\n", message, start, (char *) data->array[i][j][6], cname, (char *) data->array[i][j][1], data->rir_www[i]);
            } else {
              sprintf (message, "%sASN %i to ASN %i %s to %s (%s) by %s (date unavailable).\n", message, start, start + value - 1, (char *) data->array[i][j][6], cname, (char *) data->array[i][j][1], data->rir_www[i]);
            }
          }

          // Found a match. Post result to textview.
          fail = 0;
          msgdata = allocate_msgdata (1);  // Free'd by idle function post_message().
          msgdata->textview = data->textview17;  // Free'd by idle function post_message().
          g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
          break;
        }
      }
    }  // End loop j (record)
    if (!fail) break;
  }  // End loop i (RIR)

  // Found no matches. Report failure to textview.
  if (fail) {
    sprintf (message, "Failed to find a delegation for ASN " "%" PRIu64 "", data->asn);
    msgdata = allocate_msgdata (1);  // Free'd by idle function post_message().
    msgdata->textview = data->textview17;  // Free'd by idle function post_message().
    g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
  }

  // Clear ip_asn_searching flag.
  G_LOCK (ip_asn_searching);
  ip_asn_searching = 0;
  G_UNLOCK (ip_asn_searching);

  // Free allocated memory.
  free (message);

  return (EXIT_SUCCESS);
}

// Search for IPv4 address delegations by country code.
// This function will be executed as a separate thread.
int
search_ipv4_by_ccode (SPSData *data)
{
  uint32_t value, ip4[4];
  int i, j, k, c, year, month, day, fail;
  char ipv4s[5], temp[5], *message, *results;
  char mon_name[12][10] = {
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  };
  Msgdata *msgdata;

  // Allocate memory for message local character string.
  message = allocate_strmem (TEXT_STRINGLEN);

  // Allocate memory for string to contain all results.
  results = allocate_strmem (RIR_MEM_BLOCK);
  c = 1;  // Number of RIR_MEM_BLOCKs in use.
  k = 0;  // Index of results array.

  memset (ipv4s, 0, 5 * sizeof (char));
  strncpy (ipv4s, "ipv4", 4);

  fail = 1;
  for (i=0; i<5; i++) {
    sprintf (message, "Searching %s database...\n", data->rir_name[i]);
    msgdata = allocate_msgdata (1);  // Free'd by idle function post_message().
    msgdata->textview = data->textview18;  // Free'd by idle function post_message().
    g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
    for (j=0; j<data->nrecords[i]; j++) {
      if ((memcmp (data->array[i][j][1], data->ccode, 3) == 0) && (memcmp (data->array[i][j][2], ipv4s, 5) == 0)) {
        value = (uint32_t) ascii_to_int64 ((char *) data->array[i][j][4]);
        parse_ipv4 ((char *) data->array[i][j][3], ip4);
        show_cidr_or_range (value, ip4, message);
        memcpy (temp, (char *) data->array[i][j][5], 4 * sizeof (char));
        temp[4] = 0;  // Ensure terminated string; faster than memsetting whole string; speed counts here.
        year = (int) ascii_to_int64 (temp);
        memcpy (temp, (char *) (data->array[i][j][5] + 4), 2 * sizeof (char));
        temp[2] = 0;  // Ensure terminated string; faster than memsetting whole string; speed counts here.
        month = (int) ascii_to_int64 (temp) - 1;
        memcpy (temp, (char *) (data->array[i][j][5] + 6), 2 * sizeof (char));
        temp[2] = 0;  // Ensure terminated string; faster than memsetting whole string; speed counts here.
        day = (int) ascii_to_int64 (temp);
        if (year) {  // Date is known if not equal to zero.
          if (value == 1) {
            sprintf (message, "%s %s to %s (%s) by %s on %s %i, %i.\n", message, (char *) data->array[i][j][6], data->cname, (char *) data->array[i][j][1], data->rir_www[i], mon_name[month], day, year);
          } else {
            sprintf (message, "%s %s to %s (%s) by %s on %s %i, %i.\n", message, (char *) data->array[i][j][6], data->cname, (char *) data->array[i][j][1], data->rir_www[i], mon_name[month], day, year);
          }
        } else {
          if (value == 1) {
            sprintf (message, "%s %s to %s (%s) by %s (date unavailable).\n", message, (char *) data->array[i][j][6], data->cname, (char *) data->array[i][j][1], data->rir_www[i]);
          } else {
            sprintf (message, "%s %s to %s (%s) by %s (date unavailable).\n", message, (char *) data->array[i][j][6], data->cname, (char *) data->array[i][j][1], data->rir_www[i]);
          }
        }

        fail = 0;  // Found at least one match.
        message[TEXT_STRINGLEN - 1] = 0;  // Enforce string termination.
        strncpy (results + k, message, TEXT_STRINGLEN - 1);  // Minus one to allow for string termination
        k += strnlen (message, TEXT_STRINGLEN - 1);
        if (k > ((c * RIR_MEM_BLOCK) - (2 * TEXT_STRINGLEN))) {
          c++;
          results = reallocate_strmem (results, c * RIR_MEM_BLOCK);
          memset (results + ((c - 1) * RIR_MEM_BLOCK), 0, RIR_MEM_BLOCK);
        }
      }
    }
  }

  // Clear any text in the textviews.
  g_idle_add ((GSourceFunc) clear_textview, data->textview18);

  // Found no matches. Report failure to textview.
  if (fail) {
    sprintf (message, "Failed to find any IPv4 address delegations for %s (%s).", data->cname, data->ccode);
    msgdata = allocate_msgdata (1);  // Free'd by idle function post_message().
    msgdata->textview = data->textview18;  // Free'd by idle function post_message().
    g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));

  // Report that search is complete.
  } else {
    memset (message, 0, TEXT_STRINGLEN * sizeof (char));
    sprintf (message, "Search complete.");
    strncat (results, message, TEXT_STRINGLEN - 1);  // Minus one to allow for string termination
    msgdata = allocate_msgdata (1);  // Free'd by idle function post_message().
    msgdata->textview = data->textview18;  // Free'd by idle function post_message().
    g_idle_add ((GSourceFunc) post_message, packit (msgdata, results));  // results array free'd by idle function post_message().
  }

  // Clear ip_asn_searching flag.
  G_LOCK (ip_asn_searching);
  ip_asn_searching = 0;
  G_UNLOCK (ip_asn_searching);

  // Free allocated memory.
  free (message);

  return (EXIT_SUCCESS);
}

// Search delegation files for IPv4 address. Return country code/name.
// This function will be executed as a separate thread.
int
rev_search_ipv4 (SPSData *data)
{
  uint32_t value, ip4[4];
  int i, j, year, month, day, fail;
  char cname[TEXT_STRINGLEN], ipv4s[5], temp[5], *message;
  char mon_name[12][10] = {
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  };
  Msgdata *msgdata;

  // Allocate memory for message local character string.
  message = allocate_strmem (TEXT_STRINGLEN);

  memset (ipv4s, 0, 5 * sizeof (char));
  strncpy (ipv4s, "ipv4", 4);

  memset (cname, 0, TEXT_STRINGLEN * sizeof (char));

  fail = 1;
  for (i=0; i<5; i++) {
    for (j=0; j<data->nrecords[i]; j++) {
      value = (uint32_t) ascii_to_int64 ((char *) data->array[i][j][4]);
      if ((memcmp (data->array[i][j][2], ipv4s, 5) == 0) && interval_test_ipv4 (data->ip4string, (char *) data->array[i][j][3], value)) {
        parse_ipv4 ((char *) data->array[i][j][3], ip4);
        show_cidr_or_range (value, ip4, message);
        if (!find_country_name (cname, (char *) data->array[i][j][1], data)) {
          strncpy (cname, "[no country name assigned]", TEXT_STRINGLEN - 1);  // Minus 1 for string termination.
        }
        memcpy (temp, (char *) data->array[i][j][5], 4 * sizeof (char));
        temp[4] = 0;  // Ensure terminated string; faster than memsetting whole string; speed counts here.
        year = (int) ascii_to_int64 (temp);
        memcpy (temp, (char *) (data->array[i][j][5] + 4), 2 * sizeof (char));
        temp[2] = 0;  // Ensure terminated string; faster than memsetting whole string; speed counts here.
        month = (int) ascii_to_int64 (temp) - 1;
        memcpy (temp, (char *) (data->array[i][j][5] + 6), 2 * sizeof (char));
        temp[2] = 0;  // Ensure terminated string; faster than memsetting whole string; speed counts here.
        day = (int) ascii_to_int64 (temp);
        if (year) {  // Date is known if not equal to zero.
          if (value == 1) {
            sprintf (message, "%s %s to %s (%s) by %s on %s %i, %i.\n", message, (char *) data->array[i][j][6], cname, (char *) data->array[i][j][1], data->rir_www[i], mon_name[month], day, year);
          } else {
            sprintf (message, "%s %s to %s (%s) by %s on %s %i, %i.\n", message, (char *) data->array[i][j][6], cname, (char *) data->array[i][j][1], data->rir_www[i], mon_name[month], day, year);
          }
        } else {
          if (value == 1) {
            sprintf (message, "%s %s to %s (%s) by %s (date unavailable).\n", message, (char *) data->array[i][j][6], cname, (char *) data->array[i][j][1], data->rir_www[i]);
          } else {
            sprintf (message, "%s %s to %s (%s) by %s (date unavailable).\n", message, (char *) data->array[i][j][6], cname, (char *) data->array[i][j][1], data->rir_www[i]);
          }
        }

        // Found a match. Post result to textview.
        fail = 0;
        msgdata = allocate_msgdata (1);  // Free'd by idle function post_message().
        msgdata->textview = data->textview20;  // Free'd by idle function post_message().
        g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
        break;
      }
    }
    if (!fail) break;
  }

  // Found no matches. Report failure to textview.
  if (fail) {
    sprintf (message, "Failed to find a delegation for IPv4 address %s.", data->ip4string);
    msgdata = allocate_msgdata (1);  // Free'd by idle function post_message().
    msgdata->textview = data->textview20;  // Free'd by idle function post_message().
    g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
  }

  // Clear ip_asn_searching flag.
  G_LOCK (ip_asn_searching);
  ip_asn_searching = 0;
  G_UNLOCK (ip_asn_searching);

  // Free allocated memory.
  free (message);

  return (EXIT_SUCCESS);
}

// Search for IPv6 address delegations by country code.
// This function will be executed as a separate thread.
int
search_ipv6_by_ccode (SPSData *data)
{
  uint32_t value;
  int i, j, k, c, year, month, day, fail;
  char ipv6s[5], temp[5], *message, *results;
  char mon_name[12][10] = {
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  };
  Msgdata *msgdata;

  // Allocate memory for message local character string.
  message = allocate_strmem (TEXT_STRINGLEN);

  // Allocate memory for string to contain all results.
  results = allocate_strmem (RIR_MEM_BLOCK);
  c = 1;  // Number of RIR_MEM_BLOCKs in use.
  k = 0;  // Index of results array.

  memset (ipv6s, 0, 5 * sizeof (char));
  strncpy (ipv6s, "ipv6", 4);

  fail = 1;
  for (i=0; i<5; i++) {
    sprintf (message, "Searching %s database...\n", data->rir_name[i]);
    msgdata = allocate_msgdata (1);  // Free'd by idle function post_message().
    msgdata->textview = data->textview19;  // Free'd by idle function post_message().
    g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
    for (j=0; j<data->nrecords[i]; j++) {
      if ((memcmp (data->array[i][j][1], data->ccode, 3) == 0) && (memcmp (data->array[i][j][2], ipv6s, 5) == 0)) {
        message[0] = 0;  // Ensure terminated string; faster than memsetting whole string; speed counts here.
        value = (uint32_t) ascii_to_int64 ((char *) data->array[i][j][4]);
        memcpy (temp, (char *) data->array[i][j][5], 4 * sizeof (char));
        temp[4] = 0;  // Ensure terminated string; faster than memsetting whole string; speed counts here.
        year = (int) ascii_to_int64 (temp);
        memcpy (temp, (char *) (data->array[i][j][5] + 4), 2 * sizeof (char));
        temp[2] = 0;  // Ensure terminated string; faster than memsetting whole string; speed counts here.
        month = (int) ascii_to_int64 (temp) - 1;
        memcpy (temp, (char *) (data->array[i][j][5] + 6), 2 * sizeof (char));
        temp[2] = 0;  // Ensure terminated string; faster than memsetting whole string; speed counts here.
        day = (int) ascii_to_int64 (temp);
        if (year) {  // Date is known if not equal to zero.
          sprintf (message, "%s%s/%i %s to %s (%s) by %s on %s %i, %i.\n", message, (char *) data->array[i][j][3], value, (char *) data->array[i][j][6], data->cname, (char *) data->array[i][j][1], data->rir_www[i], mon_name[month], day, year);
        } else {
          sprintf (message, "%s%s/%i %s to %s (%s) by %s (date unavailable).\n", message, (char *) data->array[i][j][3], value, (char *) data->array[i][j][6], data->cname, (char *) data->array[i][j][1], data->rir_www[i]);
        }

        fail = 0;  // Found at least one match.
        message[TEXT_STRINGLEN - 1] = 0;  // Enforce string termination.
        strncpy (results + k, message, TEXT_STRINGLEN - 1);  // Minus one to allow for string termination
        k += strnlen (message, TEXT_STRINGLEN - 1);
        if (k > ((c * RIR_MEM_BLOCK) - (2 * TEXT_STRINGLEN))) {
          c++;
          results = reallocate_strmem (results, c * RIR_MEM_BLOCK);
          memset (results + ((c - 1) * RIR_MEM_BLOCK), 0, RIR_MEM_BLOCK);
        }
      }
    }
  }

  // Clear any text in the textviews.
  g_idle_add ((GSourceFunc) clear_textview, data->textview19);

  // Found no matches. Report failure to textview.
  if (fail) {
    sprintf (message, "Failed to find any IPv6 address delegations for %s (%s).", data->cname, data->ccode);
    msgdata = allocate_msgdata (1);  // Free'd by idle function post_message().
    msgdata->textview = data->textview19;  // Free'd by idle function post_message().
    g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));

  // Report that search is complete.
  } else {
    memset (message, 0, TEXT_STRINGLEN * sizeof (char));
    sprintf (message, "Search complete.");
    strncat (results, message, TEXT_STRINGLEN - 1);  // Minus one to allow for string termination.
    msgdata = allocate_msgdata (1);  // Free'd by idle function post_message().
    msgdata->textview = data->textview19;  // Free'd by idle function post_message().
    g_idle_add ((GSourceFunc) post_message, packit (msgdata, results));
  }

  // Clear ip_asn_searching flag.
  G_LOCK (ip_asn_searching);
  ip_asn_searching = 0;
  G_UNLOCK (ip_asn_searching);

  // Free allocated memory.
  free (message);

  return (EXIT_SUCCESS);
}

// Search delegation files for IPv6 address. Return country code/name.
// This function will be executed as a separate thread.
int
rev_search_ipv6 (SPSData *data)
{
  uint32_t value;
  int i, j, year, month, day, fail;
  char cname[TEXT_STRINGLEN], ipv6s[5], temp[5], *message;
  char mon_name[12][10] = {
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  };
  Msgdata *msgdata;

  // Allocate memory for message local character string.
  message = allocate_strmem (TEXT_STRINGLEN);

  memset (ipv6s, 0, 5 * sizeof (char));
  strncpy (ipv6s, "ipv6", 4);

  memset (cname, 0, TEXT_STRINGLEN * sizeof (char));

  fail = 1;
  for (i=0; i<5; i++) {
    for (j=0; j<data->nrecords[i]; j++) {
      value = (uint32_t) ascii_to_int64 ((char *) data->array[i][j][4]);
      if ((memcmp (data->array[i][j][2], ipv6s, 5) == 0) && interval_test_ipv6 (data->ip6string, (char *) data->array[i][j][3], value)) {
        message[0] = 0;  // Ensure terminated string; faster than memsetting whole string; speed counts here.
        if (!find_country_name (cname, (char *) data->array[i][j][1], data)) {
          strncpy (cname, "[no country name assigned]", TEXT_STRINGLEN - 1);  // Minus 1 for string termination.
        }
        memcpy (temp, (char *) data->array[i][j][5], 4 * sizeof (char));
        temp[4] = 0;  // Ensure terminated string; faster than memsetting whole string; speed counts here.
        year = (int) ascii_to_int64 (temp);
        memcpy (temp, (char *) (data->array[i][j][5] + 4), 2 * sizeof (char));
        temp[2] = 0;  // Ensure terminated string; faster than memsetting whole string; speed counts here.
        month = (int) ascii_to_int64 (temp) - 1;
        memcpy (temp, (char *) (data->array[i][j][5] + 6), 2 * sizeof (char));
        temp[2] = 0;  // Ensure terminated string; faster than memsetting whole string; speed counts here.
        day = (int) ascii_to_int64 (temp);
        if (year) {  // Date is known if not equal to zero.
          sprintf (message, "%s/%i %s to %s (%s) by %s on %s %i, %i.\n", (char *) data->array[i][j][3], value, (char *) data->array[i][j][6], cname, (char *) data->array[i][j][1], data->rir_www[i], mon_name[month], day, year);
        } else {
          sprintf (message, "%s/%i %s to %s (%s) by %s (date unavailable).\n", (char *) data->array[i][j][3], value, (char *) data->array[i][j][6], cname, (char *) data->array[i][j][1], data->rir_www[i]);
        }

        // Found a match. Post result to textview.
        fail = 0;
        msgdata = allocate_msgdata (1);  // Free'd by idle function post_message().
        msgdata->textview = data->textview20;  // Free'd by idle function post_message().
        g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
        break;
      }
    }
    if (!fail) break;
  }

  // Found no matches. Report failure to textview.
  if (fail) {
    sprintf (message, "Failed to find a delegation for IPv6 address %s.", data->ip6string);
    msgdata = allocate_msgdata (1);  // Free'd by idle function post_message().
    msgdata->textview = data->textview20;  // Free'd by idle function post_message().
    g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));
  }

  // Clear ip_asn_searching flag.
  G_LOCK (ip_asn_searching);
  ip_asn_searching = 0;
  G_UNLOCK (ip_asn_searching);

  // Free allocated memory.
  free (message);

  return (EXIT_SUCCESS);
}
