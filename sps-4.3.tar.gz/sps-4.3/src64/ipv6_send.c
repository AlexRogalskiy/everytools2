/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

extern int flood_mode;  // Flood flag
extern int sending;  // Sending flag for sending finite number of packets

G_LOCK_EXTERN (sending);  // MUTEX for flag indicating packets are being sent

// Send IPv6 packet(s).
// This function will be executed as a separate thread spawned by on_button1_clicked().
int
ipv6_send (SPSData *data)
{
  int status;
  uint64_t i;  // unsigned 64-bit integer for number of packets to send
  int j, frame, sd_tcp, sd_icmp, sd_udp;
  char *ipaddress, *message;
  struct sockaddr_ll tcp_device, icmp_device, udp_device;
  Msgdata *msgdata;

  // This state can be changed by on_button5_clicked()
  // as will flood_mode.
  G_LOCK (sending);
  sending = 1;
  G_UNLOCK (sending);

  // Allocate memory for message local character string.
  message = allocate_strmem (TEXT_STRINGLEN);

  // Grab system date and time.
  memset (message, 0, TEXT_STRINGLEN * sizeof (char));
  message = date_and_time (message, TEXT_STRINGLEN);

  // Display packet activity in Activity Log.
  if (flood_mode) {
    sprintf (message, "%s Flooding ", message);
  } else {
    sprintf (message, "%s Sending ", message);
  }
  if (data->packet_type == 3) {
    sprintf (message, "%sIPv6 TCP ethernet frames.\n", message);
  } else if (data->packet_type == 4) {
    sprintf (message, "%sIPv6 ICMP ethernet frames.\n", message);
  } else if (data->packet_type == 5) {
    sprintf (message, "%sIPv6 UDP ethernet frames.\n", message);
  } else if (data->packet_type == 101) {
    sprintf (message, "%sIPv6 TCP+ICMP+UDP ethernet frames.\n", message);
  } else {
    fprintf (stderr, "ERROR: Invalid upper layer protocol type %i in ipv6_send.c.\n", data->packet_type);
    free (message);
    exit (EXIT_FAILURE);
  }

  // Have idle function post message to UI.
  // strdup() allocates memory for message on the heap using malloc().
  msgdata = allocate_msgdata (1);
  msgdata->textview = data->textview1;
  g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));

  i = data->npackets;  // Number of packets to send
  j = 0;               // Number of packets sent

  // Array to hold an IPv4 or IPv6 address + '\0'
  ipaddress = allocate_strmem (INET6_ADDRSTRLEN);

  // Make sure all interfaces were specified
  if ((((data->packet_type == 3) || (data->packet_type == 101)) && (strnlen (data->ifname[3], TMP_STRINGLEN) < 2)) ||
      (((data->packet_type == 4) || (data->packet_type == 101)) && (strnlen (data->ifname[4], TMP_STRINGLEN) < 2)) ||
      (((data->packet_type == 5) || (data->packet_type == 101)) && (strnlen (data->ifname[5], TMP_STRINGLEN) < 2))) {
    sprintf (data->error_text, "ipv6_send(): Appears to be an invalid interface name.");
    data->parent = data->main_window;
    send_error ();
    free (message);
    free (ipaddress);
    return (EXIT_FAILURE);
  }

  // Resolve interface index.
  memset (&tcp_device, 0, sizeof (tcp_device));
  memset (&icmp_device, 0, sizeof (icmp_device));
  memset (&udp_device, 0, sizeof (udp_device));

  // TCP
  if ((data->packet_type == 3) || (data->packet_type == 101)) {
    if ((tcp_device.sll_ifindex = if_nametoindex (data->ifname[3])) == 0) {
      status = errno;
      sprintf (data->error_text, "ipv6_send(): if_nametoindex() failed to obtain interface index for TCP.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      send_error ();
      free (message);
      free (ipaddress);
      return (EXIT_FAILURE);
    }
  }

  // ICMP
  if ((data->packet_type == 4) || (data->packet_type == 101)) {
    if ((icmp_device.sll_ifindex = if_nametoindex (data->ifname[4])) == 0) {
      status = errno;
      sprintf (data->error_text, "ipv6_send(): if_nametoindex() failed to obtain interface index for ICMP.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      send_error ();
      free (message);
      free (ipaddress);
      return (EXIT_FAILURE);
    }
  }

  // UDP
  if ((data->packet_type == 5) || (data->packet_type == 101)) {
    if ((udp_device.sll_ifindex = if_nametoindex (data->ifname[5])) == 0) {
      status = errno;
      sprintf (data->error_text, "ipv6_send(): if_nametoindex() failed to obtain interface index for UDP.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      send_error ();
      free (message);
      free (ipaddress);
      return (EXIT_FAILURE);
    }
  }

  // Fill out sockaddr_ll.
  tcp_device.sll_family = AF_PACKET;
  memcpy (tcp_device.sll_addr, data->ethhdr[3].src_mac, 6 * sizeof (uint8_t));
  tcp_device.sll_halen = 6u;

  icmp_device.sll_family = AF_PACKET;
  memcpy (icmp_device.sll_addr, data->ethhdr[4].src_mac, 6 * sizeof (uint8_t));
  icmp_device.sll_halen = 6u;

  udp_device.sll_family = AF_PACKET;
  memcpy (udp_device.sll_addr, data->ethhdr[5].src_mac, 6 * sizeof (uint8_t));
  udp_device.sll_halen = 6u;

  i = data->npackets;  // Number of packets to send
  j = 0;               // Number of packets sent

  // Submit requests for raw socket descriptors.
  // Separate descriptors for TCP, ICMP, and UDP since we may use difference ethernet headers and interfaces.
  sd_tcp = -1;  // Initially set to invalid socket descriptor.
  sd_icmp = -1;  // Initially set to invalid socket descriptor.
  sd_udp = -1;  // Initially set to invalid socket descriptor.

  // TCP
  if ((data->packet_type == 3) || (data->packet_type == 101))  {
    if ((sd_tcp = socket (PF_PACKET, SOCK_RAW, htons (ETH_P_ALL))) < 0) {
      status = errno;
      sprintf (data->error_text, "ipv6_send(): socket() failed to get a socket descriptor for TCP.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      send_error ();
      free (message);
      free (ipaddress);
      return (EXIT_FAILURE);
    }
  }

  // ICMP
  if ((data->packet_type == 4) || (data->packet_type == 101)) {
    if ((sd_icmp = socket (PF_PACKET, SOCK_RAW, htons (ETH_P_ALL))) < 0) {
      status = errno;
      sprintf (data->error_text, "ipv6_send(): socket() failed to get a socket descriptor for ICMP.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      send_error ();
      free (message);
      free (ipaddress);
      return (EXIT_FAILURE);
    }
  }

  // UDP
  if ((data->packet_type == 5) || (data->packet_type == 101)) {
    if ((sd_udp = socket (PF_PACKET, SOCK_RAW, htons (ETH_P_ALL))) < 0) {
      status = errno;
      sprintf (data->error_text, "ipv6_send(): socket() failed to get a socket descriptor for UDP.\nError message: %s", strerror (status));
      data->parent = data->main_window;
      send_error ();
      free (message);
      free (ipaddress);
      return (EXIT_FAILURE);
    }
  }

  // Send TCP packet(s).
  if (data->packet_type == 3) {

    while ((i > 0ull) && sending) {

      for (frame=0; frame<data->nframes[3]; frame++) {

        if ((sendto (sd_tcp, data->ether_frame[3][frame], data->frame_length[3][frame], 0, (struct sockaddr *) &tcp_device, sizeof (tcp_device))) <= 0) {
          status = errno;
          sprintf (data->error_text, "ipv6_send(): sendto() failed for TCP.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }

      if (!flood_mode) i--;
      j++;

      // Randomize IPv6 source address if requested.
      if (data->ran_tcp6_sourceip) {
        if ((status = inet_pton (AF_INET6, ran6_addr (ipaddress, data), &data->ip6hdr[3].ip6_src)) != 1) {
          sprintf (data->error_text, "ipv6_send(): inet_pton() failed for randomized TCP source IP address.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }

      // Randomize source port if requested.
      if (data->ran_tcp6_sourceport) {
        data->tcphdr[3].th_sport = htons (ran16_0to65535 (data));
      }

      // Re-calculate upper layer protocol checksum
      // regardless of whether source IP and/or port was changed.

      // TCP header checksum (16 bits)
      data->tcphdr[3].th_sum = tcp6_checksum (data->ip6hdr[3], data->tcphdr[3], data->tcp_nopt[3], data->tcp_opt_totlen[3], data->tcp_optlen[3], data->tcp_options[3], data->tcp_optpadlen[3], data->payload[3], data->payloadlen[3]);

      // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
      memcpy (&data->ip6hdr[6], &data->ip6hdr[3], IP6_HDRLEN * sizeof (uint8_t));

      // Update ethernet frames.
      create_ip6_frame (3, data);
      create_6to4_frame (6, data);
    }

    close (sd_tcp);

  // Send ICMP packet(s).
  } else if (data->packet_type == 4) {

    while ((i > 0ull) && sending) {

      for (frame=0; frame<data->nframes[4]; frame++) {

        if ((sendto (sd_icmp, data->ether_frame[4][frame], data->frame_length[4][frame], 0, (struct sockaddr *) &icmp_device, sizeof (icmp_device))) <= 0) {
          status = errno;
          sprintf (data->error_text, "ipv6_send(): sendto() failed for ICMP.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }

      if (!flood_mode) i--;
      j++;

      // Randomize source IPv6 address if requested.
      if (data->ran_icmp6_sourceip) {
        if ((status = inet_pton (AF_INET6, ran6_addr (ipaddress, data), &data->ip6hdr[4].ip6_src)) != 1) {
          sprintf (data->error_text, "ipv6_send(): inet_pton() failed for randomized ICMP source IP address.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }

        // Re-calculate upper layer protocol checksum.
        // ICMPv6 header checksum (16 bits)
        data->icmp6hdr[4].icmp6_cksum = icmp6_checksum (data->ip6hdr[4], data->icmp6hdr[4], data->payload[4], data->payloadlen[4]);

        // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
        memcpy (&data->ip6hdr[7], &data->ip6hdr[4], IP6_HDRLEN * sizeof (uint8_t));

        // Update ethernet frames.
        create_ip6_frame (4, data);
        create_6to4_frame (7, data);
      }
    }

    close (sd_icmp);

  // Send UDP packet(s).
  } else if (data->packet_type == 5) {

    while ((i > 0ull) && sending) {

      for (frame=0; frame<data->nframes[5]; frame++) {

        if ((sendto (sd_udp, data->ether_frame[5][frame], data->frame_length[5][frame], 0, (struct sockaddr *) &udp_device, sizeof (udp_device))) <= 0) {
          status = errno;
          sprintf (data->error_text, "ipv6_send(): sendto() failed for UDP.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }

      if (!flood_mode) i--;
      j++;

      // Randomize source IPv6 address if requested.
      if (data->ran_udp6_sourceip) {
        if ((status = inet_pton (AF_INET6, ran6_addr (ipaddress, data), &data->ip6hdr[5].ip6_src)) != 1) {
          sprintf (data->error_text, "ipv6_send(): inet_pton() failed for randomized UDP source IP address.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }

      // Randomize source port if requested.
      if (data->ran_udp6_sourceport) {
        data->udphdr[5].uh_sport = htons (ran16_0to65535 (data));
      }

      // Re-calculate upper layer protocol checksum
      // regardless of whether source IP and/or port was changed.

      // UDP header checksum (16 bits)
      data->udphdr[5].uh_sum = udp6_checksum (data->ip6hdr[5], data->udphdr[5], data->payload[5], data->payloadlen[5]);

      // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
      memcpy (&data->ip6hdr[8], &data->ip6hdr[5], IP6_HDRLEN * sizeof (uint8_t));

      // Update ethernet frame.
      create_ip6_frame (5, data);
      create_6to4_frame (8, data);
    }

    close (sd_udp);

  // Send all packet types.
  } else if (data->packet_type == 101) {

    while ((i > 0ull) && sending) {

      // TCP
      for (frame=0; frame<data->nframes[3]; frame++) {

        if ((sendto (sd_tcp, data->ether_frame[3][frame], data->frame_length[3][frame], 0, (struct sockaddr *) &tcp_device, sizeof (tcp_device))) <= 0) {
          status = errno;
          sprintf (data->error_text, "ipv6_send(): sendto() failed for TCP.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }

      // ICMP
      for (frame=0; frame<data->nframes[4]; frame++) {

        if ((sendto (sd_icmp, data->ether_frame[4][frame], data->frame_length[4][frame], 0, (struct sockaddr *) &icmp_device, sizeof (icmp_device))) <= 0) {
          status = errno;
          sprintf (data->error_text, "ipv6_send(): sendto() failed for ICMP.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }

      // UDP
      for (frame=0; frame<data->nframes[5]; frame++) {

        if ((sendto (sd_udp, data->ether_frame[5][frame], data->frame_length[5][frame], 0, (struct sockaddr *) &udp_device, sizeof (udp_device))) <= 0) {
          status = errno;
          sprintf (data->error_text, "ipv6_send(): sendto() failed for UDP.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }

      if (!flood_mode) i--;
      j++;

      // Randomize source IPv6 address if requested.
      if (data->ran_tcp6_sourceip) {
        if ((status = inet_pton (AF_INET6, ran6_addr (ipaddress, data), &data->ip6hdr[3].ip6_src)) != 1) {
          sprintf (data->error_text, "ipv6_send(): inet_pton() failed for randomized TCP source IP address.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }
      if (data->ran_icmp6_sourceip) {
        if ((status = inet_pton (AF_INET6, ran6_addr (ipaddress, data), &data->ip6hdr[4].ip6_src)) != 1) {
          sprintf (data->error_text, "ipv6_send(): inet_pton() failed for randomized ICMP source IP address.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }
      if (data->ran_udp6_sourceip) {
        if ((status = inet_pton (AF_INET6, ran6_addr (ipaddress, data), &data->ip6hdr[5].ip6_src)) != 1) {
          sprintf (data->error_text, "ipv6_send(): inet_pton() failed randomized UDP source IP address.\nError message: %s", strerror (status));
          data->parent = data->main_window;
          send_error ();
          free (message);
          free (ipaddress);
          return (EXIT_FAILURE);
        }
      }

      // Randomize source port if requested.
      if (data->ran_tcp6_sourceport) {
        data->tcphdr[3].th_sport = htons (ran16_0to65535 (data));
      }
      if (data->ran_udp6_sourceport) {
        data->udphdr[5].uh_sport = htons (ran16_0to65535 (data));
      }

      // Re-calculate upper layer protocol checksum
      // regardless of whether source IP and/or port was changed.

      // Upper layer protocol header checksum (16 bits)
      data->tcphdr[3].th_sum = tcp6_checksum (data->ip6hdr[3], data->tcphdr[3], data->tcp_nopt[3], data->tcp_opt_totlen[3], data->tcp_optlen[3], data->tcp_options[3], data->tcp_optpadlen[3], data->payload[3], data->payloadlen[3]);
      data->icmp6hdr[4].icmp6_cksum = icmp6_checksum (data->ip6hdr[4], data->icmp6hdr[4], data->payload[4], data->payloadlen[4]);
      data->udphdr[5].uh_sum = udp6_checksum (data->ip6hdr[5], data->udphdr[5], data->payload[5], data->payloadlen[5]);

      // Copy IPv6 header to 6to4 IPv6 header, since create_6to4_frame() doesn't copy it.
      memcpy (&data->ip6hdr[6], &data->ip6hdr[3], IP6_HDRLEN * sizeof (uint8_t));
      memcpy (&data->ip6hdr[7], &data->ip6hdr[4], IP6_HDRLEN * sizeof (uint8_t));
      memcpy (&data->ip6hdr[8], &data->ip6hdr[5], IP6_HDRLEN * sizeof (uint8_t));

      // Update ethernet frames.
      create_ip6_frame (3, data);
      create_6to4_frame (6, data);
      create_ip6_frame (4, data);
      create_6to4_frame (7, data);
      create_ip6_frame (5, data);
      create_6to4_frame (8, data);
    }

    // Close appropriate socket descriptors.
    if ((data->packet_type == 3) || (data->packet_type == 101)) {
      close (sd_tcp);
    } else if ((data->packet_type == 4) || (data->packet_type == 101)) {
      close (sd_icmp);
    } else if ((data->packet_type == 5) || (data->packet_type == 101)) {
      close (sd_udp);
    }
  }

  // Display packet activity in Activity Log.
  memset (message, 0, TEXT_STRINGLEN * sizeof (char));
  if (data->packet_type == 3) {
    sprintf (message, "%i IPv6 TCP ethernet frames (%i packets) sent.\n", j * data->nframes[3], j);
  } else if (data->packet_type == 4) {
    sprintf (message, "%i IPv6 ICMP ethernet frames (%i packets) sent.\n", j * data->nframes[4], j);
  } else if (data->packet_type == 5) {
    sprintf (message, "%i IPv6 UDP ethernet frames (%i packets) sent.\n", j * data->nframes[5], j);
  } else {
    sprintf (message, "%i IPv6 TCP+ICMP+UDP packets sent.\n", j);
  }

  // Have idle function post message to UI.
  // strdup() allocates memory for message on the heap using malloc().
  msgdata = allocate_msgdata (1);
  msgdata->textview = data->textview1;
  g_idle_add ((GSourceFunc) post_message, packit (msgdata, strdup (message)));

  // Have idle function update source IPv6 addresses and source ports, which may have changed if randomized during send.
  g_idle_add ((GSourceFunc) update_ip6_sources, data);

  // Free allocated memory.
  free (ipaddress);
  free (message);

  return (EXIT_SUCCESS);
}

// Idle function to update source IPv6 addresses and source ports, which may have changed if randomized during send.
// This idle function returns 0 in order to stop.
int
update_ip6_sources (SPSData *data)
{
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // TCP source IPv6 address
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  if (inet_ntop (AF_INET6, &(data->ip6hdr[3].ip6_src), value, INET6_ADDRSTRLEN) == NULL) {
    fprintf (stderr, "ERROR: inet_ntop() failed for TCP source IPv6 address in update_ip6_sources().\n");
    fprintf (stderr, "       This should not happen unless invalid addresses are being generated.\n");
    exit (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry28), value);

  // ICMP source IPv6 address
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  if (inet_ntop (AF_INET6, &(data->ip6hdr[4].ip6_src), value, INET6_ADDRSTRLEN) == NULL) {
    fprintf (stderr, "ERROR: inet_ntop() failed for ICMP source IPv6 address in update_ip6_sources().\n");
    fprintf (stderr, "       This should not happen unless invalid addresses are being generated.\n");
    exit (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry109), value);

  // UDP source IPv6 address
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  if (inet_ntop (AF_INET6, &(data->ip6hdr[5].ip6_src), value, INET6_ADDRSTRLEN) == NULL) {
    fprintf (stderr, "ERROR: inet_ntop() failed for UDP source IPv6 address in update_ip6_sources().\n");
    fprintf (stderr, "       This should not happen unless invalid addresses are being generated.\n");
    exit (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (data->entry96), value);

  // TCP (IPv6) source port
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[3].th_sport));
  gtk_entry_set_text (GTK_ENTRY (data->entry79), value);

  // UDP (IPv6) source port
  memset (value, 0, TMP_STRINGLEN * sizeof (char));
  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->udphdr[5].uh_sport));
  gtk_entry_set_text (GTK_ENTRY (data->entry104), value);

  // Free allocated memory.
  free (value);

  return (0);  // This idle function stops when it returns a value of zero.
}
