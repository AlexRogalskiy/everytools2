/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Hop-by-Hop extension header editing window
int
hop_win (SPSData *data)
{
  GtkBuilder *builder;
  GError *error = NULL;

  // If hop-by-hop window is already open, return with no action.
  if (data->hop_flag) {
    return (EXIT_FAILURE);
  } else {
    data->hop_flag = 1;
  }

  // Create new GtkBuilder object.
  builder = gtk_builder_new();
  if (!gtk_builder_add_from_file (builder, "hop-by-hop.ui", &error)) {
    g_warning ("%s", error->message);
    g_free (error);
    exit (EXIT_FAILURE);
  }

  // Get objects from UI file
  data->hop_window = GTK_WIDGET (gtk_builder_get_object (builder, "hop_window"));

  data->radiobutton59 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton59"));  // Decimal data entry
  data->radiobutton60 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton60"));  // Hexadecimal data entry

  data->button142 = GTK_BUTTON (gtk_builder_get_object (builder, "button142"));  // Toggle: attach / detach a hop-by-hop header
  data->textview47 = GTK_WIDGET (gtk_builder_get_object (builder, "textview47"));  // Status: attached / detached
  data->entry438 = GTK_WIDGET (gtk_builder_get_object (builder, "entry438"));  // Hop-by-hop header length
  data->entry158 = GTK_WIDGET (gtk_builder_get_object (builder, "entry158"));  // Hop-by-hop option data
  data->entry313 = GTK_WIDGET (gtk_builder_get_object (builder, "entry313"));  // Option alignment parameter x (of xN + y)
  data->entry314 = GTK_WIDGET (gtk_builder_get_object (builder, "entry314"));  // Option alignment parameter y (of xN + y)
  data->button94 = GTK_BUTTON (gtk_builder_get_object (builder, "button94"));  // Insert Option After...
  data->entry159 = GTK_WIDGET (gtk_builder_get_object (builder, "entry159"));  // Option # to insert after
  data->button95 = GTK_BUTTON (gtk_builder_get_object (builder, "button95"));  // Append option
  data->textview22 = GTK_WIDGET (gtk_builder_get_object (builder, "textview22"));  // Number of options in hop-by-hop header
  data->button96 = GTK_BUTTON (gtk_builder_get_object (builder, "button96"));  // View hop-by-hop options
  data->entry312 = GTK_WIDGET (gtk_builder_get_object (builder, "entry312"));  // Option number to remove
  data->button97 = GTK_BUTTON (gtk_builder_get_object (builder, "button97"));  // Remove option

  // Connect signals.
  gtk_builder_connect_signals (builder, data);

  // Destroy builder, since we don't need it anymore.
  g_object_unref (G_OBJECT (builder));

  // Show window. All other widgets are automatically shown by GtkBuilder.
  gtk_widget_show (data->hop_window);

  // Populate/set widgets in hop-by-hop header editing window.
  hop_show (data->exthdr_type, data);

  return (EXIT_SUCCESS);
}

// Populate hop_window with contents of selected hop-by-hop header.
int
hop_show (int type, SPSData *data)
{
  int val;
  char *text;
  GtkTextBuffer *textbuffer22, *textbuffer47;

  // Array to hold various strings of text
  text = allocate_strmem (TEXT_STRINGLEN);

  // Flag indicating a hop-by-hop header
  textbuffer47 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview47));
  if (data->hbh_hdr_flag[data->exthdr_type]) {
    gtk_text_buffer_set_text (textbuffer47, "Attached", -1);
  } else {
    gtk_text_buffer_set_text (textbuffer47, "Not Attached", -1);
  }

  // Decimal or hexadecimal option data entry
  val = data->dec_hex_hbhopt;
  if (val) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton59), FALSE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton59), TRUE);
  }
  // Variable data->dec_hex_hbhopt will be changed by on_radiobutton59_toggled(), so set it now.
  data->dec_hex_hbhopt = val;

  // Hop-by-hop extension header length (header + alignments + options + padding)
  sprintf (text, "%" PRIu8, (uint8_t) data->hophdr[type].hdr_len);
  gtk_entry_set_text (GTK_ENTRY (data->entry438), text);

  // Number of hop-by-hop options
  sprintf (text, "%i", data->hbh_nopt[type]);
  textbuffer22 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview22));
  gtk_text_buffer_set_text (textbuffer22, text, -1);

  // Free allocated memory.
  free (text);

  return (EXIT_SUCCESS);
}

// Destination extension header editing window
int
dst_win (SPSData *data)
{
  GtkBuilder *builder;
  GError *error = NULL;

  // If destination window is already open, return with no action.
  if (data->dst_flag) {
    return (EXIT_FAILURE);
  } else {
    data->dst_flag = 1;
  }

  // Create new GtkBuilder object.
  builder = gtk_builder_new();
  if (!gtk_builder_add_from_file (builder, "destination.ui", &error)) {
    g_warning ("%s", error->message);
    g_free (error);
    exit (EXIT_FAILURE);
  }

  // Get objects from UI file
  data->dst_window = GTK_WIDGET (gtk_builder_get_object (builder, "dst_window"));

  data->radiobutton61 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton61"));  // Decimal data entry
  data->radiobutton62 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton62"));  // Hexadecimal data entry

  data->button143 = GTK_BUTTON (gtk_builder_get_object (builder, "checkbutton143"));  // Toggle: attach / detach a "first" destination header
  data->textview48 = GTK_WIDGET (gtk_builder_get_object (builder, "textview48"));  // Status: attached / detached
  data->button144 = GTK_BUTTON (gtk_builder_get_object (builder, "checkbutton144"));  // Toggle: attach / detach a "last" destination header
  data->textview49 = GTK_WIDGET (gtk_builder_get_object (builder, "textview49"));  // Status: attached / detached
  data->entry439 = GTK_WIDGET (gtk_builder_get_object (builder, "entry439"));  // Destination header length (first)
  data->entry440 = GTK_WIDGET (gtk_builder_get_object (builder, "entry440"));  // Destination header length (last)
  data->entry315 = GTK_WIDGET (gtk_builder_get_object (builder, "entry315"));  // Destination option data
  data->entry156 = GTK_WIDGET (gtk_builder_get_object (builder, "entry156"));  // Option alignment parameter x (of xN + y)
  data->entry157 = GTK_WIDGET (gtk_builder_get_object (builder, "entry157"));  // Option alignment parameter y (of xN + y)
  data->radiobutton63 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton63"));  // Designate as first destination header
  data->radiobutton64 = GTK_TOGGLE_BUTTON (gtk_builder_get_object (builder, "radiobutton64"));  // Designate as last destination header
  data->button104 = GTK_BUTTON (gtk_builder_get_object (builder, "button104"));  // Insert Option After...
  data->entry431 = GTK_WIDGET (gtk_builder_get_object (builder, "entry431"));  // Option # to insert after
  data->button105 = GTK_BUTTON (gtk_builder_get_object (builder, "button105"));  // Append option
  data->textview25 = GTK_WIDGET (gtk_builder_get_object (builder, "textview25"));  // Number of options in first destination header
  data->textview27 = GTK_WIDGET (gtk_builder_get_object (builder, "textview27"));  // Number of options in last destination header
  data->button106 = GTK_BUTTON (gtk_builder_get_object (builder, "button106"));  // View destination options (first)
  data->button109 = GTK_BUTTON (gtk_builder_get_object (builder, "button109"));  // View destination options (last)
  data->entry432 = GTK_WIDGET (gtk_builder_get_object (builder, "entry432"));  // Option number to remove
  data->button107 = GTK_BUTTON (gtk_builder_get_object (builder, "button107"));  // Remove option

  // Connect signals.
  gtk_builder_connect_signals (builder, data);

  // Destroy builder, since we don't need it anymore.
  g_object_unref (G_OBJECT (builder));

  // Show window. All other widgets are automatically shown by GtkBuilder.
  gtk_widget_show (data->dst_window);

  // Populate/set widgets in destination header editing window.
  dst_show (data->exthdr_type, data);

  return (EXIT_SUCCESS);
}

// Populate dst_window with contents of selected destination header.
int
dst_show (int type, SPSData *data)
{
  int val;
  char *text;
  GtkTextBuffer *textbuffer25, *textbuffer27, *textbuffer48, *textbuffer49;

  // Array to hold various strings of text
  text = allocate_strmem (TEXT_STRINGLEN);

  // Flag indicating a "first" destination header
  textbuffer48 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview48));
  if (data->dstf_hdr_flag[data->exthdr_type]) {
    gtk_text_buffer_set_text (textbuffer48, "Attached", -1);
  } else {
    gtk_text_buffer_set_text (textbuffer48, "Not Attached", -1);
  }

  // Flag indicating a "last" destination header
  textbuffer49 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview49));
  if (data->dstl_hdr_flag[data->exthdr_type]) {
    gtk_text_buffer_set_text (textbuffer49, "Attached", -1);
  } else {
    gtk_text_buffer_set_text (textbuffer49, "Not Attached", -1);
  }

  // Decimal or hexadecimal data entry
  val = data->dec_hex_dstopt;
  if (val) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton61), FALSE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton61), TRUE);
  }
  // Variable data->dec_hex_dstopt will be changed by on_radiobutton61_toggled(), so set it now.
  data->dec_hex_dstopt = val;

  // Designate data entry to be for first or last destination header.
  val = data->dst_fl_flag;
  if (data->dst_fl_flag) {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton64), TRUE);
  } else {
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (data->radiobutton64), FALSE);
  }
  // Variable data->dst_fl_flag will be changed by on_radiobutton61_toggled(), so set it now.
  data->dst_fl_flag = val;

  // Destination extension header (first) length (header + alignments + options + padding)
  sprintf (text, "%" PRIu8, (uint8_t) data->dstfhdr[type].hdr_len);
  gtk_entry_set_text (GTK_ENTRY (data->entry439), text);

  // Destination extension header (last) length (header + alignments + options + padding)
  sprintf (text, "%" PRIu8, (uint8_t) data->dstlhdr[type].hdr_len);
  gtk_entry_set_text (GTK_ENTRY (data->entry440), text);

  // Show number of options in first destination header.
  sprintf (text, "%i", data->dstf_nopt[type]);
  textbuffer25 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview25));
  gtk_text_buffer_set_text (textbuffer25, text, -1);

  memset (text, 0, TEXT_STRINGLEN * sizeof (char));

  // Show number of options in last destination header.
  sprintf (text, "%i", data->dstl_nopt[type]);
  textbuffer27 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data->textview27));
  gtk_text_buffer_set_text (textbuffer27, text, -1);

  // Free allocated memory.
  free (text);

  return (EXIT_SUCCESS);
}

// Prepare a string of text containing hop-by-hop header or destination header options.
int
compose_exoptstring (int type, char *string_out, int nopt, int **optlen, uint8_t ***options, SPSData *data)
{
  int iopt, i, d;
  int *optleadpadlen, *opttailpadlen;
  uint8_t **optleadpad, *opttailpad;
  char temp[80];

  if (data->hop_flag) {
    optleadpadlen = data->hbh_optleadpadlen[type];  // optleadpadlen[option #] = int
    optleadpad = data->hbh_optleadpad[type];  // optleadpad[option #] = uint8_t *
    opttailpadlen = &data->hbh_opttailpadlen[type];  // (*opttailpadlen) = int
    opttailpad = data->hbh_opttailpad[type];  // opttailpad = uint8_t *
  } else {
    if (data->dst_fl_flag) {  // Last destination header
      optleadpadlen = data->dstl_optleadpadlen[type];  // optleadpadlen[option #] = int
      optleadpad = data->dstl_optleadpad[type];  // optleadpad[option #] = uint8_t *
      opttailpadlen = &data->dstl_opttailpadlen[type];  // (*opttailpadlen) = int
      opttailpad = data->dstl_opttailpad[type];  // opttailpad = uint8_t *
    } else {  // First destination header
      optleadpadlen = data->dstf_optleadpadlen[type];  // optleadpadlen[option #] = int
      optleadpad = data->dstf_optleadpad[type];  // optleadpad[option #] = uint8_t *
      opttailpadlen = &data->dstf_opttailpadlen[type];  // (*opttailpadlen) = int
      opttailpad = data->dstf_opttailpad[type];  // opttailpad = uint8_t *
    }
  }

  d = 0;  // Index of string_out

  // Loop through all options.
  for (iopt=0; iopt<nopt; iopt++) {

    // Display option number.
    sprintf (temp, "Option %i:\n", iopt + 1);
    sprintf (string_out + d, "%s", temp); d += strnlen (temp, 80);

    // Display option alignment padding.
    sprintf (temp, "Alignment: ");
    sprintf (string_out + d, "%s", temp); d += strnlen (temp, 80);
    memset (temp, 0, 80 * sizeof (char));
    for (i=0; i<optleadpadlen[iopt]; i++) {
      sprintf (temp, "%s%02x ", temp, optleadpad[iopt][i]);
    }
    sprintf (temp, "%s\n", temp);
    sprintf (string_out + d, "%s", temp); d += strnlen (temp, 80);

    d += hexascii_listing (options[type][iopt], optlen[type][iopt], string_out + d, 1);

    // Add two line-feeds.
    string_out[d] = '\n'; d++;
    string_out[d] = '\n'; d++;
  }  // End loop through options

  // Display header final padding.
  sprintf (temp, "End padding: ");
  sprintf (string_out + d, "%s", temp); d += strnlen (temp, 80);
  memset (temp, 0, 80 * sizeof (char));
  for (i=0; i<(*opttailpadlen); i++) {
    sprintf (temp, "%s%02x ", temp, opttailpad[i]);
  }
  sprintf (temp, "%s\n", temp);
  sprintf (string_out + d, "%s", temp); d += strnlen (temp, 80);

  return (EXIT_SUCCESS);
}

// Insert, remove, or append a hop-by-hop or destination option.
int
dsthop_option (int mode, int opt_number, GtkWidget *textview1, GtkWidget *textview2, SPSData *data)
{
  // Values for mode:
  // 0 = insert
  // 1 = remove
  // 2 = append

  const char *entryx_text, *entryy_text;
  int i, j, maxoptions, maxoptlen, hdrlen;
  int *nopt, *optlen, *x, *y, *optlenbuf, *opt_totlen, *optpadlen, *optleadpadlen, *opttailpadlen;
  uint8_t **buffer, **options, *optionsbuf, **optleadpad, *opttailpad;
  char *value;
  int *bufoptlen, *xtemp, *ytemp, indx;
  GtkTextBuffer *textbuffer;

  // Set various parameters depending upon whether hop-by-hop or destination header window is open.
  if (data->hop_flag) {
    maxoptions = MAX_HBHOPTIONS;
    maxoptlen = MAX_HBHOPTLEN;
    nopt = &data->hbh_nopt[data->exthdr_type];  // (*nopt) = int
    options = data->hbh_options[data->exthdr_type];  // options[option #] = uint8_t *
    optlen = data->hbh_optlen[data->exthdr_type];  // optlen[option #] = int
    x = data->hbh_x[data->exthdr_type];  // x[option #] = int
    y = data->hbh_y[data->exthdr_type];  // y[option #] = int
    optionsbuf = data->hbh_optionsbuf[data->exthdr_type];  // optionsbuf = uint8_t *
    optlenbuf = &data->hbh_optlenbuf[data->exthdr_type];  // (*optlenbuf) = int
    opt_totlen = &data->hbh_opt_totlen[data->exthdr_type];  // (*opt_totlen) = int
    optpadlen = &data->hbh_optpadlen[data->exthdr_type];  // (*optpadlen) = int
    optleadpadlen = data->hbh_optleadpadlen[data->exthdr_type];  // optleadpadlen[option #] = int
    optleadpad = data->hbh_optleadpad[data->exthdr_type];  // optleadpad[option #] = uint8_t *
    opttailpadlen = &data->hbh_opttailpadlen[data->exthdr_type];  // (*opttailpadlen) = int
    opttailpad = data->hbh_opttailpad[data->exthdr_type];  // opttailpad = uint8_t *
    hdrlen = HOP_HDRLEN;
    entryx_text = gtk_entry_get_text (GTK_ENTRY (data->entry313));  // Alignment factor x
    entryy_text = gtk_entry_get_text (GTK_ENTRY (data->entry314));  // Alignment factor y
    data->parent = data->hop_window;
  } else {
    maxoptions = MAX_DSTOPTIONS;
    maxoptlen = MAX_DSTOPTLEN;
    if (data->dst_fl_flag) {  // Last destination header
      nopt = &data->dstl_nopt[data->exthdr_type];  // (*nopt) = int
      options = data->dstl_options[data->exthdr_type];  // options[option #] = uint8_t *
      optlen = data->dstl_optlen[data->exthdr_type];  // optlen[option #] = int
      x = data->dstl_x[data->exthdr_type];  // x[option #] = int
      y = data->dstl_y[data->exthdr_type];  // y[option #] = int
      opt_totlen = &data->dstl_opt_totlen[data->exthdr_type];  // (*opt_totlen) = int
      optpadlen = &data->dstl_optpadlen[data->exthdr_type];  // (*optpadlen) = int
      optleadpadlen = data->dstl_optleadpadlen[data->exthdr_type];  // optleadpadlen[option #] = int
      optleadpad = data->dstl_optleadpad[data->exthdr_type];  // optleadpad[option #] = uint8_t *
      opttailpadlen = &data->dstl_opttailpadlen[data->exthdr_type];  // (*opttailpadlen) = int
      opttailpad = data->dstl_opttailpad[data->exthdr_type];  // opttailpad = uint8_t *
    } else {  // First destination header
      nopt = &data->dstf_nopt[data->exthdr_type];  // (*nopt) = int
      options = data->dstf_options[data->exthdr_type];  // options[option #] = uint8_t *
      optlen = data->dstf_optlen[data->exthdr_type];  // optlen[option #] = int
      x = data->dstf_x[data->exthdr_type];  // x[option #] = int
      y = data->dstf_y[data->exthdr_type];  // y[option #] = int
      opt_totlen = &data->dstf_opt_totlen[data->exthdr_type];  // (*opt_totlen) = int
      optpadlen = &data->dstf_optpadlen[data->exthdr_type];  // (*optpadlen) = int
      optleadpadlen = data->dstf_optleadpadlen[data->exthdr_type];  // optleadpadlen[option #] = int
      optleadpad = data->dstf_optleadpad[data->exthdr_type];  // optleadpad[option #] = uint8_t *
      opttailpadlen = &data->dstf_opttailpadlen[data->exthdr_type];  // (*opttailpadlen) = int
      opttailpad = data->dstf_opttailpad[data->exthdr_type];  // opttailpad = uint8_t *
    }
    optionsbuf = data->dst_optionsbuf[data->exthdr_type];  // optionsbuf = uint8_t *
    optlenbuf = &data->dst_optlenbuf[data->exthdr_type];  // (*optlenbuf) = int
    hdrlen = DST_HDRLEN;
    entryx_text = gtk_entry_get_text (GTK_ENTRY (data->entry156));  // Alignment factor x
    entryy_text = gtk_entry_get_text (GTK_ENTRY (data->entry157));  // Alignment factor y
    data->parent = data->dst_window;
  }

  // Abort if trying to insert option after non-existent option.
  if ((mode == 0) && ((opt_number > (*nopt)) || !(*nopt) || !opt_number)) {
    return (EXIT_FAILURE);
  }

  // Abort if nothing in option entry buffer to insert or append.
  if (((mode == 0) || (mode == 2)) && ((*optlenbuf) == 0)) {
    return (EXIT_FAILURE);
  }

  // Abort if trying to remove an option and none exist.
  if ((mode == 1) && ((*nopt) == 0)) {
    return (EXIT_FAILURE);
  }

  // Abort if trying to remove an option and it, specifically, doesn't exist.
  if ((mode == 1) && ((opt_number > (*nopt)) || !opt_number)) {
    return (EXIT_FAILURE);
  }

  // Abort if user requests more than MAX_HBHOPTIONS hop-by-hop options.
  if (data->hop_flag && ((mode == 0) || (mode == 2)) && ((*nopt) == MAX_HBHOPTIONS)) {
    sprintf (data->error_text, "The number of hop-by-hop options is currently limited to %i in main.h as MAX_HBHOPTIONS.", MAX_HBHOPTIONS);
    report_error (data);
    return (EXIT_FAILURE);
  }

  // Abort if user requests for more than MAX_DSTOPTIONS destination options (for each of "first" and "last" destination headers).
  if ((!data->hop_flag) && ((mode == 0) || (mode == 2)) && ((*nopt) == MAX_DSTOPTIONS)) {
    sprintf (data->error_text, "The number of destination options is currently limited to %i in main.h as MAX_DSTOPTIONS.", MAX_DSTOPTIONS);
    report_error (data);
    return (EXIT_FAILURE);
  }

  // Abort if option alignment parameters are not specified and user wants to
  // insert or append an option.
  if (((mode == 0) || (mode == 2)) && ((strnlen (entryx_text, 2) == 0) || (strnlen (entryy_text, 2) == 0))) {
    sprintf (data->error_text, "Alignment parameters x and y need to be specified.");
    report_error (data);
    return (EXIT_FAILURE);
  }

  if (((mode == 0) || (mode == 2)) && ((ascii_to_int64 ((char *) entryy_text) >= ascii_to_int64 ((char *) entryx_text)))) {
    sprintf (data->error_text, "Alignment parameter y cannot be greater than or equal to parameter x.");
    report_error (data);
    return (EXIT_FAILURE);
  }

  // Allocate memory for buffer to temporarily hold current options.
  buffer = allocate_ustrmemp (maxoptions);
  for (i=0; i<maxoptions; i++) {
    buffer[i] = allocate_ustrmem (maxoptlen);
  }

  // Length of each option in buffer.
  bufoptlen = allocate_intmem (maxoptions);

  // Allocate memory for array xtemp to temporarily hold current option x-alignments.
  xtemp = allocate_intmem (maxoptions);

  // Allocate memory for array ytemp to temporarily hold current option y-alignments.
  ytemp = allocate_intmem (maxoptions);

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  if ((mode == 0) || (mode == 1)) {
    // Copy all current options to buffer, option lengths to bufoptlen, and
    // alignment factors to x and y.
    for (i=0; i<(*nopt); i++) {
      memcpy (buffer[i], options[i], optlen[i] * sizeof (uint8_t));
      bufoptlen[i] = optlen[i];
      xtemp[i] = x[i];
      ytemp[i] = y[i];
    }

    // Clear all current options, lengths, and alignment factors.
    for (i=0; i<maxoptions; i++) {
      memset (options[i], 0, maxoptlen * sizeof (uint8_t));
      optlen[i] = 0;
      x[i] = 0;
      y[i] = 0;
    }
  }

  if (mode == 0) {
    // Restore options, lengths, and alignment factors, but
    // stop at option after which we'll insert the new option.
    j = 0;
    for (i=0; i<opt_number; i++) {
      memcpy (options[j], buffer[i], bufoptlen[i] * sizeof (uint8_t));
      optlen[j] = bufoptlen[i];
      x[j] = xtemp[i];
      y[j] = ytemp[i];
      j++;
    }

    // New option takes length of option in buffer.
    optlen[j] = (*optlenbuf);

    // Copy contents of option buffer to option array.
    memcpy (options[j], optionsbuf, (*optlenbuf) * sizeof (uint8_t));

    // New option alignment factors are taken from entries.
    x[j] = (int) ascii_to_int64 ((char *) entryx_text);
    y[j] = (int) ascii_to_int64 ((char *) entryy_text);
    j++;

    // Copy the remaining original options, lengths, and alignment factors.
    for (i=opt_number; i<(*nopt); i++) {
      memcpy (options[j], buffer[i], bufoptlen[i] * sizeof (uint8_t));
      optlen[j] = bufoptlen[i];
      x[j] = xtemp[i];
      y[j] = ytemp[i];
      j++;
    }

    // Increment the number of options by one.
    (*nopt)++;

    // Hop-by-hop header or first destination header
    if (data->hop_flag || (data->dst_flag && !data->dst_fl_flag)) {
      textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (textview1));
      sprintf (value, "%i", (*nopt));
      gtk_text_buffer_set_text (textbuffer, value, -1);

    // Last destination header
    } else if (data->dst_flag && data->dst_fl_flag) {
      textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (textview2));
      sprintf (value, "%i", (*nopt));
      gtk_text_buffer_set_text (textbuffer, value, -1);
    }

  }  // End if mode == 0

  if (mode == 1) {
    // Restore options, lengths, and alignment factors, but skip the one we want to remove.
    j = 0;
    for (i=0; i<(*nopt); i++) {
      if ((i + 1) == opt_number) {
        continue;
      } else {
        memcpy (options[j], buffer[i], bufoptlen[i] * sizeof (uint8_t));
        optlen[j] = bufoptlen[i];
        x[j] = xtemp[i];
        y[j] = ytemp[i];
        j++;
      }
    }

    // Decrement the number of options by one.
    (*nopt)--;

    // Hop-by-hop header or first destination header
    if (data->hop_flag || (data->dst_flag && !data->dst_fl_flag)) {
      textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (textview1));
      sprintf (value, "%i", (*nopt));
      gtk_text_buffer_set_text (textbuffer, value, -1);

    // Last destination header
    } else if (data->dst_flag && data->dst_fl_flag) {
      textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (textview2));
      sprintf (value, "%i", (*nopt));
      gtk_text_buffer_set_text (textbuffer, value, -1);
    }
  }  // End if mode == 1

  if (mode == 2) {
    // New option takes length of option in buffer.
    optlen[*nopt] = (*optlenbuf);

    // Copy contents of option buffer to option array.
    memcpy (options[*nopt], optionsbuf, (*optlenbuf) * sizeof (uint8_t));

    // New alignment factors are taken from entries.
    x[*nopt] = (int) ascii_to_int64 ((char *) entryx_text);
    y[*nopt] = (int) ascii_to_int64 ((char *) entryy_text);

    // Increment number of options in packet.
    (*nopt)++;

    // Hop-by-hop header or first destination header
    if (data->hop_flag || (data->dst_flag && !data->dst_fl_flag)) {
      textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (textview1));
      sprintf (value, "%i", (*nopt));
      gtk_text_buffer_set_text (textbuffer, value, -1);

    // Last destination header
    } else if (data->dst_flag && data->dst_fl_flag) {
      textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (textview2));
      sprintf (value, "%i", (*nopt));
      gtk_text_buffer_set_text (textbuffer, value, -1);
    }
  }  // End if mode == 2

  // Calculate total length of options.
  (*opt_totlen) = 0;
  for (i=0; i<(*nopt); i++) {
    (*opt_totlen) += optlen[i];
  }

  // Determine total padding needed to align and pad options (Section 4.2 of RFC 2460).
  indx = 0;  // Index is zero at start of header.

  if ((*nopt) > 0) {
    indx += hdrlen; // Account for hop-by-hop or destination header length (Next Header and Header Length fields)

    // Loop through all options.
    for (i=0; i<(*nopt); i++) {

      // Pad as needed to achieve alignment requirements for option i.
      j = indx;
      option_pad (&indx, optleadpad[i], 0, x[i], y[i]);
      optleadpadlen[i] = indx - j;

      // Length of option i
      indx += optlen[i];
    }
    // Now pad last option to next 8-byte boundary.
    j = indx;
    option_pad (&indx, opttailpad, 0, 8, 0);
    (*opttailpadlen) = indx - j;

    // Total of alignments and final padding = indx - HOP_HDRLEN/DST_HDRLEN - total length of (non-pad) options
    (*optpadlen) = indx - hdrlen - (*opt_totlen);

    // Determine length of hop-by-hop/destination header in units of 8 bytes, excluding first 8 bytes.
    i = (indx - 8) / 8;
    if (i < 0) {
      i = 0;
    }
    if (data->hop_flag) {
      data->hophdr[data->exthdr_type].hdr_len = i;
    } else if (data->dst_flag) {
      if (!data->dst_fl_flag) {
        data->dstfhdr[data->exthdr_type].hdr_len = i;  // First destination header
      } else {
        data->dstlhdr[data->exthdr_type].hdr_len = i;  // Last destination header
      }
    }
  } else {
    (*opt_totlen) = 0;
    (*optpadlen) = 0;
  }

  // Free allocated memory.
  for (i=0; i<maxoptions; i++) {
    free (buffer[i]);
  }
  free (buffer);
  free (bufoptlen);
  free (value);
  free (xtemp);
  free (ytemp);

  return (EXIT_SUCCESS);
}

// Number of option after which to insert new hop-by-hop or destination option.
int
dsthop_opt_insert_after_entry (GtkWidget *entry, int *opt_after)
{
  const char *entry_text;

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (!ascii_to_int64 ((char *) entry_text))) {
    gtk_entry_set_text (GTK_ENTRY (entry), "");
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    *opt_after = (int) ascii_to_int64 ((char *) entry_text);
  }

  return (EXIT_SUCCESS);
}

// View hop-by-hop or destination header options.
int
dsthop_opt_view (int fl, SPSData *data)
{
  int i, total_len;
  char *string, *title;
  GtkWidget *window, *scrolled_win, *textview;
  GtkTextBuffer *buffer;
  PangoFontDescription *textview_font;

  // Allocate memory for various arrays.
  title = allocate_strmem (TEXT_STRINGLEN);
  
  total_len = 0;  // Will be used to allocate memory for display data.

  // Hop-by-hpo header
  if (data->hop_flag) {
    data->parent = data->hop_window;  // Set parent window for error messaging.

    // Abort if there are no options to display.
    if (!data->hbh_nopt[data->exthdr_type]) {
      sprintf (data->error_text, "There are no hop-by-hop options to display.");
      report_error (data);
      free (title);
      return (EXIT_FAILURE);
    }

    // Calculate length of string necessary to hold list of options.
    for (i=0; i<data->hbh_nopt[data->exthdr_type]; i++) {
      total_len += strnlen ("Option XXX: ", 12) + strnlen ("Alignment: xx xx ", 17);  // Allow for labels
      total_len += strnlen ("00000000 :", 10);  // Allow for address
      total_len += strnlen ("End padding:", 12) + 256;  // Another label plus a somewhat arbitrary (but big) allowance for list of padding bytes
      total_len += (data->hbh_optlen[data->exthdr_type][i] * 3);  // Length of each option byte in ASCII rep. of hexadecimal (2) plus a space (1)
    }
    string = allocate_strmem (total_len);  // Allocate memory for list of hop-by-hop options.
    compose_exoptstring (data->exthdr_type, string, data->hbh_nopt[data->exthdr_type], data->hbh_optlen, data->hbh_options, data);
    memset (title, 0, TEXT_STRINGLEN * sizeof (char));
    strncpy (title, "Hop-by-hop Header ", TEXT_STRINGLEN - 1);  // Minus 1 for string termination.

  // Destination headers
  } else if (data->dst_flag) {
    data->parent = data->dst_window;  // Set parent window for error messaging.

    // "First" destination header
    if (!fl) {

      // Abort if there are no options to display.
      if (!data->dstf_nopt[data->exthdr_type]) {
        sprintf (data->error_text, "There are no \"first\" destination options to display.");
        report_error (data);
        free (title);
        return (EXIT_FAILURE);
      }

      // Calculate length of string necessary to hold list of options.
      for (i=0; i<data->dstf_nopt[data->exthdr_type]; i++) {
        total_len += strnlen ("Option XXX: ", 12) + strnlen ("Alignment: xx xx ", 17);  // Allow for labels
        total_len += strnlen ("00000000 :", 10);  // Allow for address
        total_len += strnlen ("End padding:", 12) + 256;  // Another label plus a somewhat arbitrary (but big) allowance for list of padding bytes
        total_len += (data->dstf_optlen[data->exthdr_type][i] * 3);  // Length of each option byte in ASCII rep. of hexadecimal (2) plus a space (1)
      }
      string = allocate_strmem (total_len);  // Allocate memory for list of hop-by-hop options.
      compose_exoptstring (data->exthdr_type, string, data->dstf_nopt[data->exthdr_type], data->dstf_optlen, data->dstf_options, data);
      memset (title, 0, TEXT_STRINGLEN * sizeof (char));
      strncpy (title, "Destination Header (first) ", TEXT_STRINGLEN - 1);  // Minus 1 for string termination.

    // "Last" destination header
    } else {
      // Abort if there are no options to display.
      if (!data->dstl_nopt[data->exthdr_type]) {
        sprintf (data->error_text, "There are no \"last\" destination options to display.");
        report_error (data);
        free (title);
        return (EXIT_FAILURE);
      }

      // Calculate length of string necessary to hold list of options.
      for (i=0; i<data->dstl_nopt[data->exthdr_type]; i++) {
        total_len += strnlen ("Option XXX: ", 12) + strnlen ("Alignment: xx xx ", 17);  // Allow for labels
        total_len += strnlen ("00000000 :", 10);  // Allow for address
        total_len += strnlen ("End padding:", 12) + 256;  // Another label plus a somewhat arbitrary (but big) allowance for list of padding bytes
        total_len += (data->dstl_optlen[data->exthdr_type][i] * 3);  // Length of each option byte in ASCII rep. of hexadecimal (2) plus a space (1)
      }
      string = allocate_strmem (total_len);  // Allocate memory for list of hop-by-hop options.
      compose_exoptstring (data->exthdr_type, string, data->dstl_nopt[data->exthdr_type], data->dstl_optlen, data->dstl_options, data);
      memset (title, 0, TEXT_STRINGLEN * sizeof (char));
      strncpy (title, "Destination Header (last) ", TEXT_STRINGLEN - 1);  // Minus 1 for string termination.
    }

  // Error condition
  } else {
    fprintf (stderr, "ERROR: dsthop_opt view() was called and neither data->hop_flag not data->dst_flag is set.\n");
    exit (EXIT_FAILURE);
  }

  // Create new window to display options.
  window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_resizable (GTK_WINDOW (window), TRUE);
  gtk_window_set_position (GTK_WINDOW (window), GTK_WIN_POS_NONE);
  switch (data->exthdr_type) {
    case 3:
      sprintf (title, "%sOptions for IPv6 TCP Packet", title);
      break;
    case 4:
      sprintf (title, "%sOptions for IPv6 ICMP Packet", title);
      break;
    case 5:
      sprintf (title, "%sOptions for IPv6 UDP Packet", title);
      break;
    case 12:
      sprintf (title, "%sOptions for IPv6 TCP Packet for Traceroute", title);
      break;
    case 13:
      sprintf (title, "%sOptions for IPv6 ICMP Packet for Traceroute", title);
      break;
    case 14:
      sprintf (title, "%sOptions for IPv6 UDP Packet for Traceroute", title);
      break;
    default:
      fprintf (stderr, "ERROR: Invalid upper layer protocol type %i in dsthop_opt_view().\n", data->exthdr_type);
      free (string);
      free (title);
      return (EXIT_FAILURE);
  }
  gtk_window_set_title (GTK_WINDOW (window), title);
  gtk_window_set_default_size (GTK_WINDOW (window), 1000, 200);
  gtk_container_set_border_width (GTK_CONTAINER (window), 1);

  // Create a textview object to display options.
  textview = gtk_text_view_new ();
  buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (textview));
  gtk_text_view_set_cursor_visible (GTK_TEXT_VIEW (textview), TRUE);
  textview_font = pango_font_description_from_string ("Courier 10 Pitch 12");
  gtk_widget_override_font (textview, textview_font);

  // Put the text into the buffer.
  gtk_text_buffer_set_text (buffer, string, -1);

  // Add scrolled window and textview to new window and display options.
  scrolled_win = gtk_scrolled_window_new (NULL, NULL);
  gtk_container_add (GTK_CONTAINER (scrolled_win), textview);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolled_win), GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS);

  gtk_container_add (GTK_CONTAINER (window), scrolled_win);
  gtk_widget_show_all (window);

  // Free allocated memory.
  free (string);
  free (title);

  return (EXIT_SUCCESS);
}

// Number of hop-by-hop or destination option to remove.
int
dsthop_opt_remove_entry (GtkWidget *entry, int *opt_remove)
{
  const char *entry_text;

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || ((int) ascii_to_int64 ((char *) entry_text) == 0)) {
    gtk_entry_set_text (GTK_ENTRY (entry), "");
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    *opt_remove = (int) ascii_to_int64 ((char *) entry_text);
  }

  return (EXIT_SUCCESS);
}

// Provide padding as needed to achieve alignment requirements of hop-by-hop or destination option.
int
option_pad (int *indx, uint8_t *padding, int c, int x, int y)
{
  // The remainder cannot be greater than or equal to the divisor.
  if (y >= x) {
    return (EXIT_FAILURE);
  }

  int needpad;

  // Find number of padding bytes needed to achieve alignment requirements for option (Section 4.2 of RFC 2460).
  // Alignment is expressed as xN + y, which means the start of the option must occur at xN + y bytes
  // from the start of the hop-by-hop or destination header, where N is integer 0, 1, 2, ...etc.
  needpad = 0;
  while (((*indx + needpad) % x) != y) {
    needpad++;
  }

  // If required padding = 1 byte, we use Pad1 option.
  if (needpad == 1) {
    padding[c] = 0u;  // Padding option type: Pad1
    (*indx)++;
    c++;

  // If required padding is > 1 byte, we use PadN option.
  } else if (needpad > 1) {
    padding[c] = 1u;  // Padding option type: PadN
    (*indx)++;
    c++;
    padding[c] = (uint8_t) (needpad - 2);  // PadN length: N - 2
    (*indx)++;
    c++;
    memset (padding + c, 0, (needpad - 2) * sizeof (uint8_t));
    (*indx) += needpad - 2;
    c += needpad - 2;
  }

  return (EXIT_SUCCESS);
}
