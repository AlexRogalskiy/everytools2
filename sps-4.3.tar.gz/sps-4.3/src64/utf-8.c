/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Examine an array and report any non-UTF-8 characters.
int
is_valid_utf8 (uint8_t *testdata, int nbytes, GtkWidget *parent, SPSData *data)
{
  int i, j, len;
  uint8_t *temp;

  // Allocate memory for various arrays.
  temp = allocate_ustrmem (TEXT_STRINGLEN);

  i = 0;
  while (i < nbytes) {
    if (one_byte (nbytes, i, testdata)) {
      i++;
    } else if (two_byte (nbytes, i, testdata)) {
      i += 2;
    } else if (three_byte (nbytes, i, testdata)) {
      i += 3;
    } else if (four_byte (nbytes, i, testdata)) {
      i += 4;
    } else if (five_byte (nbytes, i, testdata)) {
      i += 5;
    } else if (six_byte (nbytes, i, testdata)) {
      i += 6;
    } else {
      sprintf (data->error_text, "Non-UTF-8 character appears at byte %08x\n", i);
      len = strnlen (data->error_text, TEXT_STRINGLEN);
      strncat (data->error_text, "Here are 40 characters starting with problem character (ignore quotes): \"", TEXT_STRINGLEN - len);
      memset (temp, 0, 40 * sizeof (char));
      if ((nbytes - (i+1)) >= 40) {
        for (j=i; j<(i+40); j++) {
           sprintf ((char *) temp, "%s%c", (char *) temp, (char) testdata[j]);
        }
      } else {
        for (j=i; j<nbytes; j++) {
           sprintf ((char *) temp, "%s%c", (char *) temp, (char) testdata[j]);
        }
      }
      strncat ((char *) temp, "\"", 1);
      len = strnlen (data->error_text, TEXT_STRINGLEN);
      strncat (data->error_text, (char *) temp, TEXT_STRINGLEN - len);
      data->parent = parent;
      report_error (data);
      free (temp);
      return (0);  // Found invalid UTF-8 characters.
    }
  }  // End while i < nbytes

  // Free allocated memory.
  free (temp);

  return (1);  // Success: data contains no invalid UTF-8 characters.
}

// Convert any lower case UTF-8 letters to upper case.
int
raise_case (uint8_t *input_string, int len_in, uint8_t *output_string, GtkWidget *parent, SPSData *data)
{
  int i, j, len, ZERO;
  uint8_t *small_val, *cap_val;

  ZERO = 0;

  // Allocate memory for various arrays.
  small_val = allocate_ustrmem (6);
  cap_val = allocate_ustrmem (6);

  i = 0;  // Index of input character array
  j = 0;  // Index of output character array
  while (i < len_in) {
    memset (cap_val, 0, 6 * sizeof (uint8_t));
    memset (small_val, 0, 6 * sizeof (uint8_t));
    if (one_byte (len_in, i, input_string)) {
      len = 1;
    } else if (two_byte (len_in, i, input_string)) {
      len = 2;
    } else if (three_byte (len_in, i, input_string)) {
      len = 3;
    } else if (four_byte (len_in, i, input_string)) {
      len = 4;
    } else if (five_byte (len_in, i, input_string)) {
      len = 5;
    } else if (six_byte (len_in, i, input_string)) {
      len = 6;
    } else {
      sprintf (data->error_text, "raise_case(): Found an invalid UTF-8 character.\nCall is_valid_utf8() first.");
      data->parent = parent;
      report_error (data);
      return (0);  // Found invalid UTF-8 character.
    }
    memcpy (small_val, input_string + i, len * sizeof (uint8_t));
    if (is_small_utf8_letter (small_val, data) > 0) {
      memcpy (cap_val, data->utf8[find_val (small_val, &ZERO, data)][CAPITAL], len * sizeof (uint8_t));
      memcpy (output_string + j, cap_val, len * sizeof (uint8_t));
    } else {
      memcpy (output_string + j, input_string + i, len * sizeof (uint8_t));
    }
    i += len;
    j += len;
  }

  // Free allocated memory.
  free (small_val);
  free (cap_val);

  return (1);  // Appears to be valid UTF-8 characters.
}

// Determine if character is a lower case UTF-8 letter.
// Return 1 if it is lower case letter, 0 if it is upper case letter, -1 if neither.
int
is_small_utf8_letter (uint8_t *value, SPSData *data)
{
  int zero, one;

  zero = 0;
  one = 1;

  // Lower case
  if (find_val (value, &zero, data) > -1) {
    return (1);  // It's a lower case character.

  // Upper case
  } else if (find_val (value, &one, data) > -1) {
    return (0);  // It's an upper case character.

  // Neither upper nor lower case letter.
  } else {
    return (-1);  // Must be some non-letter symbol.
  }
}

// Find a UTF-8 character's byte sequence in cross-reference array.
int
find_val (uint8_t *value, int *char_case, SPSData *data)
{
  int i, found;
  uint8_t *value2;

  // Allocate memory for various arrays.
  value2 = allocate_ustrmem (6);

  found = 0;

  // Search lower case character list.
  if (!(*char_case)) {

    for (i=0; i<data->nutf8; i++) {
      if (memcmp (value, data->utf8[i][SMALL], 6) == 0) {
        found = 1;
        break;
      }
    }

  // Search upper case character list.
  } else if (*char_case) {
    for (i=0; i<data->nutf8; i++) {
      if (memcmp (value, data->utf8[i][CAPITAL], 6) == 0) {
        found = 1;
        break;
      }
    }
  }

  // Free allocated memory.
  free (value2);

  if (!found) {
    return (-1);  // Couldn't find a match.
  }

  return (i);
}

// Convert ascii representation of UTF-8 byte sequence to uint8_t byte sequence.
uint8_t *
utf8_value (uint8_t *result, uint8_t *field)
{
  int i, j, k, len, nvals;
  char **endptr;
  uint8_t *temp;

  len = strnlen ((char *) field, TEXT_STRINGLEN);
  temp = allocate_ustrmem (3);

  // Count number of hexadecimal values are in the field.
  nvals = 0;
  i = 0;
  while (i < len) {
    while ((field[i] != ' ') && (field[i] != 0) && (i < len)) {
      i++;
    }
    nvals++;
    i++;
  }

  // Convert ASCII hex values to uint8_t array.
  memset (result, 0, 6 * sizeof (uint8_t));
  j = 0;  // Index of field
  k = 0;  // Index of result
  for (i=0; i<nvals; i++) {
    memset (temp, 0, 3 * sizeof (uint8_t));
    memcpy (temp, field + j, 2 * sizeof (uint8_t));
    j += 3;

    // Convert to base-10.
    endptr = NULL;
    result[k] = (uint8_t) strtol ((char *) temp, endptr, 16);
    if (endptr != NULL) {
      fprintf (stderr, "strtol() failed in utf8_value().\n");
      exit (EXIT_FAILURE);
    }
    k++;
  }

  // Free allocated memory.
  free (temp);

  return (result);
}

// Determine if input is a 1-byte UTF-8 character.
int
one_byte (int nbytes, int i, uint8_t *data)
{
  // Check for valid index.
  if (i >= nbytes) {
    fprintf (stderr, "ERROR: In one_byte(), index i is greater than or equal to nbytes.");
    exit (EXIT_FAILURE);
  }

  if (data[i] >> 7) {
    return (0);  // Not a valid 1-byte UTF-8 character
  }

  return (1);  // Is a valid 1-byte UTF-8 character
}

// Determine if input is a 2-byte UTF-8 character.
int
two_byte (int nbytes, int i, uint8_t *data)
{
  // Check for valid index.
  if ((i + 1) >= nbytes) {
    fprintf (stderr, "ERROR: In two_byte(), index i+1 is greater than or equal to nbytes.");
    exit (EXIT_FAILURE);
  }

  if ((data[i] >> 5) == 0x6) {  // 0x6 = 110b
    if ((data[i+1] >> 6) == 0x2) {  // 0x2 = 10b
      return (1);
    }
  }

  return (0);  // Not a valid 2-byte UTF-8 character
}

// Determine if input is a 2-byte UTF-8 character.
int
three_byte (int nbytes, int i, uint8_t *data)
{
  // Check for valid index.
  if ((i + 2) >= nbytes) {
    fprintf (stderr, "ERROR: In three_byte(), index i+2 is greater than or equal to nbytes.");
    exit (EXIT_FAILURE);
  }
    
 if ((data[i] >> 4) == 0xe) {  // 0xe = 1110b
   if ((data[i+1] >> 6) == 0x2) {  // 0x2 = 10b
     if ((data[i+2] >> 6) == 0x2) {  // 0x2 = 10b
       return (1); 
     }
   }
 }
  
  return (0);  // Not a valid 3-byte UTF-8 character
}

// Determine if input is a 4-byte UTF-8 character.
int
four_byte (int nbytes, int i, uint8_t *data)
{
  // Check for valid index.
  if ((i + 3) >= nbytes) {
    fprintf (stderr, "ERROR: In four_byte(), index i+3 is greater than or equal to nbytes.");
    exit (EXIT_FAILURE);
  }
    
 if ((data[i] >> 3) == 0x1e) {  // 0x1e = 11110b
   if ((data[i+1] >> 6) == 0x2) {  // 0x2 = 10b
     if ((data[i+2] >> 6) == 0x2) {  // 0x2 = 10b
       if ((data[i+3] >> 6) == 0x2) {  // ox2 = 10b
         return (1);
       }
     }
   }
 }

  return (0);  // Not a valid 4-byte UTF-8 character
}

// Determine if input is a 5-byte UTF-8 character.
int
five_byte (int nbytes, int i, uint8_t *data)
{
  // Check for valid index.
  if ((i + 4) >= nbytes) {
    fprintf (stderr, "ERROR: In five_byte(), index i+4 is greater than or equal to nbytes.");
    exit (EXIT_FAILURE);
  }
    
 if ((data[i] >> 2) == 0x3e) {  // 0x3e = 111110b
   if ((data[i+1] >> 6) == 0x2) {  // 0x2 = 10b
     if ((data[i+2] >> 6) == 0x2) {  // 0x2 = 10b
       if ((data[i+3] >> 6) == 0x2) {  // 0x2 = 10b
         if ((data[i+4] >> 6) == 0x2) {  // 0x2 = 10b
           return (1);
         }
       }
     }
   }
 }

  return (0);  // Not a valid 5-byte UTF-8 character
}

// Determine if input is a 6-byte UTF-8 character.
int
six_byte (int nbytes, int i, uint8_t *data)
{
  // Check for valid index.
  if ((i + 5) >= nbytes) {
    fprintf (stderr, "ERROR: In six_byte(), index i+5 is greater than or equal to nbytes.");
    exit (EXIT_FAILURE);
  }
    
 if ((data[i] >> 1) == 0x7e) {  // 0x7e = 1111110b
   if ((data[i+1] >> 6) == 0x2) {  // 0x2 = 10b
     if ((data[i+2] >> 6) == 0x2) {  // 0x2 = 10b
       if ((data[i+3] >> 6) == 0x2) {  // 0x2 = 10b
         if ((data[i+4] >> 6) == 0x2) {  // 0x2 = 10b
           if ((data[i+5] >> 6) == 0x2) {  // 0x2 = 10b
             return (1);
           }
         }
       }
     }
   }
 }  
    
  return (0);  // Not a valid 6-byte UTF-8 character
}

// Load the UTF-8 cross-reference file UTF8_FILENAME into an array.
// utf8[record][SMALL/CAP] = uint8_t * of size 6
// int nutf8 = number of lines (characters) in file UTF8_FILENAME
int
load_utf8 (SPSData *data)
{
  int i, j, k, n;
  uint8_t *temp;
  FILE *fi;

  // Allocate memory for various arrays.
  temp = allocate_ustrmem (TEXT_STRINGLEN);

  // Open small-capital UTF-8 cross-reference file.
  fi = fopen (UTF8_FILENAME, "rb");
  if (fi == NULL) {
    fprintf (stderr, "Cannot open UTF-8 cross-reference file \"%s\".", UTF8_FILENAME);
    exit (EXIT_FAILURE);
  }

  // Count all lines in input file.
  if (fgetc (fi) == EOF) {
    fprintf (stderr, "Small-capital UTF-8 cross-reference file \"%s\" is empty.", UTF8_FILENAME);
    exit (EXIT_FAILURE);
  } else {
    rewind (fi);
    data->nutf8 = 0;
    while (fgets ((char *) temp, TEXT_STRINGLEN, fi) != NULL) {
      data->nutf8++;
    }
    rewind (fi);
  }

  // Allocate memory for lines of input file
  data->utf8 = allocate_ustrmempp (data->nutf8);
  for (i=0; i<data->nutf8; i++) {
    data->utf8[i] = allocate_ustrmemp (2);
    for (j=0; j<2; j++) {
      data->utf8[i][j] = allocate_ustrmem (6);  // Maximum length of UTF-8 character is 6 bytes.
    }
  }

  // Read input file into a character array
  k = 0;  // Index of array utf8
  for (i=0; i<data->nutf8; i++) {
    memset (temp, 0, TEXT_STRINGLEN * sizeof (uint8_t));
    j = 0;
    while ((n = fgetc (fi)) != ',') {
      if (n == EOF) break;
      temp[j] = (uint8_t) n;
      j++;
    }
    while ((n = fgetc (fi)) != '\n') {
      if (n == EOF) break;
    }
    utf8_value (data->utf8[k][i % 2], temp);  // Lower case if (i % 2) = 0, Upper case if (i % 2) = 1
    if (i % 2) k++;
  }

  // Close file descriptor.
  fclose (fi);

  // Free allocated memory.
  free (temp);

  return (EXIT_SUCCESS);
}
