package com.iluwatar.domain;

import org.hamcrest.Description;
import org.hamcrest.TypeSafeMatcher;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

public class DomainObjectTest {

    @Test
    public void domainObjectConstructedProperlyFromClass() {
        DomainObject viaClassConstructor = new DomainObject(DomainObjectTest.class);
        assertThat(viaClassConstructor,
                new DomainObjectAssertion("com.iluwatar.domain", "DomainObjectTest"));
    }

    @Test
    public void domainConstructedProperlyFromInnerClass() {
        DomainObject viaClassConstructor = new DomainObject(DomainObjectTest.DomainObjectAssertion.class);
        assertThat(viaClassConstructor,
                new DomainObjectAssertion("com.iluwatar.domain", "DomainObjectAssertion"));
    }

    @Test
    public void toStringWorks() {
        String toString = new DomainObject(DomainObjectAssertion.class).toString();
        assertThat(toString, containsString("packageName"));
        assertThat(toString, containsString("className"));
    }

    private static class DomainObjectAssertion extends TypeSafeMatcher<DomainObject> {
        private String expectedPackageName;
        private String expectedClassName;

        public DomainObjectAssertion(String expectedPackageName, String expectedClassName) {
            this.expectedPackageName = expectedPackageName;
            this.expectedClassName = expectedClassName;
        }

        @Override
        public void describeTo(Description description) {
            description.appendText("faulty domain object construction");
        }

        @Override
        protected boolean matchesSafely(DomainObject domainObject) {
            assertThat(domainObject.packageName, is(expectedPackageName));
            assertThat(domainObject.className, is(expectedClassName));
            return true;
        }
    }
}
