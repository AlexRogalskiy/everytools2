/**
 * this should be ignored by the scanner
 */
package com.iluwatar.testdomain;