/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Prepare a string of text containing IPv4 header options or TCP options.
int
compose_optstring (int type, char *string_out, int nopt, int **optlen, uint8_t ***options, int optpad)
{
  int iopt, i, d;
  char *temp;

  // Allocate memeory for temporary array.
  temp = allocate_strmem (TEXT_STRINGLEN);

  d = 0;  // Index of string_out

  // Loop through all options.
  for (iopt=0; iopt<nopt; iopt++) {
    sprintf (temp, "Option %i:\n", iopt + 1);
    sprintf (string_out + d, "%s", temp); d += strnlen (temp, TEXT_STRINGLEN);

    d += hexascii_listing (options[type][iopt], optlen[type][iopt], string_out + d, 1);

    // Add two line-feeds between options.
    string_out[d] = '\n'; d++;
    string_out[d] = '\n'; d++;
  }  // End loop through options

  // Show amount of padding.
  sprintf (string_out + d, "End padding: ");
  d += 13;
  for (i=0; i<optpad; i++) {
    sprintf (string_out + d, "00 ");
    d += 3;
  }
  string_out[d] = '\n'; d++;

  // Free allocated memory.
  free (temp);

  return (EXIT_SUCCESS);
}

// Insert, remove, or append an IPv4 option.
int
ip4_option (int mode, int type, int ipopt_number, GtkWidget *textview, GtkWidget *spinbutton, SPSData *data)
{
  // Values for mode
  // 0 = insert
  // 1 = remove
  // 2 = append

  // Abort if trying to insert option after non-existent option.
  if ((mode == 0) && ((ipopt_number > data->ip_nopt[type]) || !data->ip_nopt[type] || !ipopt_number)) {
    return (EXIT_FAILURE);
  }

  // Abort if nothing in option entry buffer to insert or append.
  if (((mode == 0) || (mode == 2)) && (data->ip_optlenbuf[type] == 0)) {
    return (EXIT_FAILURE);
  }

  // Abort if trying to remove an option and none exist.
  if ((mode == 1) && (data->ip_nopt[type] == 0)) {
    return (EXIT_FAILURE);
  }

  // Abort if trying to remove an option and it, specifically, doesn't exist.
  if ((mode == 1) && ((ipopt_number > data->ip_nopt[type]) || (ipopt_number == 0))) {
    return (EXIT_FAILURE);
  }

  // Abort if user requests more than MAX_IP4OPTIONS hop-by-hop options.
  if (((mode == 0) || (mode == 2)) && (data->ip_nopt[type] == MAX_IP4OPTIONS)) {
    sprintf (data->error_text, "The number of IPv4 options is currently limited to %i in main.h as MAX_IP4OPTIONS.", MAX_IP4OPTIONS);
    report_error (data);
    return (EXIT_FAILURE);
  }

  int i, j;
  char *value;
  int *bufoptlen;
  uint8_t **buffer;
  GtkTextBuffer *textbuffer;

  if (type < 9) {
    data->parent = data->main_window;
  } else {
    data->parent = data->traceroute_window;
  }

  // Allocate memory for buffer to temporarily hold current IP options.
  buffer = allocate_ustrmemp (MAX_IP4OPTIONS);
  for (i=0; i<MAX_IP4OPTIONS; i++) {
    buffer[i] = allocate_ustrmem (MAX_IP4OPTLEN);
  }

  // Length of each IP option in buffer.
  bufoptlen = allocate_intmem (MAX_IP4OPTIONS);

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  if ((mode == 0) || (mode == 1)) {
    // Copy all current IP options to buffer and option lengths to bufoptlen.
    for (i=0; i<data->ip_nopt[type]; i++) {
      memcpy (buffer[i], data->ip_options[type][i], data->ip_optlen[type][i] * sizeof (uint8_t));
      bufoptlen[i] = data->ip_optlen[type][i];
    }

    // Clear all current IP options.
    for (i=0; i<MAX_IP4OPTIONS; i++) {
      memset (data->ip_options[type][i], 0, MAX_IP4OPTLEN * sizeof (uint8_t));
      data->ip_optlen[type][i] = 0;
    }
  }

  if (mode == 0) {
    // Copy IP options from buffer but stop at option after which we'll insert the new option.
    j = 0;
    for (i=0; i<ipopt_number; i++) {
      memcpy (data->ip_options[type][j], buffer[i], bufoptlen[i] * sizeof (uint8_t));
      data->ip_optlen[type][j] = bufoptlen[i];
      j++;
    }

    // New option takes length of option in buffer.
    data->ip_optlen[type][j] = data->ip_optlenbuf[type];

    // Copy contents of option buffer to option array.
    memcpy (data->ip_options[type][j], data->ip_optionsbuf[type], data->ip_optlenbuf[type] * sizeof (uint8_t));
    j++;

    // Copy the remaining original options from buffer.
    for (i=ipopt_number; i<data->ip_nopt[type]; i++) {
      memcpy (data->ip_options[type][j], buffer[i], bufoptlen[i] * sizeof (uint8_t));
      data->ip_optlen[type][j] = bufoptlen[i];
      j++;
    }

    // Increment the number of IP options by one.
    data->ip_nopt[type]++;
    textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (textview));
    sprintf (value, "%i", data->ip_nopt[type]);
    gtk_text_buffer_set_text (textbuffer, value, -1);
  }  // End if mode == 0

  if (mode == 1) {
    // Copy IP options from buffer but skip the one we want to remove.
    j = 0;
    for (i=0; i<data->ip_nopt[type]; i++) {
      if ((i + 1) == ipopt_number) {
        continue;
      } else {
        memcpy (data->ip_options[type][j], buffer[i], bufoptlen[i] * sizeof (uint8_t));
        data->ip_optlen[type][j] = bufoptlen[i];
        j++;
      }
    }

    // Decrement the number of IP options by one.
    data->ip_nopt[type]--;
    textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (textview));
    sprintf (value, "%i", data->ip_nopt[type]);
    gtk_text_buffer_set_text (textbuffer, value, -1);
  }  // End if mode == 1

  if (mode == 2) {
    // New option takes length of option in buffer.
    data->ip_optlen[type][data->ip_nopt[type]] = data->ip_optlenbuf[type];

    // Copy contents of option buffer to option array.
    memcpy (data->ip_options[type][data->ip_nopt[type]], data->ip_optionsbuf[type], data->ip_optlenbuf[type] * sizeof (uint8_t));

    // Increment number of IP options in packet.
    data->ip_nopt[type]++;
    textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (textview));
    sprintf (value, "%i", data->ip_nopt[type]);
    gtk_text_buffer_set_text (textbuffer, value, -1);
  }  // End if mode == 2

  // Calculate total length of IP options.
  data->ip_opt_totlen[type] = 0;
  for (i=0; i<data->ip_nopt[type]; i++) {
    data->ip_opt_totlen[type] += data->ip_optlen[type][i];
  }

  // Determine padding needed to pad IP options
  // with zeros to the next 32-bit boundary.
  data->ip_optpadlen[type] = 0;
  while (((data->ip_opt_totlen[type] + data->ip_optpadlen[type]) % 4) != 0) {
    data->ip_optpadlen[type]++;
  }

  // Truncate upper layer protocol payload if necessary to accomodate packet size limit.
  if (truncate_ip4 (type, data)) {
    sprintf (data->warning_text, "Upper layer protocol payload data was truncated\nto accomodate maximum packet size of %i bytes.", IP_MAXPACKET);
    report_warning (data);
  }

  // Update lengths, offsets, and checksums.
  ip4data_update (type, data);

  // Check if MTU is sufficiently large to accomodate packet. Revise if necessary.
  check_mtu (type, data);

  // Update ethernet frame.
  create_ip4_frame (type, data);

  // Free allocated memory.
  for (i=0; i<MAX_IP4OPTIONS; i++) {
    free (buffer[i]);
  }
  free (buffer);
  free (bufoptlen);
  free (value);

  // Update MTU spinbutton.
  gtk_spin_button_set_value (GTK_SPIN_BUTTON (spinbutton), data->ifmtu[type]);

  return (EXIT_SUCCESS);
}

// Number of option after which to insert new IPv4 option.
int
ip4_opt_insert_after_entry (GtkWidget *entry, int type, int *ipopt_after, SPSData *data)
{
  const char *entry_text;

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (!ascii_to_int64 ((char *) entry_text)) || (ascii_to_int64 ((char *) entry_text) > (data->ip_nopt[type] + 1u))) {
    gtk_entry_set_text (GTK_ENTRY (entry), "");
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    *ipopt_after = (int) ascii_to_int64 ((char *) entry_text);
  }

  return (EXIT_SUCCESS);
}

// View IPv4 header options or TCP header (IPv4 or IPv6) options.
// See dsthop_opt_view() for viewing IPv6 hop-by-hop or destination header options.
int
opt_view (int type, int iptcp_flag, SPSData *data)
{
  int i, total_len;
  char *string, *title;
  GtkWidget *window, *scrolled_win, *textview;
  GtkTextBuffer *buffer;
  PangoFontDescription *textview_font;

  // Set parent window for error messaging.
  if ((type >= 0) && (type <= 2)) {
    data->parent = data->main_window;
  } else if ((type >= 9) && (type <= 11)) {
    data->parent = data->traceroute_window;
  }

  // Allocate memory for various arrays.
  title = allocate_strmem (TEXT_STRINGLEN);

  total_len = 0;  // Will be used to allocate memory for display data.

  // IPv4 header options
  if ((((type == 0) || (type == 1) || (type == 2) || (type == 9) || type == 10) || (type == 11)) && !iptcp_flag) {

    // Abort if there are no options to display.
    if (!data->ip_nopt[type]) {
      sprintf (data->error_text, "There are no IPv4 header options to display.");
      report_error (data);
      free (title);
      return (EXIT_FAILURE);
    }

    // Calculate length of string necessary to hold list of options.
    for (i=0; i<data->ip_nopt[type]; i++) {
      total_len += strnlen ("Option XXX: ", 12);  // Allow for labels
      total_len += strnlen ("00000000 :", 10);  // Allow for address
      total_len += strnlen ("End padding:", 12) + 256;  // Another label plus a somewhat arbitrary (but big) allowance for list of padding bytes
      total_len += (data->ip_optlen[type][i] * 3);  // Length of each option byte in ASCII rep. of hexadecimal (2) plus a space (1)
    }
    string = allocate_strmem (total_len);  // Allocate memory for list of hop-by-hop options.
    compose_optstring (type, string, data->ip_nopt[type], data->ip_optlen, data->ip_options, data->ip_optpadlen[type]);
    memset (title, 0, TEXT_STRINGLEN * sizeof (char));
    strncpy (title, "IP Header ", TEXT_STRINGLEN - 1);  // Minus 1 for string termination.

  // TCP header options
  } else if (((type == 0) || (type == 3) || (type == 9) || (type == 12)) && iptcp_flag) {

    // Abort if there are no options to display.
    if (!data->tcp_nopt[type]) {
      sprintf (data->error_text, "There are no TCP header options to display.");
      report_error (data);
      free (title);
      return (EXIT_FAILURE);
    }

    // Calculate length of string necessary to hold list of options.
    for (i=0; i<data->tcp_nopt[type]; i++) {
      total_len += strnlen ("Option XXX: ", 12);  // Allow for labels
      total_len += strnlen ("00000000 :", 10);  // Allow for address
      total_len += strnlen ("End padding:", 12) + 256;  // Another label plus a somewhat arbitrary (but big) allowance for list of padding bytes
      total_len += (data->tcp_optlen[type][i] * 3);  // Length of each option byte in ASCII rep. of hexadecimal (2) plus a space (1)
    }
    string = allocate_strmem (total_len);  // Allocate memory for list of hop-by-hop options.
    compose_optstring (type, string, data->tcp_nopt[type], data->tcp_optlen, data->tcp_options, data->tcp_optpadlen[type]);
    memset (title, 0, TEXT_STRINGLEN * sizeof (char));
    strncpy (title, "TCP Header ", TEXT_STRINGLEN - 1);  // Minus 1 for string termination.

  // Error condition
  } else {
    fprintf (stderr, "ERROR: opt view() was called and neither IPv4 header nor TCP header is selected via \"type\" and \"iptcp_flag\".\n");
    fprintf (stderr, "       type = %i, iptcp_flag = %i\n", type, iptcp_flag);
    exit (EXIT_FAILURE);
  }

  // Create new window to display options.
  window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_resizable (GTK_WINDOW (window), TRUE);
  gtk_window_set_position (GTK_WINDOW (window), GTK_WIN_POS_NONE);
  switch (type) {
    case 0:
      sprintf (title, "%sOptions for IPv4 TCP Packet", title);
      break;
    case 1:
      sprintf (title, "%sOptions for IPv4 ICMP Packet", title);
      break;
    case 2:
      sprintf (title, "%sOptions for IPv4 UDP Packet", title);
      break;
    case 3:
      sprintf (title, "%sOptions for IPv6 TCP Packet", title);
      break;
    case 9:
      sprintf (title, "%sOptions for IPv4 TCP Packet for Traceroute", title);
      break;
    case 10:
      sprintf (title, "%sOptions for IPv4 ICMP Packet for Traceroute", title);
      break;
    case 11:
      sprintf (title, "%sOptions for IPv4 UDP Packet for Traceroute", title);
      break;
    case 12:
      sprintf (title, "%sOptions for IPv6 TCP Packet for Traceroute", title);
      break;
    default:
      fprintf (stderr, "ERROR: Invalid upper layer protocol type %i in opt_view().\n", type);
      free (string);
      free (title);
      return (EXIT_FAILURE);
  }
  gtk_window_set_title (GTK_WINDOW (window), title);
  gtk_window_set_default_size (GTK_WINDOW (window), 1000, 200);
  gtk_container_set_border_width (GTK_CONTAINER (window), 1);

  // Create a textview object to display options.
  textview = gtk_text_view_new ();
  buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (textview));
  gtk_text_view_set_cursor_visible (GTK_TEXT_VIEW (textview), TRUE);
  textview_font = pango_font_description_from_string ("Courier 10 Pitch 12");
  gtk_widget_override_font (textview, textview_font);

  // Put the text into the buffer.
  gtk_text_buffer_set_text (buffer, string, -1);

  // Add scrolled window and textview to new window and display options.
  scrolled_win = gtk_scrolled_window_new (NULL, NULL);
  gtk_container_add (GTK_CONTAINER (scrolled_win), textview);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolled_win), GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS);

  gtk_container_add (GTK_CONTAINER (window), scrolled_win);
  gtk_widget_show_all (window);

  // Free allocated memory.
  free (string);
  free (title);

  return (EXIT_SUCCESS);
}

// Number of IPv4 option to remove.
int
ip4_opt_remove_entry (GtkWidget *entry, int type, int *ipopt_remove, SPSData *data)
{
  const char *entry_text;

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) < 1u) || (ascii_to_int64 ((char *) entry_text) > data->ip_nopt[type])) {
    gtk_entry_set_text (GTK_ENTRY (entry), "");
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    *ipopt_remove = (int) ascii_to_int64 ((char *) entry_text);
  }

  return (EXIT_SUCCESS);
}
