/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// TCP source port (16 bits)
int
tcp_sport_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 65535)) {
    sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[type].th_sport));
    gtk_entry_set_text (GTK_ENTRY (entry), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->tcphdr[type].th_sport = htons ((uint16_t) ascii_to_int64 ((char *) entry_text));  // Update TCP header with new value

    // TCP header checksum (16 bits)
    tcp_chksum (type, data);

    // Update ethernet frames.
    if ((type == 0) || (type == 9)) {
      create_ip4_frame (type, data);

    } else if ((type == 3) || (type == 12)) {
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Create a random TCP source port number (16 bits).
int
tcp_ran_sport (int *ran_sourceport, int type, GtkWidget *entry, SPSData *data)
{
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  if (!(*ran_sourceport)) {
    *ran_sourceport = 1;
    data->tcphdr[type].th_sport = htons (ran16_0to65535 (data));
    sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[type].th_sport));
    gtk_entry_set_text (GTK_ENTRY (entry), value);

    // TCP header checksum (16 bits)
    tcp_chksum (type, data);

    // Update ethernet frames.
    if ((type == 0) || (type == 9)) {
      create_ip4_frame (type, data);

    } else if ((type == 3) || (type == 12)) {
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }

  } else {
    *ran_sourceport = 0;
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// TCP destination port (16 bits)
int
tcp_dport_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 65535)) {
    sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[type].th_dport));
    gtk_entry_set_text (GTK_ENTRY (entry), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->tcphdr[type].th_dport = htons ((uint16_t) ascii_to_int64 ((char *) entry_text));  // Update TCP header with new value

    // TCP header checksum (16 bits)
    tcp_chksum (type, data);

    // Update ethernet frames.
    if ((type == 0) || (type == 9)) {
      create_ip4_frame (type, data);

    } else if ((type == 3) || (type == 12)) {
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// TCP sequence number (32 bits)
int
tcp_seqnum_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) == 0xffffffffl)) {
    sprintf (value, "%" PRIu32, (uint32_t) ntohl (data->tcphdr[type].th_seq));
    gtk_entry_set_text (GTK_ENTRY (entry), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->tcphdr[type].th_seq = htonl (atol (entry_text));  // Update TCP header with new value

    // TCP header checksum (16 bits)
    tcp_chksum (type, data);

    // Update ethernet frames.
    if ((type == 0) || (type == 9)) {
      create_ip4_frame (type, data);

    } else if ((type == 3) || (type == 12)) {
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// TCP acknowledgement number (32 bits)
int
tcp_acknum_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) == 0xffffffffl)) {
    sprintf (value, "%" PRIu32, (uint32_t) ntohl (data->tcphdr[type].th_ack));
    gtk_entry_set_text (GTK_ENTRY (entry), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->tcphdr[type].th_ack = htonl (atol (entry_text));  // Update TCP header with new value

    // TCP header checksum (16 bits)
    tcp_chksum (type, data);

    // Update ethernet frames.
    if ((type == 0) || (type == 9)) {
      create_ip4_frame (type, data);

    } else if ((type == 3) || (type == 12)) {
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// TCP reserved (4 bits)
int
tcp_res_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 15)) {
    sprintf (value, "%" PRIu8, (uint8_t) data->tcphdr[type].th_x2);
    gtk_entry_set_text (GTK_ENTRY (entry), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->tcphdr[type].th_x2 = (uint8_t) ascii_to_int64 ((char *) entry_text);  // Update TCP header with new value

    // TCP header checksum (16 bits)
    tcp_chksum (type, data);

    // Update ethernet frames.
    if ((type == 0) || (type == 9)) {
      create_ip4_frame (type, data);

    } else if ((type == 3) || (type == 12)) {
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// TCP data offset (4 bits)
int
tcp_off_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 15)) {
    sprintf (value, "%" PRIu8, (uint8_t) data->tcphdr[type].th_off);
    gtk_entry_set_text (GTK_ENTRY (entry), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->tcphdr[type].th_off = (uint8_t) ascii_to_int64 ((char *) entry_text);  // Update TCP header with new value

    // TCP header checksum (16 bits)
    tcp_chksum (type, data);

    // Update ethernet frames.
    if ((type == 0) || (type == 9)) {
      create_ip4_frame (type, data);

    } else if ((type == 3) || (type == 12)) {
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// TCP FIN flag (1 bit)
int
tcp_fin_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 1)) {
    sprintf (value, "%" PRIu8, (uint8_t) data->tcphdr[type].th_flags & 1);
    gtk_entry_set_text (GTK_ENTRY (entry), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    if (ascii_to_int64 ((char *) entry_text) == 0u) {
      data->tcphdr[type].th_flags = data->tcphdr[type].th_flags & 254;
    } else {
      data->tcphdr[type].th_flags = data->tcphdr[type].th_flags | 1;
    }

    // TCP header checksum (16 bits)
    tcp_chksum (type, data);

    // Update ethernet frames.
    if ((type == 0) || (type == 9)) {
      create_ip4_frame (type, data);

    } else if ((type == 3) || (type == 12)) {
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// TCP SYN flag (1 bit)
int
tcp_syn_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 1)) {
    sprintf (value, "%" PRIu8, (uint8_t) ((data->tcphdr[type].th_flags & 2) >> 1));
    gtk_entry_set_text (GTK_ENTRY (entry), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    if (ascii_to_int64 ((char *) entry_text) == 0) {
      data->tcphdr[type].th_flags = data->tcphdr[type].th_flags & 253;
    } else {
      data->tcphdr[type].th_flags = data->tcphdr[type].th_flags | 2;
    }

    // TCP header checksum (16 bits)
    tcp_chksum (type, data);

    // Update ethernet frames.
    if ((type == 0) || (type == 9)) {
      create_ip4_frame (type, data);

    } else if ((type == 3) || (type == 12)) {
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// TCP RST flag (1 bit)
int
tcp_rst_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 1)) {
    sprintf (value, "%" PRIu8, (uint8_t) ((data->tcphdr[type].th_flags & 4) >> 2));
    gtk_entry_set_text (GTK_ENTRY (entry), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    if (ascii_to_int64 ((char *) entry_text) == 0) {
      data->tcphdr[type].th_flags = data->tcphdr[type].th_flags & 251;
    } else {
      data->tcphdr[type].th_flags = data->tcphdr[type].th_flags | 4;
    }

    // TCP header checksum (16 bits)
    tcp_chksum (type, data);

    // Update ethernet frames.
    if ((type == 0) || (type == 9)) {
      create_ip4_frame (type, data);

    } else if ((type == 3) || (type == 12)) {
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// TCP PSH flag (1 bit)
int
tcp_psh_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 1)) {
    sprintf (value, "%" PRIu8, (uint8_t) ((data->tcphdr[type].th_flags & 8) >> 3));
    gtk_entry_set_text (GTK_ENTRY (entry), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    if (ascii_to_int64 ((char *) entry_text) == 0) {
      data->tcphdr[type].th_flags = data->tcphdr[type].th_flags & 247;
    } else {
      data->tcphdr[type].th_flags = data->tcphdr[type].th_flags | 8;
    }

    // TCP header checksum (16 bits)
    tcp_chksum (type, data);

    // Update ethernet frames.
    if ((type == 0) || (type == 9)) {
      create_ip4_frame (type, data);

    } else if ((type == 3) || (type == 12)) {
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// TCP ACK flag (1 bit)
int
tcp_ack_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 1)) {
    sprintf (value, "%" PRIu8, (uint8_t) ((data->tcphdr[type].th_flags & 16) >> 4));
    gtk_entry_set_text (GTK_ENTRY (entry), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    if (ascii_to_int64 ((char *) entry_text) == 0) {
      data->tcphdr[type].th_flags = data->tcphdr[type].th_flags & 239;
    } else {
      data->tcphdr[type].th_flags = data->tcphdr[type].th_flags | 16;
    }

    // TCP header checksum (16 bits)
    tcp_chksum (type, data);

    // Update ethernet frames.
    if ((type == 0) || (type == 9)) {
      create_ip4_frame (type, data);

    } else if ((type == 3) || (type == 12)) {
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// TCP URG flag (1 bit)
int
tcp_urg_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 1)) {
    sprintf (value, "%" PRIu8, (uint8_t) ((data->tcphdr[type].th_flags & 32) >> 5));
    gtk_entry_set_text (GTK_ENTRY (entry), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    if (ascii_to_int64 ((char *) entry_text) == 0) {
      data->tcphdr[type].th_flags = data->tcphdr[type].th_flags & 223;
    } else {
      data->tcphdr[type].th_flags = data->tcphdr[type].th_flags | 32;
    }

    // TCP header checksum (16 bits)
    tcp_chksum (type, data);

    // Update ethernet frames.
    if ((type == 0) || (type == 9)) {
      create_ip4_frame (type, data);

    } else if ((type == 3) || (type == 12)) {
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// TCP ECE flag (1 bit)
int
tcp_ece_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 1)) {
    sprintf (value, "%" PRIu8, (uint8_t) ((data->tcphdr[type].th_flags & 64) >> 6));
    gtk_entry_set_text (GTK_ENTRY (entry), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    if (ascii_to_int64 ((char *) entry_text) == 0) {
      data->tcphdr[type].th_flags = data->tcphdr[type].th_flags & 191;
    } else {
      data->tcphdr[type].th_flags = data->tcphdr[type].th_flags | 64;
    }

    // TCP header checksum (16 bits)
    tcp_chksum (type, data);

    // Update ethernet frames.
    if ((type == 0) || (type == 9)) {
      create_ip4_frame (type, data);

    } else if ((type == 3) || (type == 12)) {
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// TCP CWR flag (1 bit)
int
tcp_cwr_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 1)) {
    sprintf (value, "%" PRIu8, (uint8_t) ((data->tcphdr[type].th_flags & 128) >> 7));
    gtk_entry_set_text (GTK_ENTRY (entry), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    if (ascii_to_int64 ((char *) entry_text) == 0) {
      data->tcphdr[type].th_flags = data->tcphdr[type].th_flags & 127;
    } else {
      data->tcphdr[type].th_flags = data->tcphdr[type].th_flags | 128;
    }

    // TCP header checksum (16 bits)
    tcp_chksum (type, data);

    // Update ethernet frames.
    if ((type == 0) || (type == 9)) {
      create_ip4_frame (type, data);

    } else if ((type == 3) || (type == 12)) {
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// TCP window size (16 bits)
int
tcp_win_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 65535)) {
    sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[type].th_win));
    gtk_entry_set_text (GTK_ENTRY (entry), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->tcphdr[type].th_win = htons ((uint16_t) ascii_to_int64 ((char *) entry_text));  // Update TCP header with new value

    // TCP header checksum (16 bits)
    tcp_chksum (type, data);

    // Update ethernet frames.
    if ((type == 0) || (type == 9)) {
      create_ip4_frame (type, data);

    } else if ((type == 3) || (type == 12)) {
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// TCP checksum (16 bits)
int
tcp_chksum_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 65535)) {
    sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[type].th_sum));
    gtk_entry_set_text (GTK_ENTRY (entry), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->tcphdr[type].th_sum = htons ((uint16_t) ascii_to_int64 ((char *) entry_text));  // Update TCP header with new value

    // Update ethernet frames.
    if ((type == 0) || (type == 9)) {
      create_ip4_frame (type, data);

    } else if ((type == 3) || (type == 12)) {
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// TCP urgent pointer (16 bits)
int
tcp_urgptr_entry (GtkWidget *entry, int type, SPSData *data)
{
  const char *entry_text;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) > 65535)) {
    sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[type].th_urp));
    gtk_entry_set_text (GTK_ENTRY (entry), value);  // Put old value back into text entry since new one was bad.
    free (value);
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    data->tcphdr[type].th_urp = htons ((uint16_t) ascii_to_int64 ((char *) entry_text));  // Update TCP header with new value

    // TCP header checksum (16 bits)
    tcp_chksum (type, data);

    // Update ethernet frames.
    if ((type == 0) || (type == 9)) {
      create_ip4_frame (type, data);

    } else if ((type == 3) || (type == 12)) {
      create_ip6_frame (type, data);
      create_6to4_frame (type + 3, data);
    }
  }

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Insert, remove, or append an IPv4 TCP option.
int
tcp4_option (int mode, int type, int tcpopt_number, GtkWidget *textview, SPSData *data)
{
  // Values for mode
  // 0 = insert
  // 1 = remove
  // 2 = append

  // Abort if trying to insert option after non-existent option.
  if ((mode == 0) && ((tcpopt_number > data->tcp_nopt[type]) || !data->tcp_nopt[type] || !tcpopt_number)) {
    return (EXIT_FAILURE);
  }

  // Abort if nothing in option entry buffer to insert or append.
  if (((mode == 0) || (mode == 2)) && (data->tcp_optlenbuf[type] == 0)) {
    return (EXIT_FAILURE);
  }

  // Abort if trying to remove an option and none exist.
  if ((mode == 1) && (data->tcp_nopt[type] == 0)) {
    return (EXIT_FAILURE);
  }

  // Abort if trying to remove an option and it, specifically, doesn't exist.
  if ((mode == 1) && ((tcpopt_number > data->tcp_nopt[type]) || (tcpopt_number == 0))) {
    return (EXIT_FAILURE);
  }

  // Abort if user requests more than MAX_TCPOPTIONS TCP header options.
  if (((mode == 0) || (mode == 2)) && (data->tcp_nopt[type] == MAX_TCPOPTIONS)) {
    sprintf (data->error_text, "The number of IPv4 TCP header options is currently limited to %i in main.h as MAX_TCPOPTIONS.", MAX_TCPOPTIONS);
    report_error (data);
    return (EXIT_FAILURE);
  }

  int i, j, flag;
  char *value;
  int *bufoptlen;
  uint8_t ***buffer;
  GtkTextBuffer *textbuffer;

  if (type < 9) {
    data->parent = data->main_window;
  } else {
    data->parent = data->traceroute_window;
  }

  // Allocate memory for buffer to temporarily hold current TCP options.
  buffer = allocate_ustrmempp (MAX_TCPOPTIONS);
  for (i=0; i<MAX_TCPOPTIONS; i++) {
    buffer[i] = allocate_ustrmemp (MAX_TCPOPTLEN);
  }

  // Length of each TCP option in buffer.
  bufoptlen = allocate_intmem (MAX_TCPOPTIONS);

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  if ((mode == 0) || (mode == 1)) {
    // Copy all current TCP options to buffer and option lengths to bufoptlen.
    for (i=0; i<data->tcp_nopt[type]; i++) {
      memcpy (buffer[i], data->tcp_options[type][i], data->tcp_optlen[type][i] * sizeof (uint8_t));
      bufoptlen[i] = data->tcp_optlen[type][i];
    }

    // Clear all current TCP options.
    for (i=0; i<MAX_TCPOPTIONS; i++) {
      memset (data->tcp_options[type][i], 0, MAX_TCPOPTLEN * sizeof (uint8_t));
      data->tcp_optlen[type][i] = 0;
    }
  }

  if (mode == 0) {
    // Copy TCP options from buffer but stop at option after which we'll insert the new option.
    j = 0;
    for (i=0; i<tcpopt_number; i++) {
      memcpy (data->tcp_options[type][j], buffer[i], bufoptlen[i] * sizeof (uint8_t));
      data->tcp_optlen[type][j] = bufoptlen[i];
      j++;
    }

    // New option takes length of option in buffer.
    data->tcp_optlen[type][j] = data->tcp_optlenbuf[type];

    // Copy contents of option buffer to option array.
    memcpy (data->tcp_options[type][j], data->tcp_optionsbuf[type], data->tcp_optlenbuf[type] * sizeof (uint8_t));
    j++;

    // Copy the remaining original options from buffer.
    for (i=tcpopt_number; i<data->tcp_nopt[type]; i++) {
      memcpy (data->tcp_options[type][j], buffer[i], bufoptlen[i] * sizeof (uint8_t));
      data->tcp_optlen[type][j] = bufoptlen[i];
      j++;
    }

    // Increment the number of TCP options by one.
    data->tcp_nopt[type]++;
    textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (textview));
    sprintf (value, "%i", data->tcp_nopt[type]);
    gtk_text_buffer_set_text (textbuffer, value, -1);
  }  // End if mode == 0

  if (mode == 1) {
    // Copy TCP options from buffer but skip the one we want to remove.
    j = 0;
    for (i=0; i<data->tcp_nopt[type]; i++) {
      if ((i + 1) == tcpopt_number) {
        continue;
      } else {
        memcpy (data->tcp_options[type][j], buffer[i], bufoptlen[i] * sizeof (uint8_t));
        data->tcp_optlen[type][j] = bufoptlen[i];
        j++;
      }
    }

    // Decrement the number of TCP options by one.
    data->tcp_nopt[type]--;
    textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (textview));
    sprintf (value, "%i", data->tcp_nopt[type]);
    gtk_text_buffer_set_text (textbuffer, value, -1);
  }  // End if mode == 1

  if (mode == 2) {
    // New option takes length of option in buffer.
    data->tcp_optlen[type][data->tcp_nopt[type]] = data->tcp_optlenbuf[type];

    // Copy contents of option buffer to option array.
    memcpy (data->tcp_options[type][data->tcp_nopt[type]], data->tcp_optionsbuf[type], data->tcp_optlenbuf[type] * sizeof (uint8_t));

    // Increment number of TCP options in packet.
    data->tcp_nopt[type]++;
    textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (textview));
    sprintf (value, "%i", data->tcp_nopt[type]);
    gtk_text_buffer_set_text (textbuffer, value, -1);
  }  // End if mode == 2

  // Calculate total length of TCP options.
  data->tcp_opt_totlen[type] = 0;
  for (i=0; i<data->tcp_nopt[type]; i++) {
    data->tcp_opt_totlen[type] += data->tcp_optlen[type][i];
  }

  // Determine padding needed to pad TCP options
  // with zeros to the next 32-bit boundary.
  data->tcp_optpadlen[type] = 0;
  while (((data->tcp_opt_totlen[type] + data->tcp_optpadlen[type]) % 4) != 0) {
    data->tcp_optpadlen[type]++;
  }

  // Truncate upper layer protocol payload if necessary to accomodate packet size limit.
  flag = 0;
  if (truncate_ip4 (type, data)) {
    flag = 1;
  }
  if (flag) {
    sprintf (data->warning_text, "Upper layer protocol payload data was truncated\nto accomodate maximum packet size of %i bytes.", IP_MAXPACKET);
    report_warning (data);
  }

  // Update lengths, offsets, and checksums.
  ip4data_update (type, data);

  // Check if MTU is sufficiently large to accomodate packet. Revise if necessary.
  check_mtu (type, data);

  // Update ethernet frame.
  create_ip4_frame (type, data);

  // Free allocated memory.
  for (i=0; i<MAX_TCPOPTIONS; i++) {
    free (buffer[i]);
  }
  free (buffer);
  free (bufoptlen);
  free (value);

  return (EXIT_SUCCESS);
}

// Insert, remove, or append an IPv6 TCP option.
int
tcp6_option (int mode, int type, int tcpopt_number, GtkWidget *textview, SPSData *data)
{
  // Values for mode
  // 0 = insert
  // 1 = remove
  // 2 = append

  // Abort if trying to insert option after non-existent option.
  if ((mode == 0) && ((tcpopt_number > data->tcp_nopt[type]) || !data->tcp_nopt[type] || !tcpopt_number)) {
    return (EXIT_FAILURE);
  }

  // Abort if nothing in option entry buffer to insert or append.
  if (((mode == 0) || (mode == 2)) && (data->tcp_optlenbuf[type] == 0)) {
    return (EXIT_FAILURE);
  }

  // Abort if trying to remove an option and none exist.
  if ((mode == 1) && (data->tcp_nopt[type] == 0)) {
    return (EXIT_FAILURE);
  }

  // Abort if trying to remove an option and it, specifically, doesn't exist.
  if ((mode == 1) && ((tcpopt_number > data->tcp_nopt[type]) || (tcpopt_number == 0))) {
    return (EXIT_FAILURE);
  }

  // Abort if user requests more than MAX_TCPOPTIONS TCP header options.
  if (((mode == 0) || (mode == 2)) && (data->tcp_nopt[type] == MAX_TCPOPTIONS)) {
    sprintf (data->error_text, "The number of IPv6 TCP header options is currently limited to %i in main.h as MAX_TCPOPTIONS.", MAX_TCPOPTIONS);
    report_error (data);
    return (EXIT_FAILURE);
  }

  int i, j, flag;
  char *value;
  int *bufoptlen;
  uint8_t ***buffer;
  GtkTextBuffer *textbuffer;

  if (type < 9) {
    data->parent = data->main_window;
  } else {
    data->parent = data->traceroute_window;
  }

  // Allocate memory for buffer to temporarily hold current TCP options.
  buffer = allocate_ustrmempp (MAX_TCPOPTIONS);
  for (i=0; i<MAX_TCPOPTIONS; i++) {
    buffer[i] = allocate_ustrmemp (MAX_TCPOPTLEN);
  }

  // Length of each TCP option in buffer.
  bufoptlen = allocate_intmem (MAX_TCPOPTIONS);

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  if ((mode == 0) || (mode == 1)) {
    // Copy all current TCP options to buffer and option lengths to bufoptlen.
    for (i=0; i<data->tcp_nopt[type]; i++) {
      memcpy (buffer[i], data->tcp_options[type][i], data->tcp_optlen[type][i] * sizeof (uint8_t));
      bufoptlen[i] = data->tcp_optlen[type][i];
    }

    // Clear all current TCP options.
    for (i=0; i<MAX_TCPOPTIONS; i++) {
      memset (data->tcp_options[type][i], 0, MAX_TCPOPTLEN * sizeof (uint8_t));
      data->tcp_optlen[type][i] = 0;
    }
  }

  if (mode == 0) {
    // Copy TCP options from buffer but stop at option after which we'll insert the new option.
    j = 0;
    for (i=0; i<tcpopt_number; i++) {
      memcpy (data->tcp_options[type][j], buffer[i], bufoptlen[i] * sizeof (uint8_t));
      data->tcp_optlen[type][j] = bufoptlen[i];
      j++;
    }

    // New option takes length of option in buffer.
    data->tcp_optlen[type][j] = data->tcp_optlenbuf[type];

    // Copy contents of option buffer to option array.
    memcpy (data->tcp_options[type][j], data->tcp_optionsbuf[type], data->tcp_optlenbuf[type] * sizeof (uint8_t));
    j++;

    // Copy the remaining original options from buffer.
    for (i=tcpopt_number; i<data->tcp_nopt[type]; i++) {
      memcpy (data->tcp_options[type][j], buffer[i], bufoptlen[i] * sizeof (uint8_t));
      data->tcp_optlen[type][j] = bufoptlen[i];
      j++;
    }

    // Increment the number of TCP options by one.
    data->tcp_nopt[type]++;
    textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (textview));
    sprintf (value, "%i", data->tcp_nopt[type]);
    gtk_text_buffer_set_text (textbuffer, value, -1);
  }  // End if mode == 0

  if (mode == 1) {
    // Copy TCP options from buffer but skip the one we want to remove.
    j = 0;
    for (i=0; i<data->tcp_nopt[type]; i++) {
      if ((i + 1) == tcpopt_number) {
        continue;
      } else {
        memcpy (data->tcp_options[type][j], buffer[i], bufoptlen[i] * sizeof (uint8_t));
        data->tcp_optlen[type][j] = bufoptlen[i];
        j++;
      }
    }

    // Decrement the number of TCP options by one.
    data->tcp_nopt[type]--;
    textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (textview));
    sprintf (value, "%i", data->tcp_nopt[type]);
    gtk_text_buffer_set_text (textbuffer, value, -1);
  }  // End if mode == 1

  if (mode == 2) {
    // New option takes length of option in buffer.
    data->tcp_optlen[type][data->tcp_nopt[type]] = data->tcp_optlenbuf[type];

    // Copy contents of option buffer to option array.
    memcpy (data->tcp_options[type][data->tcp_nopt[type]], data->tcp_optionsbuf[type], data->tcp_optlenbuf[type] * sizeof (uint8_t));

    // Increment number of TCP options in packet.
    data->tcp_nopt[type]++;
    textbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (textview));
    sprintf (value, "%i", data->tcp_nopt[type]);
    gtk_text_buffer_set_text (textbuffer, value, -1);
  }  // End if mode == 2

  // Calculate total length of TCP options.
  data->tcp_opt_totlen[type] = 0;
  for (i=0; i<data->tcp_nopt[type]; i++) {
    data->tcp_opt_totlen[type] += data->tcp_optlen[type][i];
  }

  // Determine padding needed to pad TCP options
  // with zeros to the next 32-bit boundary.
  data->tcp_optpadlen[type] = 0;
  while (((data->tcp_opt_totlen[type] + data->tcp_optpadlen[type]) % 4) != 0) {
    data->tcp_optpadlen[type]++;
  }

  // Truncate upper layer protocol payload if necessary to accomodate packet size limit.
  flag = 0;
  if (truncate_ip6 (type, data)) {
    flag = 1;
  }
  if (flag) {
    sprintf (data->warning_text, "Upper layer protocol payload data was truncated\nto accomodate maximum packet size of %i bytes.", IP_MAXPACKET);
    report_warning (data);
  }

  // Update lengths, offsets, and checksums.
  ip6data_update (type, data);

  // Check if MTU is sufficiently large to accomodate packet. Revise if necessary.
  check_mtu (type, data);

  // Update ethernet frame.
  create_ip6_frame (type, data);
  create_6to4_frame (type + 3, data);

  // Free allocated memory.
  for (i=0; i<MAX_TCPOPTIONS; i++) {
    free (buffer[i]);
  }
  free (buffer);
  free (bufoptlen);
  free (value);

  return (EXIT_SUCCESS);
}

// Number of option after which to insert new TCP option.
int
tcp_opt_insert_after_entry (GtkWidget *entry, int type, int *tcpopt_after, SPSData *data)
{
  const char *entry_text;

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (!ascii_to_int64 ((char *) entry_text)) || (ascii_to_int64 ((char *) entry_text) > (data->tcp_nopt[type] + 1))) {
    gtk_entry_set_text (GTK_ENTRY (entry), "");
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    *tcpopt_after = (int) ascii_to_int64 ((char *) entry_text);
  }

  return (EXIT_SUCCESS);
}

// Number of TCP option to remove.
int
tcp_opt_remove_entry (GtkWidget *entry, int type, int *tcpopt_remove, SPSData *data)
{
  const char *entry_text;

  // Get new value from text entry
  entry_text = gtk_entry_get_text (GTK_ENTRY (entry));

  // Is value too large or small, or are there non-numeric characters?
  if (!is_ascii_uint (entry_text) || (ascii_to_int64 ((char *) entry_text) < 1) || (ascii_to_int64 ((char *) entry_text) > data->tcp_nopt[type])) {
    gtk_entry_set_text (GTK_ENTRY (entry), "");
    return (EXIT_FAILURE);

  // Value is in acceptable range.
  } else {
    *tcpopt_remove = (int) ascii_to_int64 ((char *) entry_text);
  }

  return (EXIT_SUCCESS);
}

// Re-calculate TCP data offset and update text entry (IPv4 and IPv6).
int
tcp_dataoffset (int type, SPSData *data)
{
  GtkWidget *tcpoffset_entry;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // TCP data offset (4 bits): size of TCP header + TCP options + TCP options padding, in 32-bit words
  data->tcphdr[type].th_off = (TCP_HDRLEN + data->tcp_opt_totlen[type] + data->tcp_optpadlen[type]) / sizeof (uint32_t);
  sprintf (value, "%" PRIu8, (uint8_t) data->tcphdr[type].th_off);

  switch (type) {
    case 0:  // IPv4 TCP
      tcpoffset_entry = data->entry56;
      break;
    case 3:  // IPv6 TCP
      tcpoffset_entry = data->entry94;
      break;
    case 9:  // IPv4 TCP for traceroute
      tcpoffset_entry = data->entry197;
      break;
    case 12:  // IPv6 TCP for traceroute
      tcpoffset_entry = data->entry274;
      break;
    default:
      fprintf (stderr, "ERROR: Invalid upper layer protocol type %i in tcp_dataoffset().\n", type);
      free (value);
      exit (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (tcpoffset_entry), value);

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}

// Re-calculate TCP checksum and update text entry (IPv4 and IPv6).
int
tcp_chksum (int type, SPSData *data)
{
  GtkWidget *chksum_entry;
  char *value;

  // String to hold miscellaneous calculated values
  value = allocate_strmem (TMP_STRINGLEN);

  // TCP header checksum (16 bits)
  if ((type == 0) || (type == 9)) {
    data->tcphdr[type].th_sum = tcp4_checksum (data->ip4hdr[type], data->tcphdr[type], data->tcp_nopt[type], data->tcp_opt_totlen[type], data->tcp_optlen[type], data->tcp_options[type], data->tcp_optpadlen[type], data->payload[type], data->payloadlen[type]);

  } else if ((type == 3) || (type == 12)) {
    data->tcphdr[type].th_sum = tcp6_checksum (data->ip6hdr[type], data->tcphdr[type], data->tcp_nopt[type], data->tcp_opt_totlen[type], data->tcp_optlen[type], data->tcp_options[type], data->tcp_optpadlen[type], data->payload[type], data->payloadlen[type]);
  }

  sprintf (value, "%" PRIu16, (uint16_t) ntohs (data->tcphdr[type].th_sum));

  switch (type) {
    case 0:  // IPv4 TCP
      chksum_entry = data->entry56;
      break;
    case 3:  // IPv6 TCP
      chksum_entry = data->entry94;
      break;
    case 9:  // IPv4 TCP for traceroute
      chksum_entry = data->entry197;
      break;
    case 12:  // IPv6 TCP for traceroute
      chksum_entry = data->entry274;
      break;
    default:
      fprintf (stderr, "ERROR: Invalid upper layer protocol type %i in tcp_chksum().\n", type);
      free (value);
      exit (EXIT_FAILURE);
  }
  gtk_entry_set_text (GTK_ENTRY (chksum_entry), value);

  // Free allocated memory.
  free (value);

  return (EXIT_SUCCESS);
}
