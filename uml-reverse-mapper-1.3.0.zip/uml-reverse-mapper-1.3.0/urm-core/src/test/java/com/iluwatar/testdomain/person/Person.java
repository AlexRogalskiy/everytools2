package com.iluwatar.testdomain.person;

import com.iluwatar.testdomain.Company;
import com.iluwatar.testdomain.PhoneNumber;

import java.util.List;

public class Person {
    private Company company;
    private List<PhoneNumber> contactNumbers;
}
