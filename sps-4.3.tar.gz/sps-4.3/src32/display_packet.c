/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Display unfragmented and fragmented packet.
int
show_packet (int type, char **title, SPSData *data)
{
  int size, i, d, sixto4;
  char *temp_string, *nofrag_string, *frag_string;
  GtkWidget *window1, *scrolled_win1, *textview1;
  GtkTextBuffer *buffer1;
  GtkWidget *window2, *scrolled_win2, *textview2;
  GtkTextBuffer *buffer2;
  PangoFontDescription *textview_font1;
  PangoFontDescription *textview_font2;

  // Rough size of memory needed for ASCII listing of ethernet frames.
  size = (data->ifmtu[type] + ETH_HDRLEN) * data->nframes[type] * 10;

  // Allocate memory for ASCII and formatting text of unfragmented packet.
  temp_string = allocate_strmem (size);

  // Allocate memory for ASCII and formatting text of unfragmented packet.
  nofrag_string = allocate_strmem (size);

  // Allocate memory for ASCII and formatting text of fragmented packet.
  frag_string = allocate_strmem (size);

  // Determine if user is tunneling IPv6 over IPv4 (6to4).
  if ((type == 6) || (type == 7) || (type == 8) ||
      (type == 15) || (type == 16) || (type == 17)) {
    sixto4 = 1;
  } else {
    sixto4 = 0;
  }

  // Create new window to display unfragmented packet.
  window1 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_resizable (GTK_WINDOW (window1), TRUE);
  gtk_window_set_position (GTK_WINDOW (window1), GTK_WIN_POS_NONE);
  gtk_window_set_title (GTK_WINDOW (window1), title[0]);
  gtk_window_set_default_size (GTK_WINDOW (window1), 1000, 200);
  gtk_container_set_border_width (GTK_CONTAINER (window1), 1);

  // Create a textview object to display unfragmented packet.
  textview1 = gtk_text_view_new ();
  buffer1 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (textview1));
  gtk_text_view_set_cursor_visible (GTK_TEXT_VIEW (textview1), TRUE);
  textview_font1 = pango_font_description_from_string ("Courier 10 Pitch 12");
  gtk_widget_modify_font (textview1, textview_font1);

  // Create new window to display fragmented packet.
  window2 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_resizable (GTK_WINDOW (window2), TRUE);
  gtk_window_set_position (GTK_WINDOW (window2), GTK_WIN_POS_NONE);
  gtk_window_set_title (GTK_WINDOW (window2), title[1]);
  gtk_window_set_default_size (GTK_WINDOW (window2), 1000, 200);
  gtk_container_set_border_width (GTK_CONTAINER (window2), 1);

  // Create a textview object to display fragmented packet.
  textview2 = gtk_text_view_new ();
  buffer2 = gtk_text_view_get_buffer (GTK_TEXT_VIEW (textview2));
  gtk_text_view_set_cursor_visible (GTK_TEXT_VIEW (textview2), TRUE);
  textview_font2 = pango_font_description_from_string ("Courier 10 Pitch 12");
  gtk_widget_modify_font (textview2, textview_font2);

  // Compose text string of fragmented packet to show in textview1.
  d = 0;  // Index of nofrag_string
  for (i=0; i<data->nframes[type]; i++) {
    memset (temp_string, 0, size * sizeof (char));
    sprintf (temp_string, "Frame %i:\n\n", i + 1);
    sprintf (nofrag_string + d, "%s", temp_string);
    d += strnlen (temp_string, size);

    memset (temp_string, 0, size * sizeof (char));
    hexascii_listing (data->ether_frame[type][i], data->frame_length[type][i], temp_string, data->specify_ether[type]);
    sprintf (nofrag_string + d, "%s", temp_string);
    d += strnlen (temp_string, size);

    if (i < (data->nframes[type] - 1)) {
      sprintf (nofrag_string + d, "\n\n");
      d += 2;
    }
  }

  // Compose text string of unfragmented packet to show in textview2.
  hexascii_listing (data->packet[type], data->packet_length[type], frag_string, data->specify_ether[type]);

  // Add note for explanation of dashes instead of ethernet header.
  if (!data->specify_ether[type]) {
    sprintf (nofrag_string, "%s\n\nNote: -- to be determined by kernel.", nofrag_string);
    sprintf (frag_string, "%s\n\nNote: -- to be determined by kernel.", frag_string);
  }

  // Add note if packet includes 6to4 ethernet and IPv4 headers.
  if (sixto4) {
    sprintf (nofrag_string, "%s\n\nNote: Displayed packet includes 6to4 ethernet and IPv4 headers.", nofrag_string);
    sprintf (frag_string, "%s\n\nNote: Displayed packet includes 6to4 ethernet and IPv4 headers.", frag_string);
  }

  // Put the text into the buffer.
  gtk_text_buffer_set_text (buffer1, nofrag_string, -1);

  // Put the text into the buffer.
  gtk_text_buffer_set_text (buffer2, frag_string, -1);

  // Add scrolled window and textview to new window1 and display unfragmented packet.
  scrolled_win1 = gtk_scrolled_window_new (NULL, NULL);
  gtk_container_add (GTK_CONTAINER (scrolled_win1), textview1);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolled_win1),
                                  GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS);

  gtk_container_add (GTK_CONTAINER (window1), scrolled_win1);
  gtk_widget_show_all (window1);

  // Pause and check for pending GTK click events.
  // This allows the window manager to find a new location on screen
  // for the second window so they aren't on top of each other.
  // This doesn't always work though.
  usleep (100000);  // Pause 100 ms
  while (gtk_events_pending ()) {
    gtk_main_iteration ();
  }

  // Add scrolled window and textview to new window2 and display fragmented packet.
  scrolled_win2 = gtk_scrolled_window_new (NULL, NULL);
  gtk_container_add (GTK_CONTAINER (scrolled_win2), textview2);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolled_win2),
                                  GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS);

  gtk_container_add (GTK_CONTAINER (window2), scrolled_win2);
  gtk_widget_show_all (window2);

  free (temp_string);
  free (nofrag_string);
  free (frag_string);

  return (EXIT_SUCCESS);
}
