package com.iluwatar.testdomain.family;

import java.util.List;

public class Mother {
    List<Child> childs;
    Child favorite;
}
