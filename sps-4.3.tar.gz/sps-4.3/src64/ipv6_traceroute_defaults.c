/*  Simple Packet Sender (SPS) - a linux packet crafting network
    tool using GTK+ graphical interface.

    Copyright (C) 2011-2015  Hohlraum (h0h1r4um@yahoo.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "main.h"

// Apply IPv6 TCP traceroute page default settings
int
tcp6_tr_default (SPSData *data)
{
  int status, i, *tcp6_flags;

  // TCP flags
  tcp6_flags = allocate_intmem (8);

  // Number of ethernet frames
  data->nframes[12] = 1;

  // Ethernet header

  // Set flag for user to specify ethernet header. This will never change for IPv6.
  data->specify_ether[12] = 1;

  // Destination link-layer (MAC) address (48 bits): default to zero; user needs to fill out
  memset (data->ethhdr[12].dst_mac, 0, 6 * sizeof (uint8_t));

  // Source Interface Name: defaults to blank
  memset (data->ifname[12], 0, TMP_STRINGLEN * sizeof (char));

  // Default interface MTU
  data->ifmtu[12] = 1500;

  // Source link-layer (MAC) address (48 bits): default to zero; user needs to fill out
  memset (data->ethhdr[12].src_mac, 0, 6 * sizeof (uint8_t));

  // Ethernet type code (16 bits): default to IPv6
  // http://www.iana.org/assignments/ethernet-numbers
  data->ethhdr[12].type_code = htons (ETH_P_IPV6);

  // Deal with TCP data first so that lengths and offsets are correct for updating IP and TCP headers.

  // TCP header options

  // TCP option data entry format: default to hexadecimal input
  data->dec_hex_tcpopt_tcp6_tr = 1;

  // No TCP options
  data->tcp_nopt[12] = 0;

  // Set all option data to zero.
  for (i=0; i<MAX_TCPOPTIONS; i++) {
    data->tcp_optlen[12][i] = 0;
    memset (data->tcp_options[12][i], 0, MAX_TCPOPTLEN * sizeof (uint8_t));
  }
  memset (data->tcp_optionsbuf[12], 0, MAX_TCPOPTLEN * sizeof (uint8_t));

  // Set total length of options to zero.
  data->tcp_opt_totlen[12] = 0;

  // Show actual length of option in buffer as zero.
  data->tcp_optlenbuf[12] = 0;

  // Default option number after which to insert a new option
  data->tcpopt_tcp4_tr_after = 0;

  // Number of TCP option to remove (0 = none)
  data->tcpopt_tcp4_tr_remove = 0;

  // TCP data

  // Clear TCP data buffer.
  memset (data->payload[12], 0, IP_MAXPACKET * sizeof (uint8_t));
  data->payloadlen[12] = 0;

  // TCP data entry format: default to hexadecimal input
  data->ascii_hex_tcp6_tr = 1;

  // Hop-by-hop options

  // No hop-by-hop options
  data->hbh_hdr_flag[12] = 0;
  data->hbh_nopt[12] = 0;

  // Clear all hop-by-hop option lengths.
  memset (data->hbh_optlen[12], 0, MAX_HBHOPTIONS * sizeof (int));

  // Clear all hop-by-hop options.
  for (i=0; i<MAX_HBHOPTIONS; i++) {
    memset (data->hbh_options[12][i], 0, MAX_HBHOPTLEN * sizeof (uint8_t));
  }

  // Total length of hop-by-hop options is zero.
  data->hbh_opt_totlen[12] = 0;
  data->hophdr[12].hdr_len = 0;

  // Option alignment parameter x (of xN + y)
  memset (data->hbh_x[12], 0, MAX_HBHOPTIONS * sizeof (int));

  // Option alignment parameter y (of xN + y)
  memset (data->hbh_y[12], 0, MAX_HBHOPTIONS * sizeof (int));

  // Hop-by-hop header options padding length (includes alignment padding)
  data->hbh_optpadlen[12] = 0;  // Hop-by-hop options padding: hbh_optpadlen[type] = int

  // Destination options

  // No destination options
  data->dstf_hdr_flag[12] = 0;
  data->dstf_nopt[12] = 0;
  data->dstl_hdr_flag[12] = 0;
  data->dstl_nopt[12] = 0;
  
  // Clear all destination option lengths.
  memset (data->dstf_optlen[12], 0, MAX_DSTOPTIONS * sizeof (int));
  memset (data->dstl_optlen[12], 0, MAX_DSTOPTIONS * sizeof (int));
  
  // Clear all destination options.
  for (i=0; i<MAX_DSTOPTIONS; i++) {
    memset (data->dstf_options[12][i], 0, MAX_DSTOPTLEN * sizeof (uint8_t));
    memset (data->dstl_options[12][i], 0, MAX_DSTOPTLEN * sizeof (uint8_t));
  }

  // Total length of destination options is zero.
  data->dstf_opt_totlen[12] = 0;
  data->dstfhdr[12].hdr_len = 0;
  data->dstl_opt_totlen[12] = 0;
  data->dstlhdr[12].hdr_len = 0;

  // Option alignment parameter x (of xN + y)
  memset (data->dstf_x[12], 0, MAX_DSTOPTIONS * sizeof (int));
  memset (data->dstl_x[12], 0, MAX_DSTOPTIONS * sizeof (int));

  // Option alignment parameter y (of xN + y)
  memset (data->dstf_y[12], 0, MAX_DSTOPTIONS * sizeof (int));
  memset (data->dstl_y[12], 0, MAX_DSTOPTIONS * sizeof (int));

  // Destination header options padding length (includes alignment padding)
  data->dstf_optpadlen[12] = 0;  // Destination options padding: dstf_optpadlen[type] = int
  data->dstl_optpadlen[12] = 0;  // Destination options padding: dstl_optpadlen[type] = int

  // Routing header

  // No routing header
  data->route_hdr_flag[12] = 0;
  data->route_datlen[12] = 0;
  data->routehdr[12].hdr_len = 0;
  data->routehdr[12].routing_type = 0;
  data->routehdr[12].segs_left = 0;
  memset (data->route_data[12], 0, MAX_ROUTEDATA * sizeof (uint8_t));

  // Authentication header

  // No authentication header
  data->auth_hdr_flag[12] = 0;
  data->auth_len[12] = 0;
  data->authhdr[12].pay_len = 0;
  data->authhdr[12].reserved = 0;
  data->authhdr[12].spi = 0;
  data->authhdr[12].seq = 0;
  memset (data->auth_data[12], 0, MAX_AUTHICVLEN * sizeof (uint8_t));

  // Encapsulating security payload (ESP)

  // No ESP header and no ESP tail
  data->esp_hdr_flag[12] = 0;
  data->esp_auth_len[12] = 0;
  data->esphdr[12].spi = 0;
  data->esphdr[12].seq = 0;
  data->esptail[12].pad_len = 0;
  memset (data->esp_auth_data[12], 0, MAX_ESPICVLEN * sizeof (uint8_t));
  data->esptail[12].pad_len = 0;  // Padding length
  memset (data->esp_pad[12], 0, 255 * sizeof (uint8_t));

  // ESP trailer Next Header field
  data->esptail[12].nxt_hdr = IPPROTO_TCP;

  // IPv6 header

  // IPv6 version (4 bits), Traffic class (8 bits), Flow label (20 bits)
  data->ip6hdr[12].ip6_flow = htonl ((6 << 28) | (0 << 20) | 0);

  // Payload length (16 bits): TCP header
  data->ip6hdr[12].ip6_plen = htons (TCP_HDRLEN);

  // Next header (8 bits): 6 for TCP
  data->ip6hdr[12].ip6_nxt = IPPROTO_TCP;

  // Hop limit (8 bits): start with hop limit of 1 (next node in route)
  data->ip6hdr[12].ip6_hops = 1u;

  // Source IPv6 address (128 bits): default to loopback
  if ((status = inet_pton (AF_INET6, "::1", &(data->ip6hdr[12].ip6_src))) != 1) {
    sprintf (data->error_text, "tcp6_tr_default(): inet_pton() failed for source IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (tcp6_flags);
    return (EXIT_FAILURE);
  }

  // Destination IPv6 address (128 bits): default to loopback IP address to be safe
  if ((status = inet_pton (AF_INET6, "::1", &(data->ip6hdr[12].ip6_dst))) != 1) {
    sprintf (data->error_text, "tcp6_tr_default(): inet_pton() failed for destination IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    free (tcp6_flags);
    return (EXIT_FAILURE);
  }

  // TCP header (IPv6)

  // Source port number (16 bits): 80
  data->ran_tcp6_tr_sourceport = 0;
  data->tcphdr[12].th_sport = htons (80u);

  // Destination port number (16 bits)
  data->tcphdr[12].th_dport = htons (80u);

  // Sequence number (32 bits)
  data->tcphdr[12].th_seq = htonl (0);

  // Acknowledgement number (32 bits): 0 in first packet
  data->tcphdr[12].th_ack = htonl (0);

  // Reserved (4 bits): should be 0
  data->tcphdr[12].th_x2 = 0;

  // Data offset (4 bits): size of TCP header in 32-bit words
  data->tcphdr[12].th_off = TCP_HDRLEN / sizeof (uint32_t);

  // FIN flag (1 bit)
  tcp6_flags[0] = 0;

  // SYN flag (1 bit): set to 1
  tcp6_flags[1] = 1;

  // RST flag (1 bit)
  tcp6_flags[2] = 0;

  // PSH flag (1 bit)
  tcp6_flags[3] = 0;

  // ACK flag (1 bit)
  tcp6_flags[4] = 0;

  // URG flag (1 bit)
  tcp6_flags[5] = 0;

  // ECE flag (1 bit)
  tcp6_flags[6] = 0;

  // CWR flag (1 bit)
  tcp6_flags[7] = 0;

  // Flags (8 bits): 2 for SYN
  data->tcphdr[12].th_flags = bin8_to_dec (tcp6_flags);

  // Window size (16 bits): default to maximum value
  data->tcphdr[12].th_win = htons (0xffffu);

  // Urgent pointer (16 bits): 0 (only valid if URG flag is set)
  data->tcphdr[12].th_urp = htons (0);

  // TCP checksum (16 bits)
  data->tcphdr[12].th_sum = tcp6_checksum (data->ip6hdr[12], data->tcphdr[12], data->tcp_nopt[12], data->tcp_opt_totlen[12], data->tcp_optlen[12], data->tcp_options[12], data->tcp_optpadlen[12], data->payload[12], data->payloadlen[12]);

  // Free allocated memory.
  free (tcp6_flags);

  // Update ethernet frame.
  create_ip6_frame (12, data);

  // Apply default 6to4 settings.
  sixto4_tcp6_tr_default (data);

  return (EXIT_SUCCESS);
}

// Apply IPv6 ICMP traceroute page default settings
int
icmp6_tr_default (SPSData *data)
{
  int status, i;

  // Number of ethernet frames
  data->nframes[13] = 1;

  // Ethernet header

  // Set flag for user to specify ethernet header. This will never change for IPv6.
  data->specify_ether[13] = 1;

  // Destination link-layer (MAC) address (48 bits): default to zero; user needs to fill out
  memset (data->ethhdr[13].dst_mac, 0, 6 * sizeof (uint8_t));

  // Source Interface Name: defaults to blank
  memset (data->ifname[13], 0, TMP_STRINGLEN * sizeof (char));

  // Default interface MTU
  data->ifmtu[13] = 1500;

  // Source link-layer (MAC) address (48 bits): default to zero; user needs to fill out
  memset (data->ethhdr[13].src_mac, 0, 6 * sizeof (uint8_t));
  
  // Ethernet type code (16 bits): default to IPv6
  // http://www.iana.org/assignments/ethernet-numbers
  data->ethhdr[13].type_code = htons (ETH_P_IPV6);

  // Deal with ICMP data first so that lengths and offsets are correct for updating IP and ICMP headers.

  // ICMP data

  // Clear ICMP data buffer.
  memset (data->payload[13], 0, IP_MAXPACKET * sizeof (uint8_t));
  data->payloadlen[13] = 0;

  // ICMP data entry format: default to hexadecimal input
  data->ascii_hex_icmp6_tr = 1;

  // Hop-by-hop options

  // No hop-by-hop options
  data->hbh_hdr_flag[13] = 0;
  data->hbh_nopt[13] = 0;

  // Clear all hop-by-hop option lengths.
  memset (data->hbh_optlen[13], 0, MAX_HBHOPTIONS * sizeof (int));

  // Clear all hop-by-hop options.
  for (i=0; i<MAX_HBHOPTIONS; i++) {
    memset (data->hbh_options[13][i], 0, MAX_HBHOPTLEN * sizeof (uint8_t));
  }

  // Total length of hop-by-hop options is zero.
  data->hbh_opt_totlen[13] = 0;
  data->hophdr[13].hdr_len = 0;

  // Option alignment parameter x (of xN + y)
  memset (data->hbh_x[13], 0, MAX_HBHOPTIONS * sizeof (int));

  // Option alignment parameter y (of xN + y)
  memset (data->hbh_y[13], 0, MAX_HBHOPTIONS * sizeof (int));

  // Hop-by-hop header options padding length (includes alignment padding)
  data->hbh_optpadlen[13] = 0;  // Hop-by-hop options padding: hbh_optpadlen[type] = int

  // Destination options

  // No destination options
  data->dstf_hdr_flag[13] = 0;
  data->dstf_nopt[13] = 0;
  data->dstl_hdr_flag[13] = 0;
  data->dstl_nopt[13] = 0;

  // Clear all destination option lengths.
  memset (data->dstf_optlen[13], 0, MAX_DSTOPTIONS * sizeof (int));
  memset (data->dstl_optlen[13], 0, MAX_DSTOPTIONS * sizeof (int));
  
  // Clear all destination options.
  for (i=0; i<MAX_DSTOPTIONS; i++) {
    memset (data->dstf_options[13][i], 0, MAX_DSTOPTLEN * sizeof (uint8_t));
    memset (data->dstl_options[13][i], 0, MAX_DSTOPTLEN * sizeof (uint8_t));
  }

  // Total length of destination options is zero.
  data->dstf_opt_totlen[13] = 0;
  data->dstfhdr[13].hdr_len = 0;
  data->dstl_opt_totlen[13] = 0;
  data->dstlhdr[13].hdr_len = 0;

  // Option alignment parameter x (of xN + y)
  memset (data->dstf_x[13], 0, MAX_DSTOPTIONS * sizeof (int));
  memset (data->dstl_x[13], 0, MAX_DSTOPTIONS * sizeof (int));

  // Option alignment parameter y (of xN + y)
  memset (data->dstf_y[13], 0, MAX_DSTOPTIONS * sizeof (int));
  memset (data->dstl_y[13], 0, MAX_DSTOPTIONS * sizeof (int));

  // Destination header options padding length (includes alignment padding)
  data->dstf_optpadlen[13] = 0;  // Destination options padding: dstf_optpadlen[type] = int
  data->dstl_optpadlen[13] = 0;  // Destination options padding: dstl_optpadlen[type] = int

  // Routing header

  // No routing header
  data->route_hdr_flag[13] = 0;
  data->route_datlen[13] = 0;
  data->routehdr[13].hdr_len = 0;
  data->routehdr[13].routing_type = 0;
  data->routehdr[13].segs_left = 0;
  memset (data->route_data[13], 0, MAX_ROUTEDATA * sizeof (uint8_t));

  // Authentication header

  // No authentication header
  data->auth_hdr_flag[13] = 0;
  data->auth_len[13] = 0;
  data->authhdr[13].pay_len = 0;
  data->authhdr[13].reserved = 0;
  data->authhdr[13].spi = 0;
  data->authhdr[13].seq = 0;
  memset (data->auth_data[13], 0, MAX_AUTHICVLEN * sizeof (uint8_t));

  // Encapsulating security payload (ESP)

  // No ESP header and no ESP tail
  data->esp_hdr_flag[13] = 0;
  data->esp_auth_len[13] = 0;
  data->esphdr[13].spi = 0;
  data->esphdr[13].seq = 0;
  data->esptail[13].pad_len = 0;
  memset (data->esp_auth_data[13], 0, MAX_ESPICVLEN * sizeof (uint8_t));
  data->esptail[13].pad_len = 0;  // Padding length
  memset (data->esp_pad[13], 0, 255 * sizeof (uint8_t));

  // ESP trailer Next Header field
  data->esptail[13].nxt_hdr = IPPROTO_ICMPV6;

  // IPv6 header

  // IPv6 version (4 bits), Traffic class (8 bits), Flow label (20 bits)
  data->ip6hdr[13].ip6_flow = htonl ((6 << 28) | (0 << 20) | 0);

  // Payload length (16 bits): ICMP header
  data->ip6hdr[13].ip6_plen = htons (ICMP_HDRLEN);

  // Next header (8 bits): 58 for ICMP
  data->ip6hdr[13].ip6_nxt = IPPROTO_ICMPV6;

  // Hop limit (8 bits): start with 1 (next node in route)
  data->ip6hdr[13].ip6_hops = 1u;

  // Source IPv6 address (128 bits): default to loopback
  if ((status = inet_pton (AF_INET6, "::1", &(data->ip6hdr[13].ip6_src))) != 1) {
    sprintf (data->error_text, "icmp6_tr_default(): inet_pton() failed for source IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    return (EXIT_FAILURE);
  }

  // Destination IPv6 address (128 bits): default to loopback IP address to be safe
  if ((status = inet_pton (AF_INET6, "::1", &(data->ip6hdr[13].ip6_dst))) != 1) {
    sprintf (data->error_text, "icmp6_tr_default(): inet_pton() failed for destination IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    return (EXIT_FAILURE);
  }

  // ICMP header (IPv6)

  // Message Type (8 bits): 128 is echo request
  data->icmp6hdr[13].icmp6_type = ICMP6_ECHO_REQUEST;

  // Message Code (8 bits): echo request
  data->icmp6hdr[13].icmp6_code = 0;

  // Identifier (16 bits): usually pid of sending process - we'll arbitrarily use 1000
  data->icmp6hdr[13].icmp6_id = htons (1000u);

  // Sequence Number (16 bits): starts at 0
  data->icmp6hdr[13].icmp6_seq = htons (0);

  // ICMP header checksum (16 bits)
  data->icmp6hdr[13].icmp6_cksum = icmp6_checksum (data->ip6hdr[13], data->icmp6hdr[13], data->payload[13], data->payloadlen[13]);

  // Update ethernet frame.
  create_ip6_frame (13, data);

  // Apply default 6to4 settings.
  sixto4_icmp6_tr_default (data);

  return (EXIT_SUCCESS);
}

// Apply IPv6 UDP traceroute page default settings
int
udp6_tr_default (SPSData *data)
{
  int status, i;

  // Number of ethernet frames
  data->nframes[14] = 1;

  // Ethernet header

  // Set flag for user to specify ethernet header. This will never change for IPv6.
  data->specify_ether[14] = 1;

  // Destination link-layer (MAC) address (48 bits): default to zero; user needs to fill out
  memset (data->ethhdr[14].dst_mac, 0, 6 * sizeof (uint8_t));

  // Source Interface Name: defaults to blank
  memset (data->ifname[14], 0, TMP_STRINGLEN * sizeof (char));

  // Default interface MTU
  data->ifmtu[14] = 1500;

  // Source link-layer (MAC) address (48 bits): default to zero; user needs to fill out
  memset (data->ethhdr[14].src_mac, 0, 6 * sizeof (uint8_t));
  
  // Ethernet type code (16 bits): default to IPv6
  // http://www.iana.org/assignments/ethernet-numbers
  data->ethhdr[14].type_code = htons (ETH_P_IPV6);

  // Deal with UDP data first so that lengths and offsets are correct for updating IP and UDP headers.

  // UDP data

  // Clear UDP data buffer.
  memset (data->payload[14], 0, IP_MAXPACKET * sizeof (uint8_t));
  data->payloadlen[14] = 0;

  // UDP data entry format: default to hexadecimal input
  data->ascii_hex_udp6_tr = 1;

  // Hop-by-hop options

  // No hop-by-hop options
  data->hbh_hdr_flag[14] = 0;
  data->hbh_nopt[14] = 0;

  // Clear all hop-by-hop option lengths.
  memset (data->hbh_optlen[14], 0, MAX_HBHOPTIONS * sizeof (int));

  // Clear all hop-by-hop options.
  for (i=0; i<MAX_HBHOPTIONS; i++) {
    memset (data->hbh_options[14][i], 0, MAX_HBHOPTLEN * sizeof (uint8_t));
  }

  // Total length of hop-by-hop options is zero.
  data->hbh_opt_totlen[14] = 0;
  data->hophdr[14].hdr_len = 0;

  // Option alignment parameter x (of xN + y)
  memset (data->hbh_x[14], 0, MAX_HBHOPTIONS * sizeof (int));

  // Option alignment parameter y (of xN + y)
  memset (data->hbh_y[14], 0, MAX_HBHOPTIONS * sizeof (int));

  // Hop-by-hop header options padding length (includes alignment padding)
  data->hbh_optpadlen[14] = 0;  // Hop-by-hop options padding: hbh_optpadlen[type] = int

  // Destination options

  // No destination options
  data->dstf_hdr_flag[14] = 0;
  data->dstf_nopt[14] = 0;
  data->dstl_hdr_flag[14] = 0;
  data->dstl_nopt[14] = 0;
  
  // Clear all destination option lengths.
  memset (data->dstf_optlen[14], 0, MAX_DSTOPTIONS * sizeof (int));
  memset (data->dstl_optlen[14], 0, MAX_DSTOPTIONS * sizeof (int));
  
  // Clear all destination options.
  for (i=0; i<MAX_DSTOPTIONS; i++) {
    memset (data->dstf_options[14][i], 0, MAX_DSTOPTLEN * sizeof (uint8_t));
    memset (data->dstl_options[14][i], 0, MAX_DSTOPTLEN * sizeof (uint8_t));
  }

  // Total length of destination options is zero.
  data->dstf_opt_totlen[14] = 0;
  data->dstfhdr[14].hdr_len = 0;
  data->dstl_opt_totlen[14] = 0;
  data->dstlhdr[14].hdr_len = 0;

  // Option alignment parameter x (of xN + y)
  memset (data->dstf_x[14], 0, MAX_DSTOPTIONS * sizeof (int));
  memset (data->dstl_x[14], 0, MAX_DSTOPTIONS * sizeof (int));

  // Option alignment parameter y (of xN + y)
  memset (data->dstf_y[14], 0, MAX_DSTOPTIONS * sizeof (int));
  memset (data->dstl_y[14], 0, MAX_DSTOPTIONS * sizeof (int));

  // Destination header options padding length (includes alignment padding)
  data->dstf_optpadlen[14] = 0;  // Destination options padding: dstf_optpadlen[type] = int
  data->dstl_optpadlen[14] = 0;  // Destination options padding: dstl_optpadlen[type] = int

  // Routing header

  // No routing header
  data->route_hdr_flag[14] = 0;
  data->route_datlen[14] = 0;
  data->routehdr[14].hdr_len = 0;
  data->routehdr[14].routing_type = 0;
  data->routehdr[14].segs_left = 0;
  memset (data->route_data[14], 0, MAX_ROUTEDATA * sizeof (uint8_t));

  // Authentication header

  // No authentication header
  data->auth_hdr_flag[14] = 0;
  data->auth_len[14] = 0;
  data->authhdr[14].pay_len = 0;
  data->authhdr[14].reserved = 0;
  data->authhdr[14].spi = 0;
  data->authhdr[14].seq = 0;
  memset (data->auth_data[14], 0, MAX_AUTHICVLEN * sizeof (uint8_t));

  // Encapsulating security payload (ESP)

  // No ESP header and no ESP tail
  data->esp_hdr_flag[14] = 0;
  data->esp_auth_len[14] = 0;
  data->esphdr[14].spi = 0;
  data->esphdr[14].seq = 0;
  data->esptail[14].pad_len = 0;
  memset (data->esp_auth_data[14], 0, MAX_ESPICVLEN * sizeof (uint8_t));
  data->esptail[14].pad_len = 0;  // Padding length
  memset (data->esp_pad[14], 0, 255 * sizeof (uint8_t));

  // ESP trailer Next Header field
  data->esptail[14].nxt_hdr =  IPPROTO_UDP;

  // IPv6 header

  // IPv6 version (4 bits), Traffic class (8 bits), Flow label (20 bits)
  data->ip6hdr[14].ip6_flow = htonl ((6 << 28) | (0 << 20) | 0);

  // Payload length (16 bits): UDP header
  data->ip6hdr[14].ip6_plen = htons (UDP_HDRLEN);

  // Next header (8 bits): 17 for UDP
  data->ip6hdr[14].ip6_nxt = IPPROTO_UDP;

  // Hop limit (8 bits): start with 1 (next node in route)
  data->ip6hdr[14].ip6_hops = 1u;

  // Source IPv6 address (128 bits): default to loopback
  if ((status = inet_pton (AF_INET6, "::1", &(data->ip6hdr[14].ip6_src))) != 1) {
    sprintf (data->error_text, "udp6_tr_default(): inet_pton() failed for source IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    return (EXIT_FAILURE);
  }

  // Destination IPv6 address (128 bits): default to loopback IP address to be safe
  if ((status = inet_pton (AF_INET6, "::1", &(data->ip6hdr[14].ip6_dst))) != 1) {
    sprintf (data->error_text, "udp6_tr_default(): inet_pton() failed for destination IP address.\nError message: %s", strerror (status));
    data->parent = data->main_window;
    report_error (data);
    return (EXIT_FAILURE);
  }

  // UDP header (IPv6)

  // Source port number (16 bits): we'll arbitrarily use 4950
  data->ran_udp6_tr_sourceport = 0;
  data->udphdr[14].uh_sport = htons (4950u);

  // Destination port number (16 bits): 33435
  data->udphdr[14].uh_dport = htons (33435u);

  // Length of UDP datagram (16 bits): UDP header + UDP payload
  data->udphdr[14].uh_ulen = htons (UDP_HDRLEN + data->payloadlen[14]);

  // UDP header checksum (16 bits)
  data->udphdr[14].uh_sum = udp6_checksum (data->ip6hdr[14], data->udphdr[14], data->payload[14], data->payloadlen[14]);

  // Update ethernet frame.
  create_ip6_frame (14, data);

  // Apply default 6to4 settings.
  sixto4_udp6_tr_default (data);

  return (EXIT_SUCCESS);
}
